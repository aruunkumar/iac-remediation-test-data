"""
Terraform Remediation Agent - AgentCore Version with A2A Protocol Support
Mirrors the business logic from the old Strands-based implementation
Uses Strands Agent with MCP Terraform Server and Bedrock Knowledge Base
"""

from bedrock_agentcore import BedrockAgentCoreApp
import json
import logging
import os
import sys
import re
from typing import Dict, Any, List, Optional
from datetime import datetime
import tempfile
import shutil

# Bypass tool consent prompts for automated API usage
os.environ['BYPASS_TOOL_CONSENT'] = 'true'

# Add parent directory to path for shared module (only needed for local development)
if not os.getenv("DOCKER_CONTAINER"):
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from shared.s3_storage import S3Storage
from shared.interfaces import (
    RemediationResults, RemediationFix, ManualIntervention, 
    SecurityFinding, SeverityLevel, RemediationType
)

# Detect execution environment
IS_AGENTCORE = os.getenv("AWS_EXECUTION_ENV", "").startswith("AWS_") or os.getenv("USE_A2A", "false").lower() == "true"
IS_LOCAL = not IS_AGENTCORE

# Configure logging based on environment
if IS_AGENTCORE:
    # CloudWatch-friendly logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        stream=sys.stdout,
        force=True
    )
    # Suppress DEBUG logs from third-party libraries
    logging.getLogger('strands').setLevel(logging.INFO)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
else:
    # Local development logging with more detail
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
        force=True
    )

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO if IS_AGENTCORE else logging.DEBUG)

# Import Strands SDK components
try:
    from strands import Agent
    from strands_tools import file_read, file_write, http_request
    from strands.tools.mcp import MCPClient
    from mcp.client.stdio import stdio_client
    from mcp import StdioServerParameters
    STRANDS_AVAILABLE = True
    logger.info("Strands SDK loaded successfully")
except ImportError as e:
    logger.error(f"Strands SDK not available ({e}), agent will not function properly")
    STRANDS_AVAILABLE = False
    # Define dummy classes so code doesn't break
    Agent = None
    MCPClient = None
    file_read = None
    file_write = None
    http_request = None

# Log environment detection
logger.info(f"Environment: {'AgentCore' if IS_AGENTCORE else 'Local'}")
logger.info(f"Python version: {sys.version}")
logger.info(f"Strands SDK available: {STRANDS_AVAILABLE}")


app = BedrockAgentCoreApp(debug=not IS_AGENTCORE)

# S3 storage for sharing data with other agents
s3_storage = S3Storage()

# Terraform Best Practices Knowledge Base ID
TERRAFORM_KB_ID = os.getenv("KB_TERRAFORM_ID", "LZ2DEM1204")


def get_terraform_mcp_client():
    """Get MCP client for Terraform server - reusing existing pattern"""
    if not STRANDS_AVAILABLE:
        return None
    
    return MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["awslabs.terraform-mcp-server@latest"],
                env={"FASTMCP_LOG_LEVEL": "ERROR"},
                disabled=False,
                auto_approve=[],
                debug=True,
            )
        )
    )


def get_terraform_remediation_system_prompt() -> str:
    """System prompt for the Terraform Remediation Agent"""
    return """
    You are the Terraform Remediation Agent specialized in fixing security issues in Terraform code.
    
    ## Your Environment:
    - **Source Files**: Terraform (.tf) files are in a working directory on the filesystem
    - **Available Tools**: 
      - `file_read`: Read Terraform files
      - `file_write`: Write modified Terraform files with fixes
      - `bedrock_knowledge_base_query`: Query AWS/Terraform best practices
      - `SearchAwsProviderDocs`: Look up AWS provider resource documentation
    
    ## Decision Framework:
    
    **SAFE TO AUTO-FIX** - Issues that can be fixed without user intervention, such as:
    - Missing encryption, logging, or monitoring settings
    - Insecure defaults that have secure alternatives
    - Missing backup or versioning configurations
    - Simple compliance violations with clear remediation steps
    
    **REQUIRES MANUAL INTERVENTION** - Issues that need user decisions or could break functionality, such as:
    - Changes affecting network architecture or resource dependencies
    - Business logic decisions (which key to use, retention periods, etc.)
    - Multi-resource coordination requiring changes across files
    - Organization-specific security requirements
    
    ## CRITICAL Rules:
    - Add AGENT-FIXED comment ONLY when you make a code change that fixes the issue. 
    - DO NOT add AGENT-FIXED comment if you only add an explanation or if fix is in a different resource. If you cannot fix an issue, add a TODO comment instead!
    - **100% Coverage**: EVERY finding MUST have either an AGENT-FIXED or TODO comment
    - **Safety First**: If unsure whether a fix is safe, add a TODO comment instead
    - **Single File Operation**: Read once, apply all fixes together, write once
    - **Preserve Functionality**: Never break existing working code
    - **Use Variables**: When adding configuration, use variables with sensible defaults
    """


def bedrock_knowledge_base_query(kb_id: str, query: str) -> str:
    """Query Bedrock Knowledge Base for Terraform best practices"""
    try:
        import boto3
        bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
        
        response = bedrock_agent_runtime.retrieve(
            knowledgeBaseId=kb_id,
            retrievalQuery={'text': query}
        )
        
        # Extract and combine results
        results = []
        for result in response.get('retrievalResults', []):
            content = result.get('content', {}).get('text', '')
            if content:
                results.append(content)
        
        return '\n\n'.join(results) if results else "No relevant information found"
    
    except Exception as e:
        logger.error(f"Error querying knowledge base: {e}")
        return f"Error querying knowledge base: {str(e)}"


@app.entrypoint
def invoke(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main entry point for terraform remediation agent
    
    Supported actions:
    - remediate: Remediate issues (POST /remediate/scan-id/detailed)
    - remediate_detailed: Detailed remediation (POST /remediate/detailed)
    - validate: Validate scan results (POST /validate)
    - health: Health check (GET /health)
    - get_info: Agent info (GET /info)
    """
    action = payload.get("action", "remediate")
    execution_start = datetime.utcnow()
    
    logger.info(f"{'='*80}")
    logger.info(f"[REMEDIATION] EXECUTION START")
    logger.info(f"[REMEDIATION] Action: {action}")
    logger.info(f"[REMEDIATION] Timestamp: {execution_start.isoformat()}")
    logger.info(f"{'='*80}")
    
    try:
        if action == "remediate":
            result = remediate_issues(payload)
        elif action == "remediate_detailed":
            result = remediate_issues(payload)  # Same logic
        elif action == "validate":
            result = validate_scan_results(payload)
        elif action == "health":
            result = health_check(payload)
        elif action == "get_info":
            result = get_agent_info(payload)
        else:
            result = {"error": f"Unknown action: {action}"}
        
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.info(f"{'='*80}")
        logger.info(f"[REMEDIATION] EXECUTION END")
        logger.info(f"[REMEDIATION] Action: {action}")
        logger.info(f"[REMEDIATION] Status: {'success' if 'error' not in result else 'error'}")
        logger.info(f"[REMEDIATION] Execution time: {execution_time:.2f}s")
        logger.info(f"[REMEDIATION] Timestamp: {execution_end.isoformat()}")
        logger.info(f"{'='*80}")
        
        return result
        
    except Exception as e:
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.error(f"{'='*80}")
        logger.error(f"[REMEDIATION] EXECUTION FAILED")
        logger.error(f"[REMEDIATION] Action: {action}")
        logger.error(f"[REMEDIATION] Error: {str(e)}")
        logger.error(f"[REMEDIATION] Execution time: {execution_time:.2f}s")
        logger.error(f"[REMEDIATION] Timestamp: {execution_end.isoformat()}")
        logger.error(f"{'='*80}")
        
        raise


def remediate_issues(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Remediate security issues using Strands Agent with MCP and Bedrock KB"""
    scan_id = payload.get("scan_id")
    scan_results = payload.get("scan_results", {})
    config = payload.get("remediation_config", {})
    workflow_id = payload.get("workflow_id")
    iteration = payload.get("iteration", 1)  # Get iteration number
    
    auto_fix_enabled = config.get("auto_fix_enabled", True)
    manual_guidance_enabled = config.get("manual_guidance_enabled", True)
    
    findings = scan_results.get("findings", [])
    source_path = scan_results.get("scan_metadata", {}).get("source")
    
    logger.info(f"Starting remediation for scan {scan_id}, iteration {iteration}: {len(findings)} findings")
    
    # Download repository from S3 if workflow_id provided
    temp_dir = None
    working_dir = None
    if workflow_id:
        # On iteration 1, download original code from github-agent
        # On iteration 2+, download previously fixed code from terraform-remediation-agent
        if iteration == 1:
            agent_folder = 'github-agent'
            logger.info(f"Iteration {iteration}: Downloading original repository from S3 (github-agent)")
        else:
            agent_folder = 'terraform-remediation-agent'
            logger.info(f"Iteration {iteration}: Downloading previously remediated code from S3 (terraform-remediation-agent)")
        
        logger.info(f"Downloading repository from S3 for workflow {workflow_id}")
        temp_dir = f"/tmp/remediation_{scan_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        try:
            working_dir = s3_storage.download_directory(workflow_id, agent_folder, temp_dir)
            
            if not working_dir or not os.path.exists(working_dir):
                error_msg = f"No source code found in S3 for workflow {workflow_id}. Expected path: workflows/{workflow_id}/{agent_folder}/"
                logger.error(error_msg)
                return {
                    "error": error_msg,
                    "scan_id": scan_id,
                    "status": "failed",
                    "fixes": [],
                    "manual_interventions": [],
                    "validation_errors": [error_msg],
                    "summary": {
                        "total_fixes_applied": 0,
                        "total_manual_items": 0,
                        "total_errors": 1
                    },
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            logger.info(f"Repository downloaded from github-agent to {working_dir}")
        except Exception as e:
            error_msg = f"Failed to download from S3: {str(e)}"
            logger.error(error_msg)
            return {
                "error": error_msg,
                "scan_id": scan_id,
                "status": "failed",
                "fixes": [],
                "manual_interventions": [],
                "validation_errors": [error_msg],
                "summary": {
                    "total_fixes_applied": 0,
                    "total_manual_items": 0,
                    "total_errors": 1
                },
                "timestamp": datetime.utcnow().isoformat()
            }
    
    # Initialize Strands Agent with MCP tools if available
    if not STRANDS_AVAILABLE:
        error_msg = "Cannot remediate: Strands SDK not available"
        logger.error(error_msg)
        return {
            "error": error_msg,
            "scan_id": scan_id,
            "status": "failed",
            "fixes": [],
            "manual_interventions": [],
            "validation_errors": [error_msg],
            "summary": {
                "total_fixes_applied": 0,
                "total_manual_items": 0,
                "total_errors": 1
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    if not working_dir:
        error_msg = "Cannot remediate: No working directory provided"
        logger.error(error_msg)
        return {
            "error": error_msg,
            "scan_id": scan_id,
            "status": "failed",
            "fixes": [],
            "manual_interventions": [],
            "validation_errors": [error_msg],
            "summary": {
                "total_fixes_applied": 0,
                "total_manual_items": 0,
                "total_errors": 1
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    try:
        remediation_results = remediate_with_strands_agent(
            findings, working_dir, scan_id, scan_results
        )
    except Exception as e:
        error_msg = f"Strands agent remediation failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return {
            "error": error_msg,
            "scan_id": scan_id,
            "status": "failed",
            "fixes": [],
            "manual_interventions": [],
            "validation_errors": [error_msg],
            "summary": {
                "total_fixes_applied": 0,
                "total_manual_items": 0,
                "total_errors": 1
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    logger.info(f"Remediation complete: {len(remediation_results.fixes)} fixes, {len(remediation_results.manual_interventions)} manual items")
    
    # Upload fixed repository back to S3 if workflow_id provided
    if workflow_id and working_dir:
        try:
            # Upload remediation report separately for audit trail
            report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
            if os.path.exists(report_path):
                with open(report_path, 'r') as f:
                    report_content = f.read()
                
                # Upload report to S3 with iteration number
                report_filename = f'REMEDIATION_REPORT_iteration_{iteration}.md'
                s3_storage.upload_json(
                    {"content": report_content, "iteration": iteration, "timestamp": datetime.utcnow().isoformat()},
                    workflow_id,
                    'terraform-remediation-agent',
                    report_filename.replace('.md', '.json')
                )
                logger.info(f"Remediation report uploaded to S3: {report_filename}")
                
                # Delete report from working directory so it's not included in code commit
                os.remove(report_path)
                logger.info("Removed REMEDIATION_REPORT.md from working directory (available in S3 for audit)")
            
            logger.info("Uploading fixed repository to S3...")
            s3_uri = s3_storage.upload_directory(working_dir, workflow_id, 'terraform-remediation-agent')
            logger.info(f"Fixed repository uploaded to S3: {s3_uri}")
        except Exception as e:
            logger.error(f"Failed to upload fixed repository to S3: {e}")
    
    # Clean up temp directory
    if temp_dir and os.path.exists(temp_dir):
        shutil.rmtree(temp_dir, ignore_errors=True)
        logger.info(f"Cleaned up temp directory: {temp_dir}")
    
    result = {
        "scan_id": scan_id,
        "status": "completed",
        "fixes": [
            {
                "check_id": fix.check_id,
                "file_path": fix.file,
                "resource": fix.resource,
                "fix_type": "auto",
                "status": "applied",
                "description": fix.fix_applied
            }
            for fix in remediation_results.fixes
        ],
        "manual_interventions": [
            {
                "check_id": mi.check_id,
                "file_path": mi.file,
                "resource": mi.resource,
                "severity": "MEDIUM",
                "description": mi.todo_comment,
                "guideline": "",
                "todo_comment": mi.todo_comment
            }
            for mi in remediation_results.manual_interventions
        ],
        "validation_errors": remediation_results.validation_errors,
        "summary": {
            "total_fixes_applied": len(remediation_results.fixes),
            "total_manual_items": len(remediation_results.manual_interventions),
            "total_errors": len(remediation_results.validation_errors)
        },
        "timestamp": datetime.utcnow().isoformat(),
        "iteration": iteration  # Include iteration number in results
    }
    
    # Upload remediation results to S3 with iteration number for audit trail
    if workflow_id:
        try:
            # Save with iteration number for audit trail
            filename = f'remediation_results_iteration_{iteration}.json'
            s3_storage.upload_json(result, workflow_id, 'terraform-remediation-agent', filename)
            logger.info(f"Remediation results for iteration {iteration} uploaded to S3: {filename}")
            
            # Also save as latest for backward compatibility
            s3_storage.upload_json(result, workflow_id, 'terraform-remediation-agent', 'remediation_results.json')
            logger.info(f"Remediation results uploaded to S3 as latest")
        except Exception as e:
            logger.error(f"Failed to upload remediation results to S3: {e}")
    
    return result


def remediate_with_strands_agent(findings: List[Dict], working_dir: str, scan_id: str, scan_results: Dict) -> RemediationResults:
    """Remediate using Strands Agent with MCP Terraform Server and Bedrock KB - mirrors old implementation"""
    import time
    
    if not STRANDS_AVAILABLE:
        raise Exception("Strands SDK not available - cannot use Strands agent remediation")
    
    total_start = time.time()
    logger.info(f"Starting Strands agent remediation for {len(findings)} findings")
    
    # Initialize MCP client
    tf_mcp_client = get_terraform_mcp_client()
    if not tf_mcp_client:
        raise Exception("Failed to initialize MCP client")
    
    # Initialize Strands agent with MCP tools
    with tf_mcp_client:
        mcp_tools = tf_mcp_client.list_tools_sync()
        logger.info(f"Available MCP tools: {[tool.tool_name for tool in mcp_tools]}")
        
        all_tools = mcp_tools + [file_read, file_write, http_request, bedrock_knowledge_base_query]
        
        agent = Agent(
            system_prompt=get_terraform_remediation_system_prompt(),
            tools=all_tools,
            model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        )
        
        logger.info("Strands Agent initialized with MCP and Bedrock capabilities")
        
        # Convert findings to SecurityFinding objects
        security_findings = []
        for finding_data in findings:
            try:
                finding = convert_dict_to_security_finding(finding_data)
                security_findings.append(finding)
            except Exception as e:
                logger.error(f"Error converting finding: {e}")
        
        # Create batches by file (max 5 findings per batch)
        batches = create_finding_batches(security_findings, max_batch_size=5)
        logger.info(f"Created {len(batches)} batches from {len(security_findings)} findings")
        
        # Initialize results
        remediation_results = RemediationResults(
            scan_id=scan_id,
            fixes=[],
            manual_interventions=[],
            validation_errors=[],
            knowledge_base_queries=[]
        )
        
        # Initialize report
        report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
        initialize_report(report_path, scan_results, len(batches))
        
        # Process each batch
        for batch_idx, batch in enumerate(batches, 1):
            batch_start = time.time()
            
            logger.info(f"[{batch_idx}/{len(batches)}] Processing batch: {batch['file']} - {batch['batch_size']} finding(s)")
            
            try:
                # Process batch together
                batch_result = remediate_batch(
                    agent, batch['findings'], working_dir, TERRAFORM_KB_ID
                )
                
                # Add results
                remediation_results.fixes.extend(batch_result.get('fixes', []))
                remediation_results.manual_interventions.extend(batch_result.get('manual_interventions', []))
                remediation_results.validation_errors.extend(batch_result.get('errors', []))
                
                batch_time = time.time() - batch_start
                logger.info(f"[{batch_idx}/{len(batches)}] Completed batch in {batch_time:.2f}s")
                
                # Update report after each batch
                try:
                    update_report(report_path, batch_idx, len(batches), batch_time, remediation_results)
                except Exception as report_error:
                    logger.warning(f"Failed to update report: {report_error}")
                
            except Exception as e:
                batch_time = time.time() - batch_start
                logger.error(f"[{batch_idx}/{len(batches)}] Error processing batch in {batch_time:.2f}s: {e}")
                remediation_results.validation_errors.append(str(e))
                update_report(report_path, batch_idx, len(batches), batch_time, remediation_results, error=str(e))
        
        remediation_time = time.time() - total_start
        logger.info(f"Total remediation time: {remediation_time:.2f}s for {len(security_findings)} findings")
        
        # Extract summaries from file comments
        extract_summaries_from_files(remediation_results, working_dir)
        
        # Finalize report
        finalize_report(report_path, remediation_time, remediation_results)
        
        return remediation_results


def validate_scan_results(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validate scan results format"""
    scan_results = payload.get("scan_results", {})
    
    required_fields = ["scan_id", "findings"]
    missing_fields = [f for f in required_fields if f not in scan_results]
    
    if missing_fields:
        return {
            "valid": False,
            "errors": [f"Missing required field: {f}" for f in missing_fields]
        }
    
    findings = scan_results.get("findings", [])
    if not isinstance(findings, list):
        return {
            "valid": False,
            "errors": ["findings must be a list"]
        }
    
    return {
        "valid": True,
        "scan_id": scan_results.get("scan_id"),
        "total_findings": len(findings),
        "message": "Scan results are valid"
    }


def health_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Health check"""
    return {
        "status": "healthy",
        "agent": "terraform_remediation",
        "version": "1.0.0-agentcore",
        "capabilities": [
            "auto_fix",
            "manual_guidance",
            "bedrock_kb_integration"
        ],
        "timestamp": datetime.utcnow().isoformat()
    }


def get_agent_info(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get agent information"""
    return {
        "agent_name": "terraform_remediation",
        "version": "1.0.0-agentcore",
        "capabilities": {
            "auto_fix": True,
            "manual_guidance": True,
            "bedrock_kb": os.getenv("KB_TERRAFORM_ID") is not None,
            "well_architected_kb": os.getenv("KB_WELL_ARCH_ID") is not None
        },
        "supported_checks": [
            "CKV_AWS_18",
            "CKV_AWS_19",
            "CKV_AWS_21",
            "CKV_AWS_141",
            "CKV_AWS_142",
            "CKV_AWS_143",
            "CKV_AWS_144",
            "CKV_AWS_145"
        ],
        "communication_mode": "A2A" if os.getenv("USE_A2A", "false").lower() == "true" else "HTTP"
    }


# Helper functions for batch processing and report generation

def create_finding_batches(findings: List[SecurityFinding], max_batch_size: int = 5) -> List[Dict[str, Any]]:
    """Group findings by file for batch processing"""
    batches = []
    
    # Group by file
    by_file = {}
    for finding in findings:
        file = finding.file
        if file not in by_file:
            by_file[file] = []
        by_file[file].append(finding)
    
    # Create batches of max_batch_size for each file
    for file, file_findings in by_file.items():
        for i in range(0, len(file_findings), max_batch_size):
            batch_findings = file_findings[i:i + max_batch_size]
            batches.append({
                'file': file,
                'findings': batch_findings,
                'batch_size': len(batch_findings)
            })
    
    return batches


def remediate_batch(agent, findings: List[SecurityFinding], working_dir: str, kb_id: str) -> Dict[str, Any]:
    """Process a batch of findings together using Strands agent"""
    if not findings:
        return {'fixes': [], 'manual_interventions': [], 'errors': []}
    
    file_path = findings[0].file
    # Strip leading slash to avoid double slash when combining with working_dir
    file_path_clean = file_path.lstrip('/')
    
    # If working_dir ends with repo name and file path starts with it, strip the repo name from file path
    if working_dir:
        repo_name = os.path.basename(working_dir)
        if file_path_clean.startswith(repo_name + '/'):
            file_path_clean = file_path_clean[len(repo_name) + 1:]
    
    file_location = f"{working_dir}/{file_path_clean}" if working_dir else file_path
    
    # Build batch prompt
    findings_summary = "\n\n".join([
        f"**Finding {idx+1}:**\n"
        f"- Check ID: {f.check_id}\n"
        f"- Resource: {f.resource} ({f.resource_type})\n"
        f"- Issue: {f.description}"
        for idx, f in enumerate(findings)
    ])
    
    batch_prompt = f"""
Remediate {len(findings)} security findings in this Terraform file:

**File Path**: {file_location}

## Findings:

{findings_summary}

## Instructions:

1. Read the file using `file_read` with path: `{file_location}`
2. **CRITICAL - Check for existing comments**: For each finding, search the file for existing comments:
   - If you find `# AGENT-FIXED: <check_id>` near the resource, **SKIP THIS FINDING COMPLETELY** - it's already fixed
   - If you find `# TODO: <check_id>` near the resource, **SKIP THIS FINDING COMPLETELY** - it's already documented
   - Only skip if the comment is for the SAME check_id AND SAME resource
   - **NEVER add both AGENT-FIXED and TODO for the same check_id on the same resource**
   - A comment on one resource doesn't mean other resources in the file should be skipped
3. For remaining findings (those WITHOUT any existing comment), decide if it can be auto-fixed or if it requires manual intervention
4. Use the provided resources below when you are unsure of the best practice or need to find the right syntax
5. Modify the file with fixes and comments (AGENT-FIXED or TODO) as per below comment format
6. Write the complete modified file using `file_write` with path: `{file_location}`

## Comment Format Requirements:

**CRITICAL: Only add AGENT-FIXED if you ACTUALLY modify the code!**

**For Auto-Fixes (when you MODIFY the code to fix the issue):**
```hcl
# AGENT-FIXED: <check_id> - Brief description of what was fixed
<actual code changes here>
```

**For Manual Interventions (when you CANNOT fix the issue):**
```hcl
# TODO: <check_id> - Brief description of the issue
# Resource: <resource_name>
# Reason: Why this requires manual intervention
# Fix: Specific steps to remediate:
#   1. First step
#   2. Second step
```

**Examples of WRONG usage:**
❌ Adding AGENT-FIXED without modifying code
❌ Adding AGENT-FIXED with only an explanation comment
❌ Adding AGENT-FIXED when the fix is in a different resource

**Examples of CORRECT usage:**
✅ Add AGENT-FIXED + modify the resource block to add missing configuration
✅ Add TODO when you cannot safely fix the issue

## Resources Available:
- Knowledge Base (KB ID: '{kb_id}'): Use `bedrock_knowledge_base_query` for best practices
- AWS Provider Docs: Use `SearchAwsProviderDocs` for resource syntax

**Important**: Add a comment for each finding that you have remediated or attempted to remediate and if it doesn't already have one for that specific resource.
"""
    
    try:
        import time
        agent_start = time.time()
        result = agent(batch_prompt)
        agent_time = time.time() - agent_start
        logger.info(f"    Agent inference time: {agent_time:.2f}s for {len(findings)} findings")
        
        result_text = str(result)
        
        # Scan files for AGENT-FIXED and TODO comments
        fixes = []
        manual_interventions = []
        duplicate_comments = []  # Track issues with both AGENT-FIXED and TODO
        
        for finding in findings:
            check_id = finding.check_id
            # Strip leading slash to match extracted file structure
            relative_file = finding.file.lstrip('/')
            
            # If working_dir ends with the repo name and file path starts with it, strip the repo name
            if working_dir:
                repo_name = os.path.basename(working_dir)
                if relative_file.startswith(repo_name + '/'):
                    relative_file = relative_file[len(repo_name) + 1:]
            
            file_path = os.path.join(working_dir, relative_file)
            logger.info(f"Checking for comments in: {file_path}")
            
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        file_content = f.read()
                        
                        has_agent_fixed = f"AGENT-FIXED: {check_id}" in file_content or f"AGENT-FIXED:{check_id}" in file_content
                        has_todo = f"TODO:" in file_content and check_id in file_content
                        
                        # Check for duplicate comments (both AGENT-FIXED and TODO)
                        if has_agent_fixed and has_todo:
                            logger.warning(f"DUPLICATE COMMENT DETECTED: {check_id} in {finding.file} has BOTH AGENT-FIXED and TODO comments!")
                            duplicate_comments.append({
                                'check_id': check_id,
                                'file': finding.file,
                                'resource': finding.resource
                            })
                        
                        # Check for AGENT-FIXED comment
                        if has_agent_fixed:
                            match = re.search(rf'#\s*AGENT-FIXED:\s*{re.escape(check_id)}\s*-\s*(.+?)(?:\n|$)', file_content, re.IGNORECASE)
                            description = match.group(1).strip() if match else f"Applied fix for {check_id}"
                            
                            fix = RemediationFix(
                                violation_id=finding.id,
                                check_id=check_id,
                                file=finding.file,
                                resource=finding.resource,
                                fix_applied=description
                            )
                            fixes.append(fix)
                            logger.info(f"Found AGENT-FIXED for {check_id}")
                        
                        # Check for TODO comment (only if no AGENT-FIXED to avoid duplicates)
                        elif has_todo:
                            todo_pattern = rf'#\s*TODO:\s*([A-Z0-9_,\s]+?)\s*-\s*(.+?)(?:\n|$)'
                            for todo_match in re.finditer(todo_pattern, file_content, re.IGNORECASE):
                                check_ids_str = todo_match.group(1)
                                description = todo_match.group(2).strip()
                                check_ids_in_todo = [cid.strip() for cid in check_ids_str.split(',')]
                                
                                if check_id in check_ids_in_todo:
                                    mi = ManualIntervention(
                                        violation_id=finding.id,
                                        check_id=check_id,
                                        file=finding.file,
                                        resource=finding.resource,
                                        todo_comment=description,
                                        detailed_guidance={}
                                    )
                                    manual_interventions.append(mi)
                                    logger.info(f"Found TODO for {check_id}")
                                    break
                
                except Exception as e:
                    logger.warning(f"Could not read file {file_path}: {e}")
            else:
                logger.warning(f"File does not exist: {file_path}")
        
        # Log summary of duplicate comments
        if duplicate_comments:
            logger.error(f"Found {len(duplicate_comments)} issues with duplicate comments (both AGENT-FIXED and TODO):")
            for dup in duplicate_comments:
                logger.error(f"  - {dup['check_id']} in {dup['file']} ({dup['resource']})")
        
        return {
            'fixes': fixes,
            'manual_interventions': manual_interventions,
            'errors': []
        }
        
    except Exception as e:
        logger.error(f"Error in batch remediation: {e}")
        return {'fixes': [], 'manual_interventions': [], 'errors': [str(e)]}


def convert_dict_to_security_finding(finding_data: Dict[str, Any]) -> SecurityFinding:
    """Convert dictionary finding data to SecurityFinding object"""
    severity_str = finding_data.get('severity', 'MEDIUM').upper()
    try:
        severity = SeverityLevel(severity_str)
    except ValueError:
        severity = SeverityLevel.MEDIUM
    
    remediation_type_str = finding_data.get('remediation_type', 'manual').lower()
    try:
        remediation_type = RemediationType(remediation_type_str)
    except ValueError:
        remediation_type = RemediationType.MANUAL
    
    check_id = finding_data.get('check_id') or finding_data.get('id', '')
    file_path = finding_data.get('file') or finding_data.get('file_path', '')
    
    return SecurityFinding(
        id=finding_data.get('id', check_id),
        check_id=check_id,
        severity=severity,
        resource=finding_data.get('resource', ''),
        resource_type=finding_data.get('resource_type', ''),
        file=file_path,
        line_number=finding_data.get('line_number') or finding_data.get('line'),
        description=finding_data.get('description', ''),
        remediation_type=remediation_type,
        remediation_guidance=finding_data.get('remediation_guidance')
    )


def initialize_report(report_path: str, scan_results: Dict[str, Any], total_batches: int) -> None:
    """Initialize the remediation report"""
    report_content = f"""# Remediation Report

**Scan ID:** {scan_results.get('scan_id', 'N/A')}  
**Started:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Findings:** {scan_results.get('total_findings', 0)}  
**Batches:** {total_batches}

---

## Progress

Processing batches...

"""
    
    with open(report_path, 'w') as f:
        f.write(report_content)


def update_report(report_path: str, batch_idx: int, total_batches: int, 
                  batch_time: float, results: RemediationResults, error: str = None) -> None:
    """Update the report after each batch"""
    with open(report_path, 'r') as f:
        content = f.read()
    
    progress_line = f"- Batch {batch_idx}/{total_batches}: Completed in {batch_time:.2f}s"
    if error:
        progress_line += f" ⚠️ Error: {error}"
    progress_line += "\n"
    
    if "Processing batches..." in content:
        parts = content.rsplit("Processing batches...\n", 1)
        if len(parts) == 2:
            content = parts[0] + "Processing batches...\n" + progress_line + parts[1]
    
    with open(report_path, 'w') as f:
        f.write(content)


def finalize_report(report_path: str, total_time: float, results: RemediationResults) -> None:
    """Finalize the report with summary and results"""
    with open(report_path, 'r') as f:
        content = f.read()
    
    # Remove "Processing batches..." marker
    if "Processing batches..." in content:
        content = content.replace("Processing batches...\n", "")
    
    # Build summary
    summary = f"""
---

## Summary

**Completed:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Total Time:** {total_time:.2f}s  
**Auto-Fixes Applied:** {len(results.fixes)}  
**Manual Interventions:** {len(results.manual_interventions)}  
**Errors:** {len(results.validation_errors)}

---

## Auto-Fixed Issues

"""
    
    if results.fixes:
        summary += "| Check ID | Resource | File | What Changed |\n"
        summary += "|----------|----------|------|--------------|\n"
        for fix in results.fixes:
            description = fix.fix_applied[:100] + "..." if len(fix.fix_applied) > 100 else fix.fix_applied
            description = description.replace('\n', ' ').replace('|', '\\|')
            summary += f"| {fix.check_id} | {fix.resource} | {fix.file} | {description} |\n"
    else:
        summary += "No auto-fixes were applied.\n"
    
    summary += "\n---\n\n## Manual Intervention Required\n\n"
    
    if results.manual_interventions:
        summary += "| Check ID | Resource | File | Action Needed |\n"
        summary += "|----------|----------|------|---------------|\n"
        for mi in results.manual_interventions:
            description = mi.todo_comment[:100] + "..." if len(mi.todo_comment) > 100 else mi.todo_comment
            description = description.replace('\n', ' ').replace('|', '\\|')
            summary += f"| {mi.check_id} | {mi.resource} | {mi.file} | {description} |\n"
    else:
        summary += "No manual interventions required.\n"
    
    if results.validation_errors:
        summary += "\n---\n\n## Errors Encountered\n\n"
        for i, error in enumerate(results.validation_errors, 1):
            summary += f"{i}. {error}\n"
    
    content += summary
    
    with open(report_path, 'w') as f:
        f.write(content)


def extract_summaries_from_files(results: RemediationResults, working_dir: str) -> None:
    """Extract summaries from AGENT-FIXED and TODO comments in actual files"""
    agent_fixed_pattern = re.compile(r'#\s*AGENT-FIXED:\s*(\S+)\s*-\s*(.+?)(?:\n|$)', re.IGNORECASE)
    todo_pattern = re.compile(r'#\s*TODO:\s*([A-Z0-9_,\s]+?)\s*-\s*(.+?)(?:\n|$)', re.IGNORECASE)
    
    fixes_by_check_id = {fix.check_id: fix for fix in results.fixes}
    manual_by_check_id = {mi.check_id: mi for mi in results.manual_interventions}
    
    for root, dirs, files in os.walk(working_dir):
        for file in files:
            if file.endswith('.tf'):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r') as f:
                        content = f.read()
                        
                        # Find AGENT-FIXED comments
                        for match in agent_fixed_pattern.finditer(content):
                            check_id = match.group(1)
                            description = match.group(2).strip()
                            if check_id in fixes_by_check_id:
                                fixes_by_check_id[check_id].fix_applied = description
                        
                        # Find TODO comments
                        for match in todo_pattern.finditer(content):
                            check_ids_str = match.group(1)
                            description = match.group(2).strip()
                            check_ids = [cid.strip() for cid in check_ids_str.split(',')]
                            for check_id in check_ids:
                                if check_id in manual_by_check_id:
                                    manual_by_check_id[check_id].todo_comment = description
                
                except Exception as e:
                    logger.warning(f"Could not read file {file_path}: {e}")


if __name__ == "__main__":
    # For local testing
    app.run()
