#!/usr/bin/env python3
"""
Test suite for Terraform Remediation Agent on AWS Bedrock AgentCore
"""
import boto3
import json
import time
import os

def test_remediation_agent():
    """Test the Terraform Remediation Agent"""
    
    client = boto3.client('bedrock-agentcore', region_name='us-east-1')
    
    # Agent runtime ARN
    agent_runtime_arn = os.getenv(
        "REMEDIATION_ARN",
        "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/terraform_remediation-L6ILG8FnSE"
    )
    
    print("=" * 70)
    print("🔧 Terraform Remediation Agent - Test Suite")
    print("=" * 70)
    print(f"Agent ARN: {agent_runtime_arn}")
    print()
    
    results = []
    
    # Test 1: Health Check
    print("📋 Test 1: Health Check")
    print("-" * 70)
    try:
        payload = {"action": "health"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        print(f"✅ Status: {result.get('status')}")
        print(f"✅ Agent: {result.get('agent')} v{result.get('version')}")
        print(f"✅ Capabilities:")
        for cap in result.get('capabilities', []):
            print(f"   • {cap}")
        
        results.append(("Health Check", result.get('status') == 'healthy'))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Health Check", False))
    print()
    time.sleep(1)
    
    # Test 2: Agent Info
    print("📋 Test 2: Agent Info")
    print("-" * 70)
    try:
        payload = {"action": "get_info"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        print(f"✅ Agent: {result.get('agent_name')} v{result.get('version')}")
        print(f"✅ Communication Mode: {result.get('communication_mode')}")
        print(f"✅ Supported Checks: {len(result.get('supported_checks', []))}")
        
        capabilities = result.get('capabilities', {})
        print(f"✅ Auto-fix: {capabilities.get('auto_fix', False)}")
        print(f"✅ Manual guidance: {capabilities.get('manual_guidance', False)}")
        
        results.append(("Agent Info", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Agent Info", False))
    print()
    time.sleep(1)
    
    # Test 3: Validate Scan Results
    print("📋 Test 3: Validate Scan Results")
    print("-" * 70)
    try:
        # Valid scan results
        payload = {
            "action": "validate",
            "scan_results": {
                "scan_id": "test-123",
                "findings": [
                    {"check_id": "CKV_AWS_18", "file_path": "test.tf"}
                ]
            }
        }
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if result.get('valid'):
            print(f"✅ Validation works: {result.get('message')}")
            results.append(("Validate Scan", True))
        else:
            print(f"❌ Validation failed: {result.get('errors')}")
            results.append(("Validate Scan", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Validate Scan", False))
    print()
    time.sleep(1)
    
    # Test 4: Remediation (workflow integration test)
    print("📋 Test 4: Remediation (Workflow Integration)")
    print("-" * 70)
    try:
        # Use real workflow ID - agent will download scan results from S3
        workflow_id = "297ebbb7-5ed1-4ff4-b1b4-1c05d41e5617"
        
        # Download scan results to show what we're testing
        s3_client = boto3.client('s3')
        bucket = 'terraform-security-platform-storage'
        key = f'workflows/{workflow_id}/checkov-agent/scan_results.json'
        
        print(f"Checking scan results in S3...")
        response = s3_client.get_object(Bucket=bucket, Key=key)
        scan_results = json.loads(response['Body'].read())
        print(f"✅ Found {len(scan_results.get('findings', []))} findings to remediate")
        
        # Run remediation - agent will download from S3 using workflow_id
        payload = {
            "action": "remediate",
            "workflow_id": workflow_id,
            "scan_id": scan_results.get('scan_id', 'test-scan'),
            "scan_results": scan_results  # Still pass for validation
        }
        
        print(f"Running remediation...")
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if result.get('status') in ['success', 'completed']:
            print(f"✅ Remediation completed")
            summary = result.get('summary', {})
            print(f"✅ Auto-fixed: {summary.get('total_fixes_applied', 0)}")
            print(f"✅ Manual guidance: {summary.get('total_manual_items', 0)}")
            results.append(("Remediation", True))
        else:
            print(f"❌ Remediation failed: {result.get('error', 'Unknown error')}")
            print(f"   Full response: {json.dumps(result, indent=2)}")
            results.append(("Remediation", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Remediation", False))
    print()
    
    # Test 5: Error Handling
    print("📋 Test 5: Error Handling")
    print("-" * 70)
    try:
        payload = {"action": "invalid_action"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if 'error' in result:
            print(f"✅ Error handling works: {result.get('error')}")
            results.append(("Error Handling", True))
        else:
            print(f"❌ Expected error but got: {result}")
            results.append(("Error Handling", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Error Handling", False))
    print()
    
    # Summary
    print("=" * 70)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success is True)
    failed = sum(1 for _, success in results if success is False)
    skipped = sum(1 for _, success in results if success is None)
    total = len(results)
    
    for test_name, success in results:
        if success is True:
            status = "✅ PASS"
        elif success is False:
            status = "❌ FAIL"
        else:
            status = "⏭️  SKIP"
        print(f"{status} - {test_name}")
    
    print()
    print(f"🎯 Overall: {passed} passed, {failed} failed, {skipped} skipped (out of {total} tests)")
    
    if failed == 0 and passed > 0:
        print("🎉 All executed tests passed! Remediation agent is functional.")
    elif passed > 0:
        print("⚠️  Some tests passed. Check details above.")
    else:
        print("❌ Tests failed. Check agent configuration.")
    
    print()
    return results

if __name__ == "__main__":
    test_remediation_agent()
