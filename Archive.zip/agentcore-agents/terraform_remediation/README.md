# Terraform Remediation Agent

AWS Bedrock AgentCore agent that automatically fixes security issues identified by Checkov scanner and provides manual guidance for complex issues.

## Overview

The Terraform Remediation Agent is part of the distributed AgentCore architecture for automated Terraform security remediation. It:

- Receives scan results in payload from orchestrator
- Downloads Terraform code from S3 using workflow_id
- Applies automated fixes for common security issues
- Generates TODO comments for manual interventions
- Uploads fixed code back to S3 for next iteration or PR creation
- Supports A2A (Agent-to-Agent) communication protocol

## Architecture

### Workflow Integration

```
┌─────────────────┐
│  Orchestrator   │
│     Agent       │
└────────┬────────┘
         │ A2A invoke
         ▼
┌─────────────────┐      ┌──────────┐
│  Remediation    │◄────►│    S3    │
│     Agent       │      │ Storage  │
└─────────────────┘      └──────────┘
         │
         │ Fixed code
         ▼
┌─────────────────┐
│  GitHub Agent   │
│  (Create PR)    │
└─────────────────┘
```

### S3-Based Storage

The agent uses S3 for data sharing:

```
1. Remediation Phase:
   Receive scan results in payload → Download code from S3 → Apply fixes → Upload fixed code → Clean up

2. S3 Structure:
   workflows/{workflow_id}/
   ├── checkov-agent/
   │   ├── data.tar.gz                    # Repository (downloaded by agent)
   │   ├── scan_results.json              # Iteration 1 (NOT downloaded by agent)
   │   ├── scan_results_iteration_2.json  # Iteration 2 (NOT downloaded by agent)
   │   └── ...
   └── terraform-remediation-agent/
       └── data.tar.gz                    # Fixed repository (uploaded, overwritten each iteration)
```

**Important**: The remediation agent receives scan results in the payload from the orchestrator, not from S3. It only downloads the repository code from S3.

## Files

### Core Files
- `main.py` - Agent implementation with S3 integration
- `requirements.txt` - Python dependencies
- `Dockerfile` - Docker image definition (builds from parent dir)
- `deploy.py` - Deployment script
- `test_remediation_agent.py` - Test suite

### Configuration
- `.dockerignore` - Files to exclude from Docker build

## Prerequisites

1. **S3 Bucket**: Run setup script from parent directory
   ```bash
   cd ../
   ./setup_s3_storage.sh
   ```

2. **IAM Permissions**: Agent role needs:
   - S3: GetObject, PutObject, ListBucket
   - ECR: Read access
   - CloudWatch: Logs access

3. **Checkov Scanner**: Must be deployed (provides scan results)

## Build & Deployment

### Deploy to AgentCore

```bash
python3 deploy.py
```

This script:
1. Creates ECR repository if needed
2. Builds Docker image from parent directory (for shared module access)
3. Pushes to ECR
4. Creates/updates AgentCore runtime with S3 permissions

### Docker Build Context

The Dockerfile builds from the **parent directory** (`agentcore-agents/`) to access the shared S3 module:

```dockerfile
# Build context: agentcore-agents/
COPY shared/ /app/shared/              # Shared S3 utility
COPY terraform_remediation/ /app/      # Agent code
```

### Verify Deployment

```bash
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
```

## Testing

### Run Test Suite

```bash
python3 test_remediation_agent.py
```

**Tests:**
1. Health Check - Verifies agent is running
2. Agent Info - Returns capabilities
3. Validate Scan - Tests scan result validation
4. Remediation - Tests workflow integration (requires orchestrator)
5. Error Handling - Validates error responses

**Expected Output:**
```
🎯 Overall: 4 passed, 0 failed, 1 skipped (out of 5 tests)
🎉 All executed tests passed! Remediation agent is functional.
```

### Test via Orchestrator

The best way to test is through the orchestrator agent which coordinates the full workflow:

```bash
cd ../orchestrator
python3 test_orchestrator.py
```

### Manual Testing

```bash
aws bedrock-agentcore invoke-agent-runtime \
  --agent-runtime-arn arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/terraform_remediation-ID \
  --payload '{"action":"health"}' \
  response.json

cat response.json
```

## Usage

### Health Check

```python
payload = {"action": "health"}
```

**Response:**
```json
{
  "status": "healthy",
  "agent": "terraform_remediation",
  "version": "1.0.0-agentcore",
  "capabilities": ["auto_fix", "manual_guidance", "bedrock_kb_integration"],
  "timestamp": "2025-12-23T04:29:19.269Z"
}
```

### Get Agent Info

```python
payload = {"action": "get_info"}
```

**Response:**
```json
{
  "agent_name": "terraform_remediation",
  "version": "1.0.0-agentcore",
  "capabilities": {
    "auto_fix": true,
    "manual_guidance": true,
    "bedrock_kb": false,
    "well_architected_kb": false
  },
  "supported_checks": [
    "CKV_AWS_18",
    "CKV_AWS_19",
    "CKV_AWS_21",
    "CKV_AWS_141",
    "CKV_AWS_142",
    "CKV_AWS_143",
    "CKV_AWS_144",
    "CKV_AWS_145"
  ],
  "communication_mode": "A2A"
}
```

### Remediate Issues (Workflow)

Called by orchestrator during workflow:

```python
payload = {
  "action": "remediate",
  "workflow_id": "abc-123-def",
  "scan_id": "scan-uuid",
  "scan_results": {
    "findings": [
      {
        "check_id": "CKV_AWS_19",
        "file_path": "/modules/s3/main.tf",
        "resource": "aws_s3_bucket.example",
        "severity": "MEDIUM"
      }
    ]
  },
  "remediation_config": {
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true
  }
}
```

**Response:**
```json
{
  "scan_id": "scan-uuid",
  "status": "completed",
  "fixes": [
    {
      "check_id": "CKV_AWS_19",
      "file_path": "/modules/s3/main.tf",
      "resource": "aws_s3_bucket.example",
      "fix_type": "s3_bucket_encryption",
      "status": "applied",
      "description": "Added server-side encryption for aws_s3_bucket.example"
    }
  ],
  "manual_interventions": [
    {
      "check_id": "CKV_AWS_40",
      "file_path": "/modules/iam/main.tf",
      "resource": "aws_iam_user_policy_attachment.example",
      "severity": "HIGH",
      "description": "Ensure IAM policies are attached only to groups or roles",
      "guideline": "https://docs.bridgecrew.io/...",
      "todo_comment": "TODO: CKV_AWS_40 - Manual fix required"
    }
  ],
  "summary": {
    "total_fixes_applied": 1,
    "total_manual_items": 1,
    "total_errors": 0
  },
  "timestamp": "2025-12-23T04:29:21.184Z"
}
```

### Validate Scan Results

```python
payload = {
  "action": "validate",
  "scan_results": {
    "scan_id": "test-123",
    "findings": [...]
  }
}
```

**Response:**
```json
{
  "valid": true,
  "scan_id": "test-123",
  "total_findings": 10,
  "message": "Scan results are valid"
}
```

## Actions

1. **remediate** - Remediate issues (downloads from S3, fixes, uploads back)
2. **remediate_detailed** - Same as remediate
3. **validate** - Validate scan results format
4. **health** - Health check
5. **get_info** - Agent information

## Auto-Fix Capabilities

### Supported Checks

| Check ID | Description | Fix Type |
|----------|-------------|----------|
| CKV_AWS_18 | S3 bucket logging | Add logging configuration |
| CKV_AWS_19 | S3 bucket encryption | Add server-side encryption |
| CKV_AWS_21 | S3 bucket versioning | Enable versioning |
| CKV_AWS_141-145 | S3 encryption variants | Add encryption configuration |

### Example Fix

**Before:**
```hcl
resource "aws_s3_bucket" "example" {
  bucket = "my-bucket"
}
```

**After:**
```hcl
resource "aws_s3_bucket" "example" {
  bucket = "my-bucket"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "example_encryption" {
  bucket = aws_s3_bucket.example.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}
```

## Manual Intervention

For issues that can't be auto-fixed, the agent generates TODO comments:

```hcl
# TODO: CKV_AWS_40 - Ensure IAM policies are attached only to groups or roles
# Severity: HIGH
# Guideline: https://docs.bridgecrew.io/docs/bc_aws_iam_16
resource "aws_iam_user_policy_attachment" "example" {
  user       = aws_iam_user.example.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}
```

## Integration with Other Agents

### Workflow Sequence

```
1. Orchestrator → GitHub Agent (setup)
   └─ Uploads to: workflows/{id}/github-agent/data.tar.gz

2. Loop until convergence (max 5 iterations):
   
   Iteration N:
   a. Orchestrator → Checkov Agent (scan)
      └─ Downloads repository from S3
      └─ Scans and uploads results to S3
      └─ Returns scan results to orchestrator
   
   b. Orchestrator → Remediation Agent (fix)
      └─ Receives scan results in payload from orchestrator
      └─ Downloads repository from: workflows/{id}/checkov-agent/data.tar.gz
      └─ Applies fixes based on scan results from payload
      └─ Uploads to: workflows/{id}/terraform-remediation-agent/data.tar.gz
      └─ Returns remediation summary to orchestrator
   
   c. Orchestrator checks convergence and continues or exits loop

3. Orchestrator → GitHub Agent (create_pr)
   └─ Downloads from: workflows/{id}/terraform-remediation-agent/
   └─ Creates PR with all fixes
```

### Data Flow

```
Checkov Agent → Scan Results (payload) → Orchestrator
                                              ↓
                                    Scan results in payload
                                              ↓
Repository (S3) → Remediation Agent ← Orchestrator
                         ↓
                  Fixed Code (S3)
                         ↓
                  Checkov Agent (next iteration)
                         ↓
                  GitHub Agent (final PR)
```

**Key Points**:
- Remediation agent receives scan results in the payload (not from S3)
- Remediation agent downloads repository from S3 using workflow_id
- Remediation agent uploads fixed code to S3 for next iteration
- Each iteration overwrites the previous fixed code in S3

### A2A Communication

The orchestrator invokes the remediation agent via A2A protocol:

```python
client = boto3.client('bedrock-agentcore')
response = client.invoke_agent_runtime(
    agentRuntimeArn=remediation_arn,
    payload=json.dumps(payload)
)

# Parse response (StreamingBody)
result = json.loads(response['response'].read())
```

**Important**: The response is in `response['response']` (a StreamingBody object), not `response['body']`.

## Configuration

### Environment Variables

- `AWS_EXECUTION_ENV`: Auto-detected (AgentCore sets this)
- `USE_A2A`: Force A2A mode (default: auto-detect)
- `KB_TERRAFORM_ID`: Bedrock Knowledge Base ID for Terraform docs (optional)
- `KB_WELL_ARCH_ID`: Bedrock Knowledge Base ID for Well-Architected (optional)
- `AGENT_STORAGE_BUCKET`: S3 bucket name (default: terraform-security-platform-storage)

### Remediation Config

```python
remediation_config = {
    "auto_fix_enabled": True,
    "manual_guidance_enabled": True,
    "max_fixes_per_file": 10,
    "skip_checks": ["CKV_AWS_123"]  # Optional: checks to skip
}
```

### IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::terraform-security-platform-storage",
        "arn:aws:s3:::terraform-security-platform-storage/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "*"
    }
  ]
}
```

## Monitoring

### View Logs

```bash
aws logs tail /aws/bedrock-agentcore/runtimes/terraform_remediation-ID-DEFAULT \
  --region us-east-1 --since 5m --follow
```

### CloudWatch Metrics

AgentCore automatically publishes:
- Invocation count
- Error rate
- Duration
- OTEL traces

### Log Messages

Key log messages to monitor:
- `Starting remediation for scan {id}: {n} findings`
- `Downloading repository from S3 for workflow {id}`
- `Applied fix for {check_id} on {resource}`
- `Remediation complete: {n} fixes, {n} manual items`
- `Fixed repository uploaded to S3`

## Troubleshooting

### Agent not responding

**Cause**: Runtime not healthy or wrong ARN

**Fix**: Check runtime status
```bash
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
```

View recent logs:
```bash
aws logs tail /aws/bedrock-agentcore/runtimes/terraform_remediation-ID-DEFAULT \
  --region us-east-1 --since 10m
```

### S3 download fails

**Cause**: Missing S3 permissions or scan results don't exist

**Fix**: 
- Verify S3 bucket exists: `terraform-security-platform-storage`
- Check IAM role has S3 permissions
- Verify workflow_id and scan results exist in S3:
  ```bash
  aws s3 ls s3://terraform-security-platform-storage/workflows/{workflow_id}/checkov-agent/
  ```

### Fix application errors

**Cause**: Invalid Terraform syntax or resource names

**Fix**:
- Check Terraform file syntax
- Verify resource names are valid
- Review CloudWatch logs for detailed errors

### No fixes applied

**Cause**: No auto-fixable checks found or all checks require manual intervention

**Expected**: Check `manual_interventions` in response for TODO items

## Development

### Local Testing

Test without deploying:
```bash
# Set environment for local mode
export USE_A2A=false

# Run locally
python3 main.py
```

### Code Changes

After modifying `main.py`:
```bash
python3 deploy.py  # Rebuilds and redeploys
```

### Adding New Auto-Fixes

1. Add check ID to `auto_fixable_checks` dict in `main.py`:
   ```python
   auto_fixable_checks = {
       "CKV_AWS_NEW": "fix_type_name",
       ...
   }
   ```

2. Implement fix function:
   ```python
   def apply_new_fix(file_path: str, resource: str) -> None:
       # Implementation
       pass
   ```

3. Add to `supported_checks` in `get_agent_info()`

4. Test with sample Terraform files

5. Redeploy

## Dependencies

See `requirements.txt`:
- `bedrock-agentcore>=1.0.0` - AgentCore SDK
- `boto3>=1.34.0` - AWS SDK
- `aws-opentelemetry-distro>=0.10.0` - Observability

## Related Documentation

- [Orchestrator Agent](../orchestrator/README.md)
- [GitHub Integration Agent](../github_integration/README.md)
- [Checkov Scanner Agent](../checkov_scanner/README.md)
- [S3 Storage Migration](../S3_STORAGE_MIGRATION.md)
- [Terraform Best Practices](https://www.terraform.io/docs/cloud/guides/recommended-practices/)

## Support

For issues:
1. Check CloudWatch logs for detailed errors
2. Verify S3 bucket exists and has correct permissions
3. Ensure IAM role has required policies
4. Test S3 storage independently
5. Verify scan results format is valid
6. Check orchestrator A2A response parsing
