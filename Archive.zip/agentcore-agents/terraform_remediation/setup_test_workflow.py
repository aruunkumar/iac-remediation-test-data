#!/usr/bin/env python3
"""
Setup a new workflow with test data for remediation testing
"""
import os
import sys
import json
import uuid
import tarfile
import boto3
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.s3_storage import S3Storage

def create_tar_from_directory(source_dir: str, output_tar: str):
    """Create a tar.gz file from a directory"""
    print(f"Creating tar.gz from {source_dir}...")
    with tarfile.open(output_tar, 'w:gz') as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))
    print(f"✓ Created {output_tar}")

def main():
    # Generate new workflow ID
    workflow_id = str(uuid.uuid4())
    scan_id = str(uuid.uuid4())
    
    print("=" * 70)
    print("Setting up new test workflow")
    print("=" * 70)
    print(f"Workflow ID: {workflow_id}")
    print(f"Scan ID: {scan_id}")
    print()
    
    # Initialize S3 storage
    s3_storage = S3Storage(bucket_name='terraform-security-platform-storage')
    
    # Path to test data
    test_data_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'iac-remediation-test-data')
    
    if not os.path.exists(test_data_dir):
        print(f"❌ Test data directory not found: {test_data_dir}")
        print("Please ensure iac-remediation-test-data exists in the project root")
        return 1
    
    print(f"Test data directory: {test_data_dir}")
    print()
    
    # Create tar.gz of test data
    temp_dir = "/tmp"
    tar_filename = f"iac-remediation-test-data.tar.gz"
    tar_path = os.path.join(temp_dir, tar_filename)
    
    create_tar_from_directory(test_data_dir, tar_path)
    print()
    
    # Upload to S3 as github-agent output
    print("Uploading source code to S3...")
    s3_key = f"workflows/{workflow_id}/github-agent/{tar_filename}"
    
    try:
        s3_storage.s3_client.upload_file(
            tar_path,
            s3_storage.bucket_name,
            s3_key
        )
        print(f"✓ Uploaded to s3://{s3_storage.bucket_name}/{s3_key}")
    except Exception as e:
        print(f"❌ Failed to upload: {e}")
        return 1
    
    print()
    
    # Create scan results
    scan_results = {
        "scan_id": scan_id,
        "total_findings": 13,
        "findings": [
            {
                "id": "1",
                "check_id": "CKV_AWS_18",
                "check_name": "Ensure S3 bucket has access logging enabled",
                "file_path": "/iac-remediation-test-data/modules/cors/main.tf",
                "file": "/iac-remediation-test-data/modules/cors/main.tf",
                "resource": "aws_s3_bucket.cors_bucket",
                "resource_type": "aws_s3_bucket",
                "severity": "MEDIUM",
                "description": "S3 bucket should have access logging enabled"
            },
            {
                "id": "2",
                "check_id": "CKV_AWS_237",
                "check_name": "Ensure Create before destroy for API Gateway",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_rest_api.api",
                "resource_type": "aws_api_gateway_rest_api",
                "severity": "LOW",
                "description": "API Gateway should use create_before_destroy lifecycle"
            },
            {
                "id": "3",
                "check_id": "CKV_AWS_120",
                "check_name": "Ensure API Gateway caching is enabled",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "MEDIUM",
                "description": "API Gateway stage should have caching enabled"
            },
            {
                "id": "4",
                "check_id": "CKV_AWS_73",
                "check_name": "Ensure API Gateway has X-Ray Tracing enabled",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "LOW",
                "description": "API Gateway stage should have X-Ray tracing enabled"
            },
            {
                "id": "5",
                "check_id": "CKV_AWS_76",
                "check_name": "Ensure API Gateway has Access Logging enabled",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "MEDIUM",
                "description": "API Gateway stage should have access logging enabled"
            },
            {
                "id": "6",
                "check_id": "CKV2_AWS_4",
                "check_name": "Ensure API Gateway stage have logging level defined",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "LOW",
                "description": "API Gateway stage should have appropriate logging level"
            },
            {
                "id": "7",
                "check_id": "CKV2_AWS_51",
                "check_name": "Ensure API Gateway uses client certificate authentication",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "MEDIUM",
                "description": "API Gateway should use client certificate authentication"
            },
            {
                "id": "8",
                "check_id": "CKV2_AWS_29",
                "check_name": "Ensure public API gateway are protected by WAF",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_stage.prod",
                "resource_type": "aws_api_gateway_stage",
                "severity": "HIGH",
                "description": "Public API Gateway should be protected by WAF"
            },
            {
                "id": "9",
                "check_id": "CKV_AWS_119",
                "check_name": "Ensure DynamoDB Tables are encrypted using KMS",
                "file_path": "/iac-remediation-test-data/modules/dynamodb/main.tf",
                "file": "/iac-remediation-test-data/modules/dynamodb/main.tf",
                "resource": "aws_dynamodb_table.main",
                "resource_type": "aws_dynamodb_table",
                "severity": "MEDIUM",
                "description": "DynamoDB table should be encrypted with KMS"
            },
            {
                "id": "10",
                "check_id": "CKV_AWS_28",
                "check_name": "Ensure DynamoDB point in time recovery is enabled",
                "file_path": "/iac-remediation-test-data/modules/dynamodb/main.tf",
                "file": "/iac-remediation-test-data/modules/dynamodb/main.tf",
                "resource": "aws_dynamodb_table.main",
                "resource_type": "aws_dynamodb_table",
                "severity": "MEDIUM",
                "description": "DynamoDB table should have point-in-time recovery enabled"
            },
            {
                "id": "11",
                "check_id": "CKV2_AWS_38",
                "check_name": "Ensure Domain Name System Security Extensions (DNSSEC) signing is enabled",
                "file_path": "/iac-remediation-test-data/modules/route53/main.tf",
                "file": "/iac-remediation-test-data/modules/route53/main.tf",
                "resource": "aws_route53_zone.main",
                "resource_type": "aws_route53_zone",
                "severity": "MEDIUM",
                "description": "Route53 hosted zone should have DNSSEC signing enabled"
            },
            {
                "id": "12",
                "check_id": "CKV2_AWS_39",
                "check_name": "Ensure Domain Name System (DNS) query logging is enabled",
                "file_path": "/iac-remediation-test-data/modules/route53/main.tf",
                "file": "/iac-remediation-test-data/modules/route53/main.tf",
                "resource": "aws_route53_zone.main",
                "resource_type": "aws_route53_zone",
                "severity": "LOW",
                "description": "Route53 hosted zone should have query logging enabled"
            },
            {
                "id": "13",
                "check_id": "CKV2_AWS_53",
                "check_name": "Ensure AWS API gateway request is validated",
                "file_path": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "file": "/iac-remediation-test-data/modules/api_gateway/main.tf",
                "resource": "module.api_gateway.aws_api_gateway_method.user_get",
                "resource_type": "aws_api_gateway_method",
                "severity": "MEDIUM",
                "description": "API Gateway method should have request validation enabled"
            }
        ],
        "scan_metadata": {
            "source": test_data_dir,
            "timestamp": datetime.utcnow().isoformat()
        }
    }
    
    # Upload scan results
    print("Uploading scan results to S3...")
    try:
        s3_storage.upload_json(
            scan_results,
            workflow_id,
            'checkov-agent',
            'scan_results.json'
        )
        print(f"✓ Uploaded scan results")
    except Exception as e:
        print(f"❌ Failed to upload scan results: {e}")
        return 1
    
    print()
    print("=" * 70)
    print("✅ Setup complete!")
    print("=" * 70)
    print()
    print("Use these values for testing:")
    print(f"  WORKFLOW_ID={workflow_id}")
    print(f"  SCAN_ID={scan_id}")
    print()
    print("Update test_remediation_only.py with the new workflow_id")
    print()
    
    # Clean up
    os.remove(tar_path)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
