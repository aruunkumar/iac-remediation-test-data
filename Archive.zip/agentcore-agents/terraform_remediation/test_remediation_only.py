#!/usr/bin/env python3
"""
Test only the remediation workflow integration (Test 4)
"""
import boto3
import json
import os

def test_remediation_workflow():
    """Test the Terraform Remediation Agent with real workflow data"""
    
    from botocore.config import Config
    
    # Configure client with 10 minute timeout and no retries
    config = Config(
        read_timeout=600,
        connect_timeout=10,
        retries={'max_attempts': 1}  # Disable retries to prevent duplicate invocations
    )
    
    client = boto3.client('bedrock-agentcore', region_name='us-east-1', config=config)
    
    # Agent runtime ARN
    agent_runtime_arn = os.getenv(
        "REMEDIATION_ARN",
        "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/terraform_remediation-L6ILG8FnSE"
    )
    
    print("=" * 70)
    print("🔧 Terraform Remediation Agent - Workflow Integration Test")
    print("=" * 70)
    print(f"Agent ARN: {agent_runtime_arn}")
    print()
    
    print("📋 Test: Remediation (Workflow Integration)")
    print("-" * 70)
    
    try:
        # Use real workflow ID
        workflow_id = "d3978da9-c419-4686-a3a1-8ee501d8f050"
        
        # Download scan results to show what we're testing
        s3_client = boto3.client('s3')
        bucket = 'terraform-security-platform-storage'
        key = f'workflows/{workflow_id}/checkov-agent/scan_results.json'
        
        print(f"📥 Downloading scan results from S3...")
        print(f"   Bucket: {bucket}")
        print(f"   Key: {key}")
        response = s3_client.get_object(Bucket=bucket, Key=key)
        scan_results = json.loads(response['Body'].read())
        print(f"✅ Found {len(scan_results.get('findings', []))} findings to remediate")
        print()
        
        # Run remediation - agent will download repository from S3 using workflow_id
        payload = {
            "action": "remediate",
            "workflow_id": workflow_id,
            "scan_id": scan_results.get('scan_id', 'test-scan'),
            "scan_results": scan_results  # Pass scan results in payload
        }
        
        print(f"🔧 Running remediation...")
        print(f"   Workflow ID: {workflow_id}")
        print(f"   Scan ID: {payload['scan_id']}")
        print(f"   Total findings: {len(scan_results.get('findings', []))}")
        print()
        
        import time
        start_time = time.time()
        print(f"⏱️  Start time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}")
        
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"⏱️  End time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}")
        print(f"⏱️  Total time: {elapsed_time:.2f} seconds ({elapsed_time/60:.2f} minutes)")
        print()
        print("📊 Remediation Results:")
        print("-" * 70)
        
        if result.get('status') in ['success', 'completed']:
            print(f"✅ Status: {result.get('status')}")
            
            summary = result.get('summary', {})
            print(f"✅ Auto-fixes applied: {summary.get('total_fixes_applied', 0)}")
            print(f"✅ Manual interventions: {summary.get('total_manual_items', 0)}")
            print(f"✅ Errors: {summary.get('total_errors', 0)}")
            print()
            
            # Show sample fixes
            fixes = result.get('fixes', [])
            if fixes:
                print(f"📝 Sample Auto-Fixes ({len(fixes)} total):")
                for fix in fixes[:3]:
                    print(f"   • {fix.get('check_id')}: {fix.get('resource')}")
                    print(f"     Status: {fix.get('status')}")
                print()
            
            # Show sample manual items
            manual = result.get('manual_interventions', [])
            if manual:
                print(f"⚠️  Sample Manual Items ({len(manual)} total):")
                for item in manual[:3]:
                    print(f"   • {item.get('check_id')}: {item.get('resource')}")
                    print(f"     Severity: {item.get('severity')}")
                print()
            
            print("=" * 70)
            print("🎉 TEST PASSED - Remediation workflow completed successfully")
            print("=" * 70)
            return True
            
        else:
            print(f"❌ Status: {result.get('status', 'unknown')}")
            print(f"❌ Error: {result.get('error', 'Unknown error')}")
            print()
            print("Full response:")
            print(json.dumps(result, indent=2))
            print()
            print("=" * 70)
            print("❌ TEST FAILED - Remediation did not complete successfully")
            print("=" * 70)
            return False
            
    except Exception as e:
        print(f"❌ Exception: {str(e)}")
        import traceback
        traceback.print_exc()
        print()
        print("=" * 70)
        print("❌ TEST FAILED - Exception occurred")
        print("=" * 70)
        return False

if __name__ == "__main__":
    success = test_remediation_workflow()
    exit(0 if success else 1)
