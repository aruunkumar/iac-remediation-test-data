#!/usr/bin/env python3
"""
Deploy Terraform Remediation Agent to AWS Bedrock AgentCore
"""

import boto3
import subprocess
import sys
import json
import os

# Configuration
AWS_REGION = "us-east-1"
AWS_ACCOUNT_ID = "545009861279"
ECR_REPO_NAME = "terraform-remediation-agent"
IMAGE_TAG = "latest"
RUNTIME_NAME = "terraform_remediation"
ROLE_NAME = "terraform-remediation-agentcore-role"

def run_command(cmd, description):
    """Run a shell command and handle errors"""
    print(f"\n{description}...")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✓ {description} completed")
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"✗ {description} failed")
        print(f"Error: {e.stderr}")
        sys.exit(1)

def main():
    print("=" * 70)
    print("Terraform Remediation Agent - AgentCore Deployment")
    print("=" * 70)
    
    # Change to parent directory for build context
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(script_dir)
    os.chdir(parent_dir)
    print(f"\nWorking directory: {os.getcwd()}")
    
    ecr_client = boto3.client('ecr', region_name=AWS_REGION)
    iam_client = boto3.client('iam')
    agentcore_client = boto3.client('bedrock-agentcore-control', region_name=AWS_REGION)
    
    # Step 1: Create ECR repository
    print("\nStep 1: Checking ECR repository...")
    try:
        ecr_client.describe_repositories(repositoryNames=[ECR_REPO_NAME])
        print(f"✓ ECR repository '{ECR_REPO_NAME}' exists")
    except ecr_client.exceptions.RepositoryNotFoundException:
        print(f"Creating ECR repository: {ECR_REPO_NAME}")
        ecr_client.create_repository(
            repositoryName=ECR_REPO_NAME,
            imageScanningConfiguration={'scanOnPush': True}
        )
        print(f"✓ ECR repository created")
    
    # Step 2: Build Docker image
    image_uri = f"{AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com/{ECR_REPO_NAME}:{IMAGE_TAG}"
    
    run_command(
        f"finch build --platform linux/arm64 -f terraform_remediation/Dockerfile -t {ECR_REPO_NAME}:{IMAGE_TAG} .",
        "Building Docker image for ARM64"
    )
    
    # Step 3: Login to ECR
    run_command(
        f"aws ecr get-login-password --region {AWS_REGION} | "
        f"finch login --username AWS --password-stdin {AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com",
        "Logging in to ECR"
    )
    
    # Step 4: Tag and push
    run_command(f"finch tag {ECR_REPO_NAME}:{IMAGE_TAG} {image_uri}", "Tagging image")
    run_command(f"finch push {image_uri}", "Pushing image to ECR")
    
    print(f"\n✓ Image URI: {image_uri}")
    
    # Step 5: Create IAM role
    print("\nStep 5: Checking IAM role...")
    role_arn = f"arn:aws:iam::{AWS_ACCOUNT_ID}:role/{ROLE_NAME}"
    try:
        iam_client.get_role(RoleName=ROLE_NAME)
        print(f"✓ IAM role '{ROLE_NAME}' exists")
    except iam_client.exceptions.NoSuchEntityException:
        print(f"Creating IAM role: {ROLE_NAME}")
        
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }]
        }
        
        iam_client.create_role(
            RoleName=ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy)
        )
        
        # Attach policies
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
        )
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
        )
        
        # Add S3 access policy
        s3_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:PutObject", "s3:ListBucket"],
                "Resource": [
                    "arn:aws:s3:::terraform-security-platform-storage",
                    "arn:aws:s3:::terraform-security-platform-storage/*"
                ]
            }]
        }
        
        iam_client.put_role_policy(
            RoleName=ROLE_NAME,
            PolicyName="S3Access",
            PolicyDocument=json.dumps(s3_policy)
        )
        
        print(f"✓ IAM role created")
        print("⏳ Waiting 10 seconds for IAM propagation...")
        import time
        time.sleep(10)
    
    # Step 6: Create or update AgentCore runtime
    print("\nStep 6: Creating/updating AgentCore runtime...")
    
    try:
        response = agentcore_client.create_agent_runtime(
            agentRuntimeName=RUNTIME_NAME,
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            },
            networkConfiguration={'networkMode': 'PUBLIC'},
            roleArn=role_arn
        )
        runtime_arn = response['agentRuntimeArn']
        print("✓ Runtime created")
        
    except agentcore_client.exceptions.ConflictException:
        print(f"Runtime '{RUNTIME_NAME}' exists. Updating...")
        
        # Handle pagination
        runtime_id = None
        runtime_arn = None
        next_token = None
        
        while True:
            if next_token:
                list_response = agentcore_client.list_agent_runtimes(nextToken=next_token)
            else:
                list_response = agentcore_client.list_agent_runtimes()
            
            for runtime in list_response.get('agentRuntimes', []):
                if runtime['agentRuntimeName'] == RUNTIME_NAME:
                    runtime_id = runtime['agentRuntimeId']
                    runtime_arn = runtime['agentRuntimeArn']
                    print(f"Found runtime: {runtime_arn}")
                    break
            
            if runtime_id or 'nextToken' not in list_response:
                break
            
            next_token = list_response['nextToken']
        
        if not runtime_id:
            print(f"✗ Could not find runtime")
            sys.exit(1)
        
        agentcore_client.update_agent_runtime(
            agentRuntimeId=runtime_id,
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            },
            roleArn=role_arn,
            networkConfiguration={'networkMode': 'PUBLIC'}
        )
        print("✓ Runtime updated")
    
    # Summary
    print("\n" + "=" * 70)
    print("DEPLOYMENT SUCCESSFUL!")
    print("=" * 70)
    print(f"\nRuntime ARN: {runtime_arn}")
    print(f"Image URI: {image_uri}")
    print(f"\nTest with:")
    print(f"  python terraform_remediation/test_remediation_agent.py")
    print()

if __name__ == "__main__":
    main()
