#!/usr/bin/env python3
"""
Run E2E workflow and monitor progress
"""
import boto3
from botocore.config import Config
import json
import os
import time

# Configuration
github_token = os.getenv('GITHUB_TOKEN', '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')

print("=" * 70)
print("E2E Workflow Execution")
print("=" * 70)
print()

# Initialize client with 10 minute timeout
config = Config(read_timeout=600)
client = boto3.client('bedrock-agentcore', region_name='us-east-1', config=config)
orchestrator_arn = "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/orchestrator_agent-2tbgPPHQ1y"

# Workflow payload
payload = {
    "action": "start_workflow",
    "repository_data": {
        "owner": "aruunkumar",
        "repo": "iac-remediation-test-data",
        "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
        "source_branch": "main",
        "commit_sha": "HEAD",
        "author": "aruunkumar",
        "default_branch": "main",
        "github_token": github_token
    },
    "workflow_configuration": {
        "max_iterations": 3,
        "auto_merge": False,
        "require_approval": True
    }
}

print("🚀 Starting workflow...")
print()

try:
    start_time = time.time()
    response = client.invoke_agent_runtime(
        agentRuntimeArn=orchestrator_arn,
        payload=json.dumps(payload)
    )
    result = json.loads(response['response'].read())
    elapsed = time.time() - start_time
    
    print(f"✅ Workflow completed in {elapsed:.1f}s")
    print()
    print(f"Status: {result.get('status')}")
    print(f"Workflow ID: {result.get('workflow_id')}")
    
    if result.get('pr_url'):
        print(f"PR URL: {result.get('pr_url')}")
    
    if result.get('summary'):
        print()
        print("Summary:")
        for key, value in result.get('summary', {}).items():
            print(f"  {key}: {value}")
    
    print()
    print(json.dumps(result, indent=2))
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
