"""
Orchestrator Agent - AgentCore Version with A2A Protocol Support
Supports both A2A (for AgentCore) and HTTP (for local testing)
Enhanced with retry logic, circuit breaker, convergence metrics, and reporting
"""

from bedrock_agentcore import BedrockAgentCoreApp
import boto3
import json
import logging
import os
import sys
import uuid
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, asdict
import httpx

# Configure OpenTelemetry for AgentCore observability
try:
    from strands.tracer import configure_tracer
    configure_tracer()
except ImportError:
    # Strands tracer is optional
    pass

# Detect execution environment
IS_AGENTCORE = os.getenv("AWS_EXECUTION_ENV", "").startswith("AWS_") or os.getenv("USE_A2A", "false").lower() == "true"
IS_LOCAL = not IS_AGENTCORE

# Configure logging based on environment
if IS_AGENTCORE:
    # CloudWatch-friendly logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        stream=sys.stdout,
        force=True
    )
else:
    # Local development logging with more detail
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
        force=True
    )

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO if IS_AGENTCORE else logging.DEBUG)

# Log environment detection
logger.info(f"Environment: {'AgentCore' if IS_AGENTCORE else 'Local'}")
logger.info(f"Python version: {sys.version}")
logger.info(f"Working directory: {os.getcwd()}")

app = BedrockAgentCoreApp(debug=not IS_AGENTCORE)

# Agent communication configuration
USE_A2A = os.getenv("USE_A2A", "false").lower() == "true"

# Agent ARNs (for AgentCore A2A)
CHECKOV_SCANNER_ARN = os.getenv("CHECKOV_SCANNER_ARN", "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/checkov_scanner-FwURrtD7GD")
TERRAFORM_REMEDIATION_ARN = os.getenv("TERRAFORM_REMEDIATION_ARN", "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/terraform_remediation-L6ILG8FnSE")
GITHUB_INTEGRATION_ARN = os.getenv("GITHUB_INTEGRATION_ARN", "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/github_integration_agent_s3-KYs53SDSNM")

# HTTP URLs (for local testing)
CHECKOV_SCANNER_URL = os.getenv("CHECKOV_SCANNER_URL", "http://localhost:8000")
TERRAFORM_REMEDIATION_URL = os.getenv("TERRAFORM_REMEDIATION_URL", "http://localhost:8001")
GITHUB_INTEGRATION_URL = os.getenv("GITHUB_INTEGRATION_URL", "http://localhost:8002")

logger.info(f"Communication mode: {'A2A' if USE_A2A else 'HTTP'}")


# Data classes for tracking workflow progress
@dataclass
class IterationResult:
    """Result of a single iteration"""
    iteration_number: int
    scan_results: Dict[str, Any]
    remediation_results: Dict[str, Any]
    fixes_applied: int
    manual_items_added: int
    convergence_achieved: bool
    iteration_duration: float
    timestamp: str


@dataclass
class ConvergenceMetrics:
    """Metrics for detecting workflow convergence"""
    fixes_applied_trend: List[int]
    remaining_issues_trend: List[int]
    convergence_score: float
    convergence_achieved: bool
    convergence_reason: str


@dataclass
class CommunicationResult:
    """Result of agent communication with retry info"""
    success: bool
    response_data: Optional[Dict[str, Any]]
    status_code: Optional[int]
    error_message: Optional[str]
    retry_count: int
    total_duration: float
    agent_name: str


@dataclass
class WorkflowProgress:
    """Complete workflow progress tracking"""
    workflow_id: str
    repository_data: Dict[str, Any]
    total_iterations: int
    max_iterations: int
    iterations: List[IterationResult]
    convergence_metrics: Optional[ConvergenceMetrics]
    final_scan_results: Optional[Dict[str, Any]]
    pr_created: bool
    workflow_status: str
    start_time: str
    end_time: Optional[str]
    total_fixes_applied: int
    total_manual_items: int


class AgentCommunicator:
    """Handles communication with other agents via A2A or HTTP with retry logic and circuit breaker"""
    
    def __init__(self):
        self.runtime_client = None
        
        # Retry configuration
        self.max_retries = 3
        self.retry_delay = 1.0  # seconds
        self.retry_backoff = 2.0  # exponential backoff multiplier
        
        # Circuit breaker configuration
        self.circuit_breaker_threshold = 5  # consecutive failures
        self.circuit_breaker_timeout = 300  # seconds (5 minutes)
        self._failure_counts = {}
        self._last_failure_times = {}
        
        # Timeout configuration per agent
        self.timeouts = {
            "checkov_scanner": 90.0,  # Scanner operations
            "terraform_remediation": 600.0,  # LLM operations take time
            "github_integration": 45.0  # Git operations
        }
        
        if USE_A2A:
            logger.info("Using A2A protocol for agent communication")
        else:
            logger.info("Using HTTP for agent communication (local testing)")
    
    def _get_runtime_client(self):
        """Lazy initialization of boto3 client with extended timeout"""
        if self.runtime_client is None and USE_A2A:
            from botocore.config import Config
            # Use 10 minute timeout for long-running operations like remediation
            config = Config(read_timeout=600)
            self.runtime_client = boto3.client('bedrock-agentcore', region_name='us-east-1', config=config)
        return self.runtime_client
    
    def call_agent_with_retry(self, agent_name: str, payload: Dict[str, Any]) -> CommunicationResult:
        """Call agent with retry logic and circuit breaker protection"""
        
        # Check circuit breaker
        if self._is_circuit_breaker_open(agent_name):
            return CommunicationResult(
                success=False,
                response_data=None,
                status_code=None,
                error_message=f"Circuit breaker open for {agent_name}",
                retry_count=0,
                total_duration=0.0,
                agent_name=agent_name
            )
        
        start_time = time.time()
        retry_count = 0
        last_error = None
        
        while retry_count <= self.max_retries:
            try:
                logger.info(f"Calling {agent_name} (attempt {retry_count + 1}/{self.max_retries + 1})")
                
                # Make the call
                if USE_A2A:
                    response_data = self._call_via_a2a(agent_name, payload)
                else:
                    response_data = self._call_via_http(agent_name, payload)
                
                # Success - reset failure count
                self._reset_failure_count(agent_name)
                
                total_duration = time.time() - start_time
                
                return CommunicationResult(
                    success=True,
                    response_data=response_data,
                    status_code=200,
                    error_message=None,
                    retry_count=retry_count,
                    total_duration=total_duration,
                    agent_name=agent_name
                )
                
            except Exception as e:
                last_error = str(e)
                retry_count += 1
                
                logger.warning(f"Agent {agent_name} call failed (attempt {retry_count}): {e}")
                
                # Record failure
                self._record_failure(agent_name)
                
                # Wait before retry (with exponential backoff)
                if retry_count <= self.max_retries:
                    delay = self.retry_delay * (self.retry_backoff ** (retry_count - 1))
                    logger.info(f"Retrying {agent_name} in {delay:.1f} seconds...")
                    time.sleep(delay)
        
        # All retries exhausted
        total_duration = time.time() - start_time
        
        return CommunicationResult(
            success=False,
            response_data=None,
            status_code=None,
            error_message=f"All retries exhausted. Last error: {last_error}",
            retry_count=retry_count - 1,
            total_duration=total_duration,
            agent_name=agent_name
        )
    
    def _is_circuit_breaker_open(self, agent_name: str) -> bool:
        """Check if circuit breaker is open for an agent"""
        failure_count = self._failure_counts.get(agent_name, 0)
        
        if failure_count < self.circuit_breaker_threshold:
            return False
        
        # Check if timeout period has passed
        last_failure_time = self._last_failure_times.get(agent_name)
        if last_failure_time:
            time_since_failure = datetime.utcnow() - last_failure_time
            if time_since_failure.total_seconds() > self.circuit_breaker_timeout:
                # Reset circuit breaker
                self._reset_failure_count(agent_name)
                return False
        
        logger.warning(f"Circuit breaker OPEN for {agent_name} (failures: {failure_count})")
        return True
    
    def _record_failure(self, agent_name: str) -> None:
        """Record a failure for an agent"""
        self._failure_counts[agent_name] = self._failure_counts.get(agent_name, 0) + 1
        self._last_failure_times[agent_name] = datetime.utcnow()
        logger.warning(f"Recorded failure for {agent_name} (count: {self._failure_counts[agent_name]})")
    
    def _reset_failure_count(self, agent_name: str) -> None:
        """Reset failure count for an agent"""
        if agent_name in self._failure_counts:
            self._failure_counts[agent_name] = 0
        if agent_name in self._last_failure_times:
            del self._last_failure_times[agent_name]
    
    def call_agent(self, agent_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Legacy method - calls call_agent_with_retry and returns response_data"""
        result = self.call_agent_with_retry(agent_name, payload)
        if result.success:
            return result.response_data
        else:
            raise Exception(result.error_message)
    
    def _call_via_a2a(self, agent_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Call agent using A2A protocol"""
        arn_map = {
            "checkov_scanner": CHECKOV_SCANNER_ARN,
            "terraform_remediation": TERRAFORM_REMEDIATION_ARN,
            "github_integration": GITHUB_INTEGRATION_ARN
        }
        
        agent_arn = arn_map.get(agent_name)
        if not agent_arn:
            raise ValueError(f"Unknown agent: {agent_name}")
        
        logger.info(f"Invoking {agent_name} via A2A: {agent_arn}")
        
        client = self._get_runtime_client()
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_arn,
            payload=json.dumps(payload).encode('utf-8')
        )
        
        # The response body is in response['response'] for AgentCore
        response_body = response.get('response')
        if hasattr(response_body, 'read'):
            result = json.loads(response_body.read())
        else:
            result = json.loads(response_body or '{}')
        
        logger.info(f"Received response from {agent_name}: keys={list(result.keys())}, total_findings={result.get('total_findings', 'N/A')}")
        return result
    
    def _call_via_http(self, agent_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Call agent using HTTP (for local testing)"""
        url_map = {
            "checkov_scanner": CHECKOV_SCANNER_URL,
            "terraform_remediation": TERRAFORM_REMEDIATION_URL,
            "github_integration": GITHUB_INTEGRATION_URL
        }
        
        base_url = url_map.get(agent_name)
        if not base_url:
            raise ValueError(f"Unknown agent: {agent_name}")
        
        # Determine endpoint based on action
        action = payload.get("action")
        endpoint_map = {
            "checkov_scanner": {
                "scan": "/scan/local"
            },
            "terraform_remediation": {
                "remediate": "/remediate/scan-id/detailed"
            },
            "github_integration": {
                "setup": "/api/v1/github/setup",
                "create_pr": "/api/v1/github/commit-and-create-pr"
            }
        }
        
        endpoint = endpoint_map.get(agent_name, {}).get(action, "/invoke")
        url = f"{base_url}{endpoint}"
        
        # Get timeout for this agent
        timeout = self.timeouts.get(agent_name, 300.0)
        
        logger.info(f"Calling {agent_name} via HTTP: {url} (timeout: {timeout}s)")
        
        with httpx.Client(timeout=timeout) as client:
            response = client.post(url, json=payload)
            response.raise_for_status()
            result = response.json()
            
            # Defensive check: ensure result is a dict
            if not isinstance(result, dict):
                logger.error(f"Invalid response type from {agent_name}: {type(result)}")
                raise ValueError(f"Expected dict response, got {type(result)}")
            
            logger.info(f"Received response from {agent_name}")
            return result


communicator = AgentCommunicator()


# Helper functions for convergence and reporting

def calculate_convergence_score(metrics: ConvergenceMetrics) -> float:
    """Calculate convergence score based on trends and progress"""
    if len(metrics.remaining_issues_trend) < 2:
        return 0.0
    
    # Factor 1: Reduction in issues over time
    initial_issues = metrics.remaining_issues_trend[0] if metrics.remaining_issues_trend else 1
    current_issues = metrics.remaining_issues_trend[-1]
    
    if initial_issues == 0:
        issue_reduction_score = 1.0
    else:
        issue_reduction_score = max(0.0, (initial_issues - current_issues) / initial_issues)
    
    # Factor 2: Stability of fixes (consistent progress)
    if len(metrics.fixes_applied_trend) >= 2:
        recent_fixes = metrics.fixes_applied_trend[-2:]
        stability_score = 1.0 - abs(recent_fixes[0] - recent_fixes[1]) / max(1, max(recent_fixes))
    else:
        stability_score = 0.5
    
    # Factor 3: Diminishing returns (fewer fixes in recent iterations)
    if len(metrics.fixes_applied_trend) >= 3:
        recent_trend = metrics.fixes_applied_trend[-3:]
        if all(fixes <= 1 for fixes in recent_trend):
            diminishing_returns_score = 0.9
        else:
            diminishing_returns_score = 0.3
    else:
        diminishing_returns_score = 0.5
    
    # Weighted combination
    convergence_score = (
        0.5 * issue_reduction_score +
        0.3 * stability_score +
        0.2 * diminishing_returns_score
    )
    
    return min(1.0, max(0.0, convergence_score))


def generate_workflow_report(workflow_progress: WorkflowProgress) -> Dict[str, Any]:
    """Generate comprehensive workflow report"""
    
    # Get findings from FIRST iteration only (initial state)
    all_findings = []
    if workflow_progress.iterations:
        first_scan = workflow_progress.iterations[0].scan_results if isinstance(workflow_progress.iterations[0].scan_results, dict) else {}
        findings = first_scan.get('findings', [])
        if isinstance(findings, list):
            all_findings = findings
        initial_issues = first_scan.get('total_findings', len(all_findings))
    else:
        initial_issues = 0
    
    # Count by severity from first scan
    severity_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
    for finding in all_findings:
        severity = finding.get('severity', 'LOW').upper()
        if severity in severity_counts:
            severity_counts[severity] += 1
    
    # Calculate security improvement
    if workflow_progress.final_scan_results and isinstance(workflow_progress.final_scan_results, dict):
        final_issues = workflow_progress.final_scan_results.get('total_findings', 0)
    else:
        final_issues = initial_issues
    
    if initial_issues > 0:
        security_improvement_score = ((initial_issues - final_issues) / initial_issues) * 100
    else:
        security_improvement_score = 100.0 if final_issues == 0 else 0.0
    
    # Calculate fix success rate
    total_issues = initial_issues
    if total_issues > 0:
        fix_success_rate = (workflow_progress.total_fixes_applied / total_issues) * 100
    else:
        fix_success_rate = 0.0
    
    return {
        'workflow_id': workflow_progress.workflow_id,
        'total_issues_found': len(all_findings),
        'critical_issues': severity_counts['CRITICAL'],
        'high_issues': severity_counts['HIGH'],
        'medium_issues': severity_counts['MEDIUM'],
        'low_issues': severity_counts['LOW'],
        'auto_fixes_applied': workflow_progress.total_fixes_applied,
        'manual_interventions_required': workflow_progress.total_manual_items,
        'fix_success_rate': fix_success_rate,
        'security_improvement_score': security_improvement_score,
        'total_iterations': workflow_progress.total_iterations,
        'final_status': workflow_progress.workflow_status
    }


def generate_pr_body(workflow_progress: WorkflowProgress, report_summary: Dict[str, Any], convergence_metrics: ConvergenceMetrics) -> str:
    """Generate comprehensive PR body with report details"""
    
    body = f"""# Security Remediation Report

## Summary
- **Total Fixes Applied**: {workflow_progress.total_fixes_applied}
- **Manual Interventions Required**: {workflow_progress.total_manual_items}
- **Iterations**: {workflow_progress.total_iterations}
- **Convergence**: {convergence_metrics.convergence_achieved}
- **Convergence Reason**: {convergence_metrics.convergence_reason}
- **Convergence Score**: {convergence_metrics.convergence_score:.3f}

## Security Metrics
- **Total Issues Found**: {report_summary.get('total_issues_found', 0)}
- **Security Improvement**: {report_summary.get('security_improvement_score', 0):.1f}%
- **Fix Success Rate**: {report_summary.get('fix_success_rate', 0):.1f}%

## Severity Breakdown
- **Critical**: {report_summary.get('critical_issues', 0)}
- **High**: {report_summary.get('high_issues', 0)}
- **Medium**: {report_summary.get('medium_issues', 0)}
- **Low**: {report_summary.get('low_issues', 0)}

## Iterations
"""
    
    for iteration in workflow_progress.iterations:
        body += f"""
### Iteration {iteration.iteration_number}
- **Issues Found**: {iteration.scan_results.get('total_findings', 0) if isinstance(iteration.scan_results, dict) else 0}
- **Fixes Applied**: {iteration.fixes_applied}
- **Manual Items**: {iteration.manual_items_added}
- **Duration**: {iteration.iteration_duration:.1f}s
"""
    
    body += f"""

## Workflow Details
- **Workflow ID**: {workflow_progress.workflow_id}
- **Started**: {workflow_progress.start_time}
- **Completed**: {workflow_progress.end_time}

This PR was automatically generated by the Terraform Security Platform.
"""
    
    return body


def get_workflow_report(workflow_id: str) -> Optional[Dict[str, Any]]:
    """Get detailed workflow report"""
    workflow_data = workflows_store.get(workflow_id)
    
    if not workflow_data:
        return None
    
    # If workflow_data is already a WorkflowProgress dict, use it directly
    if isinstance(workflow_data, dict) and 'iterations' in workflow_data:
        # Reconstruct WorkflowProgress from dict
        workflow_progress = WorkflowProgress(**workflow_data)
        return generate_workflow_report(workflow_progress)
    
    return None


@app.entrypoint
def invoke(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main entry point for orchestrator agent
    
    Supported actions:
    - start_workflow: Start GitHub workflow (POST /orchestrate)
    - start_local_workflow: Start local/S3 workflow (POST /orchestrate/local)
    - handle_webhook: Handle GitHub webhook (POST /webhook/github)
    - get_status: Get workflow status (GET /workflows/{id}/status)
    - get_report: Get detailed workflow report (GET /workflows/{id}/report)
    - list_workflows: List all workflows (GET /workflows)
    - health_check: Health check (GET /health)
    - get_info: Agent info (GET /info)
    
    Payload structure varies by action - see individual functions
    """
    action = payload.get("action", "start_workflow")
    execution_start = datetime.utcnow()
    
    logger.info(f"{'='*80}")
    logger.info(f"[ORCHESTRATOR] EXECUTION START")
    logger.info(f"[ORCHESTRATOR] Action: {action}")
    logger.info(f"[ORCHESTRATOR] Timestamp: {execution_start.isoformat()}")
    logger.info(f"{'='*80}")
    logger.info(f"Payload: {json.dumps(payload, default=str)}")
    
    try:
        if action == "start_workflow":
            result = start_workflow(payload)
        elif action == "start_local_workflow":
            result = start_local_workflow(payload)
        elif action == "handle_webhook":
            result = handle_github_webhook(payload)
        elif action == "get_status":
            result = get_workflow_status(payload)
        elif action == "get_report":
            result = get_workflow_report_endpoint(payload)
        elif action == "list_workflows":
            result = list_workflows(payload)
        elif action == "health_check":
            result = health_check(payload)
        elif action == "get_info":
            result = get_agent_info(payload)
        else:
            result = {"error": f"Unknown action: {action}"}
        
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.info(f"{'='*80}")
        logger.info(f"[ORCHESTRATOR] EXECUTION END")
        logger.info(f"[ORCHESTRATOR] Action: {action}")
        logger.info(f"[ORCHESTRATOR] Status: {'success' if 'error' not in result else 'error'}")
        logger.info(f"[ORCHESTRATOR] Execution time: {execution_time:.2f}s")
        logger.info(f"[ORCHESTRATOR] Timestamp: {execution_end.isoformat()}")
        logger.info(f"{'='*80}")
        
        return result
        
    except Exception as e:
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.error(f"{'='*80}")
        logger.error(f"[ORCHESTRATOR] EXECUTION FAILED")
        logger.error(f"[ORCHESTRATOR] Action: {action}")
        logger.error(f"[ORCHESTRATOR] Error: {str(e)}")
        logger.error(f"[ORCHESTRATOR] Execution time: {execution_time:.2f}s")
        logger.error(f"[ORCHESTRATOR] Timestamp: {execution_end.isoformat()}")
        logger.error(f"{'='*80}")
        
        raise


def start_workflow(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Execute the complete security workflow with S3-based storage, enhanced with convergence tracking and reporting"""
    workflow_id = str(uuid.uuid4())
    start_time = datetime.utcnow().isoformat()
    
    repo_data = payload.get("repository_data", {})
    config = payload.get("workflow_configuration", {})
    max_iterations = config.get("max_iterations", 5)
    
    # Add workflow_id to repo_data for all agents
    repo_data['workflow_id'] = workflow_id
    
    print(f"[WORKFLOW] Starting workflow {workflow_id} for {repo_data.get('url')}")
    print(f"[WORKFLOW] Max iterations: {max_iterations}")
    logger.info(f"Starting workflow {workflow_id} for {repo_data.get('url')}")
    
    # Initialize workflow progress tracking
    workflow_progress = WorkflowProgress(
        workflow_id=workflow_id,
        repository_data=repo_data,
        total_iterations=0,
        max_iterations=max_iterations,
        iterations=[],
        convergence_metrics=None,
        final_scan_results=None,
        pr_created=False,
        workflow_status="in_progress",
        start_time=start_time,
        end_time=None,
        total_fixes_applied=0,
        total_manual_items=0
    )
    
    try:
        # Step 1: Clone repository, create branch, and upload to S3
        logger.info("Step 1: Setting up repository and uploading to S3")
        setup_result = communicator.call_agent("github_integration", {
            "action": "setup",
            "repository_data": repo_data
        })
        
        s3_uri = setup_result.get("s3_uri")
        branch_name = setup_result.get("branch_name")
        logger.info(f"Repository uploaded to S3: {s3_uri}, branch: {branch_name}")
        
        # Step 2: Iterative scan and remediate with convergence tracking
        iteration = 0
        convergence_metrics = ConvergenceMetrics(
            fixes_applied_trend=[],
            remaining_issues_trend=[],
            convergence_score=0.0,
            convergence_achieved=False,
            convergence_reason=""
        )
        
        while iteration < max_iterations:
            iteration_start_time = time.time()
            iteration += 1
            logger.info(f"Starting iteration {iteration}/{max_iterations}")
            
            # Scan - downloads from S3
            logger.info(f"Iteration {iteration}: Scanning code from S3")
            scan_result = communicator.call_agent("checkov_scanner", {
                "action": "scan",
                "workflow_id": workflow_id,
                "iteration": iteration,  # Pass iteration number for S3 tracking
                "scan_options": {
                    "frameworks": ["terraform"],
                    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
                },
                "repository_info": {
                    "owner": repo_data.get("owner"),
                    "repo": repo_data.get("repo"),
                    "url": repo_data.get("url")
                }
            })
            
            total_findings = scan_result.get("total_findings", 0)
            logger.info(f"Iteration {iteration}: Found {total_findings} issues")
            
            # Update convergence metrics with scan results
            convergence_metrics.remaining_issues_trend.append(total_findings)
            
            if total_findings == 0:
                convergence_metrics.convergence_achieved = True
                convergence_metrics.convergence_reason = "No security issues found"
                logger.info(f"Convergence achieved: {convergence_metrics.convergence_reason}")
                
                # Record final iteration with no issues
                iteration_result = IterationResult(
                    iteration_number=iteration,
                    scan_results=scan_result,
                    remediation_results={},
                    fixes_applied=0,
                    manual_items_added=0,
                    convergence_achieved=True,
                    iteration_duration=time.time() - iteration_start_time,
                    timestamp=datetime.utcnow().isoformat()
                )
                workflow_progress.iterations.append(iteration_result)
                workflow_progress.final_scan_results = scan_result
                break
            
            # Remediate - downloads from S3, fixes, and uploads back
            logger.info(f"Iteration {iteration}: Remediating issues")
            scan_id = scan_result.get("scan_id")
            remediation_result = communicator.call_agent("terraform_remediation", {
                "action": "remediate",
                "scan_id": scan_id,
                "workflow_id": workflow_id,
                "iteration": iteration,  # Pass iteration number
                "scan_results": scan_result,
                "remediation_config": {
                    "auto_fix_enabled": config.get("auto_fix_enabled", True),
                    "manual_guidance_enabled": config.get("manual_guidance_enabled", True)
                }
            })
            
            fixes = remediation_result.get("fixes", [])
            manual_items = remediation_result.get("manual_interventions", [])
            
            iteration_fixes = len(fixes) if isinstance(fixes, list) else 0
            iteration_manual = len(manual_items) if isinstance(manual_items, list) else 0
            
            workflow_progress.total_fixes_applied += iteration_fixes
            workflow_progress.total_manual_items += iteration_manual
            
            # Update convergence metrics
            convergence_metrics.fixes_applied_trend.append(iteration_fixes)
            convergence_metrics.convergence_score = calculate_convergence_score(convergence_metrics)
            
            logger.info(f"Iteration {iteration}: Applied {iteration_fixes} fixes, {iteration_manual} manual items, convergence score: {convergence_metrics.convergence_score:.3f}")
            
            # Record iteration result
            iteration_result = IterationResult(
                iteration_number=iteration,
                scan_results=scan_result,
                remediation_results=remediation_result,
                fixes_applied=iteration_fixes,
                manual_items_added=iteration_manual,
                convergence_achieved=False,
                iteration_duration=time.time() - iteration_start_time,
                timestamp=datetime.utcnow().isoformat()
            )
            workflow_progress.iterations.append(iteration_result)
            
            # Check for convergence starting from iteration 2
            # Compare current scan with previous iteration's scan to see if remediation introduced new issues
            if iteration > 1:
                prev_scan = workflow_progress.iterations[iteration - 2].scan_results  # Previous iteration
                current_scan = scan_result
                
                # Get issue IDs from previous scan
                prev_issue_ids = set()
                if isinstance(prev_scan, dict) and 'findings' in prev_scan:
                    for finding in prev_scan['findings']:
                        if isinstance(finding, dict):
                            issue_id = f"{finding.get('id')}:{finding.get('file_path')}:{finding.get('resource')}"
                            prev_issue_ids.add(issue_id)
                
                # Get issue IDs from current scan
                current_issue_ids = set()
                if isinstance(current_scan, dict) and 'findings' in current_scan:
                    for finding in current_scan['findings']:
                        if isinstance(finding, dict):
                            issue_id = f"{finding.get('id')}:{finding.get('file_path')}:{finding.get('resource')}"
                            current_issue_ids.add(issue_id)
                
                # Check if any NEW issues were introduced by previous iteration's remediation
                new_issues = current_issue_ids - prev_issue_ids
                fixed_issues = prev_issue_ids - current_issue_ids
                
                if len(new_issues) == 0:
                    # No new issues introduced - CONVERGE IMMEDIATELY
                    fixed_count = len(fixed_issues)
                    remaining_count = len(current_issue_ids)
                    
                    convergence_metrics.convergence_achieved = True
                    convergence_metrics.convergence_reason = f"No new issues introduced by remediation. Fixed {fixed_count} issues in iteration {iteration-1}, {remaining_count} remaining."
                    logger.info(f"Convergence achieved after iteration {iteration-1}: {convergence_metrics.convergence_reason}")
                    workflow_progress.final_scan_results = scan_result
                    break
                else:
                    # New issues introduced - continue to next iteration
                    logger.warning(f"Iteration {iteration}: {len(new_issues)} new issues introduced by iteration {iteration-1} remediation - continuing")
                    logger.warning(f"New issues: {new_issues}")
            
            # First iteration - no convergence check yet
            elif iteration == 1:
                logger.info(f"Iteration {iteration}: First iteration complete, will check for new issues in next iteration")
        
        workflow_progress.total_iterations = iteration
        workflow_progress.convergence_metrics = asdict(convergence_metrics)
        
        if not convergence_metrics.convergence_achieved:
            convergence_metrics.convergence_reason = "Reached maximum iterations"
            logger.info(f"Workflow ended: {convergence_metrics.convergence_reason}")
            workflow_progress.workflow_status = "max_iterations_reached"
        else:
            workflow_progress.workflow_status = "completed"
        
        # Step 3: Generate report and create PR if there are changes
        pr_created = False
        pr_url = None
        report_summary = None
        
        if workflow_progress.total_fixes_applied > 0 or workflow_progress.total_manual_items > 0:
            logger.info("Step 3: Generating report and creating pull request")
            
            # Generate comprehensive report
            report_summary = generate_workflow_report(workflow_progress)
            
            # Consolidate all fixes and manual interventions from all iterations
            # Use sets to deduplicate based on unique identifiers
            all_fixes_dict = {}  # key: unique_id, value: fix
            all_manual_dict = {}  # key: unique_id, value: manual_item
            
            for iter_result in workflow_progress.iterations:
                remediation_results = iter_result.remediation_results
                if isinstance(remediation_results, dict):
                    # Deduplicate fixes
                    for fix in remediation_results.get('fixes', []):
                        if isinstance(fix, dict):
                            # Create unique ID from check_id + file_path + resource
                            # Note: remediation agent uses 'file_path' not 'file'
                            file_path = fix.get('file_path') or fix.get('file') or 'unknown'
                            fix_id = f"{fix.get('check_id')}:{file_path}:{fix.get('resource')}"
                            # Keep the fix from the latest iteration (overwrite if duplicate)
                            all_fixes_dict[fix_id] = fix
                    
                    # Deduplicate manual interventions
                    for manual in remediation_results.get('manual_interventions', []):
                        if isinstance(manual, dict):
                            file_path = manual.get('file_path') or manual.get('file') or 'unknown'
                            manual_id = f"{manual.get('check_id')}:{file_path}:{manual.get('resource')}"
                            all_manual_dict[manual_id] = manual
            
            # Remove manual items that were eventually fixed
            # If an item appears in both fixes and manual, keep only the fix
            for fix_id in all_fixes_dict.keys():
                if fix_id in all_manual_dict:
                    del all_manual_dict[fix_id]
            
            # Convert back to lists and normalize field names for PR template
            all_fixes = []
            for fix in all_fixes_dict.values():
                # Normalize file_path to file for PR template compatibility
                if 'file_path' in fix and 'file' not in fix:
                    fix['file'] = fix['file_path']
                all_fixes.append(fix)
            
            all_manual_interventions = []
            for manual in all_manual_dict.values():
                # Normalize file_path to file for PR template compatibility
                if 'file_path' in manual and 'file' not in manual:
                    manual['file'] = manual['file_path']
                all_manual_interventions.append(manual)
            
            logger.info(f"Consolidated results: {len(all_fixes)} unique fixes, {len(all_manual_interventions)} unique manual items across {workflow_progress.total_iterations} iterations")
            
            # Always use workflow_id for tracking
            workflow_id_display = workflow_id
            
            # Create enhanced remediation results for PR
            enhanced_remediation = {
                'workflow_id': workflow_id,
                'total_iterations': workflow_progress.total_iterations,
                'fixes': all_fixes,
                'manual_interventions': all_manual_interventions,
                'scan_metadata': {
                    'total_findings': report_summary.get('total_issues_found', 0),
                    'scan_date': start_time,
                    'workflow_id': workflow_id_display,
                    'workflow_status': workflow_progress.workflow_status,
                    'security_improvement_score': report_summary.get('security_improvement_score', 0),
                    'convergence_score': convergence_metrics.convergence_score
                }
            }
            
            # Save consolidated remediation results to S3 for GitHub agent
            try:
                s3_client = boto3.client('s3')
                bucket = os.getenv('WORKFLOW_BUCKET', 'terraform-security-platform-storage')
                s3_key = f"workflows/{workflow_id}/github-agent/remediation_results.json"
                s3_client.put_object(
                    Bucket=bucket,
                    Key=s3_key,
                    Body=json.dumps(enhanced_remediation, default=str),
                    ContentType='application/json'
                )
                logger.info(f"Saved consolidated remediation results to S3: s3://{bucket}/{s3_key}")
            except Exception as e:
                logger.error(f"Failed to save consolidated remediation results to S3: {e}")
            
            pr_result = communicator.call_agent("github_integration", {
                "action": "create_pr",
                "repository_data": repo_data,
                "pr_data": {
                    "title": f"Security Remediation - {workflow_id[:8]}",
                    "body": generate_pr_body(workflow_progress, report_summary, convergence_metrics),
                    "fixes_summary": {
                        "total_fixes": workflow_progress.total_fixes_applied,
                        "total_manual_items": workflow_progress.total_manual_items
                    }
                }
            })
            
            pr_created = True
            pr_url = pr_result.get("pr_url")
            workflow_progress.pr_created = True
            logger.info(f"Pull request created: {pr_url}")
        else:
            logger.info("No changes to commit, skipping PR creation")
        
        # Finalize workflow
        end_time = datetime.utcnow().isoformat()
        workflow_progress.end_time = end_time
        
        result = {
            "workflow_id": workflow_id,
            "status": workflow_progress.workflow_status,
            "repository": {
                "url": repo_data.get("url"),
                "owner": repo_data.get("owner"),
                "repo": repo_data.get("repo")
            },
            "results": {
                "iterations_completed": workflow_progress.total_iterations,
                "max_iterations": max_iterations,
                "total_fixes_applied": workflow_progress.total_fixes_applied,
                "total_manual_items": workflow_progress.total_manual_items,
                "convergence_achieved": convergence_metrics.convergence_achieved,
                "convergence_reason": convergence_metrics.convergence_reason,
                "convergence_score": convergence_metrics.convergence_score
            },
            "pr": {
                "created": pr_created,
                "url": pr_url
            },
            "timing": {
                "start_time": start_time,
                "end_time": end_time
            },
            "report_summary": report_summary
        }
        
        # Store workflow progress in workflows store
        workflows_store[workflow_id] = asdict(workflow_progress)
        
        return result
        
    except Exception as e:
        logger.error(f"Workflow failed: {str(e)}", exc_info=True)
        workflow_progress.workflow_status = "failed"
        workflow_progress.end_time = datetime.utcnow().isoformat()
        
        return {
            "workflow_id": workflow_id,
            "status": "failed",
            "error": str(e),
            "timing": {
                "start_time": start_time,
                "end_time": workflow_progress.end_time
            }
        }


def start_local_workflow(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Start local/S3 workflow (scan-only, no PR creation)
    
    Payload:
    {
        "action": "start_local_workflow",
        "source_type": "local" or "s3",
        "source_path": "/path/to/terraform" or "s3://bucket/path",
        "workflow_configuration": {...}
    }
    """
    workflow_id = str(uuid.uuid4())
    start_time = datetime.utcnow().isoformat()
    
    source_type = payload.get("source_type")
    source_path = payload.get("source_path")
    config = payload.get("workflow_configuration", {})
    
    if not source_type or not source_path:
        return {"error": "source_type and source_path are required"}
    
    logger.info(f"Starting local workflow {workflow_id} for {source_type}:{source_path}")
    
    try:
        # For local workflows, we skip GitHub integration
        # Just scan and remediate in place
        
        max_iterations = config.get("max_iterations", 5)
        iteration = 0
        total_fixes = 0
        total_manual_items = 0
        convergence_achieved = False
        convergence_reason = ""
        
        while iteration < max_iterations:
            iteration += 1
            logger.info(f"Local workflow iteration {iteration}/{max_iterations}")
            
            # Scan
            scan_result = communicator.call_agent("checkov_scanner", {
                "action": "scan",
                "folder_path": source_path,
                "scan_options": {
                    "frameworks": ["terraform"],
                    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
                }
            })
            
            total_findings = scan_result.get("total_findings", 0)
            if total_findings == 0:
                convergence_achieved = True
                convergence_reason = "No security issues found"
                break
            
            # Remediate
            scan_id = scan_result.get("scan_id")
            remediation_result = communicator.call_agent("terraform_remediation", {
                "action": "remediate",
                "scan_id": scan_id,
                "scan_results": scan_result,
                "remediation_config": config
            })
            
            fixes = remediation_result.get("fixes", [])
            manual_items = remediation_result.get("manual_interventions", [])
            
            total_fixes += len(fixes)
            total_manual_items += len(manual_items)
            
            if len(fixes) == 0:
                convergence_achieved = True
                convergence_reason = "No auto-fixes applied"
                break
        
        return {
            "workflow_id": workflow_id,
            "status": "completed",
            "source": {
                "type": source_type,
                "path": source_path
            },
            "results": {
                "iterations_completed": iteration,
                "total_fixes_applied": total_fixes,
                "total_manual_items": total_manual_items,
                "convergence_achieved": convergence_achieved,
                "convergence_reason": convergence_reason
            },
            "note": "Local workflow - no PR created",
            "timing": {
                "start_time": start_time,
                "end_time": datetime.utcnow().isoformat()
            }
        }
        
    except Exception as e:
        logger.error(f"Local workflow failed: {str(e)}", exc_info=True)
        return {
            "workflow_id": workflow_id,
            "status": "failed",
            "error": str(e)
        }


def handle_github_webhook(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle GitHub webhook event
    
    Payload:
    {
        "action": "handle_webhook",
        "webhook_data": {
            "repository": {...},
            "ref": "refs/heads/main",
            "commits": [...]
        }
    }
    """
    webhook_data = payload.get("webhook_data", {})
    
    # Extract repository info from webhook
    repo_info = webhook_data.get("repository", {})
    owner = repo_info.get("owner", {}).get("login")
    repo_name = repo_info.get("name")
    clone_url = repo_info.get("clone_url")
    
    # Extract branch from ref
    ref = webhook_data.get("ref", "")
    branch = ref.replace("refs/heads/", "") if ref.startswith("refs/heads/") else "main"
    
    # Check if Terraform files were modified
    commits = webhook_data.get("commits", [])
    has_terraform_changes = any(
        any(".tf" in f for f in commit.get("added", []) + commit.get("modified", []))
        for commit in commits
    )
    
    if not has_terraform_changes:
        return {
            "status": "skipped",
            "message": "No Terraform files modified",
            "repository": f"{owner}/{repo_name}"
        }
    
    # Start workflow
    return start_workflow({
        "action": "start_workflow",
        "repository_data": {
            "url": clone_url,
            "owner": owner,
            "repo": repo_name,
            "source_branch": branch
        },
        "workflow_configuration": {
            "max_iterations": 5,
            "auto_fix_enabled": True,
            "manual_guidance_enabled": True
        }
    })


# In-memory workflow storage (for sandbox - would use DynamoDB in production)
workflows_store = {}


def get_workflow_status(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get workflow status
    
    Payload:
    {
        "action": "get_status",
        "workflow_id": "uuid"
    }
    """
    workflow_id = payload.get("workflow_id")
    
    if not workflow_id:
        return {"error": "workflow_id is required"}
    
    workflow = workflows_store.get(workflow_id)
    
    if not workflow:
        return {
            "error": "Workflow not found",
            "workflow_id": workflow_id
        }
    
    return workflow


def get_workflow_report_endpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get detailed workflow report
    
    Payload:
    {
        "action": "get_report",
        "workflow_id": "uuid"
    }
    """
    workflow_id = payload.get("workflow_id")
    
    if not workflow_id:
        return {"error": "workflow_id is required"}
    
    report = get_workflow_report(workflow_id)
    
    if not report:
        return {
            "error": "Workflow not found or report not available",
            "workflow_id": workflow_id
        }
    
    return report


def list_workflows(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    List all workflows
    
    Payload:
    {
        "action": "list_workflows",
        "status": "completed" (optional filter),
        "limit": 50 (optional)
    }
    """
    status_filter = payload.get("status")
    limit = payload.get("limit", 50)
    
    workflows = []
    for wf_id, wf_data in workflows_store.items():
        if status_filter and wf_data.get("status") != status_filter:
            continue
        workflows.append({
            "workflow_id": wf_id,
            "status": wf_data.get("status"),
            "repository": wf_data.get("repository"),
            "start_time": wf_data.get("timing", {}).get("start_time")
        })
        if len(workflows) >= limit:
            break
    
    return {
        "workflows": workflows,
        "total_count": len(workflows)
    }


def health_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Health check with agent status tracking
    
    Payload:
    {
        "action": "health_check",
        "check_agents": true (optional - check all connected agents)
    }
    """
    check_agents = payload.get("check_agents", False)
    
    health_response = {
        "status": "healthy",
        "orchestrator": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "communication_mode": "A2A" if USE_A2A else "HTTP"
    }
    
    # Check connected agents if requested
    if check_agents:
        agents_health = {}
        
        for agent_name in ["checkov_scanner", "terraform_remediation", "github_integration"]:
            try:
                # Simple ping - just check if agent responds
                result = communicator.call_agent_with_retry(agent_name, {"action": "health"})
                
                if result.success:
                    agents_health[agent_name] = {
                        "status": "healthy",
                        "response_time": result.total_duration,
                        "retry_count": result.retry_count
                    }
                else:
                    agents_health[agent_name] = {
                        "status": "unhealthy",
                        "error": result.error_message,
                        "retry_count": result.retry_count
                    }
                    health_response["status"] = "degraded"
                    
            except Exception as e:
                agents_health[agent_name] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
                health_response["status"] = "degraded"
        
        health_response["agents"] = agents_health
        
        # Add circuit breaker status
        health_response["circuit_breakers"] = {
            agent_name: communicator._is_circuit_breaker_open(agent_name)
            for agent_name in ["checkov_scanner", "terraform_remediation", "github_integration"]
        }
    
    return health_response


def get_agent_info(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get agent information
    
    Payload:
    {
        "action": "get_info"
    }
    """
    return {
        "agent_name": "orchestrator",
        "version": "1.0.0-agentcore-enhanced",
        "capabilities": [
            "start_workflow",
            "start_local_workflow",
            "handle_webhook",
            "get_status",
            "get_report",
            "list_workflows",
            "health_check"
        ],
        "features": [
            "retry_logic",
            "circuit_breaker",
            "convergence_metrics",
            "iteration_tracking",
            "report_generation",
            "health_monitoring"
        ],
        "communication_mode": "A2A" if USE_A2A else "HTTP",
        "connected_agents": {
            "checkov_scanner": CHECKOV_SCANNER_ARN if USE_A2A else CHECKOV_SCANNER_URL,
            "terraform_remediation": TERRAFORM_REMEDIATION_ARN if USE_A2A else TERRAFORM_REMEDIATION_URL,
            "github_integration": GITHUB_INTEGRATION_ARN if USE_A2A else GITHUB_INTEGRATION_URL
        },
        "retry_config": {
            "max_retries": communicator.max_retries,
            "retry_delay": communicator.retry_delay,
            "retry_backoff": communicator.retry_backoff
        },
        "circuit_breaker_config": {
            "threshold": communicator.circuit_breaker_threshold,
            "timeout": communicator.circuit_breaker_timeout
        },
        "timeouts": communicator.timeouts
    }


if __name__ == "__main__":
    # For local testing
    app.run()
