# Orchestrator Agent

AWS Bedrock AgentCore agent that coordinates the Terraform security remediation workflow across multiple agents with enhanced reliability and reporting.

## Overview

The orchestrator manages the complete workflow:
1. Calls GitHub Agent to clone repo and upload to S3
2. Iteratively calls Checkov Scanner and Remediation agents with convergence tracking
3. Generates comprehensive reports with security metrics
4. Calls GitHub Agent to create PR with detailed findings

**Key Role**: Workflow coordination, `workflow_id` management, convergence detection, and reporting

## Key Features

- **Retry Logic**: 3 attempts with exponential backoff (1s, 2s, 4s)
- **Circuit Breaker**: Opens after 5 consecutive failures, resets after 5 minutes
- **Convergence Metrics**: Tracks issue reduction, fix stability, and progress trends
- **Iteration Tracking**: Detailed metrics for each scan-fix cycle
- **Report Generation**: Comprehensive security metrics and improvement scores
- **Health Monitoring**: Agent status tracking with response times
- **Configurable Timeouts**: Scanner 90s, Remediation 600s, GitHub 45s

## Architecture

### Workflow Coordination

```
Orchestrator
├─> GitHub Agent (setup)
│   └─ Uploads to S3: workflows/{workflow_id}/github-agent/data.tar.gz
│
├─> Loop (max 5 iterations, until convergence):
│   │
│   ├─> Checkov Agent (scan)
│   │   ├─ Receives: workflow_id, iteration number
│   │   ├─ Downloads repository from S3
│   │   ├─ Uploads results to S3: scan_results_iteration_N.json
│   │   └─ Returns: scan results in response payload
│   │
│   ├─> Orchestrator stores scan results in memory
│   │
│   ├─> Remediation Agent (fix)
│   │   ├─ Receives: workflow_id, scan results in payload
│   │   ├─ Downloads repository from S3
│   │   ├─ Applies fixes based on scan results from payload
│   │   ├─ Uploads fixed code to S3
│   │   └─ Returns: remediation summary in response payload
│   │
│   └─> Orchestrator checks convergence:
│       ├─ No issues? Exit loop
│       ├─ No auto-fixes? Exit loop
│       ├─ Convergence score ≥ 0.85? Exit loop
│       └─ Max iterations? Exit loop
│
└─> GitHub Agent (create_pr)
    └─ Downloads fixed code from S3, creates PR with detailed report
```

**Data Flow**:
- S3 is used for repository storage (code files)
- Payloads are used for scan results and remediation summaries
- Orchestrator acts as the data broker between agents
- Iteration history is preserved in S3 for audit trail

### S3 Integration

The orchestrator **doesn't use S3 directly** - it:
- Generates unique `workflow_id` for each workflow
- Passes `workflow_id` to all agents for S3 coordination
- Passes `iteration` number to checkov scanner for scan history tracking
- Receives scan results from checkov in response payload
- Passes scan results to remediation agent in request payload
- Agents use `workflow_id` to download/upload data via S3

## Files

- `main.py` - Orchestrator implementation
- `requirements.txt` - Python dependencies
- `Dockerfile` - Docker image definition
- `deploy.py` - Deployment script
- `.dockerignore` - Docker exclusions

## Prerequisites

1. **Other Agents Deployed**:
   - GitHub Integration Agent
   - Checkov Scanner Agent
   - Terraform Remediation Agent

2. **S3 Bucket**: Run from parent directory:
   ```bash
   cd ../
   ./setup_s3_storage.sh
   ```

3. **IAM Permissions**: Orchestrator role needs:
   - Bedrock AgentCore: Invoke other agents
   - CloudWatch: Logs access
   - ECR: Read access

## Build & Deployment

### Deploy

```bash
python3 deploy.py
```

This script:
- Creates ECR repository
- Builds Docker image from parent directory
- Pushes to ECR
- Creates/updates AgentCore runtime with required permissions

### Verify

```bash
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
```

## Configuration

### Agent ARNs

Set environment variables or update in code:

```python
# For A2A communication
CHECKOV_SCANNER_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/checkov-ID"
TERRAFORM_REMEDIATION_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/remediation-ID"
GITHUB_INTEGRATION_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/github-ID"
```

### Communication Mode

```bash
# Use A2A protocol (for AgentCore)
export USE_A2A=true

# Use HTTP (for local testing)
export USE_A2A=false
```

## Usage

### Start Workflow

```python
payload = {
    "action": "start_workflow",
    "repository_data": {
        "owner": "org-name",
        "repo": "repo-name",
        "url": "https://github.com/org/repo.git",
        "source_branch": "main",
        "github_token": "ghp_..."
    },
    "workflow_configuration": {
        "max_iterations": 5,
        "auto_fix_enabled": True,
        "manual_guidance_enabled": True
    }
}
```

**Response:**
```json
{
  "workflow_id": "abc123-def456",
  "status": "completed",
  "results": {
    "iterations_completed": 2,
    "total_fixes_applied": 5,
    "total_manual_items": 2,
    "convergence_achieved": true
  },
  "pr": {
    "created": true,
    "url": "https://github.com/org/repo/pull/123"
  }
}
```

### Get Workflow Status

```python
payload = {
    "action": "get_status",
    "workflow_id": "abc123-def456"
}
```

### List Workflows

```python
payload = {
    "action": "list_workflows",
    "status": "completed",  # Optional filter
    "limit": 50
}
```

## Actions

1. **start_workflow** - Execute complete remediation workflow with convergence tracking
2. **start_local_workflow** - Scan-only workflow (no GitHub)
3. **handle_webhook** - Process GitHub webhook events
4. **get_status** - Get workflow status by ID
5. **get_report** - Get detailed workflow report with security metrics
6. **list_workflows** - List all workflows
7. **health_check** - Health check with optional agent status monitoring
8. **get_info** - Agent information including retry/circuit breaker config

## Enhanced Workflow Logic

### Convergence Detection

The workflow uses a multi-factor convergence score (0.0-1.0):
- **Issue Reduction** (50%): Progress in resolving security issues
- **Fix Stability** (30%): Consistency of fixes across iterations
- **Diminishing Returns** (20%): Detection of minimal progress

**Convergence achieved when:**
- No security issues found
- No auto-fixes applied by remediation agent
- Convergence score ≥ 0.85
- Max iterations reached

### Iteration Tracking

Each iteration records:
- Scan results with total findings
- Remediation results (auto-fixes and manual items)
- Fixes applied count
- Manual interventions count
- Iteration duration
- Convergence metrics
- Timestamp

### Retry Logic

**Per-agent retry configuration:**
```python
max_retries = 3
retry_delay = 1.0  # seconds
retry_backoff = 2.0  # exponential multiplier
```

**Retry sequence:** 1s → 2s → 4s

### Circuit Breaker

**Protection against cascading failures:**
```python
circuit_breaker_threshold = 5  # consecutive failures
circuit_breaker_timeout = 300  # seconds (5 minutes)
```

When open, agent calls fail immediately until timeout expires.

### Timeouts

**Agent-specific timeouts:**
- Checkov Scanner: 90 seconds
- Terraform Remediation: 600 seconds (10 minutes for LLM operations)
- GitHub Integration: 45 seconds

## Report Generation

### Workflow Report

Generated for each completed workflow:

```json
{
  "workflow_id": "abc123-def456",
  "total_issues_found": 15,
  "critical_issues": 2,
  "high_issues": 5,
  "medium_issues": 6,
  "low_issues": 2,
  "auto_fixes_applied": 10,
  "manual_interventions_required": 5,
  "fix_success_rate": 66.7,
  "security_improvement_score": 85.3,
  "total_iterations": 3,
  "final_status": "completed"
}
```

### PR Body

Comprehensive PR description includes:
- Summary with fixes and manual items
- Convergence metrics and score
- Security metrics (improvement %, fix success rate)
- Severity breakdown
- Iteration-by-iteration breakdown
- Workflow details and timestamps

### Iteration Example

```
Iteration 1:
  Scan: 10 issues found
  Remediate: 7 auto-fixed, 3 manual
  Convergence Score: 0.45
  Duration: 125.3s
  
Iteration 2:
  Scan: 3 issues found (manual items)
  Remediate: 0 auto-fixed, 3 manual
  Convergence Score: 0.87
  Convergence: No auto-fixes applied
  Duration: 45.2s

Result:
  Total Fixes: 7
  Total Manual Items: 6
  Security Improvement: 70%
  Fix Success Rate: 70%
```

## Enhanced Usage

### Start Workflow with Tracking

```python
payload = {
    "action": "start_workflow",
    "repository_data": {
        "owner": "org-name",
        "repo": "repo-name",
        "url": "https://github.com/org/repo.git",
        "source_branch": "main",
        "github_token": "ghp_..."
    },
    "workflow_configuration": {
        "max_iterations": 5,
        "auto_fix_enabled": True,
        "manual_guidance_enabled": True
    }
}
```

**Enhanced Response:**
```json
{
  "workflow_id": "abc123-def456",
  "status": "completed",
  "results": {
    "iterations_completed": 2,
    "total_fixes_applied": 7,
    "total_manual_items": 6,
    "convergence_achieved": true,
    "convergence_reason": "No auto-fixes applied by remediation agent",
    "convergence_score": 0.87
  },
  "pr": {
    "created": true,
    "url": "https://github.com/org/repo/pull/123"
  },
  "report_summary": {
    "total_issues_found": 10,
    "security_improvement_score": 70.0,
    "fix_success_rate": 70.0,
    "critical_issues": 2,
    "high_issues": 3
  }
}
```

### Get Detailed Report

```python
payload = {
    "action": "get_report",
    "workflow_id": "abc123-def456"
}
```

**Response:**
```json
{
  "workflow_id": "abc123-def456",
  "total_issues_found": 10,
  "critical_issues": 2,
  "high_issues": 3,
  "medium_issues": 4,
  "low_issues": 1,
  "auto_fixes_applied": 7,
  "manual_interventions_required": 6,
  "fix_success_rate": 70.0,
  "security_improvement_score": 70.0,
  "total_iterations": 2,
  "final_status": "completed"
}
```

### Health Check with Agent Status

```python
payload = {
    "action": "health_check",
    "check_agents": true
}
```

**Response:**
```json
{
  "status": "healthy",
  "orchestrator": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "communication_mode": "A2A",
  "agents": {
    "checkov_scanner": {
      "status": "healthy",
      "response_time": 0.234,
      "retry_count": 0
    },
    "terraform_remediation": {
      "status": "healthy",
      "response_time": 1.456,
      "retry_count": 0
    },
    "github_integration": {
      "status": "healthy",
      "response_time": 0.567,
      "retry_count": 0
    }
  },
  "circuit_breakers": {
    "checkov_scanner": false,
    "terraform_remediation": false,
    "github_integration": false
  }
}
```

### Get Agent Info

```python
payload = {
    "action": "get_info"
}
```

**Response:**
```json
{
  "agent_name": "orchestrator",
  "version": "1.0.0-agentcore-enhanced",
  "capabilities": [
    "start_workflow",
    "start_local_workflow",
    "handle_webhook",
    "get_status",
    "get_report",
    "list_workflows",
    "health_check"
  ],
  "features": [
    "retry_logic",
    "circuit_breaker",
    "convergence_metrics",
    "iteration_tracking",
    "report_generation",
    "health_monitoring"
  ],
  "retry_config": {
    "max_retries": 3,
    "retry_delay": 1.0,
    "retry_backoff": 2.0
  },
  "circuit_breaker_config": {
    "threshold": 5,
    "timeout": 300
  },
  "timeouts": {
    "checkov_scanner": 90.0,
    "terraform_remediation": 600.0,
    "github_integration": 45.0
  }
}
```

## Integration

### Agent Communication

**A2A Protocol (AgentCore):**
```python
client = boto3.client('bedrock-agentcore')
response = client.invoke_agent_runtime(
    agentRuntimeArn=agent_arn,
    payload=json.dumps(payload)
)
```

**HTTP (Local Testing):**
```python
import httpx
response = httpx.post(f"{agent_url}/invoke", json=payload)
```

### Workflow ID Management

```python
# Generate unique ID
workflow_id = str(uuid.uuid4())

# Add to all agent calls
repo_data['workflow_id'] = workflow_id

# Agents use it for S3 coordination
s3_key = f"workflows/{workflow_id}/agent-name/data.tar.gz"
```

## Troubleshooting

### Agent Not Found

**Cause**: Agent ARN not configured or incorrect

**Fix**: Update agent ARNs in environment variables or code

### Communication Timeout

**Cause**: Agent taking too long to respond

**Fix**: 
- Check agent logs for performance issues
- Timeouts are pre-configured per agent type
- Remediation agent has 10-minute timeout for LLM operations

### Circuit Breaker Open

**Cause**: Agent has failed 5+ consecutive times

**Fix**:
- Check agent health: `{"action": "health_check", "check_agents": true}`
- Wait 5 minutes for automatic reset
- Fix underlying agent issue
- Circuit breaker will reset on successful call

### Workflow Stuck

**Cause**: Infinite loop or agent failure

**Fix**: 
- Check max_iterations setting (default: 5)
- Review convergence metrics in workflow status
- Check agent logs for failures
- Use retry logic to handle transient failures

### Low Convergence Score

**Cause**: Workflow not making sufficient progress

**Fix**:
- Review remediation agent effectiveness
- Check if issues are auto-fixable
- Increase max_iterations if needed
- Review manual intervention items

### S3 Access Issues

**Cause**: Agents don't have S3 permissions

**Fix**: Run `../setup_s3_storage.sh` to configure IAM

## Monitoring

### CloudWatch Logs

```bash
aws logs tail /aws/bedrock-agentcore/runtimes/orchestrator_agent-ID-DEFAULT \
  --region us-east-1 --since 5m --follow
```

### Workflow Metrics

Track these key metrics:
- **Iterations per workflow**: Average convergence speed
- **Convergence rate**: % of workflows achieving convergence
- **Convergence score**: Average score across workflows
- **Auto-fix success rate**: % of issues auto-fixed
- **Security improvement**: Average improvement score
- **Average workflow duration**: End-to-end timing
- **Retry rate**: % of calls requiring retries
- **Circuit breaker activations**: Frequency of failures

### Performance Monitoring

```python
# Example: Track workflow performance
{
  "workflow_id": "abc123",
  "total_duration": 180.5,  # seconds
  "iterations": 2,
  "avg_iteration_duration": 90.25,
  "retry_count": 1,
  "circuit_breaker_triggered": false
}
```

## Development

### Local Testing

Test with HTTP mode:
```bash
export USE_A2A=false
export CHECKOV_SCANNER_URL=http://localhost:8000
export TERRAFORM_REMEDIATION_URL=http://localhost:8001
export GITHUB_INTEGRATION_URL=http://localhost:8002

# Run orchestrator
python3 main.py
```

### Testing Retry Logic

Simulate failures to test retry behavior:
```python
# Agent will retry 3 times with exponential backoff
# 1st retry: 1 second delay
# 2nd retry: 2 second delay
# 3rd retry: 4 second delay
```

### Testing Circuit Breaker

```python
# Trigger 5 consecutive failures to open circuit breaker
# Circuit breaker opens for 5 minutes
# Check status: {"action": "health_check", "check_agents": true}
```

### Adding New Actions

1. Add function in `main.py`
2. Add case in `invoke()` entrypoint
3. Update README documentation
4. Update agent info capabilities list
5. Redeploy

## Data Classes

### WorkflowProgress

Tracks complete workflow state:
```python
@dataclass
class WorkflowProgress:
    workflow_id: str
    repository_data: Dict[str, Any]
    total_iterations: int
    max_iterations: int
    iterations: List[IterationResult]
    convergence_metrics: Optional[ConvergenceMetrics]
    final_scan_results: Optional[Dict[str, Any]]
    pr_created: bool
    workflow_status: str
    start_time: str
    end_time: Optional[str]
    total_fixes_applied: int
    total_manual_items: int
```

### IterationResult

Tracks single iteration:
```python
@dataclass
class IterationResult:
    iteration_number: int
    scan_results: Dict[str, Any]
    remediation_results: Dict[str, Any]
    fixes_applied: int
    manual_items_added: int
    convergence_achieved: bool
    iteration_duration: float
    timestamp: str
```

### ConvergenceMetrics

Tracks convergence progress:
```python
@dataclass
class ConvergenceMetrics:
    fixes_applied_trend: List[int]
    remaining_issues_trend: List[int]
    convergence_score: float
    convergence_achieved: bool
    convergence_reason: str
```

### CommunicationResult

Tracks agent communication:
```python
@dataclass
class CommunicationResult:
    success: bool
    response_data: Optional[Dict[str, Any]]
    status_code: Optional[int]
    error_message: Optional[str]
    retry_count: int
    total_duration: float
    agent_name: str
```

## Related Documentation

- `../github_integration/README.md` - GitHub Agent
- `../checkov_scanner/` - Scanner Agent
- `../terraform_remediation/` - Remediation Agent
- `../S3_STORAGE_MIGRATION.md` - S3 architecture
- `../../agents/orchestrator/workflow_engine.py` - Reference implementation
- `../../agents/orchestrator/agent_communication.py` - Reference implementation
- `../../agents/orchestrator/reporting.py` - Reference implementation
