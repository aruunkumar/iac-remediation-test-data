#!/usr/bin/env python3
"""
Comprehensive test suite for Orchestrator Agent on AWS Bedrock AgentCore
"""
import boto3
import json
import time
import os
import sys

def test_orchestrator():
    """Test the Orchestrator Agent with all capabilities"""
    
    # Initialize Bedrock AgentCore client with extended timeout
    from botocore.config import Config
    config = Config(read_timeout=600)  # 10 minutes for long-running workflows
    client = boto3.client('bedrock-agentcore', region_name='us-east-1', config=config)
    
    # Agent runtime ARN
    agent_runtime_arn = os.getenv(
        "ORCHESTRATOR_ARN",
        "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/orchestrator_agent-2tbgPPHQ1y"
    )
    
    # Get GitHub token from environment
    github_token = os.getenv('GITHUB_TOKEN', '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')
    
    if not github_token:
        print("⚠️  No GITHUB_TOKEN set - GitHub agent will use Secrets Manager or fail")
    else:
        print("✓ Using GITHUB_TOKEN from environment (will be passed to GitHub agent)")
    
    print("=" * 70)
    print("🚀 Orchestrator Agent - Comprehensive Test Suite")
    print("=" * 70)
    print(f"Agent ARN: {agent_runtime_arn}")
    print()
    
    results = []
    
    # Test 1: Health Check
    print("📋 Test 1: Health Check")
    print("-" * 70)
    try:
        payload = {"action": "health_check"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        status = result.get('status', 'unknown')
        orchestrator_status = result.get('orchestrator', 'unknown')
        agents = result.get('agents', {})
        
        print(f"✅ Overall Status: {status}")
        print(f"✅ Orchestrator: {orchestrator_status}")
        print(f"✅ Connected Agents:")
        for agent_name, agent_status in agents.items():
            status_icon = "✅" if "healthy" in str(agent_status).lower() else "⚠️"
            print(f"   {status_icon} {agent_name}: {agent_status}")
        
        results.append(("Health Check", orchestrator_status == "healthy"))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Health Check", False))
    print()
    time.sleep(1)
    
    # Test 2: Agent Info
    print("📋 Test 2: Agent Info")
    print("-" * 70)
    try:
        payload = {"action": "get_info"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        print(f"✅ Agent: {result.get('agent_name', 'unknown')} v{result.get('version', 'unknown')}")
        capabilities = result.get('capabilities', [])
        print(f"✅ Capabilities ({len(capabilities)}):")
        for cap in capabilities:
            print(f"   • {cap}")
        
        comm_mode = result.get('communication_mode', 'unknown')
        print(f"✅ Communication Mode: {comm_mode}")
        
        results.append(("Agent Info", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Agent Info", False))
    print()
    time.sleep(1)
    
    # Test 3: List Workflows
    print("📋 Test 3: List Workflows")
    print("-" * 70)
    try:
        payload = {
            "action": "list_workflows",
            "limit": 5
        }
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        workflows = result.get('workflows', [])
        total_count = result.get('total_count', 0)
        
        print(f"✅ Total workflows: {total_count}")
        if workflows:
            print(f"✅ Recent workflows:")
            for wf in workflows[:3]:
                print(f"   • {wf.get('workflow_id', 'N/A')[:16]}... - {wf.get('status', 'unknown')}")
        else:
            print("   (No workflows yet)")
        
        results.append(("List Workflows", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("List Workflows", False))
    print()
    time.sleep(1)
    
    # Test 5: Workflow Step 1 - GitHub Clone & S3 Upload
    print("📋 Test 5: Workflow Step 1 - GitHub Clone & S3 Upload")
    print("-" * 70)
    print("Testing orchestrator → github agent communication")
    print()
    
    # Get GitHub token
    test_github_token = os.getenv('GITHUB_TOKEN', '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')
    
    try:
        # Load workflow config
        workflow_file = os.path.join(os.path.dirname(__file__), 'test-orchestrator-workflow.json')
        with open(workflow_file, 'r') as f:
            workflow_config = json.load(f)
        
        # Update with token
        workflow_config['repository_data']['github_token'] = test_github_token
        
        # Modify to stop after first step (we'll catch the error from missing agents)
        workflow_config['workflow_configuration']['max_iterations'] = 1
        
        print(f"Repository: {workflow_config['repository_data']['owner']}/{workflow_config['repository_data']['repo']}")
        print(f"Branch: {workflow_config['repository_data']['source_branch']}")
        print()
        print("🚀 Starting workflow (will fail at scan step - expected)...")
        
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(workflow_config)
        )
        result = json.loads(response['response'].read())
        
        # Check if workflow started and called GitHub agent
        workflow_id = result.get('workflow_id')
        status = result.get('status')
        error = result.get('error', '')
        
        print(f"Status: {status}")
        print(f"Workflow ID: {workflow_id}")
        
        # Success criteria: GitHub agent was called (even if workflow failed later)
        if workflow_id:
            print(f"✅ Workflow started with ID: {workflow_id}")
            
            # Check if error mentions checkov (means GitHub step succeeded)
            if 'checkov' in error.lower() or 'scanner' in error.lower():
                print(f"✅ GitHub agent step completed (failed at scan step as expected)")
                print(f"   Error: {error[:100]}...")
                
                # Verify S3 data was created
                print()
                print("🔍 Checking S3 for uploaded repository...")
                s3_client = boto3.client('s3')
                try:
                    response = s3_client.list_objects_v2(
                        Bucket='terraform-security-platform-storage',
                        Prefix=f'workflows/{workflow_id}/github-agent/'
                    )
                    if response.get('Contents'):
                        print(f"✅ S3 data found:")
                        for obj in response['Contents']:
                            size_kb = obj['Size'] / 1024
                            print(f"   • {obj['Key'].split('/')[-1]} ({size_kb:.1f} KB)")
                        results.append(("Workflow Step 1", True))
                    else:
                        print(f"⚠️  No S3 data found for workflow {workflow_id}")
                        results.append(("Workflow Step 1", False))
                except Exception as e:
                    print(f"⚠️  Could not check S3: {e}")
                    results.append(("Workflow Step 1", True))  # Still pass if GitHub step worked
            else:
                print(f"⚠️  Workflow failed before GitHub step: {error}")
                results.append(("Workflow Step 1", False))
        else:
            print(f"❌ Workflow did not start: {error}")
            results.append(("Workflow Step 1", False))
            
    except FileNotFoundError:
        print(f"❌ Workflow config file not found: test-orchestrator-workflow.json")
        results.append(("Workflow Step 1", False))
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        results.append(("Workflow Step 1", False))
    print()
    time.sleep(1)
    
    # Test 6: Full Workflow (if GitHub token provided and user confirms)
    if github_token and github_token != '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':
        print("📋 Test 6: Full Workflow Execution (All Agents)")
        print("-" * 70)
        print("⚠️  This test requires ALL agents deployed:")
        print("   • GitHub Integration Agent ✅")
        print("   • Checkov Scanner Agent ❌")
        print("   • Terraform Remediation Agent ❌")
        print()
        print("⏭️  Skipping - Deploy other agents first")
        results.append(("Full Workflow", None))
        print()
    else:
        print("📋 Test 6: Full Workflow Execution (All Agents)")
        print("-" * 70)
        print("⏭️  Skipped - Requires all agents deployed and valid GitHub token")
        results.append(("Full Workflow", None))
        print()
    
    # Test 4: Error Handling
    print("📋 Test 7: Error Handling (Invalid Action)")
    print("-" * 70)
    try:
        payload = {"action": "invalid_action_xyz"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if 'error' in result:
            print(f"✅ Error handling works: {result.get('error')}")
            results.append(("Error Handling", True))
        else:
            print(f"❌ Expected error but got: {result}")
            results.append(("Error Handling", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Error Handling", False))
    print()
    time.sleep(1)
    
    # Test 5: Full Workflow (if GitHub token provided)
    if github_token:
        print("📋 Test 5: Full Workflow Execution")
        print("-" * 70)
        print("⚠️  This test will:")
        print("   • Clone a real repository")
        print("   • Run security scans")
        print("   • Apply fixes")
        print("   • Create a pull request")
        print()
        
        # Load workflow configuration from JSON file
        try:
            workflow_file = os.path.join(os.path.dirname(__file__), 'test-orchestrator-workflow.json')
            with open(workflow_file, 'r') as f:
                workflow_payload = json.load(f)
            
            # Add GitHub token
            workflow_payload['repository_data']['github_token'] = github_token
            
            print(f"📄 Loaded workflow config from: test-orchestrator-workflow.json")
            print(f"   Repository: {workflow_payload['repository_data']['owner']}/{workflow_payload['repository_data']['repo']}")
            print(f"   Branch: {workflow_payload['repository_data']['source_branch']}")
            print(f"   Max Iterations: {workflow_payload['workflow_configuration']['max_iterations']}")
            print()
            print("🚀 Starting workflow execution...")
            print("-" * 70)
            
            start_time = time.time()
            
            response = client.invoke_agent_runtime(
                agentRuntimeArn=agent_runtime_arn,
                payload=json.dumps(workflow_payload)
            )
            result = json.loads(response['response'].read())
            
            elapsed_time = time.time() - start_time
            
            if result.get('status') == 'completed':
                print(f"\n✅ Workflow completed in {elapsed_time:.1f}s")
                print(f"✅ Workflow ID: {result.get('workflow_id', 'N/A')}")
                
                results_data = result.get('results', {})
                print(f"✅ Iterations: {results_data.get('iterations_completed', 0)}")
                print(f"✅ Fixes Applied: {results_data.get('total_fixes_applied', 0)}")
                print(f"✅ Manual Items: {results_data.get('total_manual_items', 0)}")
                print(f"✅ Convergence: {results_data.get('convergence_achieved', False)}")
                
                pr_data = result.get('pr', {})
                if pr_data.get('created'):
                    print(f"✅ PR Created: {pr_data.get('url', 'N/A')}")
                
                results.append(("Full Workflow", True))
            elif result.get('status') == 'failed':
                print(f"\n❌ Workflow failed: {result.get('error', 'Unknown error')}")
                results.append(("Full Workflow", False))
            else:
                print(f"\n⚠️  Unexpected status: {result.get('status')}")
                print(f"   Response: {json.dumps(result, indent=2)}")
                results.append(("Full Workflow", False))
                    
        except FileNotFoundError:
            print(f"❌ Workflow config file not found: test-orchestrator-workflow.json")
            results.append(("Full Workflow", False))
        except Exception as e:
            print(f"❌ Workflow failed: {str(e)}")
            import traceback
            traceback.print_exc()
            results.append(("Full Workflow", False))
        print()
    else:
        print("📋 Test 5: Full Workflow Execution")
        print("-" * 70)
        print("⏭️  Skipped - No GITHUB_TOKEN provided")
        print("   Set GITHUB_TOKEN environment variable to run workflow test")
        results.append(("Full Workflow", None))
        print()
    
    # Summary
    print("=" * 70)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success is True)
    failed = sum(1 for _, success in results if success is False)
    skipped = sum(1 for _, success in results if success is None)
    total = len(results)
    
    for test_name, success in results:
        if success is True:
            status = "✅ PASS"
        elif success is False:
            status = "❌ FAIL"
        else:
            status = "⏭️  SKIP"
        print(f"{status} - {test_name}")
    
    print()
    print(f"🎯 Overall: {passed} passed, {failed} failed, {skipped} skipped (out of {total} tests)")
    
    if failed == 0 and passed > 0:
        print("🎉 All executed tests passed! Orchestrator is functional.")
    elif passed > 0:
        print("⚠️  Some tests passed. Check details above.")
    else:
        print("❌ Tests failed. Check orchestrator configuration.")
    
    print()
    print("💡 View detailed logs:")
    print(f"   aws logs tail /aws/bedrock-agentcore/runtimes/orchestrator_agent-2tbgPPHQ1y-DEFAULT \\")
    print(f"     --region us-east-1 --since 5m --follow")
    print()
    
    return results

if __name__ == "__main__":
    test_orchestrator()
