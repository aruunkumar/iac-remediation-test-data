#!/usr/bin/env python3
"""
Deploy Orchestrator Agent to AWS Bedrock AgentCore
"""

import boto3
import subprocess
import sys
import json
import os
from datetime import datetime

# Configuration
AWS_REGION = "us-east-1"
AWS_ACCOUNT_ID = "545009861279"
ECR_REPO_NAME = "orchestrator-agent"
IMAGE_TAG = "latest"
RUNTIME_NAME = "orchestrator_agent"
ROLE_NAME = "orchestrator-agentcore-role"

def run_command(cmd, description):
    """Run a shell command and handle errors"""
    print(f"\n{description}...")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✓ {description} completed")
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"✗ {description} failed")
        print(f"Error: {e.stderr}")
        sys.exit(1)

def main():
    print("=" * 70)
    print("Orchestrator Agent - Deployment to AgentCore")
    print("=" * 70)
    
    # Change to script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    print(f"\nWorking directory: {os.getcwd()}")
    
    ecr_client = boto3.client('ecr', region_name=AWS_REGION)
    iam_client = boto3.client('iam')
    agentcore_client = boto3.client('bedrock-agentcore-control', region_name=AWS_REGION)
    
    # Step 1: Create ECR repository if needed
    print("\nStep 1: Checking ECR repository...")
    try:
        ecr_client.describe_repositories(repositoryNames=[ECR_REPO_NAME])
        print(f"✓ ECR repository '{ECR_REPO_NAME}' already exists")
    except ecr_client.exceptions.RepositoryNotFoundException:
        print(f"Creating ECR repository: {ECR_REPO_NAME}")
        ecr_client.create_repository(
            repositoryName=ECR_REPO_NAME,
            imageScanningConfiguration={'scanOnPush': True}
        )
        print(f"✓ ECR repository created")
    
    # Step 2: Build Docker image from parent directory
    image_uri = f"{AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com/{ECR_REPO_NAME}:{IMAGE_TAG}"
    
    # Build from parent directory
    parent_dir = os.path.dirname(script_dir)
    print(f"Building from: {parent_dir}")
    
    # Change to parent directory and build
    original_dir = os.getcwd()
    os.chdir(parent_dir)
    
    run_command(
        f"finch build --platform linux/arm64 -f orchestrator/Dockerfile -t {ECR_REPO_NAME}:{IMAGE_TAG} .",
        "Building Docker image for ARM64"
    )
    
    # Change back to original directory
    os.chdir(original_dir)
    
    # Step 3: Login to ECR
    run_command(
        f"aws ecr get-login-password --region {AWS_REGION} | "
        f"finch login --username AWS --password-stdin {AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com",
        "Logging in to ECR"
    )
    
    # Step 4: Tag image
    run_command(
        f"finch tag {ECR_REPO_NAME}:{IMAGE_TAG} {image_uri}",
        "Tagging image"
    )
    
    # Step 5: Push to ECR
    run_command(
        f"finch push {image_uri}",
        "Pushing image to ECR"
    )
    
    print(f"\n✓ Image URI: {image_uri}")
    
    # Step 6: Create IAM role if needed
    print("\nStep 6: Checking IAM role...")
    role_arn = f"arn:aws:iam::{AWS_ACCOUNT_ID}:role/{ROLE_NAME}"
    role_exists = False
    try:
        iam_client.get_role(RoleName=ROLE_NAME)
        print(f"✓ IAM role '{ROLE_NAME}' already exists")
        role_exists = True
    except iam_client.exceptions.NoSuchEntityException:
        print(f"Creating IAM role: {ROLE_NAME}")
        
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }]
        }
        
        iam_client.create_role(
            RoleName=ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy)
        )
        
        # Attach CloudWatch Logs policy
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
        )
        
        # Attach ECR read policy
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
        )
        
        # Attach Bedrock AgentCore invoke policy (to call other agents)
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/AmazonBedrockFullAccess"
        )
        
        # Create and attach S3 policy for workflow bucket access
        s3_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": [
                    "s3:GetObject",
                    "s3:PutObject",
                    "s3:ListBucket"
                ],
                "Resource": [
                    "arn:aws:s3:::terraform-security-platform-storage",
                    "arn:aws:s3:::terraform-security-platform-storage/*"
                ]
            }]
        }
        
        s3_policy_name = f"{ROLE_NAME}-s3-policy"
        try:
            iam_client.create_policy(
                PolicyName=s3_policy_name,
                PolicyDocument=json.dumps(s3_policy)
            )
            print(f"✓ Created S3 policy: {s3_policy_name}")
        except iam_client.exceptions.EntityAlreadyExistsException:
            print(f"✓ S3 policy already exists: {s3_policy_name}")
        
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn=f"arn:aws:iam::{AWS_ACCOUNT_ID}:policy/{s3_policy_name}"
        )
        
        print(f"✓ IAM role created with required permissions")
        print("⏳ Waiting 10 seconds for IAM role to propagate...")
        import time
        time.sleep(10)
    
    # Ensure S3 policy is attached (for both new and existing roles)
    if role_exists:
        print("\nEnsuring S3 permissions are attached...")
        s3_policy_name = f"{ROLE_NAME}-s3-policy"
        s3_policy_arn = f"arn:aws:iam::{AWS_ACCOUNT_ID}:policy/{s3_policy_name}"
        
        # Create S3 policy if it doesn't exist
        s3_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": [
                    "s3:GetObject",
                    "s3:PutObject",
                    "s3:ListBucket"
                ],
                "Resource": [
                    "arn:aws:s3:::terraform-security-platform-storage",
                    "arn:aws:s3:::terraform-security-platform-storage/*"
                ]
            }]
        }
        
        try:
            iam_client.create_policy(
                PolicyName=s3_policy_name,
                PolicyDocument=json.dumps(s3_policy)
            )
            print(f"✓ Created S3 policy: {s3_policy_name}")
        except iam_client.exceptions.EntityAlreadyExistsException:
            print(f"✓ S3 policy already exists: {s3_policy_name}")
        
        # Attach policy to role (idempotent operation)
        try:
            iam_client.attach_role_policy(
                RoleName=ROLE_NAME,
                PolicyArn=s3_policy_arn
            )
            print(f"✓ S3 policy attached to role")
        except Exception as e:
            print(f"⚠️  Could not attach S3 policy: {e}")
    
    # Step 7: Create or update AgentCore runtime
    print("\nStep 7: Creating/updating AgentCore runtime...")
    
    # Try to create, if it exists we'll get a conflict error
    try:
        print(f"Creating new runtime: {RUNTIME_NAME}")
        
        response = agentcore_client.create_agent_runtime(
            agentRuntimeName=RUNTIME_NAME,
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            },
            networkConfiguration={'networkMode': 'PUBLIC'},
            roleArn=role_arn
        )
        
        runtime_arn = response['agentRuntimeArn']
        print("✓ Runtime created")
        
    except agentcore_client.exceptions.ConflictException:
        print(f"Runtime '{RUNTIME_NAME}' already exists. Updating...")
        
        # List runtimes to find the ARN
        list_response = agentcore_client.list_agent_runtimes()
        runtime_arn = None
        for runtime in list_response.get('agentRuntimes', []):
            if runtime['agentRuntimeName'] == RUNTIME_NAME:
                runtime_arn = runtime['agentRuntimeArn']
                runtime_status = runtime.get('status')
                print(f"Found runtime: {runtime['agentRuntimeName']} (status: {runtime_status})")
                
                if runtime_status == 'DELETING':
                    print(f"⚠️  Runtime is being deleted. Please wait and try again.")
                    sys.exit(1)
                break
        
        if not runtime_arn:
            print(f"✗ Could not find runtime ARN for {RUNTIME_NAME}")
            print(f"Available runtimes: {[r['agentRuntimeName'] for r in list_response.get('agentRuntimes', [])]}")
            sys.exit(1)
        
        # Extract runtime ID from ARN
        runtime_id = runtime_arn.split('/')[-1]
        
        agentcore_client.update_agent_runtime(
            agentRuntimeId=runtime_id,
            roleArn=role_arn,
            networkConfiguration={'networkMode': 'PUBLIC'},
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            }
        )
        print("✓ Runtime updated")
    
    # Summary
    print("\n" + "=" * 70)
    print("DEPLOYMENT SUCCESSFUL!")
    print("=" * 70)
    print(f"\nRuntime ARN: {runtime_arn}")
    print(f"Image URI: {image_uri}")
    print(f"\nTest with:")
    print(f"  aws bedrock-agentcore invoke-agent-runtime \\")
    print(f"    --agent-runtime-arn {runtime_arn} \\")
    print(f"    --payload '{{\"action\":\"health_check\"}}' \\")
    print(f"    response.json")
    print()

if __name__ == "__main__":
    main()
