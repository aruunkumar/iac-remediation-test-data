#!/usr/bin/env python3
"""
Test suite for Checkov Scanner Agent on AWS Bedrock AgentCore
"""
import boto3
import json
import time
import os

def test_checkov_agent():
    """Test the Checkov Scanner Agent"""
    
    client = boto3.client('bedrock-agentcore', region_name='us-east-1')
    
    # Agent runtime ARN
    agent_runtime_arn = os.getenv(
        "CHECKOV_ARN",
        "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/checkov_scanner-FwURrtD7GD"
    )
    
    print("=" * 70)
    print("🔍 Checkov Scanner Agent - Test Suite")
    print("=" * 70)
    print(f"Agent ARN: {agent_runtime_arn}")
    print()
    
    results = []
    
    # Test 1: Health Check
    print("📋 Test 1: Health Check")
    print("-" * 70)
    try:
        payload = {"action": "health"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        print(f"✅ Status: {result.get('status')}")
        print(f"✅ Agent: {result.get('agent')} v{result.get('version')}")
        print(f"✅ Scans in memory: {result.get('scans_in_memory', 0)}")
        
        results.append(("Health Check", result.get('status') == 'healthy'))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Health Check", False))
    print()
    time.sleep(1)
    
    # Test 2: List Scans (empty)
    print("📋 Test 2: List Scans")
    print("-" * 70)
    try:
        payload = {"action": "list_scans", "limit": 10}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        print(f"✅ Total scans: {result.get('total_count', 0)}")
        if result.get('scans'):
            for scan in result['scans'][:3]:
                print(f"   • {scan.get('scan_id')[:16]}... - {scan.get('status')}")
        else:
            print("   (No scans yet)")
        
        results.append(("List Scans", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("List Scans", False))
    print()
    time.sleep(1)
    
    # Test 3: Scan from S3 (Real Repository Test)
    print("📋 Test 3: Scan from S3 (Real Repository)")
    print("-" * 70)
    try:
        # Use the latest workflow data from previous e2e test
        workflow_id = "d3978da9-c419-4686-a3a1-8ee501d8f050"
        
        print(f"Testing S3 scan with workflow: {workflow_id}")
        print("This will download from S3 and run MCP Checkov scan")
        print()
        
        payload = {
            "action": "scan",
            "workflow_id": workflow_id,
            "scan_options": {
                "frameworks": ["terraform"]
            },
            "repository_info": {
                "owner": "aruunkumar",
                "repo": "iac-remediation-test-data"
            }
        }
        
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if result.get('status') == 'completed':
            total_findings = result.get('total_findings', 0)
            print(f"✅ Scan completed")
            print(f"✅ Total findings: {total_findings}")
            print(f"✅ Scan ID: {result.get('scan_id', 'N/A')}")
            
            if total_findings > 0:
                print(f"✅ Found {total_findings} security issues (expected)")
                # Show sample findings
                findings = result.get('findings', [])
                if findings:
                    print(f"✅ Sample findings:")
                    for finding in findings[:3]:
                        check_id = finding.get('check_id', 'N/A')
                        resource = finding.get('resource', 'N/A')
                        print(f"   • {check_id}: {resource}")
                results.append(("S3 Scan", True))
            else:
                print(f"⚠️  No findings detected (unexpected for test repo)")
                results.append(("S3 Scan", False))
        else:
            error_msg = result.get('error', 'Unknown error')
            print(f"❌ Scan failed: {error_msg}")
            results.append(("S3 Scan", False))
            
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("S3 Scan", False))
    print()
    time.sleep(1)
    
    # Test 4: Error Handling
    print("📋 Test 4: Error Handling")
    print("-" * 70)
    try:
        payload = {"action": "scan", "folder_path": "/nonexistent/path"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if 'error' in result:
            print(f"✅ Error handling works: {result.get('error')[:80]}...")
            results.append(("Error Handling", True))
        else:
            print(f"❌ Expected error but got: {result}")
            results.append(("Error Handling", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Error Handling", False))
    print()
    
    # Summary
    print("=" * 70)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success is True)
    failed = sum(1 for _, success in results if success is False)
    skipped = sum(1 for _, success in results if success is None)
    total = len(results)
    
    for test_name, success in results:
        if success is True:
            status = "✅ PASS"
        elif success is False:
            status = "❌ FAIL"
        else:
            status = "⏭️  SKIP"
        print(f"{status} - {test_name}")
    
    print()
    print(f"🎯 Overall: {passed} passed, {failed} failed, {skipped} skipped (out of {total} tests)")
    
    if failed == 0 and passed > 0:
        print("🎉 All executed tests passed! Checkov agent is functional.")
    elif passed > 0:
        print("⚠️  Some tests passed. Check details above.")
    else:
        print("❌ Tests failed. Check agent configuration.")
    
    print()
    return results

if __name__ == "__main__":
    test_checkov_agent()
