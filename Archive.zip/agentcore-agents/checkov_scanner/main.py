"""
Checkov Scanner Agent - AgentCore Version with MCP Terraform Server
Uses MCP for Checkov scanning, not Python library directly
"""

from bedrock_agentcore import BedrockAgentCoreApp
import json
import logging
import os
import sys
import tempfile
import shutil
import uuid
from typing import Dict, Any
from datetime import datetime

# Bypass tool consent prompts
os.environ['BYPASS_TOOL_CONSENT'] = 'true'

# Add parent directory to path for shared module
if not os.getenv("DOCKER_CONTAINER"):
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from shared.s3_storage import S3Storage

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    force=True
)
logger = logging.getLogger(__name__)

# Import Strands SDK components
try:
    from strands import Agent
    from strands.tools.mcp import MCPClient
    from strands_tools import file_read, file_write
    from mcp.client.stdio import stdio_client
    from mcp import StdioServerParameters
    STRANDS_AVAILABLE = True
    logger.info("Strands SDK loaded successfully")
except ImportError as e:
    logger.error(f"Strands SDK not available ({e}), agent will not function properly")
    STRANDS_AVAILABLE = False
    # Define dummy classes so code doesn't break
    Agent = None
    MCPClient = None
    file_read = None
    file_write = None

logger.info(f"Environment: {'AgentCore' if os.getenv('DOCKER_CONTAINER') else 'Local'}")
logger.info(f"Python version: {sys.version}")
logger.info(f"Strands SDK available: {STRANDS_AVAILABLE}")

app = BedrockAgentCoreApp(debug=False)
s3_storage = S3Storage()

def get_terraform_mcp_client():
    """Get MCP client for Terraform server"""
    if not STRANDS_AVAILABLE:
        return None
    
    return MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["awslabs.terraform-mcp-server@latest"],
                env={"FASTMCP_LOG_LEVEL": "ERROR"},
                disabled=False,
                auto_approve=[],
                debug=True,
            )
        )
    )

def get_checkov_scanner_system_prompt() -> str:
    """System prompt for Checkov Scanner using MCP"""
    return """
    You are the Checkov Scanner Agent using the AWS Labs Terraform MCP Server.
    
    Use the MCP server's RunCheckovScan tool to scan Terraform code for security issues.
    Return the raw scan results without additional processing.
    """

@app.entrypoint
def invoke(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Main entry point for checkov scanner agent"""
    action = payload.get("action", "scan")
    execution_start = datetime.utcnow()
    
    logger.info(f"{'='*80}")
    logger.info(f"[CHECKOV] EXECUTION START")
    logger.info(f"[CHECKOV] Action: {action}")
    logger.info(f"[CHECKOV] Timestamp: {execution_start.isoformat()}")
    logger.info(f"{'='*80}")
    logger.info(f"Payload keys: {list(payload.keys())}")
    
    try:
        if action == "scan":
            result = scan_terraform(payload)
        elif action == "health":
            result = health_check(payload)
        else:
            result = {"error": f"Unknown action: {action}"}
        
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.info(f"{'='*80}")
        logger.info(f"[CHECKOV] EXECUTION END")
        logger.info(f"[CHECKOV] Action: {action}")
        logger.info(f"[CHECKOV] Status: {'success' if 'error' not in result else 'error'}")
        logger.info(f"[CHECKOV] Execution time: {execution_time:.2f}s")
        logger.info(f"[CHECKOV] Timestamp: {execution_end.isoformat()}")
        logger.info(f"{'='*80}")
        
        return result
        
    except Exception as e:
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.error(f"{'='*80}")
        logger.error(f"[CHECKOV] EXECUTION FAILED")
        logger.error(f"[CHECKOV] Action: {action}")
        logger.error(f"[CHECKOV] Error: {str(e)}")
        logger.error(f"[CHECKOV] Execution time: {execution_time:.2f}s")
        logger.error(f"[CHECKOV] Timestamp: {execution_end.isoformat()}")
        logger.error(f"{'='*80}")
        
        raise


def scan_terraform(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Scan Terraform code using MCP Checkov"""
    if not STRANDS_AVAILABLE:
        return {
            "error": "Strands SDK not available - cannot perform MCP scan",
            "status": "failed",
            "total_findings": 0,
            "findings": []
        }
    
    workflow_id = payload.get("workflow_id")
    iteration = payload.get("iteration", 1)  # Support iteration tracking
    scan_options = payload.get("scan_options", {})
    
    scan_id = str(uuid.uuid4())
    temp_dir = None
    working_dir = None
    
    # Download from S3 if workflow_id provided
    if workflow_id:
        # On iteration 1, scan original code from github-agent
        # On iteration 2+, scan fixed code from terraform-remediation-agent
        if iteration == 1:
            agent_folder = 'github-agent'
            logger.info(f"Iteration {iteration}: Downloading original repository from S3 (github-agent)")
        else:
            agent_folder = 'terraform-remediation-agent'
            logger.info(f"Iteration {iteration}: Downloading remediated repository from S3 (terraform-remediation-agent)")
        
        logger.info(f"Downloading repository from S3 for workflow {workflow_id}")
        temp_dir = f"/tmp/checkov_scan_{scan_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        try:
            working_dir = s3_storage.download_directory(workflow_id, agent_folder, temp_dir)
            logger.info(f"Repository downloaded to {working_dir}")
        except Exception as e:
            logger.error(f"Failed to download from S3: {e}")
            return {"error": f"Failed to download from S3: {str(e)}"}
    
    if not working_dir:
        return {"error": "workflow_id is required"}
    
    logger.info(f"Starting scan {scan_id} for {working_dir}")
    
    try:
        # Initialize MCP client and agent
        tf_mcp_client = get_terraform_mcp_client()
        
        with tf_mcp_client:
            mcp_tools = tf_mcp_client.list_tools_sync()
            all_tools = mcp_tools + [file_read, file_write]
            
            agent = Agent(
                system_prompt=get_checkov_scanner_system_prompt(),
                tools=all_tools,
                model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
            )
            
            # Call MCP RunCheckovScan directly
            logger.info(f"Calling MCP RunCheckovScan on {working_dir}")
            tool_use_id = str(uuid.uuid4())
            
            tool_result = tf_mcp_client.call_tool_sync(
                name="RunCheckovScan",
                arguments={"working_directory": working_dir},
                tool_use_id=tool_use_id
            )
            
            # Parse MCP response
            findings = parse_mcp_checkov_response(tool_result)
            
            scan_result = {
                "scan_id": scan_id,
                "status": "completed",
                "total_findings": len(findings),
                "fixable_count": len(findings),
                "findings": findings,
                "scan_metadata": {
                    "source": working_dir,
                    "source_type": "s3",
                    "total_findings": len(findings),
                    "files_scanned": 0,
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
            
            # Upload results to S3
            if workflow_id:
                try:
                    # Include iteration number in filename for tracking
                    filename = f'scan_results_iteration_{iteration}.json' if iteration > 1 else 'scan_results.json'
                    s3_storage.upload_json(scan_result, workflow_id, 'checkov-agent', filename)
                    logger.info(f"Scan results uploaded to S3 for workflow {workflow_id}, iteration {iteration}: {filename}")
                except Exception as e:
                    logger.error(f"Failed to upload scan results to S3: {e}")
            
            logger.info(f"Scan {scan_id} completed: {len(findings)} findings")
            
            # Cleanup
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            
            return scan_result
            
    except Exception as e:
        logger.error(f"Scan failed: {e}", exc_info=True)
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        return {
            "scan_id": scan_id,
            "status": "failed",
            "error": str(e),
            "total_findings": 0,
            "findings": []
        }

def parse_mcp_checkov_response(tool_result) -> list:
    """Parse MCP Checkov response to extract findings"""
    findings = []
    
    try:
        # Extract content from MCP response
        if isinstance(tool_result, dict):
            raw_response = tool_result
        elif hasattr(tool_result, 'content'):
            raw_response = tool_result.content
        elif hasattr(tool_result, 'result'):
            raw_response = tool_result.result
        else:
            raw_response = str(tool_result)
        
        logger.info(f"MCP response type: {type(raw_response)}")
        
        # Parse based on response structure
        if isinstance(raw_response, dict):
            # Check for structuredContent
            if 'structuredContent' in raw_response:
                structured = raw_response['structuredContent']
                if isinstance(structured, dict):
                    if 'vulnerabilities' in structured:
                        findings = structured['vulnerabilities']
                    elif 'results' in structured and 'failed_checks' in structured['results']:
                        findings = structured['results']['failed_checks']
            
            # Check for direct Checkov format
            elif 'results' in raw_response and 'failed_checks' in raw_response['results']:
                findings = raw_response['results']['failed_checks']
            
            # Check for content field
            elif 'content' in raw_response:
                content = raw_response['content']
                if isinstance(content, dict) and 'results' in content:
                    findings = content['results'].get('failed_checks', [])
                elif isinstance(content, str):
                    findings = parse_checkov_json_from_string(content)
        
        elif isinstance(raw_response, str):
            findings = parse_checkov_json_from_string(raw_response)
        
        logger.info(f"Parsed {len(findings)} findings from MCP response")
        
    except Exception as e:
        logger.error(f"Error parsing MCP response: {e}")
    
    return findings

def parse_checkov_json_from_string(content: str) -> list:
    """Extract Checkov JSON from string content"""
    findings = []
    
    try:
        if "Checkov stdout:" in content:
            json_start = content.find("Checkov stdout:") + len("Checkov stdout:")
            json_content = content[json_start:].strip()
            
            brace_start = json_content.find('{')
            if brace_start != -1:
                json_content = json_content[brace_start:]
                
                # Find complete JSON
                brace_count = 0
                json_end = -1
                for idx, char in enumerate(json_content):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        brace_count -= 1
                        if brace_count == 0:
                            json_end = idx + 1
                            break
                
                if json_end != -1:
                    json_str = json_content[:json_end]
                    parsed = json.loads(json_str)
                    if 'results' in parsed and 'failed_checks' in parsed['results']:
                        findings = parsed['results']['failed_checks']
    
    except Exception as e:
        logger.error(f"Error parsing JSON from string: {e}")
    
    return findings

def health_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Health check"""
    return {
        "status": "healthy",
        "agent": "checkov_scanner",
        "version": "1.0.0-agentcore-mcp",
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    app.run()
