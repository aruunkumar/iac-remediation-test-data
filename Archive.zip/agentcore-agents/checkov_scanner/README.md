# Checkov Scanner Agent

AWS Bedrock AgentCore agent that analyzes Terraform code using Checkov and identifies security vulnerabilities and compliance issues.

## Overview

The Checkov Scanner Agent is part of the distributed AgentCore architecture for automated Terraform security remediation. It:

- Downloads Terraform code from S3 (shared storage)
- Runs Checkov security scans
- Identifies security findings and compliance violations
- Uploads scan results back to S3 for the remediation agent
- Supports A2A (Agent-to-Agent) communication protocol

## Architecture

### Workflow Integration

```
┌─────────────────┐
│  Orchestrator   │
│     Agent       │
└────────┬────────┘
         │ A2A invoke
         ▼
┌─────────────────┐      ┌──────────┐
│    Checkov      │◄────►│    S3    │
│  Scanner Agent  │      │ Storage  │
└─────────────────┘      └──────────┘
         │
         │ Scan results
         ▼
┌─────────────────┐
│  Remediation    │
│     Agent       │
└─────────────────┘
```

### S3-Based Storage

The agent uses S3 for data sharing:

```
1. Scan Phase:
   Download from S3 → Run Checkov → Upload results → Clean up local

2. S3 Structure (with iteration tracking):
   workflows/{workflow_id}/
   ├── github-agent/
   │   └── data.tar.gz                    # Downloaded by scanner
   ├── checkov-agent/
   │   ├── scan_results.json              # Iteration 1 (backward compatible)
   │   ├── scan_results_iteration_2.json  # Iteration 2
   │   ├── scan_results_iteration_3.json  # Iteration 3
   │   └── ...                            # Additional iterations
   └── terraform-remediation-agent/
       └── data.tar.gz                    # Fixed code (overwritten each iteration)
```

**Iteration Tracking**: Each scan iteration creates a separate results file in S3, preserving the complete scan history for the workflow. The first iteration uses `scan_results.json` for backward compatibility.

## Files

### Core Files
- `main.py` - Agent implementation with S3 integration
- `requirements.txt` - Python dependencies
- `Dockerfile` - Docker image definition (builds from parent dir)
- `deploy.py` - Deployment script
- `test_checkov_agent.py` - Test suite

### Configuration
- `.dockerignore` - Files to exclude from Docker build

## Prerequisites

1. **S3 Bucket**: Run setup script from parent directory
   ```bash
   cd ../
   ./setup_s3_storage.sh
   ```

2. **IAM Permissions**: Agent role needs:
   - S3: GetObject, PutObject, ListBucket
   - ECR: Read access
   - CloudWatch: Logs access

3. **Checkov**: Installed via requirements.txt

## Build & Deployment

### Deploy to AgentCore

```bash
python3 deploy.py
```

This script:
1. Creates ECR repository if needed
2. Builds Docker image from parent directory (for shared module access)
3. Pushes to ECR
4. Creates/updates AgentCore runtime with S3 permissions

### Docker Build Context

The Dockerfile builds from the **parent directory** (`agentcore-agents/`) to access the shared S3 module:

```dockerfile
# Build context: agentcore-agents/
COPY shared/ /app/shared/              # Shared S3 utility
COPY checkov_scanner/ /app/            # Agent code
```

### Verify Deployment

```bash
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
```

## Testing

### Run Test Suite

```bash
python3 test_checkov_agent.py
```

**Tests:**
1. Health Check - Verifies agent is running
2. List Scans - Returns scan history
3. S3 Scan - Tests workflow integration (requires orchestrator)
4. Error Handling - Validates error responses

**Expected Output:**
```
🎯 Overall: 3 passed, 0 failed, 1 skipped (out of 4 tests)
🎉 All executed tests passed! Checkov agent is functional.
```

### Test via Orchestrator

The best way to test is through the orchestrator agent which coordinates the full workflow:

```bash
cd ../orchestrator
python3 test_orchestrator.py
```

### Manual Testing

```bash
aws bedrock-agentcore invoke-agent-runtime \
  --agent-runtime-arn arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/checkov_scanner-ID \
  --payload '{"action":"health"}' \
  response.json

cat response.json
```

## Usage

### Health Check

```python
payload = {"action": "health"}
```

**Response:**
```json
{
  "status": "healthy",
  "agent": "checkov_scanner",
  "version": "1.0.0-agentcore",
  "scans_in_memory": 0,
  "timestamp": "2025-12-23T04:29:19.269Z"
}
```

### Scan from S3 (Workflow)

Called by orchestrator during workflow:

```python
payload = {
  "action": "scan",
  "workflow_id": "abc-123-def",
  "iteration": 1,  # Iteration number for tracking (optional, defaults to 1)
  "scan_options": {
    "frameworks": ["terraform"],
    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
  },
  "repository_info": {
    "owner": "user",
    "repo": "repo-name",
    "url": "https://github.com/user/repo-name.git"
  }
}
```

**Response:**
```json
{
  "scan_id": "uuid",
  "status": "completed",
  "total_findings": 15,
  "fixable_count": 10,
  "findings": [
    {
      "check_id": "CKV_AWS_18",
      "check_name": "S3 bucket logging",
      "file_path": "/modules/s3/main.tf",
      "resource": "aws_s3_bucket.example",
      "severity": "MEDIUM",
      "description": "Ensure S3 bucket has access logging enabled",
      "guideline": "https://docs.bridgecrew.io/...",
      "status": "failed"
    }
  ],
  "scan_metadata": {
    "source": "/tmp/checkov_scan_uuid/repo",
    "source_type": "local",
    "total_findings": 15,
    "files_scanned": 8,
    "repository_info": {...},
    "timestamp": "2025-12-23T04:29:21.184Z"
  }
}
```

### List Scans

```python
payload = {
  "action": "list_scans",
  "limit": 10
}
```

**Response:**
```json
{
  "scans": [
    {
      "scan_id": "uuid",
      "status": "completed",
      "total_findings": 15,
      "timestamp": "2025-12-23T04:29:21.184Z"
    }
  ],
  "total_count": 1
}
```

## Actions

1. **scan** - Scan Terraform code (downloads from S3 if workflow_id provided)
2. **scan_project** - Same as scan
3. **scan_s3** - Scan from S3 URI directly
4. **get_scan** - Get scan results by ID
5. **list_scans** - List all scans
6. **delete_scan** - Delete scan results
7. **health** - Health check

## Integration with Other Agents

### Workflow Sequence

```
1. Orchestrator → GitHub Agent (setup)
   └─ Uploads to: workflows/{id}/github-agent/data.tar.gz

2. Loop until convergence (max 5 iterations):
   
   Iteration N:
   a. Orchestrator → Checkov Agent (scan)
      └─ Downloads from: workflows/{id}/github-agent/ (iteration 1)
                    OR: workflows/{id}/terraform-remediation-agent/ (iteration 2+)
      └─ Scans Terraform code
      └─ Uploads to: workflows/{id}/checkov-agent/scan_results_iteration_N.json
      └─ Returns scan results to orchestrator
   
   b. Orchestrator → Remediation Agent (fix)
      └─ Receives scan results in payload from orchestrator
      └─ Downloads repository from: workflows/{id}/checkov-agent/data.tar.gz
      └─ Applies fixes based on scan results
      └─ Uploads to: workflows/{id}/terraform-remediation-agent/data.tar.gz
      └─ Returns remediation results to orchestrator
   
   c. Orchestrator checks convergence:
      └─ No issues found? → Exit loop
      └─ No auto-fixes applied? → Exit loop
      └─ Convergence score ≥ 0.85? → Exit loop
      └─ Max iterations reached? → Exit loop

3. Orchestrator → GitHub Agent (create_pr)
   └─ Downloads from: workflows/{id}/terraform-remediation-agent/
   └─ Creates PR with fixes
```

### Data Flow

```
GitHub Agent (S3) → Checkov Scanner → Scan Results (payload + S3) → Orchestrator
                         ↑                                                ↓
                         |                                    Scan results in payload
                         |                                                ↓
                    Remediation Agent ←─────────────────────────── Orchestrator
                         ↓
                    Fixed Code (S3)
                         ↓
                    Checkov Scanner (next iteration)
```

**Key Points**:
- Checkov downloads repository from S3 (github-agent or terraform-remediation-agent)
- Checkov uploads scan results to S3 with iteration tracking
- Checkov returns scan results to orchestrator in response payload
- Orchestrator passes scan results to remediation agent in payload
- Remediation agent downloads repository from S3 using workflow_id
- Remediation agent uploads fixed code to S3
- Next iteration scans the fixed code

### A2A Communication

The orchestrator invokes the scanner via A2A protocol:

```python
client = boto3.client('bedrock-agentcore')
response = client.invoke_agent_runtime(
    agentRuntimeArn=scanner_arn,
    payload=json.dumps(payload)
)

# Parse response (StreamingBody)
result = json.loads(response['response'].read())
```

**Important**: The response is in `response['response']` (a StreamingBody object), not `response['body']`.

## Checkov Capabilities

### Supported Frameworks

- Terraform
- CloudFormation
- Kubernetes
- Helm
- Dockerfile
- And more...

### Security Checks

Detects 100+ security and compliance issues:
- AWS security best practices
- CIS benchmarks
- PCI-DSS compliance
- HIPAA compliance
- SOC2 compliance

### Example Findings

- **CKV_AWS_18**: S3 bucket logging not enabled
- **CKV_AWS_19**: S3 bucket encryption not enabled
- **CKV_AWS_21**: S3 bucket versioning not enabled
- **CKV_AWS_28**: DynamoDB point-in-time recovery not enabled
- **CKV_AWS_73**: API Gateway stage logging not enabled

## Configuration

### Environment Variables

- `AWS_EXECUTION_ENV`: Auto-detected (AgentCore sets this)
- `USE_A2A`: Force A2A mode (default: auto-detect)
- `AGENT_STORAGE_BUCKET`: S3 bucket name (default: terraform-security-platform-storage)

### Scan Options

```python
scan_options = {
    "frameworks": ["terraform"],
    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"],
    "skip_checks": ["CKV_AWS_123"],  # Optional: checks to skip
    "compact": False  # Optional: compact output
}
```

### IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::terraform-security-platform-storage",
        "arn:aws:s3:::terraform-security-platform-storage/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "*"
    }
  ]
}
```

## Monitoring

### View Logs

```bash
aws logs tail /aws/bedrock-agentcore/runtimes/checkov_scanner-ID-DEFAULT \
  --region us-east-1 --since 5m --follow
```

### CloudWatch Metrics

AgentCore automatically publishes:
- Invocation count
- Error rate
- Duration
- OTEL traces

### Log Messages

Key log messages to monitor:
- `Checkov scanner invoked with action: scan`
- `Downloading repository from S3 for workflow {id}`
- `Starting scan {id} for {path}`
- `Scan {id} completed: {n} findings`
- `Scan results uploaded to S3`

## Troubleshooting

### Agent not responding

**Cause**: Runtime not healthy or wrong ARN

**Fix**: Check runtime status
```bash
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
```

View recent logs:
```bash
aws logs tail /aws/bedrock-agentcore/runtimes/checkov_scanner-ID-DEFAULT \
  --region us-east-1 --since 10m
```

### S3 download fails

**Cause**: Missing S3 permissions or workflow_id doesn't exist

**Fix**: 
- Verify S3 bucket exists: `terraform-security-platform-storage`
- Check IAM role has S3 permissions
- Verify workflow_id exists in S3:
  ```bash
  aws s3 ls s3://terraform-security-platform-storage/workflows/{workflow_id}/
  ```

### Scan errors

**Cause**: Invalid Terraform files or Checkov version issues

**Fix**:
- Check Checkov version compatibility
- Verify Terraform files are valid
- Review CloudWatch logs for detailed errors

### "Found 0 issues" but scan shows findings

**Cause**: Orchestrator parsing response incorrectly

**Fix**: Ensure orchestrator uses `response['response'].read()` not `response['body']`

```python
# Correct A2A response parsing
response_body = response.get('response')
if hasattr(response_body, 'read'):
    result = json.loads(response_body.read())
```

## Development

### Local Testing

Test without deploying:
```bash
# Set environment for local mode
export USE_A2A=false

# Run locally
python3 main.py
```

### Code Changes

After modifying `main.py`:
```bash
python3 deploy.py  # Rebuilds and redeploys
```

### Adding New Checks

Checkov checks are automatically updated. To customize:
1. Create custom Checkov policies
2. Add to scan_options in orchestrator
3. Update documentation

## Dependencies

See `requirements.txt`:
- `bedrock-agentcore>=1.0.0` - AgentCore SDK
- `checkov>=3.0.0` - Security scanner
- `boto3>=1.34.0` - AWS SDK
- `aws-opentelemetry-distro>=0.10.0` - Observability

## Related Documentation

- [Orchestrator Agent](../orchestrator/README.md)
- [GitHub Integration Agent](../github_integration/README.md)
- [Terraform Remediation Agent](../terraform_remediation/README.md)
- [S3 Storage Migration](../S3_STORAGE_MIGRATION.md)
- [Checkov Documentation](https://www.checkov.io/)

## Support

For issues:
1. Check CloudWatch logs for detailed errors
2. Verify S3 bucket exists and has correct permissions
3. Ensure IAM role has required policies
4. Test S3 storage independently
5. Verify Checkov version compatibility
6. Check orchestrator A2A response parsing
