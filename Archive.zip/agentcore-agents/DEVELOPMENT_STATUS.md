# Terraform Remediation Agent - Development Status

**Last Updated:** 2026-01-30  
**Status:** Production Ready - Core functionality working, optimizations complete

---

## Overview

Multi-agent system for automated Terraform security remediation using AWS Bedrock AgentCore. The system consists of three agents that work together to scan, remediate, and orchestrate the security fix workflow.

---

## Architecture

### Agents

1. **GitHub Integration Agent** (`github_integration/`)
   - Downloads repository from GitHub
   - Uploads to S3 as `data.tar.gz`
   - Status: ✅ Working

2. **Checkov Scanner Agent** (`checkov_scanner/`)
   - Downloads repository from S3
   - Runs Checkov security scans
   - Uploads scan results to S3
   - Status: ✅ Working (fixed tar.gz extraction)

3. **Terraform Remediation Agent** (`terraform_remediation/`)
   - Downloads repository and scan results from S3
   - Uses Strands Agent with MCP Terraform Server
   - Applies auto-fixes and generates TODO comments
   - Uploads remediated code as tar.gz
   - Status: ⚠️ Partially working (see issues below)

4. **Orchestrator Agent** (`orchestrator/`)
   - Coordinates workflow between agents
   - Runs scan-fix loop up to 5 iterations
   - Status: ✅ Working

---

## Recent Progress

### Completed Fixes (January 2026)

#### Phase 1: S3 Storage & Basic Fixes (Jan 24)

1. **S3 Storage tar.gz Extraction**
   - Fixed `download_directory` to automatically extract tar.gz files
   - Returns extracted root directory path
   - Applied to both `shared/s3_storage.py` and `agentcore-agents/shared/s3_storage.py`
   - Status: ✅ Complete

2. **Check ID Field Mapping**
   - Fixed remediation agent to read `id` field (not just `check_id`)
   - Line 410: `check_id = finding.get("check_id") or finding.get("id")`
   - Status: ✅ Complete

3. **Iteration Tracking**
   - Checkov scanner uploads `scan_results_iteration_N.json` for iterations 2+
   - Preserves complete scan history in S3
   - Status: ✅ Complete

4. **README Documentation**
   - Updated all three agent READMEs with correct data flow
   - Documented iteration tracking
   - Status: ✅ Complete

5. **Initial Terraform Remediation Agent Fixes**
   - Added `uv` installation to Dockerfile for MCP Terraform Server
   - Added Bedrock IAM permissions (InvokeModelWithResponseStream)
   - Fixed file path construction (strip leading `/` and repo name prefix)
   - Fixed S3 download to use `github-agent` (not `checkov-agent`)
   - Changed upload to compressed tar.gz format
   - Added error handling for report generation
   - Status: ✅ Complete

#### Phase 2: Strands Integration & Optimization (Jan 30)

6. **Strands Agent Integration with MCP Tools**
   - Integrated Strands Agent SDK for LLM-driven remediation
   - Added MCP Terraform Server for AWS provider documentation
   - Implemented file_read and file_write tools for code manipulation
   - Status: ✅ Complete

7. **Improved Prompts**
   - System prompt: Clear environment context, open-ended decision criteria
   - Batch prompt: Task-focused, checks for existing comments at resource level
   - Prompts are complementary (system = general rules, batch = specific task)
   - Status: ✅ Complete

8. **Path Handling Fixes**
   - Fixed double directory issue (iac-remediation-test-data vs iac-remediation-test-data-main)
   - Proper repo name stripping from file paths
   - S3 download returns correct extracted directory
   - Status: ✅ Complete

9. **Error Handling Improvements**
   - Removed simple_remediation fallback (everything LLM-driven now)
   - Fail fast with clear error messages
   - Proper S3 download validation
   - Status: ✅ Complete

10. **Test Improvements**
    - Added timing measurements (start, end, total time)
    - Disabled boto3 retries to prevent duplicate invocations
    - Increased timeout to 5 minutes
    - Status: ✅ Complete

11. **Logging Improvements**
    - Suppressed DEBUG logs from strands, botocore, urllib3
    - Cleaner CloudWatch logs
    - Status: ✅ Complete

12. **Check ID Variable Scope Fix**
    - Fixed f-string template to use `<check_id>` instead of `{check_id}`
    - Prevents "cannot access local variable" error
    - Status: ✅ Complete

13. **Results Aggregation Fix**
    - Fixed issue where results showed 0 fixes but files were modified
    - Wrapped report operations in try-except blocks
    - Prevents report errors from breaking result aggregation
    - Status: ✅ Complete

14. **Test Timeout Fix**
    - Increased boto3 client timeout from 3 to 5 minutes
    - Disabled boto3 retries to prevent duplicate agent invocations
    - Status: ✅ Complete

15. **Double Directory Path Fix**
    - Fixed mismatch between tar directory name and scan result paths
    - Proper repo name stripping logic
    - Tar directory now matches scan paths
    - Status: ✅ Complete

---

## Current Status

### Working Features ✅

1. **LLM-Driven Remediation**
   - Strands Agent with Claude Sonnet 4.5
   - MCP Terraform Server for AWS provider docs
   - Intelligent auto-fix vs manual intervention decisions
   - Consistent results: 4 auto-fixes, 9 manual interventions

2. **File Operations**
   - Downloads repository from S3
   - Applies fixes using file_read/file_write tools
   - Uploads remediated code back to S3
   - Proper path handling (no double directories)

3. **Comment Generation**
   - AGENT-FIXED comments for auto-fixes
   - TODO comments with detailed manual intervention steps
   - Resource-level comment checking (skips already fixed resources)

4. **Performance**
   - ~4 minutes for 13 findings (5 batches)
   - Batch processing with LLM inference
   - Proper error handling and logging

### Known Limitations

1. **Sequential Processing**: Batches processed one at a time (~47-88s per batch)
2. **No Validation**: Remediated code not validated before upload
3. **Fixed Batch Size**: Max 5 findings per batch (not configurable)
4. **Single Model**: Uses Claude Sonnet 4.5 only (no fallback)
5. **LLM Non-determinism**: Results may vary slightly between runs (temperature > 0)

---

## File Structure

```
agentcore-agents/
├── shared/
│   ├── s3_storage.py          # S3 utilities (tar.gz extraction)
│   └── interfaces.py          # Shared data models
├── github_integration/
│   ├── main.py
│   └── deploy.py
├── checkov_scanner/
│   ├── main.py
│   ├── deploy.py
│   └── README.md
├── terraform_remediation/
│   ├── main.py                # Main agent logic
│   ├── Dockerfile             # Includes uv for MCP
│   ├── deploy.py
│   ├── test_remediation_only.py
│   └── README.md
└── orchestrator/
    ├── main.py
    ├── deploy.py
    └── README.md
```

---

## Key Code Locations

### Terraform Remediation Agent

**File Download & Extraction:**
- `main.py` lines 195-220: Downloads from `github-agent` S3 path
- `shared/s3_storage.py` lines 36-80: Extracts tar.gz and returns root dir

**Batch Processing:**
- `main.py` lines 290-395: `remediate_with_strands_agent()` function
- `main.py` lines 350-380: Batch loop with result aggregation
- `main.py` lines 580-670: `remediate_batch()` - processes findings and scans for comments

**File Path Handling:**
- `main.py` line 590: Strips leading `/` from file paths
- `main.py` lines 610-620: Strips repo name prefix to avoid double paths

**Result Detection:**
- `main.py` lines 620-665: Scans files for AGENT-FIXED and TODO comments
- Uses regex to extract check IDs and descriptions

**S3 Upload:**
- `main.py` lines 230-240: Uploads remediated code as tar.gz
- `shared/s3_storage.py` lines 36-60: Creates tar.gz and uploads

---

## Testing

### Test Files

1. `test_remediation_only.py` - Tests remediation workflow with real S3 data
   - Workflow ID: `297ebbb7-5ed1-4ff4-b1b4-1c05d41e5617`
   - 13 findings from Checkov scan
   - Timeout: 180 seconds (boto3 client config)

### Test Workflow

```bash
cd agentcore-agents/terraform_remediation
../../venv/bin/python test_remediation_only.py
```

### Expected Results

- Auto-fixes: 4 (CKV_AWS_237, CKV_AWS_73, CKV2_AWS_53, CKV_AWS_119)
- Manual interventions: 9 (remaining checks requiring user decisions)
- Total time: ~4 minutes (239 seconds)
- Compressed output: `remediated_code.tar.gz` in S3

### Actual Results (Latest Run - Jan 30, 2026)

- Auto-fixes: 4 ✅
- Manual interventions: 9 ✅
- Total time: 239.45 seconds (3.99 minutes) ✅
- Files modified correctly ✅
- Results aggregated correctly ✅

---

## Deployment

### Prerequisites

- AWS CLI configured
- Docker/Finch installed
- Python 3.11+ with venv
- ECR repositories created
- IAM roles with proper permissions

### Deploy Command

```bash
cd agentcore-agents/terraform_remediation
../../venv/bin/python deploy.py
```

### IAM Permissions Required

- Bedrock: `InvokeModel`, `InvokeModelWithResponseStream`
- S3: `GetObject`, `PutObject`, `ListBucket`
- CloudWatch: Logs access (automatic)

---

## Next Steps

### Potential Improvements (Optional)

1. **Parallel Processing**
   - Use `ThreadPoolExecutor` for batch processing
   - Could reduce 4-minute runtime to ~1.5 minutes
   - Requires careful handling of LLM rate limits

2. **Terraform Validation**
   - Run `terraform validate` on remediated code
   - Check for syntax errors before upload
   - Report validation results

3. **Temperature Control**
   - Set temperature to 0 for deterministic results
   - Currently using default temperature (some variability)

4. **Retry Logic**
   - Add retry for failed batches
   - Handle transient LLM errors

5. **Configurable Batch Size**
   - Make max batch size configurable
   - Allow tuning based on finding complexity

6. **Multi-Model Support**
   - Add fallback to other Claude models
   - Handle rate limiting gracefully

---

## Known Limitations

1. **Sequential Processing**: Batches processed one at a time (slow for many findings)
2. **No Validation**: Remediated code not validated before upload
3. **Fixed Batch Size**: Max 5 findings per batch (not configurable)
4. **Single Model**: Uses Claude Sonnet 4.5 only (no fallback)
5. **LLM Non-determinism**: Results may vary slightly between runs due to temperature > 0
6. **No Retry Logic**: Failed batches not retried automatically

---

## Configuration

### Environment Variables

- `WORKFLOW_BUCKET`: S3 bucket for agent data (default: `bedrock-agentcore-workflows`)
- `KB_TERRAFORM_ID`: Bedrock Knowledge Base ID (default: `LZ2DEM1204`)
- `AWS_EXECUTION_ENV`: Detected automatically for AgentCore vs local

### Model Configuration

- Model: `us.anthropic.claude-sonnet-4-5-20250929-v1:0`
- Location: `main.py` line 318

### Batch Configuration

- Max batch size: 5 findings per batch
- Location: `main.py` line 334

---

## Troubleshooting

### Issue: "No files found matching pattern"

**Cause:** File path mismatch between scan results and extracted files  
**Fix:** Check that file paths are stripped correctly (lines 590, 610-620)

### Issue: "Failed to download from S3"

**Cause:** Trying to download from wrong agent path  
**Fix:** Ensure downloading from `github-agent` not `checkov-agent` (line 210)

### Issue: Results show 0 fixes but files are modified

**Status:** ✅ FIXED  
**Cause:** Report errors breaking result aggregation  
**Fix:** Report operations wrapped in try-except, proper error handling

### Issue: Test timeout

**Status:** ✅ FIXED  
**Cause:** Agent takes >3 minutes to process  
**Fix:** Increased boto3 timeout to 5 minutes, disabled retries

### Issue: "cannot access local variable 'check_id'"

**Status:** ✅ FIXED  
**Cause:** f-string template using `{check_id}` instead of literal  
**Fix:** Changed to `<check_id>` in prompt template

### Issue: Double directory path

**Status:** ✅ FIXED  
**Cause:** Mismatch between tar directory name and scan result paths  
**Fix:** Proper repo name stripping logic, tar directory matches scan paths

---

## References

- [Strands Agent SDK](https://github.com/strands-ai/strands)
- [MCP Terraform Server](https://github.com/awslabs/terraform-mcp-server)
- [Bedrock AgentCore Docs](https://docs.aws.amazon.com/bedrock/latest/userguide/agentcore.html)
- [Checkov Security Checks](https://www.checkov.io/5.Policy%20Index/terraform.html)

---

## Contact & Support

For issues or questions:
1. Check CloudWatch logs: `/aws/bedrock-agentcore/runtimes/terraform_remediation-L6ILG8FnSE-DEFAULT`
2. Review S3 outputs: `s3://terraform-security-platform-storage/workflows/{workflow_id}/`
3. Test locally: Use `test_remediation_only.py` with real workflow data
