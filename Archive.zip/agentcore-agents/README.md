# AgentCore Agents - Terraform Security Platform

AWS Bedrock AgentCore implementation of the Terraform Security Platform with S3-based distributed storage and A2A protocol support.

## Overview

**4 Distributed Agents:**
1. **Orchestrator** - Coordinates the complete workflow
2. **Checkov Scanner** - Scans Terraform for security issues  
3. **Terraform Remediation** - Automatically fixes security issues
4. **GitHub Integration** - Manages Git operations and PRs

**Key Features:**
- ✅ **S3-Based Storage**: Agents share data via S3 (no local /tmp dependencies)
- ✅ **A2A Protocol**: Native AgentCore agent-to-agent communication
- ✅ **Docker Deployment**: ARM64 containers deployed to ECR
- ✅ **Workflow Isolation**: Each workflow has unique ID and S3 namespace
- ✅ **Auto-Cleanup**: S3 lifecycle policy deletes data after 7 days
- ✅ **Dual Mode**: Supports both AgentCore (A2A) and local testing (HTTP)

## Architecture

### Data Flow

```
1. Orchestrator generates workflow_id
   ↓
2. GitHub Agent → Clone repo → Upload to S3
   ↓
3. Checkov Agent → Download from S3 → Scan → Upload results
   ↓
4. Remediation Agent → Download from S3 → Fix → Upload fixed code
   ↓
5. GitHub Agent → Download from S3 → Create PR
```

### S3 Storage Structure

```
s3://terraform-security-platform-storage/
└── workflows/{workflow_id}/
    ├── github-agent/
    │   ├── data.tar.gz           # Cloned repository
    │   └── metadata.json         # Repository metadata
    ├── checkov-agent/
    │   └── scan_results.json     # Security findings
    └── terraform-remediation-agent/
        ├── data.tar.gz           # Fixed repository
        └── remediation_results.json
```

### Communication

- **AgentCore (Production)**: A2A Protocol via `bedrock-agentcore:InvokeAgentRuntime`
- **Local Testing**: HTTP REST APIs
- **Response Parsing**: Uses `response['response'].read()` for A2A (StreamingBody)

## Quick Start

### Prerequisites

1. **S3 Bucket Setup**:
   ```bash
   cd agentcore-agents
   ./setup_s3_storage.sh
   ```

2. **AWS CLI** configured with credentials
3. **Finch or Docker** installed
4. **Python 3.11+**

### Deploy All Agents

Each agent has its own deployment script:

```bash
# Deploy Checkov Scanner
cd agentcore-agents/checkov_scanner
python3 deploy.py

# Deploy Terraform Remediation
cd ../terraform_remediation
python3 deploy.py

# Deploy GitHub Integration
cd ../github_integration
python3 deploy_manual.py

# Deploy Orchestrator (update agent ARNs first!)
cd ../orchestrator
# Edit main.py to set correct agent ARNs
python3 deploy.py
```

### Test the Deployment

```bash
# Test orchestrator
cd agentcore-agents/orchestrator
python3 test_orchestrator.py

# Test individual agents
cd ../checkov_scanner
python3 test_checkov_agent.py

cd ../terraform_remediation
python3 test_remediation_agent.py

cd ../github_integration
python3 test_github_agent.py
```

## Agent Details

### 1. Orchestrator Agent

**Purpose**: Coordinates the complete workflow across all agents

**Key Actions**:
- `start_workflow` - Execute complete remediation workflow
- `get_status` - Get workflow status by ID
- `list_workflows` - List all workflows
- `health_check` - Check all agents' health

**Configuration**:
```python
# In orchestrator/main.py
CHECKOV_SCANNER_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/checkov_scanner-ID"
TERRAFORM_REMEDIATION_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/terraform_remediation-ID"
GITHUB_INTEGRATION_ARN = "arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/github_integration_agent_s3-ID"
```

**Documentation**: See [orchestrator/README.md](orchestrator/README.md)

### 2. Checkov Scanner Agent

**Purpose**: Scans Terraform code using Checkov and identifies security vulnerabilities

**Key Actions**:
- `scan` - Scan Terraform code (downloads from S3 if workflow_id provided)
- `list_scans` - List scan history
- `health` - Health check

**Features**:
- Detects 100+ security and compliance issues
- Downloads repo from S3, scans, uploads results
- Supports multiple frameworks (Terraform, CloudFormation, etc.)

**Documentation**: See [checkov_scanner/README.md](checkov_scanner/README.md)

### 3. Terraform Remediation Agent

**Purpose**: Automatically fixes security issues and provides manual guidance

**Key Actions**:
- `remediate` - Fix security issues (downloads from S3, applies fixes, uploads back)
- `validate` - Validate scan results format
- `get_info` - Agent capabilities

**Features**:
- Auto-fixes common issues (S3 encryption, versioning, etc.)
- Generates TODO comments for manual interventions
- Supports 8+ auto-fixable checks

**Documentation**: See [terraform_remediation/README.md](terraform_remediation/README.md)

### 4. GitHub Integration Agent

**Purpose**: Manages Git operations and pull request creation

**Key Actions**:
- `setup` - Clone repo, create branch, upload to S3
- `create_pr` - Download from S3, commit, push, create PR

**Features**:
- S3-based storage for distributed execution
- Automatic branch creation
- PR creation with detailed descriptions
- **Independent token management** - fetches from Secrets Manager, request, or env var

**GitHub Token Configuration**:

The agent independently fetches the GitHub token with this priority:
1. **AWS Secrets Manager** (if `GITHUB_TOKEN_SECRET_NAME` env var is set)
2. **Token from request payload** (`repository_data['github_token']`)
3. **Environment variable** (`GITHUB_TOKEN`)

**Setup Secrets Manager:**
```bash
# Create secret
aws secretsmanager create-secret \
  --name terraform-security-platform/github-token \
  --secret-string '{"github_token":"ghp_your_token_here"}'

# Set environment variable for agent
export GITHUB_TOKEN_SECRET_NAME="terraform-security-platform/github-token"
```

**Or pass token in request:**
```json
{
  "repository_data": {
    "github_token": "ghp_your_token_here",
    ...
  }
}
```

**Documentation**: See [github_integration/README.md](github_integration/README.md)

## S3 Storage Architecture

### Why S3 Storage?

**Problem**: AgentCore agents run in isolated containers. Local `/tmp` storage isn't shared between agents or invocations.

**Solution**: S3 provides:
- Shared storage across distributed agents
- Data persistence between invocations
- Workflow isolation via unique IDs
- Automatic cleanup via lifecycle policies
- Complete audit trail

### Setup S3 Storage

**Option 1: Shell Script (Quick)**
```bash
cd agentcore-agents
./setup_s3_storage.sh
```

**Option 2: Terraform (Infrastructure as Code)**
```hcl
module "s3_storage" {
  source = "./modules/s3_storage"

  environment              = "dev"
  bucket_name              = "terraform-security-platform-storage"
  workflow_retention_days  = 7
  
  agent_role_names = [
    "github-integration-agentcore-role",
    "checkov-scanner-agentcore-role",
    "terraform-remediation-agentcore-role",
    "orchestrator-agentcore-role"
  ]

  tags = {
    Environment = "dev"
    Project     = "terraform-security-platform"
  }
}
```

### S3 Storage Features

**Bucket Configuration:**
- ✅ Versioning enabled (data recovery)
- ✅ Server-side encryption (AES256)
- ✅ Public access blocked
- ✅ Lifecycle policy (7-day retention)

**IAM Policy:**
- Automatically created and attached to agent roles
- Grants: GetObject, PutObject, DeleteObject, ListBucket

### Workflow Data Lifecycle

```
1. Workflow starts → workflow_id generated
2. Agents upload/download data to workflows/{workflow_id}/
3. Workflow completes → data remains for debugging
4. After 7 days → S3 lifecycle policy auto-deletes
```

### Shared S3 Utility Module

All agents use `shared/s3_storage.py`:

```python
from shared.s3_storage import S3Storage

s3 = S3Storage()

# Upload directory (compressed as tarball)
s3_uri = s3.upload_directory(
    local_path="/tmp/myrepo",
    workflow_id="abc-123",
    agent_name="github-agent"
)

# Download directory (extracts tarball)
local_path = s3.download_directory(
    workflow_id="abc-123",
    source_agent="github-agent",
    local_path="/tmp/download"
)

# Upload JSON metadata
s3.upload_json(
    data={"key": "value"},
    workflow_id="abc-123",
    agent_name="github-agent",
    filename="metadata.json"
)

# Download JSON metadata
data = s3.download_json(
    workflow_id="abc-123",
    agent_name="github-agent",
    filename="metadata.json"
)

# Get workflow statistics
info = s3.get_workflow_metadata("abc-123")
# Returns: {'agents': [...], 'total_size_mb': 150, 'file_count': 5}

# Cleanup workflow data
s3.cleanup_workflow("abc-123")
```

### Test S3 Storage

```bash
python3 test_s3_storage.py
```

This tests:
- Directory upload/download with tarball compression
- JSON upload/download
- Multi-agent workflow simulation
- Workflow metadata retrieval
- Cleanup functionality

### S3 Storage Cost

**Example (100 workflows/day, 7-day retention):**
- Average repo size: 50 MB
- Storage per workflow: 150 MB (original + scan + fixed)
- Daily storage: 100 × 150 MB = 15 GB
- With 7-day retention: 105 GB
- Monthly cost: 105 GB × $0.023 = **~$2.40/month**
- Requests: 30,000 operations = **~$0.15/month**
- **Total: ~$2.55/month**

### Troubleshooting S3 Storage

**S3 Access Denied:**
```bash
# Check IAM role has S3 permissions
aws iam list-attached-role-policies --role-name agent-role-name

# Re-run setup script to attach policy
./setup_s3_storage.sh
```

**Workflow Data Not Found:**
```bash
# List all workflows
aws s3 ls s3://terraform-security-platform-storage/workflows/

# View specific workflow
aws s3 ls s3://terraform-security-platform-storage/workflows/{workflow_id}/ --recursive

# Download for debugging
aws s3 sync s3://terraform-security-platform-storage/workflows/{workflow_id}/ ./debug/
```

**Download/Extract Fails:**
```bash
# Download tarball manually
aws s3 cp s3://terraform-security-platform-storage/workflows/{workflow_id}/agent/data.tar.gz ./debug.tar.gz

# Inspect tarball
tar -tzf debug.tar.gz

# Check upload logs
aws logs tail /aws/bedrock-agentcore/runtimes/agent-ID-DEFAULT --since 30m | grep -i error
```

## Deployment

### Docker Build Context

All Dockerfiles build from the **parent directory** (`agentcore-agents/`) to access the shared S3 module:

```dockerfile
# Build context: agentcore-agents/
COPY shared/ /app/shared/              # Shared S3 utility
COPY agent_name/ /app/                 # Agent code
```

### Deployment Scripts

Each agent has a `deploy.py` script that:
1. Creates ECR repository if needed
2. Builds ARM64 Docker image from parent directory
3. Pushes to ECR
4. Creates/updates AgentCore runtime with S3 permissions

### IAM Permissions

Each agent role needs:
- **S3**: GetObject, PutObject, ListBucket on `terraform-security-platform-storage`
- **ECR**: Read access
- **CloudWatch**: Logs access
- **Orchestrator only**: `bedrock-agentcore:InvokeAgentRuntime` for other agents

## Testing

### Test Individual Agents

```bash
# Checkov Scanner
python3 checkov_scanner/test_checkov_agent.py

# Terraform Remediation
python3 terraform_remediation/test_remediation_agent.py

# GitHub Integration
python3 github_integration/test_github_agent.py

# Orchestrator (full workflow)
python3 orchestrator/test_orchestrator.py
```

### Test S3 Storage

```bash
python3 test_s3_storage.py
```

## Monitoring

### View Logs

```bash
# Orchestrator
aws logs tail /aws/bedrock-agentcore/runtimes/orchestrator_agent-ID-DEFAULT \
  --region us-east-1 --since 5m --follow

# Checkov Scanner
aws logs tail /aws/bedrock-agentcore/runtimes/checkov_scanner-ID-DEFAULT \
  --region us-east-1 --since 5m --follow

# Terraform Remediation
aws logs tail /aws/bedrock-agentcore/runtimes/terraform_remediation-ID-DEFAULT \
  --region us-east-1 --since 5m --follow

# GitHub Integration
aws logs tail /aws/bedrock-agentcore/runtimes/github_integration_agent_s3-ID-DEFAULT \
  --region us-east-1 --since 5m --follow
```

### CloudWatch Metrics

AgentCore automatically publishes:
- Invocation count
- Error rate
- Duration
- OTEL traces

## Troubleshooting

### Common Issues

**1. S3 Access Denied**
```bash
# Check IAM role has S3 permissions
aws iam list-attached-role-policies --role-name agent-role-name

# Attach policy if missing
./setup_s3_storage.sh
```

**2. Agent Not Responding**
```bash
# Check runtime status
aws bedrock-agentcore-control list-agent-runtimes --region us-east-1

# View logs
aws logs tail /aws/bedrock-agentcore/runtimes/agent-ID-DEFAULT --since 10m
```

**3. "Found 0 issues" but scan shows findings**
- **Cause**: Orchestrator parsing A2A response incorrectly
- **Fix**: Ensure using `response['response'].read()` not `response['body']`

**4. Build Fails: "shared: not found"**
- **Cause**: Docker build context is wrong
- **Fix**: Ensure building from parent directory in deploy script

### Debugging Commands

```bash
# View all workflows in S3
aws s3 ls s3://terraform-security-platform-storage/workflows/

# View specific workflow data
aws s3 ls s3://terraform-security-platform-storage/workflows/{workflow_id}/ --recursive

# Download workflow data for inspection
aws s3 sync s3://terraform-security-platform-storage/workflows/{workflow_id}/ ./debug/

# Test S3 access
python3 -c "from shared.s3_storage import S3Storage; s3 = S3Storage(); print('S3 OK')"
```

## Cost Estimate

### Per Workflow
- Orchestrator: ~$0.10
- Checkov Scanner: ~$0.05
- Terraform Remediation: ~$0.05
- GitHub Integration: ~$0.02
- S3 Storage: ~$0.01

**Total**: ~$0.23 per workflow

### Monthly (100 workflows)
- Agent invocations: ~$23
- S3 storage (7-day retention): ~$2.50

**Total**: ~$25.50/month

**Comparison**:
- ECS (always-on): ~$130/month
- AgentCore (pay-per-use): ~$25/month
- **Savings**: 80% for typical usage

## Key Learnings

### CloudWatch Logging
- ✅ Use `logger.info()` instead of `print()` for proper CloudWatch integration
- ✅ Each `print()` creates a separate log stream (causes fragmentation)
- ✅ Logger methods aggregate logs correctly

### A2A Response Parsing
- ✅ Response is in `response['response']` (StreamingBody), not `response['body']`
- ✅ Must call `.read()` on StreamingBody: `json.loads(response['response'].read())`
- ✅ This was the fix for "Found 0 issues" bug

### Docker Builds
- ✅ Build from parent directory to access shared module
- ✅ Use ARM64 platform for AgentCore: `--platform linux/arm64`
- ✅ Heavy imports (like checkov) should be inside functions, not at module level

### IAM Permissions
- ✅ Use wildcards in ARN patterns: `runtime/agent_name*/*`
- ✅ Orchestrator needs `bedrock-agentcore:InvokeAgentRuntime` for other agents
- ✅ All agents need S3 permissions for shared storage

## Files Structure

```
agentcore-agents/
├── orchestrator/
│   ├── main.py                      # Workflow coordinator
│   ├── deploy.py                    # Deployment script
│   ├── test_orchestrator.py         # Test suite
│   ├── Dockerfile                   # Docker image
│   ├── requirements.txt             # Dependencies
│   └── README.md                    # Documentation
├── checkov_scanner/
│   ├── main.py                      # Security scanner
│   ├── deploy.py                    # Deployment script
│   ├── test_checkov_agent.py        # Test suite
│   ├── Dockerfile                   # Docker image
│   ├── requirements.txt             # Dependencies
│   └── README.md                    # Documentation
├── terraform_remediation/
│   ├── main.py                      # Auto-fix agent
│   ├── deploy.py                    # Deployment script
│   ├── test_remediation_agent.py    # Test suite
│   ├── Dockerfile                   # Docker image
│   ├── requirements.txt             # Dependencies
│   └── README.md                    # Documentation
├── github_integration/
│   ├── main.py                      # Git operations
│   ├── deploy_manual.py             # Deployment script
│   ├── test_github_agent.py         # Test suite
│   ├── Dockerfile.manual            # Docker image
│   ├── requirements.txt             # Dependencies
│   └── README.md                    # Documentation
├── shared/
│   ├── s3_storage.py                # S3 utility module
│   └── __init__.py                  # Module init
├── setup_s3_storage.sh              # S3 bucket setup
├── test_s3_storage.py               # S3 testing
└── README.md                        # This file
```

## Related Documentation

- [Orchestrator Agent](orchestrator/README.md) - Workflow coordination
- [Checkov Scanner Agent](checkov_scanner/README.md) - Security scanning
- [Terraform Remediation Agent](terraform_remediation/README.md) - Auto-fix
- [GitHub Integration Agent](github_integration/README.md) - Git operations

## Support

For issues:
1. Check CloudWatch logs for detailed errors
2. Verify S3 bucket exists and has correct permissions
3. Ensure IAM roles have required policies
4. Test S3 storage independently with `test_s3_storage.py`
5. Verify agent runtime status in AgentCore console
6. Check orchestrator A2A response parsing

## Next Steps

1. ✅ Deploy all agents using deployment scripts
2. ✅ Test individual agents with test scripts
3. ✅ Test full workflow with orchestrator
4. ✅ Monitor CloudWatch logs
5. ✅ Set up CloudWatch alarms (optional)
6. ✅ Document any custom configurations

## TODO
- Update logic to have remediation agent read checkov results from S3 instead of expecting it in input
