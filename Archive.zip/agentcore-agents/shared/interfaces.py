"""
Common interfaces and data models for agent communication
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum
import json

class SeverityLevel(Enum):
    """Security finding severity levels"""
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

class RemediationType(Enum):
    """Types of remediation available"""
    AUTO = "auto"
    MANUAL = "manual"

@dataclass
class SecurityFinding:
    """Standardized security finding data model"""
    id: str
    check_id: str
    severity: SeverityLevel
    resource: str
    resource_type: str
    file: str
    line_number: Optional[int]
    description: str
    remediation_type: RemediationType
    remediation_guidance: Optional[str] = None
    # Additional fields from Checkov scan results
    type: Optional[str] = None  # Checkov finding type (e.g., "terraform")
    fixed: Optional[bool] = None  # Whether the finding is fixed
    fix_details: Optional[str] = None  # Fix details from Checkov

@dataclass
class ScanResults:
    """Standardized scan results data model"""
    scan_id: str
    repository_url: str
    commit_sha: str
    total_findings: int
    fixable_count: int
    manual_count: int
    findings: List[SecurityFinding]
    scan_metadata: Dict[str, Any]

@dataclass
class RemediationFix:
    """Applied remediation fix data model"""
    violation_id: str
    check_id: str
    file: str
    resource: str
    fix_applied: str
    knowledge_base_reference: Optional[Dict[str, Any]] = None

@dataclass
class ManualIntervention:
    """Manual intervention item data model"""
    violation_id: str
    check_id: str
    file: str
    resource: str
    todo_comment: str
    detailed_guidance: Dict[str, Any]

@dataclass
class RemediationResults:
    """Remediation results data model"""
    scan_id: str
    fixes: List[RemediationFix]
    manual_interventions: List[ManualIntervention]
    validation_errors: List[str]
    knowledge_base_queries: List[Dict[str, Any]]

@dataclass
class AgentRequest:
    """Standardized agent communication request"""
    request_id: str
    source_agent: str
    target_agent: str
    action: str
    payload: Dict[str, Any]
    iteration: int
    timestamp: str

@dataclass
class AgentResponse:
    """Standardized agent communication response"""
    request_id: str
    source_agent: str
    status: str  # success, error, partial
    payload: Dict[str, Any]
    error_message: Optional[str] = None
    timestamp: str = ""

class AgentInterface:
    """Base interface for all agents"""
    
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
    
    def process_request(self, request: AgentRequest) -> AgentResponse:
        """Process incoming agent request"""
        raise NotImplementedError("Subclasses must implement process_request")
    
    def health_check(self) -> Dict[str, Any]:
        """Agent health check endpoint"""
        return {
            'agent': self.agent_name,
            'status': 'healthy',
            'timestamp': self._get_timestamp()
        }
    
    def _get_timestamp(self) -> str:
        """Get current timestamp in ISO format"""
        from datetime import datetime
        return datetime.utcnow().isoformat()

class RepositoryData:
    """Repository data container"""
    
    def __init__(self, url: str, owner: str, repo: str, branch: str = "main"):
        self.url = url
        self.owner = owner
        self.repo = repo
        self.branch = branch
        self.commit_sha = ""
        self.files = {}  # Dict[str, str] - filename to content mapping
        self.terraform_files = {}  # Dict[str, str] - terraform files only
    
    def add_file(self, filename: str, content: str) -> None:
        """Add file content to repository data"""
        self.files[filename] = content
        if filename.endswith(('.tf', '.tfvars')):
            self.terraform_files[filename] = content
    
    def get_terraform_files(self) -> Dict[str, str]:
        """Get only Terraform files"""
        return self.terraform_files
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'url': self.url,
            'owner': self.owner,
            'repo': self.repo,
            'branch': self.branch,
            'commit_sha': self.commit_sha,
            'files': self.files,
            'terraform_files': self.terraform_files
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RepositoryData':
        """Create from dictionary"""
        repo_data = cls(
            url=data['url'],
            owner=data['owner'],
            repo=data['repo'],
            branch=data.get('branch', 'main')
        )
        repo_data.commit_sha = data.get('commit_sha', '')
        repo_data.files = data.get('files', {})
        repo_data.terraform_files = data.get('terraform_files', {})
        return repo_data