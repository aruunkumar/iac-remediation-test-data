"""S3 storage utilities for agent data sharing"""
import boto3
import json
import os
import tempfile
import shutil
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class S3Storage:
    """S3 storage for sharing data between agents"""
    
    def __init__(self, bucket_name: Optional[str] = None):
        self.s3_client = boto3.client('s3')
        self.bucket_name = bucket_name or os.getenv('WORKFLOW_BUCKET', 'bedrock-agentcore-workflows')
    
    def upload_json(self, data: Dict[str, Any], workflow_id: str, agent_name: str, filename: str) -> str:
        """Upload JSON data to S3"""
        key = f"workflows/{workflow_id}/{agent_name}/{filename}"
        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=key,
            Body=json.dumps(data),
            ContentType='application/json'
        )
        return f"s3://{self.bucket_name}/{key}"
    
    def download_json(self, workflow_id: str, agent_name: str, filename: str) -> Dict[str, Any]:
        """Download JSON data from S3"""
        key = f"workflows/{workflow_id}/{agent_name}/{filename}"
        response = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
        return json.loads(response['Body'].read())
    
    def upload_directory(self, local_dir: str, workflow_id: str, agent_name: str) -> str:
        """Upload directory to S3 as a compressed tar.gz file"""
        import tarfile
        import tempfile
        
        # Create tar.gz in temp location
        with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp_file:
            tar_path = tmp_file.name
        
        try:
            # Create tar.gz of the directory
            logger.info(f"Creating tar.gz of {local_dir}")
            
            # Custom filter to include .git directory (tar.add excludes hidden files by default)
            def include_git_filter(tarinfo):
                return tarinfo
            
            with tarfile.open(tar_path, 'w:gz') as tar:
                # Add all files from local_dir, preserving structure including .git
                tar.add(local_dir, arcname=os.path.basename(local_dir), filter=include_git_filter)
            
            # Upload tar.gz to S3
            s3_key = f"workflows/{workflow_id}/{agent_name}/remediated_code.tar.gz"
            logger.info(f"Uploading tar.gz to S3: {s3_key}")
            self.s3_client.upload_file(tar_path, self.bucket_name, s3_key)
            
            return f"s3://{self.bucket_name}/{s3_key}"
        
        finally:
            # Clean up temp tar file
            if os.path.exists(tar_path):
                os.remove(tar_path)
    
    def download_directory(self, workflow_id: str, agent_name: str, local_dir: str) -> str:
        """Download directory from S3 and return the actual content directory"""
        import tarfile
        
        prefix = f"workflows/{workflow_id}/{agent_name}/"
        paginator = self.s3_client.get_paginator('list_objects_v2')
        
        extracted_root = None
        
        logger.info(f"Downloading from S3: bucket={self.bucket_name}, prefix={prefix}")
        
        contents_found = False
        for page in paginator.paginate(Bucket=self.bucket_name, Prefix=prefix):
            if 'Contents' not in page:
                logger.warning(f"No contents found for prefix: {prefix}")
                continue
            
            contents_found = True
            for obj in page['Contents']:
                key = obj['Key']
                relative_path = key[len(prefix):]
                local_path = os.path.join(local_dir, relative_path)
                
                logger.info(f"Downloading: {key} -> {local_path}")
                
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                self.s3_client.download_file(self.bucket_name, key, local_path)
                
                # Extract tar.gz files automatically
                if local_path.endswith('.tar.gz') or local_path.endswith('.tgz'):
                    logger.info(f"Extracting {local_path} to {local_dir}")
                    with tarfile.open(local_path, 'r:gz') as tar:
                        tar.extractall(path=local_dir)
                        # Get the root directory from tar contents
                        members = tar.getmembers()
                        if members:
                            # Get the top-level directory name
                            first_member = members[0].name
                            root_dir = first_member.split('/')[0]
                            extracted_root = os.path.join(local_dir, root_dir)
                            logger.info(f"Extracted root directory: {extracted_root}")
                            logger.info(f"First few members: {[m.name for m in members[:5]]}")
                    # Remove the tar.gz file after extraction
                    os.remove(local_path)
                    logger.info(f"Removed {local_path}")
        
        # If no contents were found, return None
        if not contents_found:
            logger.error(f"No files found in S3 for prefix: {prefix}")
            return None
        
        # Return the extracted root directory if tar.gz was extracted, otherwise return local_dir
        result_dir = extracted_root if extracted_root else local_dir
        logger.info(f"Returning working directory: {result_dir}")
        
        # List what's actually in the directory
        if os.path.exists(result_dir):
            contents = os.listdir(result_dir)
            logger.info(f"Directory contents ({len(contents)} items): {contents[:10]}")
        else:
            logger.error(f"Result directory does not exist: {result_dir}")
        
        return result_dir
