"""
Shared utilities for agent communication and common operations
"""

import json
import logging
import requests
from typing import Dict, Any, Optional
from datetime import datetime
import hashlib
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AgentCommunicator:
    """Utility class for HTTP communication between agents"""
    
    def __init__(self, base_url: str = None):
        self.base_url = base_url or os.getenv('AGENTCORE_BASE_URL', 'http://localhost:8000')
        self.timeout = 30
        self.retry_count = 3
    
    def call_agent(self, agent_name: str, action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Make HTTP call to another agent"""
        url = f"{self.base_url}/agents/{agent_name}/{action}"
        
        request_data = {
            'action': action,
            'payload': payload,
            'timestamp': datetime.utcnow().isoformat(),
            'request_id': self._generate_request_id()
        }
        
        for attempt in range(self.retry_count):
            try:
                logger.info(f"Calling agent {agent_name} - attempt {attempt + 1}")
                response = requests.post(
                    url,
                    json=request_data,
                    timeout=self.timeout,
                    headers={'Content-Type': 'application/json'}
                )
                
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.warning(f"Agent call failed with status {response.status_code}")
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Agent communication error: {e}")
                if attempt == self.retry_count - 1:
                    raise
        
        raise Exception(f"Failed to communicate with agent {agent_name} after {self.retry_count} attempts")
    
    def _generate_request_id(self) -> str:
        """Generate unique request ID"""
        timestamp = datetime.utcnow().isoformat()
        return hashlib.md5(timestamp.encode()).hexdigest()[:8]

class ConfigManager:
    """Configuration management utility"""
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or os.getenv('CONFIG_PATH', 'config')
        self.config_cache = {}
    
    def get_config(self, environment: str) -> Dict[str, Any]:
        """Get configuration for specific environment"""
        if environment in self.config_cache:
            return self.config_cache[environment]
        
        config_file = os.path.join(self.config_path, f"{environment}.json")
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
                self.config_cache[environment] = config
                return config
        except FileNotFoundError:
            logger.error(f"Configuration file not found: {config_file}")
            return {}
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in configuration file: {e}")
            return {}
    
    def get_agent_config(self, agent_name: str, environment: str) -> Dict[str, Any]:
        """Get agent-specific configuration"""
        config = self.get_config(environment)
        return config.get('agents', {}).get(agent_name, {})
    
    def get_knowledge_base_config(self, environment: str) -> Dict[str, Any]:
        """Get knowledge base configuration"""
        config = self.get_config(environment)
        return config.get('knowledge_bases', {})

class ValidationUtils:
    """Validation utilities for data models"""
    
    @staticmethod
    def validate_repository_data(data: Dict[str, Any]) -> bool:
        """Validate repository data structure"""
        required_fields = ['url', 'owner', 'repo']
        return all(field in data for field in required_fields)
    
    @staticmethod
    def validate_scan_results(data: Dict[str, Any]) -> bool:
        """Validate scan results structure"""
        required_fields = ['scan_id', 'total_findings', 'findings']
        return all(field in data for field in required_fields)
    
    @staticmethod
    def validate_remediation_results(data: Dict[str, Any]) -> bool:
        """Validate remediation results structure"""
        required_fields = ['scan_id', 'fixes', 'manual_interventions']
        return all(field in data for field in required_fields)

class FileUtils:
    """File operation utilities"""
    
    @staticmethod
    def is_terraform_file(filename: str) -> bool:
        """Check if file is a Terraform file"""
        return filename.endswith(('.tf', '.tfvars', '.tf.json'))
    
    @staticmethod
    def extract_terraform_files(files: Dict[str, str]) -> Dict[str, str]:
        """Extract only Terraform files from file collection"""
        return {
            filename: content 
            for filename, content in files.items() 
            if FileUtils.is_terraform_file(filename)
        }
    
    @staticmethod
    def create_temp_directory() -> str:
        """Create temporary directory for file operations"""
        import tempfile
        return tempfile.mkdtemp(prefix='terraform_security_')
    
    @staticmethod
    def cleanup_temp_directory(directory: str) -> None:
        """Clean up temporary directory"""
        import shutil
        try:
            shutil.rmtree(directory)
            logger.info(f"Cleaned up temporary directory: {directory}")
        except Exception as e:
            logger.error(f"Failed to cleanup directory {directory}: {e}")

class SecurityUtils:
    """Security-related utilities"""
    
    @staticmethod
    def validate_github_webhook_signature(payload: bytes, signature: str, secret: str) -> bool:
        """Validate GitHub webhook signature"""
        import hmac
        
        expected_signature = 'sha256=' + hmac.new(
            secret.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(expected_signature, signature)
    
    @staticmethod
    def sanitize_repository_url(url: str) -> str:
        """Sanitize repository URL for security"""
        # Remove any potential injection attempts
        import re
        sanitized = re.sub(r'[^a-zA-Z0-9\-_./:]', '', url)
        return sanitized
    
    @staticmethod
    def mask_sensitive_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """Mask sensitive data in logs"""
        sensitive_keys = ['token', 'secret', 'password', 'key']
        masked_data = data.copy()
        
        for key in masked_data:
            if any(sensitive in key.lower() for sensitive in sensitive_keys):
                masked_data[key] = '***MASKED***'
        
        return masked_data

class MetricsCollector:
    """Metrics collection utility"""
    
    def __init__(self):
        self.metrics = {}
    
    def record_scan_duration(self, duration: float) -> None:
        """Record scan duration metric"""
        self.metrics['scan_duration'] = duration
    
    def record_findings_count(self, total: int, fixable: int, manual: int) -> None:
        """Record findings count metrics"""
        self.metrics.update({
            'total_findings': total,
            'fixable_findings': fixable,
            'manual_findings': manual
        })
    
    def record_remediation_success(self, fixes_applied: int, fixes_failed: int) -> None:
        """Record remediation success metrics"""
        self.metrics.update({
            'fixes_applied': fixes_applied,
            'fixes_failed': fixes_failed,
            'remediation_success_rate': fixes_applied / (fixes_applied + fixes_failed) if (fixes_applied + fixes_failed) > 0 else 0
        })
    
    def record_knowledge_base_query(self, kb_type: str, query_duration: float, results_count: int) -> None:
        """Record knowledge base query metrics"""
        if 'kb_queries' not in self.metrics:
            self.metrics['kb_queries'] = []
        
        self.metrics['kb_queries'].append({
            'kb_type': kb_type,
            'duration': query_duration,
            'results_count': results_count,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get collected metrics"""
        return self.metrics.copy()
    
    def reset_metrics(self) -> None:
        """Reset metrics collection"""
        self.metrics = {}

class KnowledgeBaseIntegration:
    """Integration utility for knowledge base operations"""
    
    def __init__(self, config_manager: ConfigManager = None):
        self.config_manager = config_manager or ConfigManager()
        self._kb_engine = None
    
    @property
    def kb_engine(self):
        """Lazy initialization of knowledge base engine"""
        if self._kb_engine is None:
            from .knowledge_base_utils import KnowledgeBaseQueryEngine
            self._kb_engine = KnowledgeBaseQueryEngine()
        return self._kb_engine
    
    def get_remediation_guidance(self, 
                               resource_type: str, 
                               violation_type: str,
                               environment: str = 'prod') -> Dict[str, Any]:
        """
        Get remediation guidance from knowledge bases
        
        Args:
            resource_type: AWS resource type
            violation_type: Type of security violation
            environment: Environment configuration to use
            
        Returns:
            Remediation guidance with sources
        """
        try:
            # Get knowledge base configuration
            kb_config = self.config_manager.get_knowledge_base_config(environment)
            
            # Query for remediation guidance
            result = self.kb_engine.get_terraform_security_guidance(
                resource_type=resource_type,
                violation_type=violation_type,
                context={'environment': environment}
            )
            
            return {
                'guidance': result.results,
                'confidence_scores': result.confidence_scores,
                'query_duration': result.query_duration,
                'total_results': result.total_results,
                'sources': [r.get('source', {}) for r in result.results]
            }
            
        except Exception as e:
            logger.error(f"Error getting remediation guidance: {e}")
            return {
                'error': str(e),
                'guidance': [],
                'fallback': True
            }
    
    def get_well_architected_guidance(self, 
                                    pillar: str = 'security',
                                    topic: Optional[str] = None) -> Dict[str, Any]:
        """
        Get Well-Architected Framework guidance
        
        Args:
            pillar: Well-Architected pillar
            topic: Specific topic within pillar
            
        Returns:
            Well-Architected guidance
        """
        try:
            result = self.kb_engine.get_well_architected_guidance(
                pillar=pillar,
                topic=topic
            )
            
            return {
                'guidance': result.results,
                'pillar': pillar,
                'topic': topic,
                'confidence_scores': result.confidence_scores,
                'query_duration': result.query_duration
            }
            
        except Exception as e:
            logger.error(f"Error getting Well-Architected guidance: {e}")
            return {
                'error': str(e),
                'guidance': [],
                'fallback': True
            }
    
    def clear_cache(self) -> bool:
        """Clear knowledge base cache"""
        try:
            self.kb_engine.clear_cache()
            return True
        except Exception as e:
            logger.error(f"Error clearing knowledge base cache: {e}")
            return False