"""
Knowledge Base Query Utilities for Terraform Security Platform
Provides optimized querying, caching, and error handling for Bedrock Knowledge Bases
"""

import json
import logging
import boto3
import hashlib
import time
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import os
import redis
from botocore.exceptions import ClientError, BotoCoreError

# Configure logging
logger = logging.getLogger(__name__)

class KnowledgeBaseType(Enum):
    """Enumeration of available knowledge base types"""
    TERRAFORM_AWS = "terraform_aws"
    WELL_ARCHITECTED = "well_architected"

@dataclass
class QueryResult:
    """Data class for knowledge base query results"""
    query: str
    knowledge_base_type: str
    results: List[Dict[str, Any]]
    confidence_scores: List[float]
    total_results: int
    query_duration: float
    timestamp: str
    cached: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

@dataclass
class KnowledgeBaseConfig:
    """Configuration for knowledge base"""
    kb_id: str
    name: str
    description: str
    embedding_model: str
    max_results: int = 10
    confidence_threshold: float = 0.7

class KnowledgeBaseQueryEngine:
    """
    Main query engine for Bedrock Knowledge Bases with caching and optimization
    """
    
    def __init__(self, 
                 region_name: str = None,
                 cache_enabled: bool = True,
                 cache_ttl: int = 3600,
                 redis_host: str = None,
                 redis_port: int = 6379):
        """
        Initialize the knowledge base query engine
        
        Args:
            region_name: AWS region name
            cache_enabled: Whether to enable result caching
            cache_ttl: Cache time-to-live in seconds
            redis_host: Redis host for caching (optional)
            redis_port: Redis port for caching
        """
        self.region_name = region_name or os.getenv('AWS_REGION', 'us-east-1')
        self.cache_enabled = cache_enabled
        self.cache_ttl = cache_ttl
        
        # Initialize AWS clients
        try:
            self.bedrock_agent_runtime = boto3.client(
                'bedrock-agent-runtime',
                region_name=self.region_name
            )
            self.bedrock_agent = boto3.client(
                'bedrock-agent',
                region_name=self.region_name
            )
        except Exception as e:
            logger.error(f"Failed to initialize AWS clients: {e}")
            raise
        
        # Initialize cache
        self.cache = None
        if cache_enabled:
            try:
                if redis_host:
                    self.cache = redis.Redis(
                        host=redis_host,
                        port=redis_port,
                        decode_responses=True,
                        socket_timeout=5
                    )
                    # Test connection
                    self.cache.ping()
                    logger.info("Redis cache initialized successfully")
                else:
                    # Use in-memory cache as fallback
                    self.cache = {}
                    logger.info("Using in-memory cache")
            except Exception as e:
                logger.warning(f"Cache initialization failed, disabling cache: {e}")
                self.cache_enabled = False
        
        # Knowledge base configurations
        self.kb_configs = self._load_kb_configs()
        
        # Query optimization settings
        self.max_retries = 3
        self.retry_delay = 1.0
        self.request_timeout = 30
        
    def _load_kb_configs(self) -> Dict[str, KnowledgeBaseConfig]:
        """Load knowledge base configurations from environment or defaults"""
        configs = {}
        
        # Terraform AWS Knowledge Base
        terraform_kb_id = os.getenv('TERRAFORM_AWS_KB_ID')
        if terraform_kb_id:
            configs[KnowledgeBaseType.TERRAFORM_AWS.value] = KnowledgeBaseConfig(
                kb_id=terraform_kb_id,
                name="Terraform AWS Provider Knowledge Base",
                description="AWS Terraform Provider documentation and best practices",
                embedding_model="amazon.titan-embed-text-v1",
                max_results=15,
                confidence_threshold=0.6
            )
        
        # Well-Architected Knowledge Base
        wa_kb_id = os.getenv('WELL_ARCHITECTED_KB_ID')
        if wa_kb_id:
            configs[KnowledgeBaseType.WELL_ARCHITECTED.value] = KnowledgeBaseConfig(
                kb_id=wa_kb_id,
                name="AWS Well-Architected Framework Knowledge Base",
                description="AWS Well-Architected Framework documentation",
                embedding_model="amazon.titan-embed-text-v1",
                max_results=10,
                confidence_threshold=0.7
            )
        
        return configs
    
    def query_knowledge_base(self,
                           query: str,
                           kb_type: Union[KnowledgeBaseType, str],
                           max_results: Optional[int] = None,
                           confidence_threshold: Optional[float] = None,
                           use_cache: bool = True) -> QueryResult:
        """
        Query a specific knowledge base with optimization and caching
        
        Args:
            query: Search query string
            kb_type: Knowledge base type to query
            max_results: Maximum number of results to return
            confidence_threshold: Minimum confidence score for results
            use_cache: Whether to use cached results
            
        Returns:
            QueryResult object with search results and metadata
        """
        start_time = time.time()
        
        # Normalize kb_type
        if isinstance(kb_type, KnowledgeBaseType):
            kb_type_str = kb_type.value
        else:
            kb_type_str = kb_type
        
        # Validate knowledge base type
        if kb_type_str not in self.kb_configs:
            raise ValueError(f"Unknown knowledge base type: {kb_type_str}")
        
        kb_config = self.kb_configs[kb_type_str]
        
        # Use config defaults if not specified
        max_results = max_results or kb_config.max_results
        confidence_threshold = confidence_threshold or kb_config.confidence_threshold
        
        # Check cache first
        cache_key = None
        if self.cache_enabled and use_cache:
            cache_key = self._generate_cache_key(query, kb_type_str, max_results, confidence_threshold)
            cached_result = self._get_cached_result(cache_key)
            if cached_result:
                cached_result.cached = True
                logger.info(f"Cache hit for query: {query[:50]}...")
                return cached_result
        
        # Execute query with retries
        result = self._execute_query_with_retries(
            query, kb_config, max_results, confidence_threshold
        )
        
        # Calculate query duration
        query_duration = time.time() - start_time
        
        # Create result object
        query_result = QueryResult(
            query=query,
            knowledge_base_type=kb_type_str,
            results=result['results'],
            confidence_scores=result['confidence_scores'],
            total_results=len(result['results']),
            query_duration=query_duration,
            timestamp=datetime.utcnow().isoformat(),
            cached=False
        )
        
        # Cache the result
        if self.cache_enabled and use_cache and cache_key:
            self._cache_result(cache_key, query_result)
        
        logger.info(f"Knowledge base query completed: {query_result.total_results} results in {query_duration:.2f}s")
        return query_result
    
    def query_multiple_knowledge_bases(self,
                                     query: str,
                                     kb_types: List[Union[KnowledgeBaseType, str]],
                                     max_results_per_kb: int = 5,
                                     merge_results: bool = True) -> Union[QueryResult, List[QueryResult]]:
        """
        Query multiple knowledge bases and optionally merge results
        
        Args:
            query: Search query string
            kb_types: List of knowledge base types to query
            max_results_per_kb: Maximum results per knowledge base
            merge_results: Whether to merge results into single QueryResult
            
        Returns:
            Single merged QueryResult or list of QueryResults
        """
        results = []
        
        for kb_type in kb_types:
            try:
                result = self.query_knowledge_base(
                    query=query,
                    kb_type=kb_type,
                    max_results=max_results_per_kb
                )
                results.append(result)
            except Exception as e:
                logger.error(f"Error querying {kb_type}: {e}")
                # Continue with other knowledge bases
                continue
        
        if not results:
            raise Exception("All knowledge base queries failed")
        
        if merge_results:
            return self._merge_query_results(query, results)
        else:
            return results
    
    def get_terraform_security_guidance(self,
                                      resource_type: str,
                                      violation_type: str,
                                      context: Optional[Dict[str, Any]] = None) -> QueryResult:
        """
        Get specific security guidance for Terraform resources
        
        Args:
            resource_type: AWS resource type (e.g., 'aws_s3_bucket')
            violation_type: Type of security violation
            context: Additional context for the query
            
        Returns:
            QueryResult with security guidance
        """
        # Construct optimized query for security guidance
        query_parts = [
            f"security best practices for {resource_type}",
            f"fix {violation_type}",
            "terraform configuration"
        ]
        
        if context:
            if 'severity' in context:
                query_parts.append(f"severity {context['severity']}")
            if 'compliance' in context:
                query_parts.append(f"compliance {context['compliance']}")
        
        query = " ".join(query_parts)
        
        # Query both knowledge bases for comprehensive guidance
        return self.query_multiple_knowledge_bases(
            query=query,
            kb_types=[KnowledgeBaseType.TERRAFORM_AWS, KnowledgeBaseType.WELL_ARCHITECTED],
            max_results_per_kb=8,
            merge_results=True
        )
    
    def get_well_architected_guidance(self,
                                    pillar: str = "security",
                                    topic: Optional[str] = None) -> QueryResult:
        """
        Get Well-Architected Framework guidance for specific pillar
        
        Args:
            pillar: Well-Architected pillar (security, reliability, etc.)
            topic: Specific topic within the pillar
            
        Returns:
            QueryResult with Well-Architected guidance
        """
        query_parts = [f"AWS Well-Architected {pillar} pillar"]
        
        if topic:
            query_parts.append(topic)
        
        query = " ".join(query_parts)
        
        return self.query_knowledge_base(
            query=query,
            kb_type=KnowledgeBaseType.WELL_ARCHITECTED,
            max_results=12,
            confidence_threshold=0.6
        )
    
    def _execute_query_with_retries(self,
                                  query: str,
                                  kb_config: KnowledgeBaseConfig,
                                  max_results: int,
                                  confidence_threshold: float) -> Dict[str, Any]:
        """Execute knowledge base query with retry logic"""
        
        for attempt in range(self.max_retries):
            try:
                response = self.bedrock_agent_runtime.retrieve(
                    knowledgeBaseId=kb_config.kb_id,
                    retrievalQuery={
                        'text': query
                    },
                    retrievalConfiguration={
                        'vectorSearchConfiguration': {
                            'numberOfResults': max_results,
                            'overrideSearchType': 'HYBRID'
                        }
                    }
                )
                
                # Process results
                results = []
                confidence_scores = []
                
                for item in response.get('retrievalResults', []):
                    confidence = item.get('score', 0.0)
                    
                    if confidence >= confidence_threshold:
                        results.append({
                            'content': item.get('content', {}).get('text', ''),
                            'source': item.get('location', {}).get('s3Location', {}),
                            'metadata': item.get('metadata', {}),
                            'confidence': confidence
                        })
                        confidence_scores.append(confidence)
                
                return {
                    'results': results,
                    'confidence_scores': confidence_scores
                }
                
            except (ClientError, BotoCoreError) as e:
                logger.warning(f"Knowledge base query attempt {attempt + 1} failed: {e}")
                if attempt == self.max_retries - 1:
                    raise
                time.sleep(self.retry_delay * (2 ** attempt))  # Exponential backoff
            
            except Exception as e:
                logger.error(f"Unexpected error in knowledge base query: {e}")
                raise
        
        raise Exception(f"Knowledge base query failed after {self.max_retries} attempts")
    
    def _generate_cache_key(self, query: str, kb_type: str, max_results: int, confidence_threshold: float) -> str:
        """Generate cache key for query"""
        key_data = f"{query}:{kb_type}:{max_results}:{confidence_threshold}"
        return f"kb_query:{hashlib.md5(key_data.encode()).hexdigest()}"
    
    def _get_cached_result(self, cache_key: str) -> Optional[QueryResult]:
        """Get cached query result"""
        try:
            if isinstance(self.cache, dict):
                # In-memory cache
                cached_data = self.cache.get(cache_key)
                if cached_data and cached_data['expires'] > time.time():
                    return QueryResult(**cached_data['result'])
            else:
                # Redis cache
                cached_json = self.cache.get(cache_key)
                if cached_json:
                    cached_data = json.loads(cached_json)
                    return QueryResult(**cached_data)
        except Exception as e:
            logger.warning(f"Cache retrieval error: {e}")
        
        return None
    
    def _cache_result(self, cache_key: str, result: QueryResult) -> None:
        """Cache query result"""
        try:
            if isinstance(self.cache, dict):
                # In-memory cache
                self.cache[cache_key] = {
                    'result': result.to_dict(),
                    'expires': time.time() + self.cache_ttl
                }
            else:
                # Redis cache
                self.cache.setex(
                    cache_key,
                    self.cache_ttl,
                    json.dumps(result.to_dict())
                )
        except Exception as e:
            logger.warning(f"Cache storage error: {e}")
    
    def _merge_query_results(self, query: str, results: List[QueryResult]) -> QueryResult:
        """Merge multiple query results into a single result"""
        all_results = []
        all_confidence_scores = []
        total_duration = 0
        
        for result in results:
            all_results.extend(result.results)
            all_confidence_scores.extend(result.confidence_scores)
            total_duration += result.query_duration
        
        # Sort by confidence score
        combined = list(zip(all_results, all_confidence_scores))
        combined.sort(key=lambda x: x[1], reverse=True)
        
        sorted_results, sorted_scores = zip(*combined) if combined else ([], [])
        
        return QueryResult(
            query=query,
            knowledge_base_type="merged",
            results=list(sorted_results),
            confidence_scores=list(sorted_scores),
            total_results=len(sorted_results),
            query_duration=total_duration,
            timestamp=datetime.utcnow().isoformat(),
            cached=False
        )
    
    def clear_cache(self) -> None:
        """Clear all cached results"""
        try:
            if isinstance(self.cache, dict):
                self.cache.clear()
            else:
                # Redis cache - clear only our keys
                keys = self.cache.keys("kb_query:*")
                if keys:
                    self.cache.delete(*keys)
            logger.info("Knowledge base cache cleared")
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        try:
            if isinstance(self.cache, dict):
                return {
                    'cache_type': 'in_memory',
                    'total_keys': len(self.cache),
                    'cache_enabled': self.cache_enabled
                }
            else:
                info = self.cache.info()
                return {
                    'cache_type': 'redis',
                    'total_keys': info.get('db0', {}).get('keys', 0),
                    'memory_usage': info.get('used_memory_human', 'unknown'),
                    'cache_enabled': self.cache_enabled
                }
        except Exception as e:
            logger.error(f"Error getting cache stats: {e}")
            return {'error': str(e)}

# Convenience functions for common use cases
def query_terraform_security(query: str, max_results: int = 10) -> QueryResult:
    """
    Convenience function to query Terraform security knowledge base
    
    Args:
        query: Search query
        max_results: Maximum number of results
        
    Returns:
        QueryResult with Terraform security guidance
    """
    engine = KnowledgeBaseQueryEngine()
    return engine.query_knowledge_base(
        query=query,
        kb_type=KnowledgeBaseType.TERRAFORM_AWS,
        max_results=max_results
    )

def query_well_architected(query: str, max_results: int = 10) -> QueryResult:
    """
    Convenience function to query Well-Architected knowledge base
    
    Args:
        query: Search query
        max_results: Maximum number of results
        
    Returns:
        QueryResult with Well-Architected guidance
    """
    engine = KnowledgeBaseQueryEngine()
    return engine.query_knowledge_base(
        query=query,
        kb_type=KnowledgeBaseType.WELL_ARCHITECTED,
        max_results=max_results
    )

def get_security_remediation_guidance(resource_type: str, 
                                    violation_type: str,
                                    severity: str = "HIGH") -> QueryResult:
    """
    Get comprehensive security remediation guidance
    
    Args:
        resource_type: AWS resource type
        violation_type: Type of security violation
        severity: Severity level
        
    Returns:
        QueryResult with remediation guidance
    """
    engine = KnowledgeBaseQueryEngine()
    return engine.get_terraform_security_guidance(
        resource_type=resource_type,
        violation_type=violation_type,
        context={'severity': severity}
    )