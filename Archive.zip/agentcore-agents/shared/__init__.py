# Shared module for agent communication
