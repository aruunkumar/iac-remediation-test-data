#!/usr/bin/env python3
"""
Deploy GitHub Integration Agent using manually built Docker image
This bypasses the bedrock-agentcore-starter-toolkit and uses direct AWS API calls
"""

import boto3
import subprocess
import sys
import json
from datetime import datetime

# Configuration
AWS_REGION = "us-east-1"
AWS_ACCOUNT_ID = "545009861279"
ECR_REPO_NAME = "github-integration-agent"
IMAGE_TAG = "latest"
RUNTIME_NAME = "github_integration_agent_s3"
ROLE_NAME = "github-integration-agentcore-role"

def run_command(cmd, description):
    """Run a shell command and handle errors"""
    print(f"\n{description}...")
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print(f"✓ {description} completed")
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"✗ {description} failed")
        print(f"Error: {e.stderr}")
        sys.exit(1)

def main():
    print("=" * 70)
    print("GitHub Integration Agent - Manual Docker Deployment")
    print("=" * 70)
    
    # Change to script directory
    import os
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    print(f"\nWorking directory: {os.getcwd()}")
    
    ecr_client = boto3.client('ecr', region_name=AWS_REGION)
    iam_client = boto3.client('iam')
    agentcore_client = boto3.client('bedrock-agentcore-control', region_name=AWS_REGION)
    
    # Step 1: Create ECR repository if needed
    print("\nStep 1: Checking ECR repository...")
    try:
        ecr_client.describe_repositories(repositoryNames=[ECR_REPO_NAME])
        print(f"✓ ECR repository '{ECR_REPO_NAME}' already exists")
    except ecr_client.exceptions.RepositoryNotFoundException:
        print(f"Creating ECR repository: {ECR_REPO_NAME}")
        ecr_client.create_repository(
            repositoryName=ECR_REPO_NAME,
            imageScanningConfiguration={'scanOnPush': True}
        )
        print(f"✓ ECR repository created")
    
    # Step 2: Build Docker image
    image_uri = f"{AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com/{ECR_REPO_NAME}:{IMAGE_TAG}"
    
    # Build from parent directory to access shared module
    parent_dir = os.path.dirname(script_dir)
    print(f"Building from: {parent_dir}")
    
    # Change to parent directory and build
    original_dir = os.getcwd()
    os.chdir(parent_dir)
    
    run_command(
        f"finch build --platform linux/arm64 -f github_integration/Dockerfile.manual -t {ECR_REPO_NAME}:{IMAGE_TAG} .",
        "Building Docker image for ARM64"
    )
    
    # Change back to original directory
    os.chdir(original_dir)
    
    # Step 3: Login to ECR
    run_command(
        f"aws ecr get-login-password --region {AWS_REGION} | "
        f"finch login --username AWS --password-stdin {AWS_ACCOUNT_ID}.dkr.ecr.{AWS_REGION}.amazonaws.com",
        "Logging in to ECR"
    )
    
    # Step 4: Tag image
    run_command(
        f"finch tag {ECR_REPO_NAME}:{IMAGE_TAG} {image_uri}",
        "Tagging image"
    )
    
    # Step 5: Push to ECR
    run_command(
        f"finch push {image_uri}",
        "Pushing image to ECR"
    )
    
    print(f"\n✓ Image URI: {image_uri}")
    
    # Step 6: Create IAM role if needed
    print("\nStep 6: Checking IAM role...")
    role_arn = f"arn:aws:iam::{AWS_ACCOUNT_ID}:role/{ROLE_NAME}"
    try:
        iam_client.get_role(RoleName=ROLE_NAME)
        print(f"✓ IAM role '{ROLE_NAME}' already exists")
    except iam_client.exceptions.NoSuchEntityException:
        print(f"Creating IAM role: {ROLE_NAME}")
        
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }]
        }
        
        iam_client.create_role(
            RoleName=ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy)
        )
        
        # Attach CloudWatch Logs policy
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
        )
        
        # Attach ECR read policy
        iam_client.attach_role_policy(
            RoleName=ROLE_NAME,
            PolicyArn="arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
        )
        
        print(f"✓ IAM role created with CloudWatch and ECR permissions")
        print("⏳ Waiting 10 seconds for IAM role to propagate...")
        import time
        time.sleep(10)
    
    # Ensure role has S3 and Secrets Manager permissions (for existing roles too)
    print("\nEnsuring IAM role has required permissions...")
    
    # S3 access policy
    s3_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::terraform-security-platform-storage",
                "arn:aws:s3:::terraform-security-platform-storage/*"
            ]
        }]
    }
    
    # Secrets Manager access policy
    secrets_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetSecretValue"
            ],
            "Resource": [
                f"arn:aws:secretsmanager:{AWS_REGION}:{AWS_ACCOUNT_ID}:secret:terraform-security-platform/github-token*"
            ]
        }]
    }
    
    try:
        iam_client.put_role_policy(
            RoleName=ROLE_NAME,
            PolicyName="S3Access",
            PolicyDocument=json.dumps(s3_policy)
        )
        print("✓ S3 access policy attached")
    except Exception as e:
        print(f"⚠️  Could not attach S3 policy: {e}")
    
    try:
        iam_client.put_role_policy(
            RoleName=ROLE_NAME,
            PolicyName="SecretsManagerAccess",
            PolicyDocument=json.dumps(secrets_policy)
        )
        print("✓ Secrets Manager access policy attached")
    except Exception as e:
        print(f"⚠️  Could not attach Secrets Manager policy: {e}")
    
    # Step 7: Create or update AgentCore runtime
    print("\nStep 7: Creating/updating AgentCore runtime...")
    
    # Environment variables for the agent
    environment_variables = {
        'GITHUB_TOKEN_SECRET_NAME': 'terraform-security-platform/github-token',
        'WORKFLOW_BUCKET': 'terraform-security-platform-storage',
        'AWS_REGION': 'us-east-1'
    }
    
    # Try to create, if it exists we'll get a conflict error
    try:
        print(f"Creating new runtime: {RUNTIME_NAME}")
        
        response = agentcore_client.create_agent_runtime(
            agentRuntimeName=RUNTIME_NAME,
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            },
            networkConfiguration={'networkMode': 'PUBLIC'},
            roleArn=role_arn,
            environmentVariables=environment_variables
        )
        
        runtime_arn = response['agentRuntimeArn']
        print("✓ Runtime created")
        print(f"✓ Environment variables set: {list(environment_variables.keys())}")
        
    except agentcore_client.exceptions.ConflictException:
        print(f"Runtime '{RUNTIME_NAME}' already exists. Updating...")
        
        # List runtimes to find the ID
        list_response = agentcore_client.list_agent_runtimes()
        runtime_arn = None
        runtime_id = None
        for runtime in list_response.get('agentRuntimes', []):
            # Runtime name might have a suffix, check if it starts with our name
            if runtime['agentRuntimeName'] == RUNTIME_NAME:
                runtime_arn = runtime['agentRuntimeArn']
                runtime_id = runtime['agentRuntimeId']
                runtime_status = runtime.get('status')
                print(f"Found runtime: {runtime['agentRuntimeName']} (status: {runtime_status})")
                
                if runtime_status == 'DELETING':
                    print(f"⚠️  Runtime is being deleted. Please wait and try again.")
                    sys.exit(1)
                break
        
        if not runtime_id:
            print(f"✗ Could not find runtime ID for {RUNTIME_NAME}")
            print(f"Available runtimes: {[r['agentRuntimeName'] for r in list_response.get('agentRuntimes', [])]}")
            sys.exit(1)
        
        agentcore_client.update_agent_runtime(
            agentRuntimeId=runtime_id,
            agentRuntimeArtifact={
                'containerConfiguration': {
                    'containerUri': image_uri
                }
            },
            roleArn=role_arn,
            networkConfiguration={'networkMode': 'PUBLIC'},
            environmentVariables=environment_variables
        )
        print("✓ Runtime updated")
        print(f"✓ Environment variables set: {list(environment_variables.keys())}")
    
    # Summary
    print("\n" + "=" * 70)
    print("DEPLOYMENT SUCCESSFUL!")
    print("=" * 70)
    print(f"\nRuntime ARN: {runtime_arn}")
    print(f"Image URI: {image_uri}")
    print(f"\nTest with:")
    print(f"  python test_github_agent.py")
    print(f"\nOr manually:")
    print(f"  aws bedrock-agentcore invoke-agent-runtime \\")
    print(f"    --agent-runtime-arn {runtime_arn} \\")
    print(f"    --payload '{{\"action\":\"health\"}}' \\")
    print(f"    response.json")
    print()

if __name__ == "__main__":
    main()
