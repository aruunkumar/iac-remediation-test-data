#!/usr/bin/env python3
"""
Comprehensive test of GitHub Integration Agent deployed on AWS Bedrock AgentCore
Tests S3-based storage for repository data sharing between agents
"""
import boto3
import json
import time
import os
import uuid

def test_github_agent():
    """Test the GitHub Integration Agent with S3 storage functionality"""
    
    # Initialize Bedrock AgentCore client
    client = boto3.client('bedrock-agentcore', region_name='us-east-1')
    
    # Agent runtime ARN - Use the S3-enabled deployment
    agent_runtime_arn = os.getenv(
        "AGENT_ARN",
        "arn:aws:bedrock-agentcore:us-east-1:545009861279:runtime/github_integration_agent_s3-KYs53SDSNM"
    )
    
    # Get GitHub token from environment or use default
    github_token = os.getenv('GITHUB_TOKEN', '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')
    
    if not github_token or github_token == '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':
        print("⚠️  Using default GitHub token (agent can also fetch from Secrets Manager)")
    else:
        print("✓ Using GITHUB_TOKEN from environment (will be passed to agent)")
    
    print("=" * 70)
    print("🚀 GitHub Integration Agent - S3 Storage Test Suite")
    print("=" * 70)
    print(f"Agent ARN: {agent_runtime_arn}")
    print(f"Note: Agent now uses S3 for storage (not local /tmp)")
    print()
    
    results = []
    
    # Test 1: Health Check
    print("📋 Test 1: Health Check")
    print("-" * 70)
    try:
        payload = {"action": "health"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        print(f"✅ Status: {result.get('status', 'unknown')}")
        results.append(("Health Check", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Health Check", False))
    print()
    time.sleep(1)
    
    # Test 2: Status & Capabilities
    print("📋 Test 2: Status & Capabilities")
    print("-" * 70)
    try:
        payload = {"action": "status"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        print(f"✅ Agent: {result.get('agent_name', 'unknown')} v{result.get('version', 'unknown')}")
        print(f"✅ Status: {result.get('status', 'unknown')}")
        capabilities = result.get('capabilities', [])
        print(f"✅ Capabilities ({len(capabilities)}):")
        for cap in capabilities:
            print(f"   • {cap}")
        results.append(("Status Check", True))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Status Check", False))
    print()
    time.sleep(1)
    
    # Test 3: Setup Repository with S3 Upload
    if True:  # Always run with default token
        print("📋 Test 3: Setup Repository (Clone, Branch & Upload to S3)")
        print("-" * 70)
        try:
            # Generate unique workflow ID for this test
            test_workflow_id = f"test-{uuid.uuid4().hex[:12]}"
            
            payload = {
                "action": "setup",  # Orchestrator uses "setup"
                "repository_data": {
                    "owner": "aruunkumar",
                    "repo": "iac-remediation-test-data",
                    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
                    "source_branch": "main",
                    "commit_sha": "HEAD",
                    "workflow_id": test_workflow_id,
                    "author": "aruunkumar",
                    "default_branch": "main",
                    "github_token": github_token  # Optional - agent will fetch from Secrets Manager if not provided
                }
            }
            response = client.invoke_agent_runtime(
                agentRuntimeArn=agent_runtime_arn,
                payload=json.dumps(payload)
            )
            result = json.loads(response['response'].read())
            
            if result.get('success'):
                print(f"✅ S3 URI: {result.get('s3_uri', 'N/A')}")
                print(f"✅ Branch created: {result.get('branch_name')}")
                print(f"✅ Workflow ID: {result.get('workflow_id')}")
                print(f"✅ Message: {result.get('message')}")
                results.append(("Setup Repository", True))
                
                # Store for later tests
                workflow_id = result.get('workflow_id')
                s3_uri = result.get('s3_uri')
                branch_name = result.get('branch_name')
            else:
                print(f"❌ Failed: {result.get('error', 'Unknown error')}")
                results.append(("Setup Repository", False))
        except Exception as e:
            print(f"❌ Failed: {str(e)}")
            results.append(("Setup Repository", False))
        print()
        time.sleep(1)
        
        # Note: Get File Content and Cleanup tests removed - not relevant for S3 workflow
        # In S3 workflow: Checkov agent downloads from S3, not GitHub agent
        # Cleanup is handled by orchestrator, not individual test calls

    
    # Test 4: Create PR (using existing workflow with remediated code)
    print("📋 Test 4: Create PR from Remediated Code")
    print("-" * 70)
    print("Using workflow: d3978da9-c419-4686-a3a1-8ee501d8f050")
    print("This workflow has remediated code in S3")
    print("Agent will download remediation_results.json from S3")
    print()
    try:
        payload = {
            "action": "create_pr",
            "repository_data": {
                "owner": "aruunkumar",
                "repo": "iac-remediation-test-data",
                "source_branch": "main",
                "workflow_id": "d3978da9-c419-4686-a3a1-8ee501d8f050",
                "github_token": github_token
            }
            # No remediation_results in payload - agent downloads from S3
        }
        
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if result.get('success'):
            print(f"✅ PR Created: {result.get('pr_url')}")
            print(f"✅ PR Number: {result.get('pr_number')}")
            print(f"✅ Branch: {result.get('branch_name')}")
            results.append(("Create PR", True))
        else:
            print(f"❌ Failed: {result.get('error', 'Unknown error')}")
            results.append(("Create PR", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Create PR", False))
    print()
    time.sleep(1)
    
    # Test 5: Error Handling
    print("📋 Test 5: Error Handling (Invalid Action)")
    print("-" * 70)
    try:
        payload = {"action": "invalid_action_xyz"}
        response = client.invoke_agent_runtime(
            agentRuntimeArn=agent_runtime_arn,
            payload=json.dumps(payload)
        )
        result = json.loads(response['response'].read())
        
        if 'error' in result or result.get('status') == 'error':
            print(f"✅ Error handling works: {result.get('error', result.get('message'))}")
            results.append(("Error Handling", True))
        else:
            print(f"❌ Expected error but got: {result}")
            results.append(("Error Handling", False))
    except Exception as e:
        print(f"❌ Failed: {str(e)}")
        results.append(("Error Handling", False))
    print()
    
    # Summary
    print("=" * 70)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print()
    print(f"🎯 Overall: {passed}/{total} tests passed ({passed*100//total}%)")
    
    if passed == total:
        print("🎉 All tests passed! Agent is fully functional with S3 storage.")
    elif passed > 0:
        print("⚠️  Some tests passed. Check details above.")
    else:
        print("❌ All tests failed. Check agent configuration and S3 permissions.")
    
    print()
    print("💡 View detailed logs:")
    print(f"   aws logs tail /aws/bedrock-agentcore/runtimes/github_integration_agent_manual-ycVHWBElRZ-DEFAULT \\")
    print(f"     --region us-east-1 --since 5m --follow")
    print()
    print("💡 Check S3 storage:")
    print(f"   aws s3 ls s3://terraform-security-platform-storage/workflows/ --recursive")
    print()
    
    return results

if __name__ == "__main__":
    test_github_agent()
