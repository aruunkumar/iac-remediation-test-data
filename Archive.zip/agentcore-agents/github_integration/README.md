# GitHub Integration Agent

AWS Bedrock AgentCore agent for GitHub repository operations with S3-based storage for distributed workflows.

## Overview

This agent handles GitHub repository operations in the Terraform Security Platform:
- Clones repositories and creates remediation branches
- Uploads repository data to S3 for sharing with other agents
- Downloads fixed code from S3 and creates pull requests
- Manages GitHub API interactions (labels, reviewers, workflows)

## Architecture

### S3-Based Storage

The agent uses S3 instead of local `/tmp` storage to enable distributed execution:

```
1. Setup Phase:
   Clone repo → Create branch → Upload to S3 → Clean up local

2. PR Creation Phase:
   Download from S3 → Commit changes → Push → Create PR → Clean up local
```

**S3 Structure:**
```
s3://terraform-security-platform-storage/
└── workflows/{workflow_id}/
    ├── github-agent/
    │   ├── data.tar.gz           # Repository tarball
    │   └── metadata.json         # Branch, owner, repo info
    └── terraform-remediation-agent/
        └── data.tar.gz           # Fixed repository (for PR creation)
```

### Key Features

- **Distributed Execution**: Agents can run on different containers
- **Data Persistence**: Repository data survives across agent invocations
- **Workflow Isolation**: Each workflow has unique ID and S3 namespace
- **Auto-cleanup**: S3 lifecycle policy deletes data after 7 days

## Files

### Core Files
- `main.py` - Agent implementation with S3 integration
- `requirements.txt` - Python dependencies
- `Dockerfile.manual` - Docker image definition (builds from parent dir)
- `deploy_manual.py` - Deployment script
- `test_github_agent.py` - Test suite

### Configuration
- `.dockerignore` - Files to exclude from Docker build

### Toolkit Deployment (Legacy)
- `toolkit-deployment/` - Original bedrock-agentcore-starter-toolkit files

## Prerequisites

1. **S3 Bucket**: Run setup script from parent directory
   ```bash
   cd ../
   ./setup_s3_storage.sh
   ```

2. **IAM Permissions**: Agent role needs:
   - S3: GetObject, PutObject, DeleteObject, ListBucket
   - ECR: Read access
   - CloudWatch: Logs access
   - Secrets Manager: GetSecretValue (if using Secrets Manager for token)

3. **GitHub Token Configuration**:

   The agent independently fetches the GitHub token with this priority:
   
   **Option 1: AWS Secrets Manager (Recommended for Production)**
   ```bash
   # Create secret
   aws secretsmanager create-secret \
     --name terraform-security-platform/github-token \
     --secret-string '{"github_token":"ghp_your_token_here"}'
   
   # Set environment variable in Dockerfile or deployment
   export GITHUB_TOKEN_SECRET_NAME="terraform-security-platform/github-token"
   ```
   
   **Option 2: Pass in Request Payload**
   ```json
   {
     "repository_data": {
       "github_token": "ghp_your_token_here",
       ...
     }
   }
   ```
   
   **Option 3: Environment Variable (Development)**
   ```bash
   export GITHUB_TOKEN="ghp_your_token_here"
   ```

## Build & Deployment

### Deployment Options

There are **two ways** to deploy this agent:

#### 1. Manual Deployment (Recommended)
Python script with full control:
```bash
python3 deploy_manual.py
```

**Features:**
- Builds from parent directory (supports shared module)
- Full control over build process
- Supports S3 integration
- Handles ECR, IAM, and AgentCore runtime

#### 2. Toolkit Deployment (toolkit-deployment/)
Uses `bedrock-agentcore-starter-toolkit`:
```bash
cd toolkit-deployment/
python3 deploy_github_agent.py
```

**Features:**
- Automated deployment via CodeBuild
- No manual Docker builds
- **Limitation**: Can't build from parent directory (no shared module support)

**For S3 storage, use manual deployment (option 1).**

### Docker Build Context

The Dockerfile builds from the **parent directory** (`agentcore-agents/`) to access the shared S3 module:

```dockerfile
# Build context: agentcore-agents/
COPY shared/ /app/shared/              # Shared S3 utility
COPY github_integration/ /app/         # Agent code
```

### Deployment Steps

**Deploy the agent:**

```bash
python3 deploy_manual.py
```

This script:
   - Creates ECR repository if needed
   - Builds Docker image from parent directory
   - Pushes to ECR
   - Creates/updates AgentCore runtime

2. **Verify Deployment**:
   ```bash
   aws bedrock-agentcore-control list-agent-runtimes --region us-east-1
   ```

3. **Test**:
   ```bash
   export AGENT_ARN="arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/github_integration_agent_s3-ID"
   python3 test_github_agent.py
   ```

### Environment Variables

Set in Dockerfile or deployment configuration:
- `AGENT_STORAGE_BUCKET=terraform-security-platform-storage` - S3 bucket for workflow data
- `AWS_REGION=us-east-1` - AWS region
- `GITHUB_TOKEN_SECRET_NAME=terraform-security-platform/github-token` - (Optional) Secrets Manager secret name for GitHub token
- `GITHUB_TOKEN=ghp_...` - (Optional) Direct GitHub token (not recommended for production)

## Usage

### Setup Repository (Step 1)

Called by orchestrator at workflow start:

```python
payload = {
    "action": "setup",
    "repository_data": {
        "owner": "org-name",
        "repo": "repo-name",
        "url": "https://github.com/org-name/repo-name.git",
        "source_branch": "main",
        "workflow_id": "unique-workflow-id",
        "github_token": "ghp_..."  # Optional - agent will fetch from Secrets Manager or env var if not provided
    }
}
```

**Response:**
```json
{
  "success": true,
  "s3_uri": "s3://bucket/workflows/workflow-id/github-agent/data.tar.gz",
  "branch_name": "iac-remediation/main-abc123",
  "workflow_id": "unique-workflow-id",
  "message": "Repository cloned and uploaded to S3"
}
```

### Create Pull Request (Step 4)

Called by orchestrator after remediation:

```python
payload = {
    "action": "create_pr",
    "repository_data": {
        "owner": "org-name",
        "repo": "repo-name",
        "workflow_id": "unique-workflow-id",
        "github_token": "ghp_..."  # Optional - agent will fetch from Secrets Manager or env var if not provided
    },
    "remediation_results": {
        "fixes": [...],
        "manual_interventions": [...]
    }
}
```

**Response:**
```json
{
  "success": true,
  "pr_number": 123,
  "pr_url": "https://github.com/org/repo/pull/123",
  "branch_name": "iac-remediation/main-abc123",
  "status": "created"
}
```

## Testing

### Run Test Suite

```bash
export AGENT_ARN="arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/github_integration_agent_s3-ID"
python3 test_github_agent.py
```

**Tests:**
1. Health Check - Verifies agent is running
2. Status Check - Returns capabilities
3. Setup Repository - Tests S3 upload workflow
4. Error Handling - Validates error responses

**Expected Output:**
```
🎯 Overall: 4/4 tests passed (100%)
🎉 All tests passed! Agent is fully functional with S3 storage.
```

### Verify S3 Data

```bash
aws s3 ls s3://terraform-security-platform-storage/workflows/ --recursive
```

### Check Logs

```bash
aws logs tail /aws/bedrock-agentcore/runtimes/github_integration_agent_s3-ID-DEFAULT \
  --region us-east-1 --since 5m --follow
```

## Agent Capabilities

The agent exposes these actions:

1. **setup_repository_and_branch** - Clone repo, create branch, upload to S3
2. **commit_and_create_pr** - Download from S3, commit, push, create PR
3. **get_file_content** - Read file from repository
4. **update_file_content** - Update file in repository
5. **cleanup_repository** - Clean up local repository

## Integration with Other Agents

### Workflow Sequence

```
1. Orchestrator → GitHub Agent (setup)
   └─ Uploads to: workflows/{id}/github-agent/

2. Orchestrator → Checkov Agent (scan)
   └─ Downloads from: workflows/{id}/github-agent/
   └─ Uploads to: workflows/{id}/checkov-agent/

3. Orchestrator → Remediation Agent (fix)
   └─ Downloads from: workflows/{id}/checkov-agent/
   └─ Uploads to: workflows/{id}/terraform-remediation-agent/

4. Orchestrator → GitHub Agent (create_pr)
   └─ Downloads from: workflows/{id}/terraform-remediation-agent/
   └─ Creates PR with fixes
```

### Shared Dependencies

- **S3 Storage Module**: `../shared/s3_storage.py`
  - Shared across all agents
  - Handles upload/download/cleanup
  - Single source of truth

## Troubleshooting

### Build Fails: "shared: not found"

**Cause**: Docker build context is wrong

**Fix**: Ensure building from parent directory:
```python
# In deploy_manual.py
parent_dir = os.path.dirname(script_dir)
os.chdir(parent_dir)
run_command("finch build -f github_integration/Dockerfile.manual ...")
```

### S3 Access Denied

**Cause**: Missing IAM permissions

**Fix**: Attach S3 policy to agent role:
```bash
aws iam attach-role-policy \
  --role-name github-integration-agentcore-role \
  --policy-arn arn:aws:iam::ACCOUNT:policy/AgentCoreS3StoragePolicy
```

### Setup Works But PR Creation Fails

**Cause**: Remediation agent hasn't uploaded fixed code yet

**Fix**: Ensure remediation agent completes before calling create_pr

### "datetime" Error

**Cause**: Duplicate datetime import

**Fix**: Already fixed - only one `from datetime import datetime` at top of file

## Development

### Local Testing

Test S3 storage without deploying:
```bash
cd ../
python3 test_s3_storage.py
```

### Code Changes

After modifying `main.py`:
```bash
python3 deploy_manual.py  # Rebuilds and redeploys
```

### Adding New Actions

1. Add method to `GitHubIntegrationAgent` class
2. Add case in `invoke()` entrypoint
3. Update test suite
4. Redeploy

## Configuration

### S3 Bucket

Default: `terraform-security-platform-storage`

Change in:
- `Dockerfile.manual`: `ENV AGENT_STORAGE_BUCKET=your-bucket`
- `../shared/s3_storage.py`: Default bucket name

### Lifecycle Policy

S3 data auto-deletes after 7 days. To change:
```bash
# Edit ../setup_s3_storage.sh
"Expiration": { "Days": 14 }  # Change from 7 to 14
```

### Docker Platform

Default: `linux/arm64` (Graviton)

For x86:
```python
# In deploy_manual.py
run_command("finch build --platform linux/amd64 ...")
```

## Architecture Decisions

### Why S3 Instead of Local Storage?

**Problem**: AgentCore agents run in isolated containers. Local `/tmp` storage isn't shared.

**Solution**: S3 provides:
- Shared storage across distributed agents
- Data persistence between invocations
- Workflow isolation via unique IDs
- Automatic cleanup via lifecycle policies

### Why Build from Parent Directory?

**Problem**: Docker can't `COPY ../shared` from parent directory.

**Solution**: Build context is `agentcore-agents/`, allowing:
- Single copy of shared module
- No code duplication
- Easier maintenance

### Why Tarball Compression?

**Benefits**:
- 60-70% size reduction
- Faster S3 transfers
- Preserves file permissions
- Single atomic upload/download

## Related Documentation

- `../S3_STORAGE_MIGRATION.md` - Complete S3 migration guide
- `../shared/s3_storage.py` - S3 utility implementation
- `../setup_s3_storage.sh` - S3 bucket setup script
- `toolkit-deployment/DEPLOY.md` - Legacy toolkit deployment (deprecated)

## Support

For issues:
1. Check CloudWatch logs for detailed errors
2. Verify S3 bucket exists and has correct permissions
3. Ensure IAM role has required policies
4. Test S3 storage independently with `test_s3_storage.py`
5. Verify agent runtime status in AgentCore console
