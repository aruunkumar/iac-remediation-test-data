# Toolkit-Based Deployment

This folder contains deployment files using `bedrock-agentcore-starter-toolkit`.

## What is the Toolkit?

The toolkit is a Python library that automates AgentCore deployment:
- Automatically builds Docker images via CodeBuild
- Creates ECR repositories
- Manages IAM roles
- Deploys to AgentCore

**No manual Docker builds required!**

## Files

- `.bedrock_agentcore.yaml` - Toolkit configuration
- `Dockerfile` - Toolkit-generated Dockerfile
- `deploy_github_agent.py` - **Toolkit deployment script** (uses toolkit library)
- `DEPLOY.md` - Original deployment documentation

## Usage

```bash
# Install toolkit
pip install bedrock-agentcore-starter-toolkit

# Deploy
python3 deploy_github_agent.py
```

The toolkit handles everything automatically.

## Limitations for S3 Integration

The toolkit approach has limitations for our S3 storage needs:
- Can't easily build from parent directory (needed for shared module)
- Less control over Docker build process
- Harder to customize for S3 integration

## Current Deployment Methods

We now have **two manual deployment options** in the parent directory:

1. **deploy_manual.py** (Python) - Recommended
   - Full control over build process
   - Builds from parent directory for shared module
   - Supports S3 integration

2. **deploy_docker.sh** (Bash) - Alternative
   - Same functionality as deploy_manual.py
   - Shell script version

Both support S3 storage. See `../README.md` for details.
