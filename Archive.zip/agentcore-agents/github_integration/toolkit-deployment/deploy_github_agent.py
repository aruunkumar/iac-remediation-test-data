#!/usr/bin/env python3
"""Deploy github_integration agent using bedrock-agentcore-starter-toolkit"""

from bedrock_agentcore_starter_toolkit import Runtime
from boto3.session import Session

boto_session = Session()
region = boto_session.region_name

agentcore_runtime = Runtime()
agent_name = "github_integration_agent_docker"

print(f"Deploying {agent_name} to region {region}...")

# Configure
response = agentcore_runtime.configure(
    entrypoint="main.py",
    auto_create_execution_role=True,
    auto_create_ecr=True,
    requirements_file="requirements.txt",
    region=region,
    agent_name=agent_name
)

print("\nConfiguration complete")

# Deploy
print("\nLaunching agent...")
launch_response = agentcore_runtime.launch(auto_update_on_conflict=True)

print("\n" + "="*60)
print("DEPLOYMENT SUCCESSFUL!")
print("="*60)
print(f"Agent ARN: {launch_response.agent_arn}")
print(f"Agent ID: {launch_response.agent_id}")
print(f"ECR URI: {launch_response.ecr_uri}")
print(f"CodeBuild ID: {launch_response.codebuild_id}")
print("="*60)
