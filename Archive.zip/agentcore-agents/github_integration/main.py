"""
GitHub Integration Agent - Repository operations and PR management
Built with Strands SDK for deployment on AWS Bedrock AgentCore
Uses S3 for shared storage across agents
"""

from typing import Dict, List, Any, Optional
import json
import logging
import os
import subprocess
import requests
import sys
from datetime import datetime
from bedrock_agentcore.runtime import BedrockAgentCoreApp

# Add parent directory to path for shared module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from shared.s3_storage import S3Storage

logger = logging.getLogger(__name__)

class GitHubIntegrationAgent:
    """GitHub Integration Agent for repository operations and PR workflows"""
    
    def __init__(self):
        self.base_url = "https://api.github.com"
        self.github_token = None  # Will be fetched per-request
        
        # Working directory for repository operations
        self.work_dir = "/tmp/github_repos"
        
        # S3 storage for sharing data with other agents
        self.s3_storage = S3Storage()
        
        # Setup requests session with default headers (token added per-request)
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json'
        })
    
    def _get_github_token(self, request_token: Optional[str] = None) -> str:
        """
        Get GitHub token with priority:
        1. AWS Secrets Manager (if GITHUB_TOKEN_SECRET_NAME env var is set)
        2. Token passed in request
        3. GITHUB_TOKEN environment variable
        
        Args:
            request_token: Token passed in the request payload
            
        Returns:
            str: GitHub token
        """
        # Priority 1: AWS Secrets Manager
        secret_name = os.getenv("GITHUB_TOKEN_SECRET_NAME")
        
        if secret_name:
            try:
                import boto3
                
                secrets_client = boto3.client('secretsmanager')
                response = secrets_client.get_secret_value(SecretId=secret_name)
                
                if 'SecretString' in response:
                    secret_data = json.loads(response['SecretString'])
                    token = secret_data.get('github_token') or secret_data.get('token')
                    if token:
                        logger.info(f"GitHub token fetched from Secrets Manager: {secret_name}")
                        return token
                
                logger.warning(f"GitHub token not found in Secrets Manager secret: {secret_name}")
            except Exception as e:
                logger.error(f"Failed to fetch GitHub token from Secrets Manager: {str(e)}")
        
        # Priority 2: Token from request
        if request_token:
            logger.info("Using GitHub token from request payload")
            return request_token
        
        # Priority 3: Environment variable
        env_token = os.getenv('GITHUB_TOKEN', '')
        if env_token:
            logger.info("Using GitHub token from GITHUB_TOKEN environment variable")
            return env_token
        
        logger.warning("No GitHub token configured - operations may fail")
        return ""
    
    def _setup_auth_headers(self, token: str) -> None:
        """Setup authorization headers for GitHub API requests"""
        if token:
            self.session.headers.update({
                'Authorization': f'token {token}'
            })
            token_preview = f"{token[:4]}...{token[-4:]}" if len(token) > 8 else "***"
            logger.info(f"GitHub auth configured with token: {token_preview} (length: {len(token)})")
        else:
            # Remove auth header if no token
            self.session.headers.pop('Authorization', None)
            logger.warning("No GitHub token - API requests will be unauthenticated")
    
    def _run_git_command(self, command: list, cwd: str = None) -> subprocess.CompletedProcess:
        """Helper method to run git commands using subprocess"""
        try:
            result = subprocess.run(
                command,
                cwd=cwd or self.work_dir,
                capture_output=True,
                text=True,
                check=True
            )
            logger.debug(f"Git command succeeded: {' '.join(command)}")
            return result
        except subprocess.CalledProcessError as e:
            logger.error(f"Git command failed: {' '.join(command)}")
            logger.error(f"Error: {e.stderr}")
            raise
    
    def setup_repository_and_branch(self, repository_data: Dict[str, Any]) -> str:
        """
        Clone repository, create remediation branch, and upload to S3
        
        This is Step 1 - called BEFORE scanning and remediation.
        Creates a working branch and uploads to S3 for other agents to access.
        
        Args:
            repository_data: Repository information including owner, repo, source_branch, commit_sha, workflow_id, github_token (optional)
            
        Returns:
            dict: Contains s3_uri, branch_name, and workflow_id
        """
        owner = repository_data.get('owner')
        repo_name = repository_data.get('repo')
        source_branch = repository_data.get('source_branch', 'main')
        commit_sha = repository_data.get('commit_sha', 'latest')[:8]
        workflow_id = repository_data.get('workflow_id')
        request_token = repository_data.get('github_token')
        
        if not workflow_id:
            raise ValueError("workflow_id is required for S3 storage")
        
        # Get GitHub token
        github_token = self._get_github_token(request_token)
        self._setup_auth_headers(github_token)
        
        logger.info(f"Setting up repository {owner}/{repo_name} at branch {source_branch}")
        logger.info(f"Workflow ID: {workflow_id}")
        
        # Prepare working directory
        os.makedirs(self.work_dir, exist_ok=True)
        repo_path = os.path.join(self.work_dir, repo_name)
        
        # Remove existing directory if it exists
        if os.path.exists(repo_path):
            subprocess.run(["rm", "-rf", repo_path], check=True)
            logger.info(f"Cleaned up existing directory: {repo_path}")
        
        # Clone with authentication
        if github_token:
            auth_url = f"https://{github_token}@github.com/{owner}/{repo_name}.git"
        else:
            auth_url = repository_data.get('url')
        
        # Full clone (not shallow) so we can create branches and push
        subprocess.run(
            ["git", "clone", "--branch", source_branch, auth_url, repo_name],
            cwd=self.work_dir,
            capture_output=True,
            text=True,
            check=True
        )
        
        if not os.path.exists(repo_path):
            raise Exception(f"Failed to clone repository {owner}/{repo_name}")
        
        logger.info(f"Successfully cloned repository to {repo_path}")
        
        # Create remediation branch
        # If commit_sha looks like a real SHA (not "HEAD" or branch name), use it
        if commit_sha and len(commit_sha) >= 7 and commit_sha not in ['HEAD', 'main', 'master']:
            suffix = commit_sha[:7]  # Use first 7 chars of commit SHA
        elif workflow_id:
            suffix = workflow_id[:8]  # Use first 8 chars of workflow ID
        else:
            # Fallback to timestamp
            suffix = datetime.now().strftime("%Y%m%d-%H%M%S")
        
        branch_name = f"iac-remediation/{source_branch}-{suffix}"
        subprocess.run(["git", "checkout", "-b", branch_name], cwd=repo_path, check=True)
        logger.info(f"Created remediation branch: {branch_name}")
        
        # Upload repository to S3 for other agents
        logger.info("Uploading repository to S3...")
        s3_uri = self.s3_storage.upload_directory(repo_path, workflow_id, 'github-agent')
        logger.info(f"Repository uploaded to S3: {s3_uri}")
        
        # Store metadata in S3
        metadata = {
            'owner': owner,
            'repo': repo_name,
            'source_branch': source_branch,
            'branch_name': branch_name,
            'workflow_id': workflow_id,
            'repo_path': repo_name,  # Relative path within tarball
            'timestamp': datetime.now().isoformat()
        }
        self.s3_storage.upload_json(metadata, workflow_id, 'github-agent', 'metadata.json')
        
        # Clean up local directory
        subprocess.run(["rm", "-rf", repo_path], check=True)
        logger.info(f"Cleaned up local directory: {repo_path}")
        
        # Return S3 location and metadata
        return {
            "success": True,
            "s3_uri": s3_uri,
            "branch_name": branch_name,
            "workflow_id": workflow_id,
            "message": f"Repository cloned and uploaded to S3"
        }
    
    def commit_and_create_pr(self, repository_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Download repository from S3, commit changes, and create pull request
        
        This is Step 4 - called AFTER remediation is complete.
        Downloads the repository from S3 (with fixes applied by Terraform Remediation Agent),
        downloads remediation results from S3, commits changes, pushes, and creates PR.
        
        Args:
            repository_data: Repository information including owner, repo, source_branch, author, workflow_id, github_token (optional)
            
        Returns:
            dict: PR creation results including PR number, URL, branch name, etc.
        """
        workflow_id = repository_data.get('workflow_id')
        request_token = repository_data.get('github_token')
        
        if not workflow_id:
            raise ValueError("workflow_id is required to download from S3")
        
        # Get GitHub token
        github_token = self._get_github_token(request_token)
        self._setup_auth_headers(github_token)
        
        logger.info(f"Downloading repository from S3 for workflow {workflow_id}")
        
        # Download consolidated remediation results from S3 (saved by orchestrator)
        logger.info("Downloading consolidated remediation results from S3")
        remediation_results = self.s3_storage.download_json(workflow_id, 'github-agent', 'remediation_results.json')
        logger.info(f"Downloaded remediation results: {len(remediation_results.get('fixes', []))} fixes, {len(remediation_results.get('manual_items', []))} manual items")
        
        # Download repository from S3 (uploaded by remediation agent after fixes)
        temp_dir = f"/tmp/github_repos_{workflow_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        repo_path = self.s3_storage.download_directory(workflow_id, 'terraform-remediation-agent', temp_dir)
        logger.info(f"Repository downloaded to: {repo_path}")
        
        source_branch = repository_data.get('source_branch', 'main')
        commit_sha_raw = repository_data.get('commit_sha', 'latest')
        commit_sha = commit_sha_raw[:8] if commit_sha_raw else 'latest'
        is_main_branch = source_branch in ['main', 'master', 'develop']
        
        # Branch name matches what was created in setup_repository_and_branch()
        # Get current branch name from git
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        branch_name = result.stdout.strip()
        
        # Commit all changes (files are already fixed by Terraform Remediation Agent)
        has_changes = self._commit_all_changes(repo_path, remediation_results)
        
        # Push the branch to remote (only if there are changes or branch doesn't exist on remote)
        if has_changes:
            self._push_branch(branch_name, repo_path)
        else:
            # Check if branch exists on remote
            check_remote = subprocess.run(
                ["git", "ls-remote", "--heads", "origin", branch_name],
                cwd=repo_path,
                capture_output=True,
                text=True
            )
            if not check_remote.stdout.strip():
                # Branch doesn't exist on remote, push it
                self._push_branch(branch_name, repo_path)
            else:
                logger.info(f"Branch {branch_name} already exists on remote, skipping push")
        
        # Create pull request
        pr_result = self._create_pull_request(repository_data, remediation_results, branch_name)
        
        # Add labels to the PR
        pr_labels = ['security', 'terraform', 'automated-fix']
        if remediation_results.get('manual_interventions'):
            pr_labels.append('manual-intervention-required')
        
        if pr_result.get('number'):
            self.add_pr_labels(repository_data, pr_result.get('number'), pr_labels)
            
            # Request review based on branch type
            if is_main_branch:
                # For main branch: security team review
                reviewers = ['team:security-team', 'team:devops-team']
            else:
                # For feature branches: original developer review
                original_author = repository_data.get('author')
                reviewers = [original_author] if original_author else []
            
            if reviewers:
                self.request_pr_review(repository_data, pr_result.get('number'), reviewers)
        
        # Only create and trigger approval workflow for main branch PRs
        workflow_result = False
        if is_main_branch:
            self.create_approval_workflow(repository_data)
            workflow_result = self._trigger_approval_workflow(repository_data, pr_result)
        
        logger.info(f"Created PR #{pr_result.get('number')} with {len(remediation_results.get('fixes', []))} fixes")
        
        # Clean up local directory
        subprocess.run(["rm", "-rf", temp_dir], check=True)
        logger.info(f"Cleaned up local directory: {temp_dir}")
        
        return {
            'success': True,
            'pr_number': pr_result.get('number'),
            'pr_url': pr_result.get('html_url'),
            'branch_name': branch_name,
            'source_branch': source_branch,
            'workflow_triggered': workflow_result,
            'labels_added': pr_labels,
            'reviewers_requested': bool(reviewers) if pr_result.get('number') else False,
            'requires_security_approval': is_main_branch,
            'status': 'created'
        }
    

    
    def _clone_repository(self, repository_data: Dict[str, Any]) -> bool:
        """Clone repository using git commands"""
        repo_url = repository_data.get('url')
        owner = repository_data.get('owner')
        repo_name = repository_data.get('repo')
        source_branch = repository_data.get('source_branch', 'main')
        request_token = repository_data.get('github_token')
        
        # Get GitHub token
        github_token = self._get_github_token(request_token)
        
        logger.info(f"Cloning repository: {repo_url}")
        
        # Prepare working directory
        os.makedirs(self.work_dir, exist_ok=True)
        repo_path = self._get_repo_path(repository_data)
        
        # Remove existing directory if it exists
        if os.path.exists(repo_path):
            subprocess.run(["rm", "-rf", repo_path], check=True)
            logger.info(f"Cleaned up existing directory: {repo_path}")
        
        # Clone with authentication
        if github_token:
            auth_url = f"https://{github_token}@github.com/{owner}/{repo_name}.git"
        else:
            auth_url = repo_url
        
        # Clone repository using subprocess (shallow clone for speed)
        self._run_git_command([
            "git", "clone",
            "--branch", source_branch,
            "--single-branch",
            "--depth", "1",
            auth_url,
            repo_name
        ])
        
        # Verify clone was successful
        if os.path.exists(repo_path):
            logger.info(f"Successfully cloned repository to {repo_path}")
            return True
        else:
            logger.error(f"Failed to clone repository to {repo_path}")
            return False
    
    def _get_repo_path(self, repository_data: Dict[str, Any]) -> str:
        """Get the local path for the repository"""
        repo_name = repository_data.get('repo')
        return os.path.join(self.work_dir, repo_name)
    
    def extract_terraform_files(self, repository_data: Dict[str, Any]) -> List[str]:
        """Extract all Terraform files from the repository"""
        repo_path = self._get_repo_path(repository_data)
        
        # Find all .tf files
        find_result = subprocess.run(
            ["find", repo_path, "-name", "*.tf", "-type", "f"],
            capture_output=True,
            text=True,
            check=True
        )
        
        # Parse the result to get file paths
        terraform_files = [f.strip() for f in find_result.stdout.split('\n') if f.strip().endswith('.tf')]
        
        logger.info(f"Found {len(terraform_files)} Terraform files")
        return terraform_files
    
    def _push_branch(self, branch_name: str, repo_path: str) -> None:
        """Push the branch to remote repository"""
        subprocess.run(["git", "push", "origin", branch_name], cwd=repo_path, check=True)
        logger.info(f"Pushed branch {branch_name} to remote")
    
    def _commit_all_changes(self, repo_path: str, remediation_results: Dict[str, Any]) -> bool:
        """
        Commit all changes in the repository (files already fixed by Terraform Remediation Agent)
        
        Args:
            repo_path: Path to repository with fixes already applied
            remediation_results: Metadata about fixes for commit message
            
        Returns:
            bool: True if changes were committed, False if no changes to commit
        """
        logger.info("Committing all security remediation changes")
        
        # Configure git user for commits
        subprocess.run(
            ["git", "config", "user.email", "terraform-security-platform@example.com"],
            cwd=repo_path,
            check=True
        )
        subprocess.run(
            ["git", "config", "user.name", "Terraform Security Platform"],
            cwd=repo_path,
            check=True
        )
        
        # Add all changes
        subprocess.run(["git", "add", "."], cwd=repo_path, check=True)
        
        # Check if there are changes to commit
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        
        if not status_result.stdout.strip():
            logger.info("No changes to commit - working tree is clean")
            return False
        
        # Commit changes
        commit_message = self._generate_commit_message(remediation_results)
        subprocess.run(["git", "commit", "-m", commit_message], cwd=repo_path, check=True)
        
        logger.info("Committed security remediation changes")
        return True
    
    def _generate_commit_message(self, remediation_results: Dict[str, Any]) -> str:
        """Generate comprehensive commit message"""
        fixes_count = len(remediation_results.get('fixes', []))
        manual_count = len(remediation_results.get('manual_interventions', []))
        
        commit_message = f"""Security remediation: {fixes_count} auto-fixes, {manual_count} manual items

Auto-fixes applied:"""
        
        for fix in remediation_results.get('fixes', []):
            commit_message += f"\n- {fix.get('check_id')}: {fix.get('resource')}"
        
        if manual_count > 0:
            commit_message += f"\n\nManual intervention required:"
            for manual in remediation_results.get('manual_interventions', []):
                commit_message += f"\n- {manual.get('check_id')}: {manual.get('resource')}"
        
        return commit_message
    
    def _create_pull_request(self, repository_data: Dict[str, Any], remediation_results: Dict[str, Any], branch_name: str) -> Dict[str, Any]:
        """Create pull request with detailed description"""
        owner = repository_data.get('owner')
        repo = repository_data.get('repo')
        source_branch = repository_data.get('source_branch', 'main')
        
        pr_title = f"Security Remediation - {len(remediation_results.get('fixes', []))} fixes applied"
        pr_description = self._generate_pr_description(remediation_results)
        
        pr_data = {
            'title': pr_title,
            'body': pr_description,
            'head': branch_name,
            'base': source_branch  # Target the source branch, not main
        }
        
        # GitHub API call to create PR
        api_url = f"{self.base_url}/repos/{owner}/{repo}/pulls"
        
        logger.info(f"Creating PR: {pr_title}")
        
        # Make direct HTTP request to GitHub API
        try:
            response = self.session.post(api_url, json=pr_data)
            response.raise_for_status()
            
            pr_response = response.json()
            return {
                'number': pr_response.get('number'),
                'html_url': pr_response.get('html_url'),
                'head_ref': branch_name
            }
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to create PR: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response: {e.response.text}")
            raise Exception(f"Failed to create PR: {str(e)}")
    
    def _generate_pr_description(self, remediation_results: Dict[str, Any]) -> str:
        """Generate comprehensive PR description"""
        scan_metadata = remediation_results.get('scan_metadata', {})
        fixes = remediation_results.get('fixes', [])
        manual_interventions = remediation_results.get('manual_interventions', [])
        
        # Header with summary statistics
        description = f"""## 🔒 Security Remediation Summary

This PR contains automated security fixes and manual intervention items identified by the Terraform Security Platform.

**Scan Results:**
- 📊 Total Issues Found: {scan_metadata.get('total_findings', len(fixes) + len(manual_interventions))}
- ✅ Auto-Fixes Applied: {len(fixes)}
- ⚠️ Manual Intervention Required: {len(manual_interventions)}
- 📅 Scan Date: {scan_metadata.get('scan_date', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}
- 🆔 Workflow ID: {scan_metadata.get('workflow_id', 'N/A')}

"""
        
        # Auto-fixes section with detailed information
        if fixes:
            description += "### ✅ Auto-Fixes Applied\n\n"
            
            # Group fixes by severity
            severity_groups = {}
            for fix in fixes:
                severity = fix.get('severity', 'UNKNOWN')
                if severity not in severity_groups:
                    severity_groups[severity] = []
                severity_groups[severity].append(fix)
            
            for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN']:
                if severity in severity_groups:
                    severity_emoji = {'CRITICAL': '🚨', 'HIGH': '⚠️', 'MEDIUM': '🔶', 'LOW': '🔵', 'UNKNOWN': '❓'}
                    description += f"#### {severity_emoji.get(severity, '❓')} {severity} Severity\n\n"
                    
                    for fix in severity_groups[severity]:
                        description += f"- **{fix.get('check_id')}**: {fix.get('description', 'Security fix applied')}\n"
                        description += f"  - 📁 File: `{fix.get('file')}`\n"
                        description += f"  - 🎯 Resource: `{fix.get('resource')}`\n"
                        if fix.get('knowledge_base_reference'):
                            description += f"  - 📚 Reference: {fix.get('knowledge_base_reference')}\n"
                        description += "\n"
        
        # Manual interventions section
        if manual_interventions:
            description += "### ⚠️ Manual Intervention Required\n\n"
            description += "The following security issues require manual review and remediation:\n\n"
            
            # Group manual items by severity
            severity_groups = {}
            for manual in manual_interventions:
                severity = manual.get('severity', 'UNKNOWN')
                if severity not in severity_groups:
                    severity_groups[severity] = []
                severity_groups[severity].append(manual)
            
            for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN']:
                if severity in severity_groups:
                    severity_emoji = {'CRITICAL': '🚨', 'HIGH': '⚠️', 'MEDIUM': '🔶', 'LOW': '🔵', 'UNKNOWN': '❓'}
                    description += f"#### {severity_emoji.get(severity, '❓')} {severity} Severity\n\n"
                    
                    for manual in severity_groups[severity]:
                        description += f"- **{manual.get('check_id')}**: {manual.get('description', 'Manual intervention required')}\n"
                        description += f"  - 📁 File: `{manual.get('file')}`\n"
                        description += f"  - 🎯 Resource: `{manual.get('resource')}`\n"
                        description += f"  - 💡 Guidance: {manual.get('todo_comment', 'See TODO comments in code')}\n"
                        if manual.get('knowledge_base_reference'):
                            description += f"  - 📚 Reference: {manual.get('knowledge_base_reference')}\n"
                        description += "\n"
        
        # Review guidelines
        description += """### 📋 Review Guidelines

#### For Auto-Fixes:
1. ✅ Verify all auto-fixes maintain functionality
2. 🧪 Test changes in a non-production environment first
3. 📖 Review the applied changes for correctness
4. 🔍 Ensure no breaking changes were introduced

#### For Manual Items:
1. 🔍 Locate TODO comments in the affected files
2. 📚 Review the provided guidance and references
3. 🛠️ Implement the recommended security fixes
4. ✅ Remove TODO comments after addressing issues

#### Security Compliance:
- 🏢 Ensure compliance with organizational security policies
- 📋 Follow your team's security review process
- 🔐 Validate that all changes align with security best practices
- 📊 Consider impact on existing infrastructure

### 🚦 Approval Process

This PR requires security team approval before merging. The automated security scan will be re-run after any additional commits to ensure no new issues are introduced.

**Next Steps:**
1. Review all changes in this PR
2. Address any manual intervention items
3. Request security team review
4. Merge after approval

---
*Generated by Terraform Security Platform - Automated Security Remediation*
"""
        
        return description
    
    def _trigger_approval_workflow(self, repository_data: Dict[str, Any], pr_result: Dict[str, Any]) -> bool:
        """Trigger GitHub Actions approval workflow"""
        owner = repository_data.get('owner')
        repo = repository_data.get('repo')
        workflow_id = 'security-approval.yml'  # Default workflow file name
        
        workflow_data = {
            'ref': pr_result.get('head_ref'),
            'inputs': {
                'pr_number': str(pr_result.get('number', '')),
                'requires_approval': 'true',
                'scan_id': repository_data.get('scan_id', ''),
                'branch_name': pr_result.get('head_ref')
            }
        }
        
        # GitHub API call to trigger workflow
        api_url = f"{self.base_url}/repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches"
        
        logger.info("Triggering approval workflow")
        
        # Make direct HTTP request to GitHub API
        try:
            response = self.session.post(api_url, json=workflow_data)
            # GitHub returns 204 No Content on success for workflow dispatch
            return response.status_code == 204
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to trigger workflow: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response: {e.response.text}")
            # Don't fail the whole PR creation if workflow trigger fails
            return False
    


    def get_file_content(self, repository_data: Dict[str, Any], file_path: str) -> Optional[str]:
        """Get content of a specific file from the repository"""
        repo_path = self._get_repo_path(repository_data)
        full_file_path = os.path.join(repo_path, file_path)
        
        if os.path.exists(full_file_path):
            try:
                with open(full_file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"Error reading file {file_path}: {e}")
                return None
        else:
            logger.warning(f"File not found: {file_path}")
            return None
    
    def update_file_content(self, repository_data: Dict[str, Any], file_path: str, new_content: str) -> bool:
        """Update content of a specific file in the repository"""
        repo_path = self._get_repo_path(repository_data)
        full_file_path = os.path.join(repo_path, file_path)
        
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(full_file_path), exist_ok=True)
            
            # Write new content
            with open(full_file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            logger.info(f"Updated file: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error updating file {file_path}: {e}")
            return False
    
    def create_branch_from_commit(self, repository_data: Dict[str, Any], branch_name: str, commit_sha: Optional[str] = None) -> bool:
        """Create a new branch from a specific commit"""
        repo_path = self._get_repo_path(repository_data)
        
        if commit_sha:
            # Create branch from specific commit
            subprocess.run(["git", "checkout", "-b", branch_name, commit_sha], cwd=repo_path, check=True)
        else:
            # Create branch from current HEAD
            subprocess.run(["git", "checkout", "-b", branch_name], cwd=repo_path, check=True)
        
        branch_result = True
        
        if branch_result:
            logger.info(f"Created branch {branch_name} from commit {commit_sha or 'HEAD'}")
            return True
        else:
            logger.error(f"Failed to create branch {branch_name}")
            return False
    
    def get_terraform_file_changes(self, repository_data: Dict[str, Any], base_branch: str = 'main') -> List[Dict[str, Any]]:
        """Get list of Terraform files that have changed compared to base branch"""
        repo_path = self._get_repo_path(repository_data)
        
        # Get list of changed files
        diff_result = subprocess.run(
            ["git", "diff", "--name-only", f"{base_branch}...HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        
        changed_files = []
        if diff_result.stdout:
            all_changed = [f.strip() for f in diff_result.stdout.split('\n') if f.strip()]
            
            # Filter for Terraform files
            terraform_changed = [f for f in all_changed if f.endswith('.tf')]
            
            for tf_file in terraform_changed:
                file_info = {
                    'file_path': tf_file,
                    'content': self.get_file_content(repository_data, tf_file),
                    'status': 'modified'  # Could be 'added', 'modified', 'deleted'
                }
                changed_files.append(file_info)
        
        logger.info(f"Found {len(changed_files)} changed Terraform files")
        return changed_files
    
    def get_repository_path(self, repository_data: Dict[str, Any]) -> str:
        """
        Get the local path for a cloned repository (called by Orchestrator)
        
        Args:
            repository_data: Repository information
            
        Returns:
            str: Local path to the repository
        """
        return self._get_repo_path(repository_data)
    
    def cleanup_repository(self, repository_data: Dict[str, Any]) -> None:
        """
        Clean up local repository directory (called by Orchestrator)
        
        Args:
            repository_data: Repository information
        """
        repo_path = self._get_repo_path(repository_data)
        
        if os.path.exists(repo_path):
            subprocess.run(["rm", "-rf", repo_path], check=True)
            logger.info(f"Cleaned up repository: {repo_path}")
    
    def create_approval_workflow(self, repository_data: Dict[str, Any]) -> bool:
        """Create GitHub Actions workflow for security approval gates"""
        repo_path = self._get_repo_path(repository_data)
        workflow_dir = os.path.join(repo_path, '.github', 'workflows')
        workflow_file = os.path.join(workflow_dir, 'security-approval.yml')
        
        # Create workflow directory if it doesn't exist
        os.makedirs(workflow_dir, exist_ok=True)
        
        workflow_content = """name: Security Approval Gate

on:
  workflow_dispatch:
    inputs:
      pr_number:
        description: 'Pull Request Number'
        required: true
        type: string
      requires_approval:
        description: 'Requires Security Approval'
        required: true
        type: boolean
        default: true
      scan_id:
        description: 'Security Scan ID'
        required: false
        type: string
      branch_name:
        description: 'Branch Name'
        required: false
        type: string

jobs:
  security-approval:
    runs-on: ubuntu-latest
    if: ${{ github.event.inputs.requires_approval == 'true' }}
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          ref: ${{ github.event.inputs.branch_name }}
      
      - name: Wait for Security Approval
        uses: trstringer/manual-approval@v1
        with:
          secret: ${{ github.TOKEN }}
          approvers: security-team,devops-team
          minimum-approvals: 1
          issue-title: "Security Approval Required for PR #${{ github.event.inputs.pr_number }}"
          issue-body: |
            ## Security Approval Required
            
            A security remediation PR has been created and requires approval before merging.
            
            **Details:**
            - PR Number: #${{ github.event.inputs.pr_number }}
            - Scan ID: ${{ github.event.inputs.scan_id }}
            - Branch: ${{ github.event.inputs.branch_name }}
            
            **Review Checklist:**
            - [ ] All auto-fixes have been reviewed
            - [ ] Manual intervention items have been addressed
            - [ ] Changes comply with security policies
            - [ ] No breaking changes introduced
            
            Please review the PR and approve this workflow to proceed.
          exclude-workflow-initiator-as-approver: false
      
      - name: Approval Granted
        run: |
          echo "Security approval granted for PR #${{ github.event.inputs.pr_number }}"
          echo "Scan ID: ${{ github.event.inputs.scan_id }}"
          echo "The PR can now be merged following standard procedures."
      
      - name: Update PR Status
        uses: actions/github-script@v7
        with:
          script: |
            github.rest.issues.createComment({
              issue_number: ${{ github.event.inputs.pr_number }},
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: '✅ Security approval granted! This PR has been approved by the security team and can be merged.'
            });

  no-approval-required:
    runs-on: ubuntu-latest
    if: ${{ github.event.inputs.requires_approval != 'true' }}
    
    steps:
      - name: No Approval Required
        run: |
          echo "No security approval required for this workflow run."
          echo "PR #${{ github.event.inputs.pr_number }} can proceed without additional approval."
"""
        
        try:
            with open(workflow_file, 'w', encoding='utf-8') as f:
                f.write(workflow_content)
            
            logger.info("Created GitHub Actions security approval workflow")
            return True
        except Exception as e:
            logger.error(f"Error creating workflow file: {e}")
            return False
    
    def add_pr_labels(self, repository_data: Dict[str, Any], pr_number: int, labels: List[str]) -> bool:
        """Add labels to a pull request"""
        owner = repository_data.get('owner')
        repo = repository_data.get('repo')
        
        api_url = f"{self.base_url}/repos/{owner}/{repo}/issues/{pr_number}/labels"
        label_data = {'labels': labels}
        
        # Make direct HTTP request to GitHub API
        try:
            response = self.session.post(api_url, json=label_data)
            response.raise_for_status()
            logger.info(f"Added labels {labels} to PR #{pr_number}")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to add labels to PR #{pr_number}: {e}")
            return False
    
    def request_pr_review(self, repository_data: Dict[str, Any], pr_number: int, reviewers: List[str]) -> bool:
        """Request review from specific users or teams"""
        owner = repository_data.get('owner')
        repo = repository_data.get('repo')
        
        api_url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/requested_reviewers"
        
        # Separate individual reviewers from team reviewers
        individual_reviewers = [r for r in reviewers if not r.startswith('team:')]
        team_reviewers = [r.replace('team:', '') for r in reviewers if r.startswith('team:')]
        
        review_data = {
            'reviewers': individual_reviewers,
            'team_reviewers': team_reviewers
        }
        
        # Make direct HTTP request to GitHub API
        try:
            response = self.session.post(api_url, json=review_data)
            response.raise_for_status()
            logger.info(f"Requested review from {reviewers} for PR #{pr_number}")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to request review for PR #{pr_number}: {e}")
            return False

# Initialize BedrockAgentCore App
app = BedrockAgentCoreApp()

# Initialize agent instance
github_agent = GitHubIntegrationAgent()

@app.entrypoint
def invoke(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    AgentCore entrypoint for GitHub Integration Agent
    
    Supported actions:
    - health: Health check
    - status: Get agent status and capabilities
    - setup_repository_and_branch: Clone repo and create remediation branch
    - commit_and_create_pr: Commit changes and create pull request
    - get_file_content: Get content of a file
    - update_file_content: Update content of a file
    - cleanup_repository: Clean up local repository
    """
    action = payload.get('action')
    execution_start = datetime.utcnow()
    
    logger.info(f"{'='*80}")
    logger.info(f"[GITHUB] EXECUTION START")
    logger.info(f"[GITHUB] Action: {action}")
    logger.info(f"[GITHUB] Timestamp: {execution_start.isoformat()}")
    logger.info(f"{'='*80}")
    
    try:
        if action == 'health':
            result = {
                'status': 'healthy',
                'agent': 'github_integration',
                'version': '1.0.0'
            }
        
        elif action == 'status':
            result = {
                'agent_name': 'github_integration',
                'status': 'operational',
                'capabilities': [
                    'setup_repository_and_branch',
                    'commit_and_create_pr',
                    'get_file_content',
                    'update_file_content',
                    'cleanup_repository'
                ]
            }
        
        elif action in ['setup_repository_and_branch', 'setup']:
            repository_data = payload.get('repository_data', {})
            result = github_agent.setup_repository_and_branch(repository_data)
        
        elif action in ['commit_and_create_pr', 'create_pr']:
            repository_data = payload.get('repository_data', {})
            
            # Agent now downloads remediation_results.json from S3 directly
            # No need to pass remediation_results in payload
            result = github_agent.commit_and_create_pr(repository_data)
        
        elif action == 'get_file_content':
            repository_data = payload.get('repository_data', {})
            file_path = payload.get('file_path')
            content = github_agent.get_file_content(repository_data, file_path)
            result = {'content': content}
        
        elif action == 'update_file_content':
            repository_data = payload.get('repository_data', {})
            file_path = payload.get('file_path')
            new_content = payload.get('new_content')
            success = github_agent.update_file_content(repository_data, file_path, new_content)
            result = {'success': success}
        
        elif action in ['cleanup_repository', 'cleanup']:
            repository_data = payload.get('repository_data', {})
            github_agent.cleanup_repository(repository_data)
            result = {'status': 'cleaned'}
        
        else:
            result = {
                'error': f'Unknown action: {action}',
                'status': 'failed',
                'supported_actions': [
                    'health', 'status', 'setup_repository_and_branch',
                    'commit_and_create_pr', 'get_file_content',
                    'update_file_content', 'cleanup_repository'
                ]
            }
        
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.info(f"{'='*80}")
        logger.info(f"[GITHUB] EXECUTION END")
        logger.info(f"[GITHUB] Action: {action}")
        logger.info(f"[GITHUB] Status: {'success' if 'error' not in result else 'error'}")
        logger.info(f"[GITHUB] Execution time: {execution_time:.2f}s")
        logger.info(f"[GITHUB] Timestamp: {execution_end.isoformat()}")
        logger.info(f"{'='*80}")
        
        return result
    
    except Exception as e:
        execution_end = datetime.utcnow()
        execution_time = (execution_end - execution_start).total_seconds()
        
        logger.error(f"{'='*80}")
        logger.error(f"[GITHUB] EXECUTION FAILED")
        logger.error(f"[GITHUB] Action: {action}")
        logger.error(f"[GITHUB] Error: {str(e)}", exc_info=True)
        logger.error(f"[GITHUB] Execution time: {execution_time:.2f}s")
        logger.error(f"[GITHUB] Timestamp: {execution_end.isoformat()}")
        logger.error(f"{'='*80}")
        
        return {
            'error': str(e),
            'status': 'failed',
            'action': action
        }

if __name__ == "__main__":
    app.run()

