# Terraform Security Platform

A cloud-native multi-agent system for automated Terraform security scanning and remediation, built with Strands SDK and deployed on AWS Bedrock AgentCore.

## Overview

The Terraform Security Platform enhances security scanning and remediation for Terraform infrastructure code through specialized AI agents that work together to identify, fix, and manage security vulnerabilities automatically.

### Key Features

- **Multi-Agent Architecture**: Specialized agents for scanning, remediation, and GitHub integration
- **Iterative Remediation**: Automated scanning and fixing cycles with convergence detection
- **Knowledge Base Integration**: AWS Bedrock Knowledge Bases for current best practices
- **GitHub Integration**: Automated PR creation with approval workflows
- **Cloud-Native Deployment**: Scalable deployment on AWS Bedrock AgentCore

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────────┐
│  GitHub Repo    │───▶│  API Gateway     │───▶│  Orchestrator Agent │
└─────────────────┘    └──────────────────┘    └─────────────────────┘
                                                          │
                       ┌─────────────────────────────────┼─────────────────────────────────┐
                       │                                 │                                 │
                       ▼                                 ▼                                 ▼
            ┌─────────────────────┐         ┌─────────────────────┐         ┌─────────────────────┐
            │ Checkov Scanner     │         │ Terraform           │         │ GitHub Integration  │
            │ Agent               │         │ Remediation Agent   │         │ Agent               │
            └─────────────────────┘         └─────────────────────┘         └─────────────────────┘
                                                        │
                                            ┌───────────┴───────────┐
                                            │                       │
                                            ▼                       ▼
                                ┌─────────────────────┐ ┌─────────────────────┐
                                │ Terraform AWS       │ │ AWS Well-Architected│
                                │ Knowledge Base      │ │ Knowledge Base      │
                                └─────────────────────┘ └─────────────────────┘
```

## Project Structure

```
terraform-security-platform/
├── agents/                          # Agent implementations
│   ├── orchestrator/               # Main workflow coordination
│   ├── checkov_scanner/           # Security scanning operations
│   ├── terraform_remediation/     # Code remediation with KB integration
│   │   ├── main.py                # Main remediation agent logic
│   │   ├── models.py              # Data models for findings and results
│   │   ├── test_remediation.py   # Test script for remediation
│   │   └── mcp_terraform_server/  # MCP Terraform Server integration
│   └── github_integration/        # Repository and PR management
├── shared/                         # Shared utilities and interfaces
│   ├── interfaces.py              # Common data models and interfaces
│   └── utils.py                   # Shared utilities for communication
├── infrastructure/                 # Terraform infrastructure code
│   └── terraform/
│       ├── modules/               # Reusable Terraform modules
│       │   ├── agentcore/        # AgentCore deployment infrastructure
│       │   └── knowledge_base/   # Bedrock Knowledge Base setup
│       └── environments/         # Environment-specific configurations
│           ├── dev/              # Development environment
│           ├── staging/          # Staging environment
│           └── prod/             # Production environment
├── config/                        # Environment configuration files
│   ├── dev.json                  # Development configuration
│   ├── staging.json              # Staging configuration
│   └── prod.json                 # Production configuration
└── Source&Output/                 # Test data and remediation outputs
    ├── input/                    # Sample Terraform code for testing
    └── output/                   # Remediation results by scan ID
        └── <scan_id>/
            └── remediation_output/  # Fixed code and reports
```

## Remediation Process

### How It Works

The Terraform Remediation Agent uses an intelligent, batch-based approach to fix security findings:

1. **Batch Creation**: Groups findings by file and complexity (max 5 per batch)
2. **Intelligent Analysis**: For each batch, the agent:
   - Reads the Terraform file using MCP Terraform Server
   - Analyzes all findings together for context
   - Determines which can be auto-fixed vs. require manual intervention
3. **Code Modification**: Applies fixes directly to files with:
   - `# AGENT-FIXED: CKV_XXX - Description` comments for automated fixes
   - `# TODO: CKV_XXX - Description` comments with detailed guidance for manual fixes
4. **Report Generation**: Scans modified files to extract summaries from comments
5. **Output**: Creates a comprehensive remediation report with clean, accurate tables

### Comment-Based Reporting

The agent adds structured comments to the code that serve dual purposes:
- **Documentation**: Clear explanation of what was fixed or needs fixing
- **Report Source**: Comments are extracted to generate the remediation report

Example auto-fix comment:
```terraform
# AGENT-FIXED: CKV_AWS_28 - Enabled point-in-time recovery for DynamoDB backup and restore capability
point_in_time_recovery {
  enabled = true
}
```

Example manual intervention comment:
```terraform
# TODO: CKV_AWS_119 - Ensure DynamoDB Tables are encrypted using a KMS Customer Managed CMK
# Reason: Requires KMS key creation and management, has cost implications
# 
# Implementation:
# 1. Create KMS key with rotation enabled
# 2. Configure key policy for DynamoDB access
# 3. Update table encryption configuration
```

### Fallback Logic

If the agent's structured output cannot be parsed:
1. Scans all modified files for `AGENT-FIXED` and `TODO` comments
2. Matches comments to findings by check_id
3. Extracts descriptions for the report
4. Ensures accurate reporting even if parsing fails

## Agents

### Orchestrator Agent
- Coordinates the overall security scanning workflow
- Manages iterative scanning and remediation cycles (max 5 iterations)
- Communicates with other agents via HTTP
- Tracks progress and generates final reports

### Checkov Scanner Agent
- Executes Checkov security scans on Terraform code
- Normalizes scan results into standardized format
- Categorizes findings by severity and remediability
- Provides scan metadata and statistics

### Terraform Remediation Agent
- Analyzes scan results for auto-fixable violations
- Uses MCP (Model Context Protocol) Terraform Server for intelligent code modifications
- Queries Bedrock Knowledge Bases for remediation guidance
- Applies automated fixes for common security issues with safety checks
- Generates comprehensive TODO comments with implementation guidance for manual interventions
- Processes findings in batches for efficiency (up to 5 findings per batch)
- Extracts summaries from code comments for accurate reporting

### GitHub Integration Agent
- Manages repository operations (clone, branch, commit)
- Creates pull requests with comprehensive change descriptions
- Triggers GitHub Actions workflows with approval gates
- Handles webhook events for CI/CD integration

## Infrastructure Components

### AgentCore Module
- AWS Bedrock AgentCore runtime for agent deployment
- VPC with private/public subnets for secure networking
- IAM roles and policies for agent execution
- S3 storage for agent artifacts and logs
- CloudWatch monitoring and logging

### Knowledge Base Module
- Bedrock Knowledge Bases for AWS documentation
- OpenSearch Serverless for vector storage
- Automated data source synchronization
- Embedding models for semantic search

## Configuration

### Environment Files
Each environment (dev/staging/prod) has its own configuration file in the `config/` directory:

- **Agent endpoints and timeouts**
- **Knowledge base IDs and settings**
- **Infrastructure scaling parameters**
- **Monitoring and alerting configuration**
- **Security and compliance settings**

### Terraform Variables
Environment-specific Terraform variables control:

- **VPC and networking configuration**
- **Agent memory and timeout settings**
- **Auto-scaling parameters**
- **Security and encryption settings**

## Deployment

### Prerequisites
- AWS CLI configured with appropriate permissions
- Terraform >= 1.0 installed
- GitHub App created with repository permissions
- Bedrock model access enabled in target AWS region

### Environment Setup

1. **Configure AWS credentials**:
   ```bash
   aws configure
   ```

2. **Set environment variables**:
   ```bash
   export GITHUB_APP_ID="your-app-id"
   export GITHUB_PRIVATE_KEY="your-private-key"
   export GITHUB_WEBHOOK_SECRET="your-webhook-secret"
   ```

3. **Deploy infrastructure**:
   ```bash
   cd infrastructure/terraform/environments/dev
   terraform init
   terraform plan
   terraform apply
   ```

### Agent Deployment
Agents are deployed automatically as part of the Terraform infrastructure using the AgentCore module. Each agent is configured with:

- Strands SDK integration
- Environment-specific settings
- Auto-scaling capabilities
- Monitoring and logging

## Usage

### GitHub Integration
1. Install the GitHub App in your repositories
2. Configure webhook endpoints to point to the API Gateway
3. Push Terraform code changes to trigger security scans
4. Review and approve generated pull requests

### API Endpoints
- `POST /api/v1/scans` - Initiate security scan
- `GET /api/v1/scans/{scanId}` - Get scan status
- `GET /api/v1/scans/{scanId}/results` - Get scan results
- `POST /api/v1/scans/{scanId}/approve` - Approve remediation

### Workflow
1. **Trigger**: GitHub push event or API call
2. **Scan**: Checkov Scanner Agent analyzes Terraform code
3. **Remediate**: Terraform Remediation Agent processes findings in batches:
   - Groups findings by file and complexity
   - Applies automated fixes with AGENT-FIXED comments
   - Adds TODO comments with detailed guidance for manual interventions
   - Generates remediation report with extracted summaries
4. **Iterate**: Repeat until no new fixes or max iterations reached
5. **PR Creation**: GitHub Integration Agent creates pull request
6. **Review**: Manual review and approval of changes
7. **Merge**: Approved changes are merged to main branch

### Remediation Report
After each remediation run, a comprehensive report is generated showing:
- **Auto-Fixed Issues**: Table with check IDs, resources, files, and what changed (extracted from AGENT-FIXED comments)
- **Manual Interventions**: Table with check IDs, resources, files, and action needed (extracted from TODO comments)
- **Progress Tracking**: Batch processing times and completion status
- **Next Steps**: Guidance for implementing manual fixes

## Monitoring

### CloudWatch Metrics
- Scan completion rates and processing times
- Agent performance and resource utilization
- API response times and error rates
- Knowledge base query performance

### Alerting
- Failed scan notifications
- System health alerts
- Security vulnerability escalations
- Performance threshold breaches

## Security

### Encryption
- All data encrypted at rest and in transit
- KMS keys for sensitive data encryption
- Secure communication between agents

### Access Control
- IAM roles with least privilege access
- VPC isolation for agent communication
- API Gateway authentication and authorization

### Compliance
- Audit logging for all operations
- Data retention policies
- Compliance framework support (SOC2, PCI-DSS)

## Development

### Local Development
For local development and testing:

1. **Set up Python environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Configure local settings**:
   ```bash
   cp config/dev.json config/local.json
   # Edit local.json with local endpoints
   ```

3. **Run agents locally**:
   ```bash
   python agents/orchestrator/main.py
   ```

### Testing

#### Terraform Remediation Agent Testing
Test the remediation agent with a specific scan ID:
```bash
source venv/bin/activate
export AWS_PROFILE=your-profile
python agents/terraform_remediation/test_remediation.py <scan_id>
```

The test will:
- Load scan results from the specified scan ID
- Download source code from S3
- Process findings in batches
- Apply automated fixes and generate TODO comments
- Create a remediation report
- Copy output to `Source&Output/output/<scan_id>/remediation_output/`

#### Other Tests
- Unit tests for individual agent functions
- Integration tests for agent communication
- End-to-end tests for complete workflows

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes and add tests
4. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the GitHub repository
- Contact the development team
- Review the documentation and troubleshooting guides