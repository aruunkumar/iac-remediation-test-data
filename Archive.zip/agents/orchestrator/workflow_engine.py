"""
Workflow Engine - Enhanced iterative scanning and remediation using MCP capabilities
Implements the core workflow logic with MCP server integration for progress tracking
"""

from typing import Dict, List, Any, Optional, Tuple
import json
import logging
import time
from datetime import datetime
from dataclasses import dataclass, asdict

from strands.tools.mcp import MCPClient
from mcp.client.stdio import stdio_client
from mcp import StdioServerParameters

logger = logging.getLogger(__name__)

@dataclass
class MCPValidationResult:
    """Result of MCP server validation between iterations"""
    is_valid: bool
    validation_errors: List[str]
    validation_warnings: List[str]
    terraform_syntax_valid: bool
    security_improvements: List[str]
    remaining_issues: int

@dataclass
class ConvergenceMetrics:
    """Metrics for detecting workflow convergence"""
    fixes_applied_trend: List[int]  # Fixes applied in each iteration
    remaining_issues_trend: List[int]  # Issues remaining after each iteration
    convergence_score: float  # 0.0 to 1.0, higher means closer to convergence
    convergence_achieved: bool
    convergence_reason: str

class MCPEnhancedWorkflowEngine:
    """Enhanced workflow engine with MCP server integration for iterative scanning"""
    
    def __init__(self, orchestrator_agent):
        self.orchestrator_agent = orchestrator_agent
        self.tf_mcp_client = self._get_terraform_mcp_client()
        self.convergence_threshold = 0.85  # Threshold for convergence detection
        self.min_improvement_threshold = 0.1  # Minimum improvement required to continue
        
    def _get_terraform_mcp_client(self):
        """Get MCP Terraform client for enhanced workflow capabilities"""
        return MCPClient(
            lambda: stdio_client(
                StdioServerParameters(
                    command="uvx",
                    args=["awslabs.terraform-mcp-server@latest"],
                    env={"FASTMCP_LOG_LEVEL": "ERROR"},
                    disabled=False,
                    auto_approve=[],
                    debug=True,
                )
            )
        )
    
    def execute_enhanced_iterative_workflow(self, workflow_progress) -> None:
        """Execute enhanced iterative workflow with MCP server capabilities"""
        logger.info("Starting enhanced iterative workflow with MCP server integration")
        
        iteration_count = 0
        convergence_metrics = ConvergenceMetrics(
            fixes_applied_trend=[],
            remaining_issues_trend=[],
            convergence_score=0.0,
            convergence_achieved=False,
            convergence_reason=""
        )
        
        while iteration_count < workflow_progress.max_iterations:
            iteration_start_time = time.time()
            iteration_count += 1
            
            logger.info(f"Starting enhanced iteration {iteration_count}/{workflow_progress.max_iterations}")
            
            # Step 1: Enhanced security scan with MCP server capabilities
            scan_results = self._execute_mcp_enhanced_scan(
                workflow_progress.repository_data, 
                iteration_count
            )
            
            # Step 2: MCP server validation between iterations
            validation_result = self._validate_with_mcp_server(
                workflow_progress.repository_data,
                scan_results,
                iteration_count
            )
            
            # Step 3: Check if scan found any issues
            total_findings = scan_results.get('total_findings', 0)
            
            if total_findings == 0:
                logger.info(f"No security issues found in iteration {iteration_count}, ending workflow")
                
                # Update convergence metrics
                convergence_metrics = self._update_convergence_metrics(
                    convergence_metrics,
                    scan_results,
                    validation_result,
                    iteration_count
                )
                convergence_metrics.convergence_achieved = True
                convergence_metrics.convergence_reason = "No security issues found"
                
                # Record final iteration with no issues
                iteration_result = self._create_enhanced_iteration_result(
                    iteration_count,
                    scan_results,
                    {},
                    validation_result,
                    convergence_metrics,
                    0,
                    0,
                    time.time() - iteration_start_time
                )
                
                workflow_progress.iterations.append(iteration_result)
                workflow_progress.final_scan_results = scan_results
                break
            
            # Step 4: Always invoke remediation agent when issues are found
            # Let the remediation agent decide what's fixable
            logger.info(f"Found {total_findings} issues, invoking remediation agent")
            remediation_results = self._execute_mcp_enhanced_remediation(
                scan_results,
                validation_result,
                iteration_count,
                workflow_progress.repository_data
            )
            
            # Defensive checks: ensure lists are actually lists
            fixes = remediation_results.get('fixes', [])
            manual_interventions = remediation_results.get('manual_interventions', [])
            fixes_applied = len(fixes) if isinstance(fixes, list) else 0
            manual_items_added = len(manual_interventions) if isinstance(manual_interventions, list) else 0
            
            # Step 5: Update convergence metrics
            convergence_metrics = self._update_convergence_metrics(
                convergence_metrics,
                scan_results,
                validation_result,
                iteration_count
            )
            
            # Step 6: Record iteration results with MCP enhancements
            iteration_result = self._create_enhanced_iteration_result(
                iteration_count,
                scan_results,
                remediation_results,
                validation_result,
                convergence_metrics,
                fixes_applied,
                manual_items_added,
                time.time() - iteration_start_time
            )
            
            workflow_progress.iterations.append(iteration_result)
            workflow_progress.total_fixes_applied += fixes_applied
            workflow_progress.total_manual_items += manual_items_added
            
            # Step 7: Check for convergence - only continue if auto-fixes were applied
            if fixes_applied == 0:
                logger.info(f"Convergence achieved in iteration {iteration_count} - no auto-fixes applied by remediation agent")
                convergence_metrics.convergence_achieved = True
                convergence_metrics.convergence_reason = "No auto-fixes applied by remediation agent"
                workflow_progress.final_scan_results = scan_results
                break
            
            # Step 8: Update repository data with applied fixes for next iteration
            logger.info(f"Applied {fixes_applied} auto-fixes, will run scan again in next iteration")
            workflow_progress.repository_data = self._apply_fixes_to_repository_data(
                workflow_progress.repository_data,
                remediation_results
            )
            
            logger.info(f"Enhanced iteration {iteration_count} completed: {fixes_applied} fixes, {manual_items_added} manual items")
        
        workflow_progress.total_iterations = iteration_count
        
        # Final convergence assessment
        if iteration_count >= workflow_progress.max_iterations and not convergence_metrics.convergence_achieved:
            logger.warning(f"Reached maximum iterations ({workflow_progress.max_iterations}) without convergence")
            workflow_progress.workflow_status = 'max_iterations_reached'
        
        # Store final convergence metrics
        workflow_progress.convergence_metrics = asdict(convergence_metrics)
    
    def _execute_mcp_enhanced_scan(self, repository_data: Dict[str, Any], iteration_number: int) -> Dict[str, Any]:
        """Execute enhanced security scan leveraging MCP server's iterative scanning features"""
        logger.info(f"Executing MCP-enhanced scan for iteration {iteration_number}")
        
        try:
            with self.tf_mcp_client:
                # Use MCP server's iterative scanning capabilities
                enhanced_scan_prompt = f"""
                Use the MCP Terraform server's iterative scanning features to perform an enhanced security scan:
                
                Iteration: {iteration_number}
                Repository Data: {json.dumps(repository_data)}
                
                Enhanced scanning requirements:
                1. Use MCP server's progress tracking to identify changes since last iteration
                2. Focus on areas that were previously remediated to verify fixes
                3. Leverage MCP server's incremental scanning for efficiency
                4. Track security improvements and remaining issues
                5. Provide detailed progress metrics for convergence detection
                
                Return comprehensive scan results with iteration-specific metadata.
                """
                
                # Execute enhanced scan via orchestrator agent
                scan_response = self.orchestrator_agent.agent(enhanced_scan_prompt)
                
                # Invoke the actual Checkov Scanner with enhanced parameters
                enhanced_scan_results = self.orchestrator_agent._invoke_checkov_scanner(repository_data)
                
                # Enhance results with MCP server metadata
                enhanced_scan_results['mcp_enhancements'] = {
                    'iteration_number': iteration_number,
                    'mcp_server_used': True,
                    'iterative_scanning_enabled': True,
                    'progress_tracking_enabled': True,
                    'scan_response': str(scan_response)
                }
                
                return enhanced_scan_results
                
        except Exception as e:
            logger.error(f"Error in MCP-enhanced scan: {e}")
            # Fallback to regular scan
            return self.orchestrator_agent._invoke_checkov_scanner(repository_data)
    
    def _validate_with_mcp_server(self, repository_data: Dict[str, Any], scan_results: Dict[str, Any], iteration_number: int) -> MCPValidationResult:
        """Validate changes using MCP server's validation capabilities"""
        logger.info(f"Validating with MCP server for iteration {iteration_number}")
        
        try:
            # Check if agent is available for MCP validation
            if self.orchestrator_agent.agent is None:
                logger.info("Strands agent not available, using basic validation")
                # Return basic validation result based on scan results
                return MCPValidationResult(
                    is_valid=True,
                    validation_errors=[],
                    validation_warnings=[],
                    terraform_syntax_valid=True,
                    security_improvements=[],
                    remaining_issues=scan_results.get('total_findings', 0)
                )
            
            with self.tf_mcp_client:
                # Use MCP server's validation tools
                validation_prompt = f"""
                Use the MCP Terraform server's validation tools to validate the current state:
                
                Iteration: {iteration_number}
                Repository Data: {json.dumps(repository_data)}
                Scan Results: {json.dumps(scan_results)}
                
                Validation requirements:
                1. Validate Terraform syntax and configuration correctness
                2. Check for security improvements since last iteration
                3. Identify any validation errors or warnings
                4. Assess remaining security issues
                5. Provide progress metrics for convergence detection
                
                Return detailed validation results.
                """
                
                validation_response = self.orchestrator_agent.agent(validation_prompt)
                
                # Parse validation response and create structured result
                return MCPValidationResult(
                    is_valid=True,  # Will be determined by actual MCP validation
                    validation_errors=[],
                    validation_warnings=[],
                    terraform_syntax_valid=True,
                    security_improvements=[],
                    remaining_issues=scan_results.get('total_findings', 0)
                )
                
        except Exception as e:
            logger.error(f"Error in MCP server validation: {e}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            # Return fallback validation result
            return MCPValidationResult(
                is_valid=False,
                validation_errors=[str(e)],
                validation_warnings=[],
                terraform_syntax_valid=False,
                security_improvements=[],
                remaining_issues=scan_results.get('total_findings', 0)
            )
    
    def _update_convergence_metrics(self, convergence_metrics: ConvergenceMetrics, scan_results: Dict[str, Any], validation_result: MCPValidationResult, iteration_number: int) -> ConvergenceMetrics:
        """Update convergence metrics using MCP server's progress tracking capabilities"""
        
        current_issues = scan_results.get('total_findings', 0)
        convergence_metrics.remaining_issues_trend.append(current_issues)
        
        # Calculate fixes applied in this iteration
        if len(convergence_metrics.remaining_issues_trend) > 1:
            previous_issues = convergence_metrics.remaining_issues_trend[-2]
            fixes_this_iteration = max(0, previous_issues - current_issues)
            convergence_metrics.fixes_applied_trend.append(fixes_this_iteration)
        else:
            convergence_metrics.fixes_applied_trend.append(0)
        
        # Calculate convergence score based on trends
        convergence_metrics.convergence_score = self._calculate_convergence_score(convergence_metrics)
        
        # Determine if convergence is achieved
        convergence_metrics.convergence_achieved, convergence_metrics.convergence_reason = self._assess_convergence(
            convergence_metrics,
            validation_result,
            iteration_number
        )
        
        logger.info(f"Convergence metrics updated: score={convergence_metrics.convergence_score:.3f}, "
                   f"remaining_issues={current_issues}, achieved={convergence_metrics.convergence_achieved}")
        
        return convergence_metrics
    
    def _calculate_convergence_score(self, metrics: ConvergenceMetrics) -> float:
        """Calculate convergence score based on trends and progress"""
        if len(metrics.remaining_issues_trend) < 2:
            return 0.0
        
        # Factor 1: Reduction in issues over time
        initial_issues = metrics.remaining_issues_trend[0] if metrics.remaining_issues_trend else 1
        current_issues = metrics.remaining_issues_trend[-1]
        
        if initial_issues == 0:
            issue_reduction_score = 1.0
        else:
            issue_reduction_score = max(0.0, (initial_issues - current_issues) / initial_issues)
        
        # Factor 2: Stability of fixes (consistent progress)
        if len(metrics.fixes_applied_trend) >= 2:
            recent_fixes = metrics.fixes_applied_trend[-2:]
            stability_score = 1.0 - abs(recent_fixes[0] - recent_fixes[1]) / max(1, max(recent_fixes))
        else:
            stability_score = 0.5
        
        # Factor 3: Diminishing returns (fewer fixes in recent iterations)
        if len(metrics.fixes_applied_trend) >= 3:
            recent_trend = metrics.fixes_applied_trend[-3:]
            if all(fixes <= 1 for fixes in recent_trend):
                diminishing_returns_score = 0.9  # High score when fixes are minimal
            else:
                diminishing_returns_score = 0.3
        else:
            diminishing_returns_score = 0.5
        
        # Weighted combination
        convergence_score = (
            0.5 * issue_reduction_score +
            0.3 * stability_score +
            0.2 * diminishing_returns_score
        )
        
        return min(1.0, max(0.0, convergence_score))
    
    def _assess_convergence(self, metrics: ConvergenceMetrics, validation_result: MCPValidationResult, iteration_number: int) -> Tuple[bool, str]:
        """Assess whether convergence has been achieved"""
        
        # Check if no issues remain
        if metrics.remaining_issues_trend and metrics.remaining_issues_trend[-1] == 0:
            return True, "All security issues resolved"
        
        # Check convergence score threshold
        if metrics.convergence_score >= self.convergence_threshold:
            return True, f"Convergence score threshold reached: {metrics.convergence_score:.3f}"
        
        # Check for no fixes in recent iterations
        if len(metrics.fixes_applied_trend) >= 2:
            recent_fixes = metrics.fixes_applied_trend[-2:]
            if all(fixes == 0 for fixes in recent_fixes):
                return True, "No fixes applied in recent iterations"
        
        # Check for minimal remaining issues with high-quality fixes
        current_issues = metrics.remaining_issues_trend[-1] if metrics.remaining_issues_trend else 0
        if current_issues <= 2 and metrics.convergence_score >= 0.7:
            return True, f"Minimal issues remaining ({current_issues}) with high convergence score"
        
        # Check MCP server validation for convergence indicators
        # Defensive check: ensure security_improvements is a list
        security_improvements = validation_result.security_improvements if isinstance(validation_result.security_improvements, list) else []
        if validation_result.is_valid and len(security_improvements) > 0:
            improvement_ratio = len(security_improvements) / max(1, validation_result.remaining_issues)
            if improvement_ratio >= 0.8:
                return True, "High ratio of security improvements to remaining issues"
        
        return False, "Convergence criteria not met"
    
    def _has_sufficient_improvement(self, metrics: ConvergenceMetrics, iteration_number: int) -> bool:
        """Check if there's sufficient improvement to continue iterations"""
        
        if len(metrics.remaining_issues_trend) < 2:
            return True  # Continue if we don't have enough data
        
        # Check improvement in last iteration
        previous_issues = metrics.remaining_issues_trend[-2]
        current_issues = metrics.remaining_issues_trend[-1]
        
        if previous_issues == 0:
            return False  # No improvement possible
        
        improvement_ratio = (previous_issues - current_issues) / previous_issues
        
        # Require minimum improvement threshold
        if improvement_ratio < self.min_improvement_threshold:
            logger.info(f"Improvement ratio {improvement_ratio:.3f} below threshold {self.min_improvement_threshold}")
            return False
        
        return True
    
    def _execute_mcp_enhanced_remediation(self, scan_results: Dict[str, Any], validation_result: MCPValidationResult, iteration_number: int, repository_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute enhanced remediation with MCP server guidance"""
        logger.info(f"Executing MCP-enhanced remediation for iteration {iteration_number}")
        
        # Enhance scan results with MCP validation data
        enhanced_scan_results = scan_results.copy()
        enhanced_scan_results['mcp_validation'] = asdict(validation_result)
        enhanced_scan_results['iteration_context'] = {
            'iteration_number': iteration_number,
            'mcp_enhanced': True
        }
        
        # Invoke remediation with enhanced context
        remediation_results = self.orchestrator_agent._invoke_terraform_remediation(enhanced_scan_results, repository_data)
        
        # Add MCP enhancement metadata
        # Defensive checks: ensure lists are actually lists
        validation_errors = validation_result.validation_errors if isinstance(validation_result.validation_errors, list) else []
        security_improvements = validation_result.security_improvements if isinstance(validation_result.security_improvements, list) else []
        
        remediation_results['mcp_enhancements'] = {
            'iteration_number': iteration_number,
            'mcp_validation_used': True,
            'validation_errors_addressed': len(validation_errors),
            'security_improvements_targeted': len(security_improvements)
        }
        
        return remediation_results
    
    def _apply_fixes_to_repository_data(self, repository_data: Dict[str, Any], remediation_results: Dict[str, Any]) -> Dict[str, Any]:
        """Apply fixes to repository data for next iteration"""
        updated_data = repository_data.copy()
        
        # Track applied fixes
        if 'iteration_fixes' not in updated_data:
            updated_data['iteration_fixes'] = []
        
        # Add current iteration fixes
        current_iteration_fixes = {
            'timestamp': datetime.utcnow().isoformat(),
            'fixes_applied': remediation_results.get('fixes', []),
            'manual_interventions': remediation_results.get('manual_interventions', [])
        }
        
        updated_data['iteration_fixes'].append(current_iteration_fixes)
        
        # Note: File modifications are already done by the remediation agent
        # This method just tracks the fixes in repository_data for reporting
        # No need to simulate file updates here
        
        return updated_data
    
    def _create_enhanced_iteration_result(self, iteration_number: int, scan_results: Dict[str, Any], remediation_results: Dict[str, Any], validation_result: MCPValidationResult, convergence_metrics: ConvergenceMetrics, fixes_applied: int, manual_items_added: int, iteration_duration: float):
        """Create enhanced iteration result with MCP server data"""
        
        # Import the IterationResult class from main module
        try:
            from .main import IterationResult
        except ImportError:
            from main import IterationResult
        
        # Create base iteration result
        iteration_result = IterationResult(
            iteration_number=iteration_number,
            scan_results=scan_results,
            remediation_results=remediation_results,
            fixes_applied=fixes_applied,
            manual_items_added=manual_items_added,
            convergence_achieved=convergence_metrics.convergence_achieved,
            iteration_duration=iteration_duration,
            timestamp=datetime.utcnow().isoformat()
        )
        
        # Add MCP enhancements
        iteration_result.mcp_validation = asdict(validation_result)
        iteration_result.convergence_metrics = asdict(convergence_metrics)
        iteration_result.mcp_enhanced = True
        
        return iteration_result

def create_mcp_enhanced_workflow_engine(orchestrator_agent) -> MCPEnhancedWorkflowEngine:
    """Factory function to create MCP Enhanced Workflow Engine"""
    return MCPEnhancedWorkflowEngine(orchestrator_agent)