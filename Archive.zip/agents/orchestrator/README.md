# Orchestrator Agent

The Orchestrator Agent coordinates the complete security workflow by managing communication between three specialized agents: Checkov Scanner, Terraform Remediation, and GitHub Integration. It implements an iterative scan-fix-rescan loop until convergence, then creates a comprehensive pull request.

## Overview

The Orchestrator Agent:
- **Clones** repositories and creates remediation branches
- **Scans** Terraform code for security issues
- **Remediates** issues automatically where possible
- **Iterates** until no more auto-fixes can be applied (max 5 iterations)
- **Creates PRs** with detailed reports of all fixes and manual items
- **Tracks** progress with comprehensive metrics and audit trails

## Agent Communication - Simplified Architecture

The orchestrator uses **ONE primary endpoint per operation** for clarity and maintainability.

### Checkov Scanner Agent (Port 8000)
- **Endpoint**: `POST /scan/local`
- **Purpose**: Scan Terraform files, save results to file
- **Returns**: `scan_id`, `findings[]`, `summary`

### Terraform Remediation Agent (Port 8001)
- **Endpoint**: `POST /remediate/scan-id/detailed`
- **Purpose**: Load scan results, apply fixes, return detailed lists
- **Returns**: `fixes[]`, `manual_interventions[]`, `validation_errors[]`

### GitHub Integration Agent (Port 8002)
- **Endpoint 1**: `POST /api/v1/github/setup` - Clone repo, create branch
- **Endpoint 2**: `POST /api/v1/github/commit-and-create-pr` - Commit and create PR
- **Returns**: `repo_path`, `pr_url`, `pr_number`

See [ENDPOINT_CONSOLIDATION.md](../../ENDPOINT_CONSOLIDATION.md) for complete API details.

## Key Features

### 1. **Iterative Convergence**
- Repeats scan→remediate until no more auto-fixes possible
- Maximum 5 iterations for safety
- Stops when `fixes.length == 0`

### 2. **Robust Communication**
- 3 retries with exponential backoff per agent call
- Circuit breaker protection against repeated failures
- Health monitoring and communication stats

### 3. **Comprehensive Reporting**
- Iteration-by-iteration breakdown
- Security metrics (improvement score, fix success rate)
- Complete audit trail
- Multiple output formats (JSON, Markdown, CSV)

## Workflow

### Complete Flow (Simplified)

```
┌─────────────────────────────────────────────────────────────┐
│  STEP 1: Clone Repository                                    │
└─────────────────────────────────────────────────────────────┘

POST /api/v1/github/setup
├─> Clone repository to /tmp/github_repos/{repo}
├─> Create remediation branch
└─> Returns: repo_path

┌─────────────────────────────────────────────────────────────┐
│  STEP 2: Iterative Scan & Remediate (Max 5 iterations)      │
└─────────────────────────────────────────────────────────────┘

LOOP:
  ┌─────────────────────────────────────────┐
  │ Iteration N                              │
  └─────────────────────────────────────────┘
  
  1. Scan
     POST /scan/local
     ├─> Scan Terraform files
     ├─> Save results to /tmp/scan_results/{scan_id}.json
     └─> Returns: scan_id, findings[], total_findings
  
  2. Remediate
     POST /remediate/scan-id/detailed
     ├─> Load scan results from file
     ├─> Apply auto-fixes to files
     ├─> Add TODO comments for manual items
     └─> Returns: fixes[], manual_interventions[]
  
  3. Check Convergence
     IF fixes.length == 0:
       BREAK (no more auto-fixes possible)
     ELSE:
       Continue to next iteration

┌─────────────────────────────────────────────────────────────┐
│  STEP 3: Create Pull Request (if changes exist)             │
└─────────────────────────────────────────────────────────────┘

Check: Are there any fixes OR manual interventions?
  
  IF fixes == 0 AND manual_interventions == 0:
    ├─> Skip PR creation
    ├─> Log: "No changes to commit"
    └─> Mark workflow as completed
  
  ELSE:
    POST /api/v1/github/commit-and-create-pr
    ├─> Commit all changes
    ├─> Push to remediation branch
    ├─> Create PR with detailed description
    │   ├─> List all auto-fixes
    │   ├─> List all manual interventions
    │   ├─> Security metrics
    │   └─> Iteration breakdown
    └─> Returns: pr_url, pr_number
```

### Example: 2-Iteration Workflow

**Iteration 1:**
- Scan finds 10 issues
- Remediation fixes 7 automatically, adds 3 TODO comments
- Continue (fixes > 0)

**Iteration 2:**
- Scan finds 3 remaining issues
- Remediation finds 0 auto-fixable issues
- Stop (convergence reached)

**Result:**
- PR created with 7 auto-fixes and 3 manual items
- 70% auto-fix rate
- 2 iterations to convergence

## API Endpoints

### POST /orchestrate
Start a new security workflow

**Request:**
```json
{
  "repository_data": {
    "url": "https://github.com/owner/repo.git",
    "owner": "owner",
    "repo": "repo",
    "source_branch": "main",
    "github_token": "ghp_..."
  },
  "workflow_configuration": {
    "max_iterations": 5,
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true
  }
}
```

**Response:**
```json
{
  "workflow_id": "uuid",
  "status": "started",
  "message": "Workflow started in background"
}
```

### GET /workflows/{workflow_id}/status
Get workflow status and progress

**Response:**
```json
{
  "workflow_id": "uuid",
  "status": "completed",
  "progress": {
    "total_fixes_applied": 7,
    "total_manual_items": 3,
    "iterations_completed": 2,
    "convergence_achieved": true
  },
  "pr_created": true,
  "pr_url": "https://github.com/owner/repo/pull/123"
}
```

### GET /workflows
List all workflows

**Response:**
```json
{
  "workflows": [
    {
      "workflow_id": "uuid",
      "status": "completed",
      "repository": "https://github.com/owner/repo.git",
      "start_time": "2024-11-24T20:00:00Z",
      "end_time": "2024-11-24T20:05:00Z",
      "total_fixes": 7,
      "pr_created": true
    }
  ],
  "total_count": 1
}
```

### GET /health
Health check with agent status

**Response:**
```json
{
  "status": "healthy",
  "orchestrator": "healthy",
  "agent_health": {
    "total_agents": 3,
    "healthy_agents": 3,
    "health_percentage": 100.0
  }
}
```

## Architecture

### Core Components

**1. OrchestratorAgent** (`main.py`)
- Main workflow coordinator
- Manages iterative scan-remediate loop
- Handles convergence detection
- Generates final reports

**2. AgentCommunicationManager** (`agent_communication.py`)
- HTTP client with retry logic (3 attempts, exponential backoff)
- Circuit breaker protection
- Health monitoring
- GitHub token extraction for GitHub Integration agent

**3. MCPEnhancedWorkflowEngine** (`workflow_engine.py`)
- Manages iteration loop
- Tracks convergence metrics
- MCP server validation (when agent available)

**4. ReportGenerator** (`reporting.py`)
- Generates comprehensive reports
- Calculates security metrics
- Creates iteration summaries
- Produces audit trails

**5. GitHubPRCoordinator** (`reporting.py`)
- Coordinates PR creation
- Consolidates fixes across iterations
- Prepares enhanced PR data
  3. Remediate issues
  4. Repeat steps 2-3 until convergence
  5. Commit changes and create PR
  6. Generate comprehensive report

### 2. **MCPEnhancedWorkflowEngine** (`workflow_engine.py`)
- **Purpose**: Enhanced workflow engine with MCP server integration
- **Features**:
  - **Iterative Scanning**: Leverages MCP server's progress tracking
  - **Convergence Detection**: Advanced metrics and scoring system
  - **MCP Validation**: Validates changes between iterations
  - **Progress Tracking**: Monitors fixes applied and issues remaining
- **Key Methods**:
  - `execute_enhanced_iterative_workflow()`: Main iteration loop
  - `_execute_mcp_enhanced_scan()`: Enhanced scanning with MCP
  - `_validate_with_mcp_server()`: Validates changes with MCP
  - `_update_convergence_metrics()`: Calculates convergence scores
  - `_assess_convergence()`: Determines if convergence achieved

### 3. **AgentCommunicationManager** (`agent_communication.py`)
- **Purpose**: Manages HTTP communication between agents with reliability features
- **Features**:
  - **Retry Logic**: 3 retries with exponential backoff
  - **Circuit Breaker**: Protects against repeated failures (5 failure threshold)
  - **Health Monitoring**: Tracks agent health and response times
  - **Parallel Coordination**: Supports concurrent agent calls
- **Key Methods**:
  - `call_agent_with_retry()`: Reliable agent communication
  - `check_agent_health()`: Health check for specific agent
  - `check_all_agents_health()`: Health check for all agents
  - `coordinate_parallel_agent_calls()`: Parallel agent coordination
  - `get_communication_stats()`: Communication statistics

### 4. **ReportGenerator** (`reporting.py`)
- **Purpose**: Generates comprehensive reports and metrics
- **Features**:
  - **Security Metrics**: Total issues, fixes, improvement scores
  - **Iteration Summaries**: Breakdown of each iteration
  - **Recommendations**: Actionable next steps
  - **Multiple Formats**: JSON, Markdown, CSV
- **Key Methods**:
  - `generate_final_report()`: Creates comprehensive report
  - `_calculate_security_metrics()`: Calculates security metrics
  - `_create_iteration_summaries()`: Summarizes each iteration
  - `_generate_recommendations()`: Generates actionable recommendations

### 5. **GitHubPRCoordinator** (`reporting.py`)
- **Purpose**: Coordinates PR creation with comprehensive reporting
- **Features**:
  - **Enhanced PR Data**: Includes full report in PR description
  - **Report Artifacts**: JSON, Markdown, CSV formats
  - **Comprehensive Description**: Detailed PR with metrics and recommendations
- **Key Methods**:
  - `create_comprehensive_pr()`: Creates PR with full report
  - `_prepare_enhanced_pr_data()`: Prepares PR data with report
  - `generate_report_artifacts()`: Generates report in multiple formats

### 6. **FastAPI Wrapper** (`api.py`)
- **Purpose**: HTTP API interface for workflow management
- **Key Endpoints**:
  - `POST /orchestrate`: Start new workflow
  - `POST /webhook/github`: Handle GitHub webhooks
  - `GET /workflows/{id}/status`: Get workflow status
  - `GET /workflows/{id}/report`: Get comprehensive report
  - `GET /workflows/{id}/audit-trail`: Get audit trail
  - `GET /workflows`: List all workflows
  - `GET /health`: Service health check
  - `GET /info`: Agent information

## Workflow Logic

### Iteration Loop

```
START
  ↓
[Run Security Scan]
  ↓
[Check: Any issues found?]
  ↓
  NO → END (Convergence: No issues)
  ↓
  YES
  ↓
[Invoke Remediation Agent]
  (Agent decides what's fixable)
  ↓
[Check: Any auto-fixes applied?]
  ↓
  NO → END (Convergence: No auto-fixes)
  ↓
  YES
  ↓
[Apply fixes to repository]
  ↓
[Check: Max iterations reached?]
  ↓
  YES → END (Max iterations)
  ↓
  NO → LOOP BACK to [Run Security Scan]
```

### Convergence Conditions

The workflow ends when any of these conditions are met:

1. **No Issues Found**: Scanner returns 0 findings
   - Reason: "No security issues found"
   - Status: Convergence achieved

2. **No Auto-Fixes Applied**: Remediation agent applies 0 auto-fixes
   - Reason: "No auto-fixes applied by remediation agent"
   - Status: Convergence achieved
   - Note: Manual intervention items may still be generated

3. **Max Iterations Reached**: Completed 5 iterations (configurable)
   - Reason: "Reached maximum iterations"
   - Status: Max iterations reached

### Agent Responsibilities

| Agent | Responsibilities |
|-------|-----------------|
| **Orchestrator** | Coordinates workflow, manages iterations, decides when to stop |
| **GitHub Integration** | Clones repo, creates branches, commits changes, creates PRs |
| **Checkov Scanner** | Scans Terraform files, returns ALL findings |
| **Terraform Remediation** | Decides fixability, applies auto-fixes, generates manual guidance |

## API Endpoints

### Workflow Management

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/orchestrate` | POST | Start new GitHub security workflow |
| `/orchestrate/local` | POST | Start local/S3 workflow (scan-only, no PR) |
| `/webhook/github` | POST | Handle GitHub webhook events |
| `/workflows` | GET | List all workflows (with filtering) |
| `/workflows/{id}/status` | GET | Get real-time workflow status |
| `/workflows/{id}/report` | GET | Get comprehensive report (after completion) |
| `/workflows/{id}/audit-trail` | GET | Get detailed audit trail |
| `/health` | GET | Service health check |
| `/info` | GET | Agent information and capabilities |

### Example: Start Local/S3 Workflow (Scan-Only)

```bash
# Scan local Terraform folder
curl -X POST http://localhost:8080/orchestrate/local \
  -H "Content-Type: application/json" \
  -d '{
    "source_type": "local",
    "source_path": "/absolute/path/to/terraform",
    "workflow_configuration": {
      "max_iterations": 5,
      "auto_fix_enabled": true,
      "manual_guidance_enabled": true
    }
  }'

# Scan S3 bucket
curl -X POST http://localhost:8080/orchestrate/local \
  -H "Content-Type: application/json" \
  -d '{
    "source_type": "s3",
    "source_path": "s3://my-bucket/terraform-project",
    "workflow_configuration": {
      "max_iterations": 5
    }
  }'

# Response:
{
  "workflow_id": "xyz-789-abc-012",
  "status": "started",
  "message": "Local security workflow initiated (scan-only, no PR)",
  "source": {
    "type": "local",
    "path": "/absolute/path/to/terraform"
  },
  "started_at": "2024-01-15T10:30:00Z",
  "note": "This workflow will not create a GitHub PR. Results available via /workflows/{workflow_id}/report"
}
```

### Example: Start Workflow via Webhook

```bash
curl -X POST http://localhost:8080/webhook/github \
  -H "Content-Type: application/json" \
  -d '{
    "repository": {
      "owner": {"login": "myorg"},
      "name": "iac-repo",
      "clone_url": "https://github.com/myorg/iac-repo.git",
      "default_branch": "main"
    },
    "ref": "refs/heads/feature-branch",
    "after": "abc123def456",
    "commits": [
      {
        "added": ["main.tf"],
        "modified": ["variables.tf"]
      }
    ]
  }'

# Response:
{
  "workflow_id": "abc-123-def-456",
  "status": "started",
  "message": "Security workflow initiated",
  "repository": {
    "url": "https://github.com/myorg/iac-repo.git",
    "owner": "myorg",
    "repo": "iac-repo"
  },
  "started_at": "2024-01-15T10:30:00Z"
}
```

### Example: Check Workflow Status

```bash
curl http://localhost:8080/workflows/abc-123-def-456/status

# Response (Running):
{
  "workflow_id": "abc-123-def-456",
  "status": "running",
  "progress": {
    "total_fixes_applied": 5,
    "total_manual_items": 2,
    "iterations_completed": 2,
    "convergence_achieved": false
  },
  "current_iteration": 2,
  "total_iterations": 5,
  "start_time": "2024-01-15T10:30:00Z",
  "end_time": null,
  "pr_created": false
}

# Response (Completed):
{
  "workflow_id": "abc-123-def-456",
  "status": "completed",
  "progress": {
    "total_fixes_applied": 7,
    "total_manual_items": 3,
    "iterations_completed": 2,
    "convergence_achieved": true
  },
  "current_iteration": 2,
  "total_iterations": 5,
  "start_time": "2024-01-15T10:30:00Z",
  "end_time": "2024-01-15T10:40:00Z",
  "pr_created": true
}
```

### Example: Get Final Report

```bash
curl http://localhost:8080/workflows/abc-123-def-456/report

# Response includes:
{
  "workflow_id": "abc-123-def-456",
  "report": {
    "execution_summary": {
      "status": "completed",
      "total_iterations": 2,
      "total_duration_formatted": "10.0 minutes",
      "total_fixes_applied": 7,
      "total_manual_items": 3,
      "pr_created": true
    },
    "security_metrics": {
      "total_issues_found": 10,
      "critical_issues": 2,
      "high_issues": 3,
      "auto_fixes_applied": 7,
      "manual_interventions_required": 3,
      "fix_success_rate": 70.0,
      "security_improvement_score": 70.0
    },
    "iteration_summaries": [...],
    "recommendations": [...]
  },
  "artifacts": {
    "json_report": "{...}",
    "markdown_summary": "# Security Workflow Report\n...",
    "csv_metrics": "Metric,Value\n..."
  }
}
```

## Dependencies

### Core Dependencies
```
fastapi>=0.104.1           # Web framework
uvicorn[standard]>=0.24.0  # ASGI server
pydantic>=2.5.0            # Data validation
strands-sdk>=1.0.0         # Strands SDK for agents
mcp>=1.0.0                 # Model Context Protocol
httpx>=0.25.2              # HTTP client
requests>=2.31.0           # HTTP library
boto3>=1.34.0              # AWS SDK
```

### Agent Communication
- **Retry Logic**: Exponential backoff with 3 retries
- **Circuit Breaker**: 5 consecutive failures threshold, 5-minute timeout
- **Health Monitoring**: 60-second health check interval
- **Parallel Execution**: ThreadPoolExecutor with 5 max concurrent requests

## Installation & Setup

### 1. Environment Setup
```bash
# Clone repository
git clone <repository-url>
cd agents/orchestrator

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configuration
```bash
# Required environment variables
export AGENTCORE_BASE_URL=http://localhost:8080
export MAX_ITERATIONS=5
export GITHUB_TOKEN=ghp_xxxxx
export LOG_LEVEL=INFO

# Optional AWS configuration (for Bedrock KB)
export AWS_REGION=us-east-1
export TERRAFORM_KB_ID=terraform-aws-kb
export WELL_ARCHITECTED_KB_ID=aws-well-architected-kb
```

### 3. Start the Service
```bash
# Development
python api.py

# Production (with uvicorn)
uvicorn api:app --host 0.0.0.0 --port 8080 --workers 4
```

## Docker Deployment

```bash
# Build container
docker build -t orchestrator-agent .

# Run container
docker run -p 8080:8080 \
  -e AGENTCORE_BASE_URL=http://agentcore:8080 \
  -e GITHUB_TOKEN=ghp_xxxxx \
  -e MAX_ITERATIONS=5 \
  orchestrator-agent
```

## Kubernetes Deployment

```bash
# Apply deployment configuration
kubectl apply -f agentcore-deployment.yaml

# Check deployment status
kubectl get pods -n terraform-security-platform

# View logs
kubectl logs -f deployment/orchestrator-agent -n terraform-security-platform
```

The deployment includes:
- **ConfigMap**: Environment configuration
- **Secret**: Sensitive credentials (GitHub token, AWS keys)
- **Deployment**: 2 replicas with health checks
- **Service**: ClusterIP service on port 80
- **Ingress**: HTTPS ingress with TLS
- **HPA**: Auto-scaling (2-10 replicas based on CPU/memory)

## Usage Examples

### Python Client

```python
import requests
import time

# Start workflow
response = requests.post('http://localhost:8080/webhook/github', json={
    "repository": {
        "owner": {"login": "myorg"},
        "name": "iac-repo",
        "clone_url": "https://github.com/myorg/iac-repo.git"
    },
    "ref": "refs/heads/feature-branch",
    "after": "abc123",
    "commits": [{"modified": ["main.tf"]}]
})

workflow_id = response.json()['workflow_id']
print(f"Workflow started: {workflow_id}")

# Poll for completion
while True:
    status_response = requests.get(f'http://localhost:8080/workflows/{workflow_id}/status')
    status = status_response.json()['status']
    
    if status != 'running':
        break
    
    print(f"Status: {status}, Iteration: {status_response.json()['current_iteration']}")
    time.sleep(30)

# Get final report
report_response = requests.get(f'http://localhost:8080/workflows/{workflow_id}/report')
report = report_response.json()

print(f"Workflow completed!")
print(f"Total fixes: {report['report']['execution_summary']['total_fixes_applied']}")
print(f"Security improvement: {report['report']['security_metrics']['security_improvement_score']}%")
```

### GitHub Action Integration

```yaml
name: Terraform Security Scan
on:
  push:
    branches:
      - '**'  # Trigger on ANY branch
    paths:
      - '**.tf'  # Only when Terraform files change

jobs:
  trigger-scan:
    runs-on: ubuntu-latest
    steps:
      - name: Trigger Security Workflow
        run: |
          curl -X POST ${{ secrets.ORCHESTRATOR_URL }}/webhook/github \
            -H "Content-Type: application/json" \
            -d "${{ toJson(github.event) }}"
```

## Monitoring & Observability

### Health Checks

```bash
# Check orchestrator health
curl http://localhost:8080/health

# Response:
{
  "status": "healthy",
  "orchestrator": "healthy",
  "agent_health_summary": {
    "total_agents": 3,
    "healthy_agents": 3,
    "health_percentage": 100.0
  },
  "agent_details": {
    "checkov_scanner": {
      "is_healthy": true,
      "response_time": 0.5,
      "consecutive_failures": 0
    },
    "terraform_remediation": {
      "is_healthy": true,
      "response_time": 1.2,
      "consecutive_failures": 0
    },
    "github_integration": {
      "is_healthy": true,
      "response_time": 0.8,
      "consecutive_failures": 0
    }
  },
  "circuit_breaker_status": {
    "checkov_scanner": false,
    "terraform_remediation": false,
    "github_integration": false
  }
}
```

### Metrics

The orchestrator tracks:
- **Workflow Metrics**: Total workflows, completion rate, average duration
- **Agent Health**: Response times, failure rates, circuit breaker status
- **Security Metrics**: Issues found, fixes applied, improvement scores
- **Iteration Metrics**: Average iterations, convergence rate

## Testing

### Direct Testing (Recommended)

Test the orchestrator workflow engine directly without starting the API server. This approach is simpler and faster for development testing.

**Prerequisites:**
1. Start Checkov Scanner: `cd agents/checkov_scanner && python3 api.py`
2. Start Terraform Remediation: `cd agents/terraform_remediation && python3 api.py`

**Run Test:**

```bash
# Using the helper script (handles venv and AWS profile)
./agents/orchestrator/run_direct_test.sh --local /path/to/terraform

# Or run directly
cd agents/orchestrator
source venv/bin/activate
export AWS_PROFILE=aruunk+genaiTF-Admin
python3 test_orchestrator_direct.py --local /path/to/terraform

# Test with S3 bucket
python3 test_orchestrator_direct.py --s3 s3://bucket-name/path/to/terraform

# Custom max iterations
python3 test_orchestrator_direct.py --local /path/to/terraform --max-iterations 3
```

**What it does:**
- Directly imports and runs the workflow engine
- Makes HTTP calls to scanner and remediation agents
- No need to start the orchestrator API server
- Faster feedback loop for development

### API Testing (Full Integration)

Test the complete system including the orchestrator API server.

**Prerequisites:**
1. Start all three agents:
   - Orchestrator: `cd agents/orchestrator && python3 api.py`
   - Checkov Scanner: `cd agents/checkov_scanner && python3 api.py`
   - Terraform Remediation: `cd agents/terraform_remediation && python3 api.py`

**Run Test:**

```bash
# Using the helper script
./agents/orchestrator/run_test.sh --local /path/to/terraform

# Or run directly
python3 agents/orchestrator/test_orchestrator.py --local /path/to/terraform

# Test with S3 bucket
python3 agents/orchestrator/test_orchestrator.py --s3 s3://bucket-name/path/to/terraform

# Custom timeout
python3 agents/orchestrator/test_orchestrator.py --local /path/to/terraform --timeout 600
```

**What it does:**
- Makes HTTP requests to orchestrator API
- Tests complete API endpoints
- Polls for workflow status
- Retrieves reports and audit trails

### Test Comparison

| Feature | Direct Test | API Test |
|---------|-------------|----------|
| Orchestrator API needed | ❌ No | ✅ Yes |
| Scanner agent needed | ✅ Yes | ✅ Yes |
| Remediation agent needed | ✅ Yes | ✅ Yes |
| Tests API endpoints | ❌ No | ✅ Yes |
| Tests workflow engine | ✅ Yes | ✅ Yes |
| Faster feedback | ✅ Yes | ❌ No |
| Full integration test | ❌ No | ✅ Yes |

**Recommendation:** Use direct testing during development, API testing for full integration validation.

## Troubleshooting

### Common Issues

1. **Workflow Not Starting**
   - Check webhook endpoint is reachable
   - Verify GitHub token is valid
   - Check agent health: `GET /health`

2. **Clone Fails**
   - Verify GitHub token has repo access
   - Check repository URL is correct
   - Ensure sufficient disk space

3. **Scan Returns 0 Issues**
   - Verify .tf files exist in repository
   - Check scanner agent is healthy
   - Review scanner logs

4. **PR Not Created**
   - Verify GitHub token has write access
   - Check branch permissions
   - Review GitHub Integration agent logs

5. **Workflow Stuck**
   - Check current iteration count (max 5)
   - Review agent communication stats
   - Check for circuit breaker activation

6. **Test Fails: Service Not Reachable**
   - Ensure required agents are running (see Prerequisites)
   - Check ports 8000 (scanner) and 8001 (remediation) are available
   - Verify AWS credentials are configured

### Debug Mode

```bash
# Enable debug logging
export LOG_LEVEL=DEBUG
python api.py

# Check logs for detailed information
tail -f orchestrator.log
```

### Agent Communication Issues

```bash
# Check communication stats
curl http://localhost:8080/health | jq '.agent_details'

# Check circuit breaker status
curl http://localhost:8080/health | jq '.circuit_breaker_status'
```

## Example Timeline

```
00:00 - Developer pushes to feature-branch
00:01 - GitHub Action triggers, sends webhook
00:02 - Orchestrator receives webhook, starts workflow
00:03 - Repository cloned, remediation branch created
00:04 - Iteration 1: Scan finds 10 issues
00:05 - Iteration 1: Remediation fixes 7, marks 3 manual
00:06 - Iteration 2: Scan finds 3 issues
00:07 - Iteration 2: Remediation fixes 0, marks 3 manual (convergence)
00:08 - Changes committed, PR created
00:09 - Report generated
00:10 - Developer notified, workflow complete ✅
```

**Total time: ~10 minutes for typical workflow**

## Contributing

1. Follow existing code structure and patterns
2. Add tests for new functionality
3. Update documentation for API changes
4. Ensure compatibility with Strands SDK and MCP integration

## License

[Add appropriate license information]


## API Input/Output Reference

### POST /orchestrate (GitHub Workflow)

**Input:**
```json
{
  "repository_data": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "commit_sha": "HEAD",
    "source_branch": "main",
    "default_branch": "main",
    "github_token": "ghp_xxxxx"
  },
  "workflow_configuration": {
    "max_iterations": 5,
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true,
    "use_mcp_server": true,
    "use_bedrock_kb": true
  }
}
```

**Output:**
```json
{
  "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06",
  "status": "started",
  "message": "Security workflow initiated",
  "repository": {
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data"
  },
  "configuration": {
    "max_iterations": 5,
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true
  },
  "started_at": "2025-11-21T08:48:17Z"
}
```

### POST /orchestrate/local (Local/S3 Workflow)

**Input:**
```json
{
  "source_type": "local",
  "source_path": "/absolute/path/to/terraform",
  "workflow_configuration": {
    "max_iterations": 5,
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true
  }
}
```

**Output:**
```json
{
  "workflow_id": "666cdbae-776d-4ce2-9ef2-306ef0e69106",
  "status": "started",
  "message": "Local security workflow initiated (scan-only, no PR)",
  "source": {
    "type": "local",
    "path": "/absolute/path/to/terraform"
  },
  "started_at": "2025-11-21T20:26:29Z"
}
```

### GET /workflows/{workflow_id}/status

**Output:**
```json
{
  "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06",
  "workflow_status": "completed",
  "current_iteration": 2,
  "total_iterations": 5,
  "total_fixes_applied": 4,
  "total_manual_interventions": 15,
  "convergence_achieved": true,
  "convergence_reason": "No auto-fixes applied by remediation agent",
  "start_time": "2025-11-21T08:48:17Z",
  "end_time": "2025-11-21T08:51:45Z",
  "pr_created": true,
  "pr_url": "https://github.com/aruunkumar/iac-remediation-test-data/pull/42",
  "working_directory": "/var/folders/.../T/orchestrator_workflow_aelhnz7d"
}
```

### Communication with Other Agents

#### To GitHub Integration Agent

**POST /api/v1/github/setup**
```json
{
  "repository_data": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "source_branch": "main",
    "commit_sha": "HEAD",
    "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06",
    "github_token": "ghp_xxxxx"
  }
}
```

**Response:**
```json
{
  "success": true,
  "repo_path": "/tmp/github_repos/iac-remediation-test-data",
  "branch_name": "iac-remediation/main-13db5f4a",
  "message": "Successfully setup repository at /tmp/github_repos/iac-remediation-test-data with remediation branch iac-remediation/main-13db5f4a"
}
```

#### To Checkov Scanner Agent

**POST /scan/local**
```json
{
  "folder_path": "/tmp/github_repos/iac-remediation-test-data",
  "scan_options": {
    "frameworks": ["terraform"],
    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
  },
  "repository_info": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git"
  }
}
```

**Response:**
```json
{
  "request_id": "scan-123",
  "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
  "status": "completed",
  "total_findings": 19,
  "fixable_count": 4,
  "findings": [...],
  "scan_metadata": {
    "source": "/tmp/github_repos/iac-remediation-test-data",
    "source_type": "local",
    "total_findings": 19,
    "files_scanned": 8
  }
}
```

#### To Terraform Remediation Agent

**POST /remediate**
```json
{
  "scan_results": {
    "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
    "total_findings": 19,
    "findings": [...],
    "scan_metadata": {
      "source": "/tmp/github_repos/iac-remediation-test-data"
    }
  },
  "remediation_configuration": {
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true,
    "use_mcp_server": true,
    "use_bedrock_kb": true
  }
}
```

**Response:**
```json
{
  "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
  "remediation_results": {
    "fixes": [
      {
        "check_id": "CKV_AWS_23",
        "resource": "aws_security_group.fleet_sg",
        "file": "/main.tf",
        "fix_applied": "Added description to egress rule"
      }
    ],
    "manual_interventions": [
      {
        "check_id": "CKV_AWS_382",
        "resource": "aws_security_group.fleet_sg",
        "file": "/main.tf",
        "todo_comment": "Restrict egress traffic from 0.0.0.0/0"
      }
    ]
  },
  "working_directory": "/tmp/github_repos/iac-remediation-test-data",
  "auto_fixes_applied": 4,
  "todos_added": 15
}
```

#### To GitHub Integration Agent (PR Creation)

**POST /api/v1/github/commit-and-create-pr**
```json
{
  "repo_path": "/tmp/github_repos/iac-remediation-test-data",
  "repository_data": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "source_branch": "main",
    "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06"
  },
  "remediation_results": {
    "scan_metadata": {
      "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
      "total_findings": 19
    },
    "fixes": [...],
    "manual_interventions": [...]
  }
}
```

**Response:**
```json
{
  "pr_number": 42,
  "pr_url": "https://github.com/aruunkumar/iac-remediation-test-data/pull/42",
  "branch_name": "iac-remediation/main-13db5f4a",
  "labels_added": ["security", "terraform", "automated-fix"],
  "reviewers_requested": true,
  "requires_security_approval": true
}
```


## Running the Orchestrator

### Local Development

1. **Install dependencies:**
```bash
cd agents/orchestrator
pip install -r requirements.txt
```

2. **Start all agents:**
```bash
# From project root
bash scripts/start_agents.sh
```

This starts:
- Checkov Scanner on port 8000
- Terraform Remediation on port 8001
- GitHub Integration on port 8002
- Orchestrator on port 8080

3. **Verify health:**
```bash
curl http://localhost:8080/health
```

### Testing

**End-to-end test:**
```bash
python agents/orchestrator/test_github_workflow.py
```

This test:
- Checks all agent health
- Starts a workflow for a test repository
- Polls for completion
- Verifies PR creation

**Expected output:**
```
✅ Orchestrator is healthy
✅ Checkov Scanner is healthy
✅ Terraform Remediation is healthy
✅ GitHub Integration is healthy

📤 Starting GitHub workflow...
✅ Workflow started: workflow-uuid

⏳ Polling workflow status...
✅ Workflow completed
✅ PR created: https://github.com/owner/repo/pull/123
```

## Configuration

### Environment Variables

- `AGENT_API_TOKEN`: Token for agent authentication (default: `dev-token-123`)
- `AWS_PROFILE`: AWS profile for Bedrock access
- `GITHUB_TOKEN`: GitHub personal access token (passed in request)

### Workflow Configuration

```json
{
  "max_iterations": 5,           // Maximum scan-remediate cycles
  "auto_fix_enabled": true,      // Enable automatic fixes
  "manual_guidance_enabled": true // Add TODO comments for manual items
}
```

## Troubleshooting

### Workflow completes but no PR is created

**Cause**: No fixes or manual interventions were applied

**Expected Behavior**: If the workflow finds 0 auto-fixable issues and 0 manual interventions, it will NOT create a PR. This prevents empty PRs when:
- All issues require manual intervention beyond TODO comments
- The code is already compliant
- The scanner found no issues

**Check**: Look at workflow status for `total_fixes_applied` and `total_manual_items`. If both are 0, no PR will be created.

### Workflow shows 0 fixes but remediation agent applied fixes

**Cause**: Response format mismatch between orchestrator and remediation agent

**Solution**: Ensure using `/remediate/scan-id/detailed` endpoint which returns `fixes[]` and `manual_interventions[]` as lists, not counts.

### GitHub PR creation fails with 401 Unauthorized

**Cause**: GitHub token not being passed correctly

**Solution**: Ensure `github_token` is in `repository_data`. The orchestrator automatically extracts it and adds to Authorization header.

### Workflow times out on initial request

**Expected behavior**: The `/orchestrate` endpoint starts the workflow in the background and returns immediately. The actual workflow runs asynchronously. Use `/workflows/{workflow_id}/status` to poll for completion.

### Agent communication failures

**Check**:
1. All agents are running: `curl http://localhost:{port}/health`
2. Circuit breaker status: Check orchestrator health endpoint
3. Logs: Check orchestrator terminal for detailed error messages

## Key Metrics

The orchestrator tracks and reports:

- **Total Issues Found**: All security findings across iterations
- **Auto-Fixes Applied**: Number of issues fixed automatically
- **Manual Interventions**: Number of TODO comments added
- **Security Improvement Score**: Percentage reduction in issues
- **Fix Success Rate**: Percentage of issues resolved
- **Iterations to Convergence**: Number of scan-remediate cycles
- **Processing Time**: Total workflow duration

## Related Documentation

- [ENDPOINT_CONSOLIDATION.md](../../ENDPOINT_CONSOLIDATION.md) - Complete API reference
- [Checkov Scanner README](../checkov_scanner/README.md)
- [Terraform Remediation README](../terraform_remediation/README.md)
- [GitHub Integration README](../github_integration/README.md)
- [EXECUTIVE_SUMMARY.md](../../EXECUTIVE_SUMMARY.md) - Platform overview
