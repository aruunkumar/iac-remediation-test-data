"""
Orchestrator Agent - Workflow coordination and iterative scanning logic
Built with Strands SDK for deployment on AWS Bedrock AgentCore
Coordinates multi-agent security scanning and remediation workflows
"""

from strands import Agent
from strands_tools import http_request, file_read, file_write
from typing import Dict, List, Any, Optional
import json
import logging
import time
import uuid
import os
from datetime import datetime
from dataclasses import dataclass, asdict

# Import the enhanced workflow engine, communication manager, and reporting
import sys
import os as os_module
sys.path.insert(0, os_module.path.dirname(os_module.path.abspath(__file__)))

from workflow_engine import MCPEnhancedWorkflowEngine, create_mcp_enhanced_workflow_engine
from agent_communication import AgentCommunicationManager, create_agent_communication_manager
from reporting import ReportGenerator, GitHubPRCoordinator, create_report_generator, create_github_pr_coordinator

logger = logging.getLogger(__name__)

@dataclass
class IterationResult:
    """Result of a single iteration in the workflow"""
    iteration_number: int
    scan_results: Dict[str, Any]
    remediation_results: Dict[str, Any]
    fixes_applied: int
    manual_items_added: int
    convergence_achieved: bool
    iteration_duration: float
    timestamp: str

@dataclass
class WorkflowProgress:
    """Progress tracking for the entire workflow"""
    workflow_id: str
    repository_data: Dict[str, Any]
    total_iterations: int
    max_iterations: int
    iterations: List[IterationResult]
    final_scan_results: Optional[Dict[str, Any]]
    pr_created: bool
    workflow_status: str  # 'running', 'completed', 'failed', 'max_iterations_reached'
    start_time: str
    end_time: Optional[str]
    total_fixes_applied: int
    total_manual_items: int
    working_directory: Optional[str] = None  # Path to working directory (for local/S3 workflows)

def get_orchestrator_system_prompt() -> str:
    """System prompt for the Orchestrator Agent with workflow coordination capabilities"""
    return """
    You are the Orchestrator Agent for the Terraform Security Platform. Your role is to coordinate 
    the iterative security scanning and remediation workflow by managing communication between 
    specialized agents deployed on AgentCore.
    
    Core Workflow:
    1. Invoke Checkov Scanner Agent to analyze Terraform code for security violations
    2. If scan finds any issues, invoke Terraform Remediation Agent (which decides what's fixable)
    3. If remediation agent applied auto-fixes, run scan again in next iteration
    4. If scan finds no new issues OR remediation applied no auto-fixes, end the loop
    5. Repeat until convergence or max iterations (5) reached
    6. Invoke GitHub Integration Agent to create PR with all changes and manual intervention items
    
    Agent Communication:
    - Use http_request tool to communicate with other agents via their AgentCore HTTP endpoints
    - Track iteration count and remediation progress across the workflow
    - Implement convergence detection to avoid infinite loops
    - Handle agent communication failures with retry logic
    
    Progress Monitoring:
    - Monitor progress across iterations to detect when no new fixes are being applied
    - Track total fixes applied and manual intervention items generated
    - Generate comprehensive final reports consolidating all iteration results
    - Ensure workflow completes within maximum iteration limit
    
    Always maintain detailed logs and provide comprehensive status reporting throughout the workflow.
    """

class OrchestratorAgent:
    """Orchestrator Agent for coordinating multi-agent security workflows"""
    
    def __init__(self, 
                 agentcore_base_url: Optional[str] = None,
                 checkov_scanner_url: Optional[str] = None,
                 terraform_remediation_url: Optional[str] = None,
                 github_integration_url: Optional[str] = None,
                 use_agent: bool = False):
        self.agentcore_base_url = agentcore_base_url or "http://localhost:8080"  # Default AgentCore URL
        self.max_iterations = 5
        self.use_agent = use_agent
        
        # Only create Strands Agent if explicitly requested (for AgentCore deployment)
        # For local workflows, we use direct HTTP calls via communication manager
        if use_agent:
            self.agent = Agent(
                system_prompt=get_orchestrator_system_prompt(),
                tools=[http_request, file_read, file_write],
                model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
            )
        else:
            self.agent = None
        
        # Agent endpoint configurations
        # Support both AgentCore URLs and direct agent URLs for local testing
        self.agent_endpoints = {
            'checkov_scanner': checkov_scanner_url or f"{self.agentcore_base_url}/agents/checkov-scanner",
            'terraform_remediation': terraform_remediation_url or f"{self.agentcore_base_url}/agents/terraform-remediation", 
            'github_integration': github_integration_url or f"{self.agentcore_base_url}/agents/github-integration"
        }
        
        # Initialize enhanced workflow engine with MCP capabilities
        self.workflow_engine = create_mcp_enhanced_workflow_engine(self)
        
        # Initialize agent communication manager
        self.communication_manager = create_agent_communication_manager(self)
        
        # Initialize reporting and PR coordination
        self.report_generator = create_report_generator(self)
        self.pr_coordinator = create_github_pr_coordinator(self)
        
        logger.info(f"Orchestrator Agent initialized with AgentCore base URL: {self.agentcore_base_url}")
    
    def orchestrate_security_workflow(self, repository_data: Dict[str, Any], workflow_id: Optional[str] = None) -> WorkflowProgress:
        """
        Main orchestration method for iterative security scanning and remediation
        
        Complete Flow:
        1. Clone repository and create remediation branch (GitHub Integration Agent)
        2. Scan cloned files (Checkov Scanner Agent)
        3. Fix issues (Terraform Remediation Agent)
        4. Repeat steps 2-3 until convergence
        5. Commit changes and create PR (GitHub Integration Agent)
        6. Generate comprehensive report
        
        Args:
            repository_data: Repository information
            workflow_id: Optional workflow ID (if not provided, generates new UUID)
        """
        if workflow_id is None:
            workflow_id = str(uuid.uuid4())
        start_time = datetime.utcnow().isoformat()
        
        logger.info(f"Starting security workflow {workflow_id} for repository: {repository_data.get('url')}")
        
        # Initialize workflow progress tracking
        workflow_progress = WorkflowProgress(
            workflow_id=workflow_id,
            repository_data=repository_data,
            total_iterations=0,
            max_iterations=self.max_iterations,
            iterations=[],
            final_scan_results=None,
            pr_created=False,
            workflow_status='running',
            start_time=start_time,
            end_time=None,
            total_fixes_applied=0,
            total_manual_items=0
        )
        
        try:
            # Step 1: Clone repository and setup remediation branch
            logger.info("Step 1: Cloning repository and setting up remediation branch")
            repo_path = self._clone_repository_for_scanning(workflow_progress.repository_data)
            workflow_progress.repository_data['repo_path'] = repo_path
            logger.info(f"Repository cloned to: {repo_path}")
            
            # Step 2-4: Execute iterative scanning and remediation workflow
            logger.info("Step 2-4: Starting iterative scanning and remediation")
            self.workflow_engine.execute_enhanced_iterative_workflow(workflow_progress)
            
            # Step 5: Commit changes and create PR
            logger.info("Step 5: Committing changes and creating pull request")
            self._commit_and_create_pr(workflow_progress)
            
            # Step 6: Mark workflow as completed
            workflow_progress.workflow_status = 'completed'
            workflow_progress.end_time = datetime.utcnow().isoformat()
            
            logger.info(f"Workflow {workflow_id} completed successfully with {workflow_progress.total_fixes_applied} total fixes")
            
        except Exception as e:
            logger.error(f"Workflow {workflow_id} failed: {e}")
            workflow_progress.workflow_status = 'failed'
            workflow_progress.end_time = datetime.utcnow().isoformat()
            raise
        
        return workflow_progress
    
    def _execute_iterative_workflow(self, workflow_progress: WorkflowProgress) -> None:
        """Execute the iterative scanning and remediation loop"""
        iteration_count = 0
        
        while iteration_count < self.max_iterations:
            iteration_start_time = time.time()
            iteration_count += 1
            
            logger.info(f"Starting iteration {iteration_count}/{self.max_iterations}")
            
            # Step 1: Run security scan
            scan_results = self._invoke_checkov_scanner(workflow_progress.repository_data)
            
            # Check if scan found any issues
            total_findings = scan_results.get('total_findings', 0)
            
            if total_findings == 0:
                logger.info(f"No security issues found in iteration {iteration_count}, ending workflow")
                
                # Record final iteration with no issues
                iteration_result = IterationResult(
                    iteration_number=iteration_count,
                    scan_results=scan_results,
                    remediation_results={},
                    fixes_applied=0,
                    manual_items_added=0,
                    convergence_achieved=True,
                    iteration_duration=time.time() - iteration_start_time,
                    timestamp=datetime.utcnow().isoformat()
                )
                
                workflow_progress.iterations.append(iteration_result)
                workflow_progress.final_scan_results = scan_results
                break
            
            # Step 2: Always invoke remediation agent when issues are found
            # Let the remediation agent decide what's fixable
            logger.info(f"Found {total_findings} issues, invoking remediation agent")
            remediation_results = self._invoke_terraform_remediation(scan_results, workflow_progress.repository_data)
            
            # Count fixes applied in this iteration
            # Defensive checks: ensure lists are actually lists
            fixes = remediation_results.get('fixes', [])
            manual_interventions = remediation_results.get('manual_interventions', [])
            fixes_applied = len(fixes) if isinstance(fixes, list) else 0
            manual_items_added = len(manual_interventions) if isinstance(manual_interventions, list) else 0
            
            # Record iteration results
            iteration_result = IterationResult(
                iteration_number=iteration_count,
                scan_results=scan_results,
                remediation_results=remediation_results,
                fixes_applied=fixes_applied,
                manual_items_added=manual_items_added,
                convergence_achieved=fixes_applied == 0,
                iteration_duration=time.time() - iteration_start_time,
                timestamp=datetime.utcnow().isoformat()
            )
            
            workflow_progress.iterations.append(iteration_result)
            workflow_progress.total_fixes_applied += fixes_applied
            workflow_progress.total_manual_items += manual_items_added
            
            # Step 3: Check for convergence - only continue if auto-fixes were applied
            if fixes_applied == 0:
                logger.info(f"Convergence achieved in iteration {iteration_count} - no auto-fixes applied by remediation agent")
                workflow_progress.final_scan_results = scan_results
                break
            
            # Step 4: Update repository data with applied fixes for next iteration
            logger.info(f"Applied {fixes_applied} auto-fixes, will run scan again in next iteration")
            workflow_progress.repository_data = self._update_repository_with_fixes(
                workflow_progress.repository_data, 
                remediation_results
            )
            
            logger.info(f"Iteration {iteration_count} completed: {fixes_applied} fixes applied, {manual_items_added} manual items")
        
        workflow_progress.total_iterations = iteration_count
        
        # Check if we reached max iterations without convergence
        if iteration_count >= self.max_iterations and not workflow_progress.iterations[-1].convergence_achieved:
            logger.warning(f"Reached maximum iterations ({self.max_iterations}) without full convergence")
            workflow_progress.workflow_status = 'max_iterations_reached'
    
    def _invoke_checkov_scanner(self, repository_data: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke Checkov Scanner Agent via HTTP with retry logic"""
        logger.info("Invoking Checkov Scanner Agent")
        
        # Orchestrator always provides a local working directory path
        # Whether from GitHub clone, S3 download, or local copy
        repo_path = repository_data.get('repo_path')
        
        if not repo_path or not os.path.exists(repo_path):
            raise ValueError(f"Working directory not found: {repo_path}")
        
        logger.info(f"Scanning Terraform files in: {repo_path}")
        
        # Use local scan endpoint - scanner discovers files itself
        scan_request_data = {
            'folder_path': repo_path,
            'scan_options': {
                'frameworks': ['terraform'],
                'severity_levels': ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
            },
            'repository_info': {
                'owner': repository_data.get('owner', ''),
                'repo': repository_data.get('repo', ''),
                'url': repository_data.get('url', '')
            }
        }
        
        # Use communication manager for reliable agent communication
        result = self.communication_manager.call_agent_with_retry(
            agent_name='checkov_scanner',
            endpoint_path='/scan/local',
            request_data=scan_request_data,
            method='POST'
        )
        
        if result.success:
            # Defensive check: ensure response_data is a dict
            if not isinstance(result.response_data, dict):
                logger.error(f"Invalid scanner response_data type: {type(result.response_data)}, value: {result.response_data}")
                return {
                    'total_findings': 0,
                    'findings': [],
                    'scan_status': 'failed',
                    'error': f'Invalid response data type: {type(result.response_data)}'
                }
            
            logger.info(f"Checkov scan completed with {result.response_data.get('total_findings', 0)} findings")
            return result.response_data
        else:
            logger.error(f"Checkov Scanner communication failed: {result.error_message}")
            # Return empty results to allow workflow to continue
            return {
                'total_findings': 0,
                'findings': [],
                'scan_status': 'failed',
                'error': result.error_message,
                'retry_count': result.retry_count
            }
    
    def _invoke_terraform_remediation(self, scan_results: Dict[str, Any], repository_data: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke Terraform Remediation Agent via HTTP with retry logic using scan-id endpoint"""
        logger.info("Invoking Terraform Remediation Agent")
        
        # Extract scan_id from scan_results
        scan_id = scan_results.get('scan_id') or scan_results.get('request_id', 'unknown')
        
        # Get repo_path from repository_data (optional - remediation agent will read from scan metadata if not provided)
        repo_path = repository_data.get('repo_path')
        
        # Build simple request with just scan_id (remediation agent loads scan results from file)
        remediation_request_data = {
            'scan_id': scan_id,
            'source_path': repo_path  # Optional - will be read from scan metadata if not provided
        }
        
        # Use communication manager for reliable agent communication
        # Use /remediate/scan-id/detailed endpoint which returns full fix and manual intervention details
        result = self.communication_manager.call_agent_with_retry(
            agent_name='terraform_remediation',
            endpoint_path='/remediate/scan-id/detailed',
            request_data=remediation_request_data,
            method='POST'
        )
        
        if result.success:
            # Defensive check: ensure response_data is a dict
            if not isinstance(result.response_data, dict):
                logger.error(f"Invalid response_data type: {type(result.response_data)}, value: {result.response_data}")
                return {
                    'fixes': [],
                    'manual_interventions': [],
                    'remediation_status': 'failed',
                    'error': f'Invalid response data type: {type(result.response_data)}'
                }
            
            # The detailed endpoint returns fixes and manual_interventions as lists
            fixes = result.response_data.get('fixes', [])
            manual_interventions = result.response_data.get('manual_interventions', [])
            
            # Log what we received for debugging
            logger.info(f"Received from remediation agent - fixes type: {type(fixes)}, manual_interventions type: {type(manual_interventions)}")
            logger.info(f"Response data keys: {list(result.response_data.keys())}")
            
            # Defensive checks: ensure they are actually lists
            if not isinstance(fixes, list):
                logger.error(f"CRITICAL: fixes is not a list (type: {type(fixes)}, value: {fixes})")
                logger.error(f"Full response_data: {json.dumps(result.response_data, indent=2, default=str)}")
                fixes = []
            if not isinstance(manual_interventions, list):
                logger.error(f"CRITICAL: manual_interventions is not a list (type: {type(manual_interventions)}, value: {manual_interventions})")
                logger.error(f"Full response_data: {json.dumps(result.response_data, indent=2, default=str)}")
                manual_interventions = []
            
            fixes_count = len(fixes)
            manual_count = len(manual_interventions)
            logger.info(f"Remediation completed: {fixes_count} auto-fixes, {manual_count} manual items")
            
            # Return the response data with guaranteed list types
            return {
                'fixes': fixes,
                'manual_interventions': manual_interventions,
                'validation_errors': result.response_data.get('validation_errors', []),
                'knowledge_base_queries': result.response_data.get('knowledge_base_queries', []),
                'processing_metadata': result.response_data.get('processing_metadata', {}),
                'scan_id': result.response_data.get('scan_id', scan_id),
                'remediation_status': 'success'
            }
        else:
            logger.error(f"Terraform Remediation Agent communication failed: {result.error_message}")
            # Return empty results to allow workflow to continue
            return {
                'fixes': [],
                'manual_interventions': [],
                'remediation_status': 'failed',
                'error': result.error_message,
                'retry_count': result.retry_count
            }
    
    def _clone_repository_for_scanning(self, repository_data: Dict[str, Any]) -> str:
        """
        Clone repository and create remediation branch via GitHub Integration Agent
        This is called at the START of the workflow (Step 1)
        """
        logger.info("Invoking GitHub Integration Agent to clone repository")
        
        clone_request_data = {
            'repository_data': repository_data,
            'operation': 'setup_repository_and_branch'
        }
        
        # Use communication manager for reliable agent communication
        result = self.communication_manager.call_agent_with_retry(
            agent_name='github_integration',
            endpoint_path='/api/v1/github/setup',
            request_data=clone_request_data,
            method='POST'
        )
        
        if result.success:
            # Defensive check: ensure response_data is a dict
            if not isinstance(result.response_data, dict):
                logger.error(f"Invalid GitHub clone response_data type: {type(result.response_data)}, value: {result.response_data}")
                raise Exception(f"Invalid response data type from GitHub Integration: {type(result.response_data)}")
            
            repo_path = result.response_data.get('repo_path')
            branch_name = result.response_data.get('branch_name')
            logger.info(f"Repository cloned successfully to: {repo_path}")
            logger.info(f"Remediation branch created: {branch_name}")
            return repo_path
        else:
            logger.error(f"GitHub Integration Agent clone failed: {result.error_message}")
            raise Exception(f"Failed to clone repository: {result.error_message}")
    
    def _transform_fix_for_github(self, fix: Dict[str, Any]) -> Dict[str, Any]:
        """Transform remediation agent fix format to GitHub Integration agent format"""
        # Extract knowledge_base_reference as string
        kb_ref = fix.get('knowledge_base_reference', '')
        if isinstance(kb_ref, dict):
            # If it's a dict, extract the most relevant string
            kb_ref = kb_ref.get('agent_result', kb_ref.get('fix_summary', str(kb_ref)))
        
        return {
            'check_id': fix.get('check_id', 'UNKNOWN'),
            'file': fix.get('file', 'unknown'),
            'resource': fix.get('resource', 'unknown'),
            'severity': 'MEDIUM',  # Default severity since remediation agent doesn't provide it
            'description': fix.get('fix_applied', 'Security fix applied'),
            'original_content': '',  # Not provided by remediation agent
            'fix_applied': fix.get('fix_applied', ''),
            'knowledge_base_reference': kb_ref if isinstance(kb_ref, str) else ''
        }
    
    def _transform_manual_intervention_for_github(self, intervention: Dict[str, Any]) -> Dict[str, Any]:
        """Transform remediation agent manual intervention format to GitHub Integration agent format"""
        # Extract knowledge_base_reference as string
        kb_ref = intervention.get('knowledge_base_reference', '')
        if isinstance(kb_ref, dict):
            kb_ref = kb_ref.get('agent_result', kb_ref.get('fix_summary', str(kb_ref)))
        
        # Extract detailed_guidance as string
        detailed_guidance = intervention.get('detailed_guidance', 'Manual intervention required')
        if isinstance(detailed_guidance, dict):
            # If it's a dict, extract the most relevant string
            detailed_guidance = detailed_guidance.get('agent_result', detailed_guidance.get('single_call_guidance', str(detailed_guidance)))
        
        return {
            'check_id': intervention.get('check_id', 'UNKNOWN'),
            'file': intervention.get('file', 'unknown'),
            'resource': intervention.get('resource', 'unknown'),
            'severity': 'MEDIUM',  # Default severity
            'description': detailed_guidance if isinstance(detailed_guidance, str) else 'Manual intervention required',
            'todo_comment': intervention.get('todo_comment', '# TODO: Manual fix required'),
            'line_number': 1,  # Default line number
            'knowledge_base_reference': kb_ref if isinstance(kb_ref, str) else ''
        }
    
    def _commit_and_create_pr(self, workflow_progress: WorkflowProgress) -> None:
        """
        Commit all changes and create PR via GitHub Integration Agent
        This is called at the END of the workflow (Step 5)
        """
        logger.info("Invoking GitHub Integration Agent to commit changes and create PR")
        
        # Consolidate all fixes and manual interventions from all iterations
        all_fixes = []
        all_manual_interventions = []
        
        for iteration in workflow_progress.iterations:
            remediation_results = iteration.remediation_results
            all_fixes.extend(remediation_results.get('fixes', []))
            all_manual_interventions.extend(remediation_results.get('manual_interventions', []))
        
        # Deduplicate fixes by (check_id, resource) tuple
        seen_fixes = set()
        unique_fixes = []
        for fix in all_fixes:
            key = (fix.get('check_id'), fix.get('resource'))
            if key not in seen_fixes:
                seen_fixes.add(key)
                unique_fixes.append(fix)
        
        # Deduplicate manual interventions by (check_id, resource) tuple
        seen_manual = set()
        unique_manual = []
        for manual in all_manual_interventions:
            key = (manual.get('check_id'), manual.get('resource'))
            if key not in seen_manual:
                seen_manual.add(key)
                unique_manual.append(manual)
        
        logger.info(f"Deduplicated: {len(all_fixes)} -> {len(unique_fixes)} fixes, {len(all_manual_interventions)} -> {len(unique_manual)} manual interventions")
        
        # Check if there are any fixes or manual interventions
        if len(unique_fixes) == 0 and len(unique_manual) == 0:
            logger.info("No fixes or manual interventions to commit - skipping PR creation")
            workflow_progress.pr_created = False
            return
        
        # Transform fixes and manual interventions to GitHub Integration format
        transformed_fixes = [self._transform_fix_for_github(fix) for fix in unique_fixes]
        transformed_manual = [self._transform_manual_intervention_for_github(mi) for mi in unique_manual]
        
        # Prepare consolidated remediation results for PR creation with transformed format
        consolidated_results = {
            'scan_metadata': {
                'scan_id': workflow_progress.workflow_id,
                'scan_date': workflow_progress.start_time,
                'total_findings': workflow_progress.final_scan_results.get('total_findings', 0) if workflow_progress.final_scan_results else 0,
                'scan_duration': None
            },
            'fixes': transformed_fixes,
            'manual_interventions': transformed_manual
        }
        
        # Log token presence for debugging
        token_in_repo_data = workflow_progress.repository_data.get('github_token', '')
        if token_in_repo_data:
            logger.info(f"GitHub token present in repository_data (length: {len(token_in_repo_data)})")
        else:
            logger.error("GitHub token NOT found in repository_data!")
        
        pr_request_data = {
            'repo_path': workflow_progress.repository_data.get('repo_path'),
            'repository_data': workflow_progress.repository_data,
            'remediation_results': consolidated_results,
            'operation': 'commit_and_create_pr'
        }
        
        # Use communication manager for reliable GitHub Integration Agent communication
        result = self.communication_manager.call_agent_with_retry(
            agent_name='github_integration',
            endpoint_path='/api/v1/github/commit-and-create-pr',
            request_data=pr_request_data,
            method='POST'
        )
        
        if result.success:
            # Defensive check: ensure response_data is a dict
            if not isinstance(result.response_data, dict):
                logger.error(f"Invalid PR creation response_data type: {type(result.response_data)}, value: {result.response_data}")
                logger.error("PR creation failed due to invalid response format")
                return
            
            workflow_progress.pr_created = result.response_data.get('status') == 'created'
            pr_url = result.response_data.get('pr_url', 'N/A')
            pr_number = result.response_data.get('pr_number', 'N/A')
            logger.info(f"PR created successfully: #{pr_number} - {pr_url}")
        else:
            logger.error(f"GitHub Integration Agent PR creation failed: {result.error_message}")
            workflow_progress.pr_created = False
    
    def _create_comprehensive_final_pr(self, workflow_progress: WorkflowProgress) -> None:
        """Create comprehensive final PR with detailed reporting and audit trail"""
        logger.info("Creating comprehensive final PR with detailed reporting")
        
        try:
            # Use PR coordinator for comprehensive PR creation with reporting
            pr_result = self.pr_coordinator.create_comprehensive_pr(workflow_progress)
            
            workflow_progress.pr_created = pr_result.get('success', False)
            
            if workflow_progress.pr_created:
                logger.info(f"Comprehensive PR created successfully: {pr_result.get('pr_url', 'N/A')}")
                
                # Log report summary
                report_summary = pr_result.get('report_summary', {})
                logger.info(f"Report summary - Issues: {report_summary.get('total_issues', 0)}, "
                           f"Fixes: {report_summary.get('fixes_applied', 0)}, "
                           f"Security improvement: {report_summary.get('security_improvement', 'N/A')}")
            else:
                logger.error(f"Comprehensive PR creation failed: {pr_result.get('error', 'Unknown error')}")
                
        except Exception as e:
            logger.error(f"Error creating comprehensive final PR: {e}")
            workflow_progress.pr_created = False
    
    def _create_final_pr(self, workflow_progress: WorkflowProgress) -> None:
        """Legacy method - redirects to comprehensive PR creation"""
        self._create_comprehensive_final_pr(workflow_progress)
    
    def _count_fixable_issues(self, scan_results: Dict[str, Any]) -> int:
        """Count the number of fixable issues in scan results"""
        findings = scan_results.get('findings', [])
        fixable_count = 0
        
        for finding in findings:
            # Check if finding is marked as auto-fixable
            if finding.get('remediability') == 'auto' or finding.get('auto_fixable', False):
                fixable_count += 1
        
        return fixable_count
    
    def _update_repository_with_fixes(self, repository_data: Dict[str, Any], remediation_results: Dict[str, Any]) -> Dict[str, Any]:
        """Update repository data with applied fixes for next iteration"""
        # In a real implementation, this would update the repository content
        # For now, we'll just add metadata about applied fixes
        updated_data = repository_data.copy()
        
        # Add applied fixes to repository metadata
        if 'applied_fixes' not in updated_data:
            updated_data['applied_fixes'] = []
        
        updated_data['applied_fixes'].extend(remediation_results.get('fixes', []))
        
        # Update last_scan_timestamp
        updated_data['last_scan_timestamp'] = datetime.utcnow().isoformat()
        
        return updated_data
    
    def _parse_agent_response(self, response: Any, agent_name: str) -> Dict[str, Any]:
        """Parse response from agent HTTP calls"""
        try:
            # Handle different response formats
            if hasattr(response, 'response'):
                # If response has a response attribute, parse it
                response_data = response.response
                if isinstance(response_data, str):
                    return json.loads(response_data)
                else:
                    return response_data
            elif isinstance(response, str):
                # Try to parse as JSON
                return json.loads(response)
            elif isinstance(response, dict):
                # Already a dictionary
                return response
            else:
                # Fallback: create a basic response structure
                return {
                    'status': 'unknown',
                    'raw_response': str(response),
                    'agent': agent_name
                }
                
        except (json.JSONDecodeError, AttributeError) as e:
            logger.warning(f"Failed to parse response from {agent_name}: {e}")
            # Return a fallback response structure
            return {
                'status': 'parse_error',
                'error': str(e),
                'raw_response': str(response),
                'agent': agent_name
            }
    
    def invoke_mcp_enhanced_checkov_scanner(self, repository_data: Dict[str, Any], iteration_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Invoke MCP-enhanced Checkov Scanner Agent with iteration context"""
        logger.info("Invoking MCP-enhanced Checkov Scanner Agent")
        
        enhanced_scan_request = {
            'repository_data': repository_data,
            'scan_configuration': {
                'frameworks': ['terraform'],
                'severity_levels': ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'],
                'mcp_enhanced': True,
                'iterative_scanning': True
            },
            'iteration_context': iteration_context or {}
        }
        
        try:
            # Use agent to make HTTP request with MCP enhancements
            scan_prompt = f"""
            Make an HTTP POST request to the MCP-enhanced Checkov Scanner Agent:
            
            URL: {self.agent_endpoints['checkov_scanner']}/scan-enhanced
            Headers: {{"Content-Type": "application/json"}}
            Body: {json.dumps(enhanced_scan_request)}
            
            The MCP-enhanced scanner will use iterative scanning features and progress tracking.
            """
            
            scan_response = self.agent(scan_prompt)
            scan_results = self._parse_agent_response(scan_response, 'mcp_checkov_scanner')
            
            # Add MCP enhancement metadata
            scan_results['mcp_enhanced'] = True
            scan_results['iteration_context'] = iteration_context
            
            logger.info(f"MCP-enhanced Checkov scan completed with {scan_results.get('total_findings', 0)} findings")
            return scan_results
            
        except Exception as e:
            logger.error(f"Error invoking MCP-enhanced Checkov Scanner: {e}")
            # Fallback to regular scanner
            return self._invoke_checkov_scanner(repository_data)
    
    def invoke_mcp_enhanced_remediation_agent(self, scan_results: Dict[str, Any], iteration_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Invoke MCP-enhanced Terraform Remediation Agent with iteration context"""
        logger.info("Invoking MCP-enhanced Terraform Remediation Agent")
        
        enhanced_remediation_request = {
            'scan_results': scan_results,
            'remediation_configuration': {
                'auto_fix_enabled': True,
                'manual_guidance_enabled': True,
                'use_mcp_server': True,
                'use_bedrock_kb': True,
                'mcp_enhanced': True,
                'iterative_remediation': True
            },
            'iteration_context': iteration_context or {}
        }
        
        try:
            # Use agent to make HTTP request with MCP enhancements
            remediation_prompt = f"""
            Make an HTTP POST request to the MCP-enhanced Terraform Remediation Agent:
            
            URL: {self.agent_endpoints['terraform_remediation']}/remediate-enhanced
            Headers: {{"Content-Type": "application/json"}}
            Body: {json.dumps(enhanced_remediation_request)}
            
            The MCP-enhanced agent will use server capabilities and Bedrock KB for comprehensive remediation.
            """
            
            remediation_response = self.agent(remediation_prompt)
            remediation_results = self._parse_agent_response(remediation_response, 'mcp_terraform_remediation')
            
            # Add MCP enhancement metadata
            remediation_results['mcp_enhanced'] = True
            remediation_results['iteration_context'] = iteration_context
            
            # Defensive checks: ensure lists are actually lists
            fixes = remediation_results.get('fixes', [])
            manual_interventions = remediation_results.get('manual_interventions', [])
            fixes_count = len(fixes) if isinstance(fixes, list) else 0
            manual_count = len(manual_interventions) if isinstance(manual_interventions, list) else 0
            
            logger.info(f"MCP-enhanced remediation completed: {fixes_count} auto-fixes, {manual_count} manual items")
            return remediation_results
            
        except Exception as e:
            logger.error(f"Error invoking MCP-enhanced Terraform Remediation Agent: {e}")
            # Fallback to regular remediation
            return self._invoke_terraform_remediation(scan_results)
    
    def generate_workflow_report(self, workflow_progress: WorkflowProgress) -> Dict[str, Any]:
        """Generate comprehensive workflow report"""
        logger.info(f"Generating workflow report for {workflow_progress.workflow_id}")
        
        final_report = self.report_generator.generate_final_report(workflow_progress)
        
        return {
            'report': asdict(final_report),
            'artifacts': self.pr_coordinator.generate_report_artifacts(final_report)
        }
    
    def orchestrate_local_workflow(self, local_workflow_data: Dict[str, Any], workflow_id: Optional[str] = None) -> WorkflowProgress:
        """
        Orchestrate local/S3 workflow (scan and remediate without GitHub integration)
        
        Flow:
        1. Scan files from local/S3 path (Checkov Scanner Agent)
        2. Remediate issues (Terraform Remediation Agent)
        3. Repeat steps 1-2 until convergence
        4. Generate comprehensive report
        
        No repository cloning or PR creation - scan-only mode.
        
        Args:
            local_workflow_data: Contains source_type ('local' or 's3') and source_path
            workflow_id: Optional workflow ID
        """
        if workflow_id is None:
            workflow_id = str(uuid.uuid4())
        start_time = datetime.utcnow().isoformat()
        
        source_type = local_workflow_data.get('source_type')
        source_path = local_workflow_data.get('source_path')
        
        logger.info(f"Starting local workflow {workflow_id} for {source_type} source: {source_path}")
        
        # Initialize workflow progress tracking
        workflow_progress = WorkflowProgress(
            workflow_id=workflow_id,
            repository_data={
                'source_type': source_type,
                'source_path': source_path,
                'workflow_type': 'local'
            },
            total_iterations=0,
            max_iterations=self.max_iterations,
            iterations=[],
            final_scan_results=None,
            pr_created=False,
            workflow_status='running',
            start_time=start_time,
            end_time=None,
            total_fixes_applied=0,
            total_manual_items=0
        )
        
        try:
            # Execute iterative scanning and remediation (no GitHub steps)
            logger.info("Starting iterative scanning and remediation for local source")
            self._execute_local_iterative_workflow(workflow_progress)
            
            # Mark workflow as completed (no PR creation for local workflows)
            workflow_progress.workflow_status = 'completed'
            workflow_progress.end_time = datetime.utcnow().isoformat()
            
            logger.info(f"Local workflow {workflow_id} completed successfully with {workflow_progress.total_fixes_applied} total fixes")
            logger.info(f"Note: No PR created for local workflow. Modified files available in scan results.")
            
        except Exception as e:
            logger.error(f"Local workflow {workflow_id} failed: {e}")
            workflow_progress.workflow_status = 'failed'
            workflow_progress.end_time = datetime.utcnow().isoformat()
            raise
        
        return workflow_progress
    
    def _execute_local_iterative_workflow(self, workflow_progress: WorkflowProgress) -> None:
        """Execute iterative scanning and remediation for local/S3 sources"""
        import tempfile
        import shutil
        import os
        
        iteration_count = 0
        source_type = workflow_progress.repository_data.get('source_type')
        source_path = workflow_progress.repository_data.get('source_path')
        
        # Create working directory for the workflow
        working_directory = tempfile.mkdtemp(prefix='orchestrator_workflow_')
        logger.info(f"Created working directory: {working_directory}")
        
        # Store working directory in workflow progress
        workflow_progress.working_directory = working_directory
        
        try:
            # Step 0: Copy source files to working directory
            if source_type == 's3':
                logger.info(f"Downloading files from S3: {source_path} to {working_directory}")
                self._download_from_s3(source_path, working_directory)
            elif source_type == 'local':
                logger.info(f"Copying files from local: {source_path} to {working_directory}")
                self._copy_local_files(source_path, working_directory)
            else:
                raise ValueError(f"Unsupported source type: {source_type}")
            
            logger.info(f"Files ready in working directory: {working_directory}")
        
        except Exception as e:
            logger.error(f"Failed to prepare working directory: {e}")
            shutil.rmtree(working_directory, ignore_errors=True)
            raise
        
        try:
            while iteration_count < self.max_iterations:
                iteration_start_time = time.time()
                iteration_count += 1
                
                logger.info(f"Starting local iteration {iteration_count}/{self.max_iterations}")
                
                # Step 1: Run security scan on working directory
                scan_results = self._invoke_scanner_for_local_source('local', working_directory)
                
                # Check if scan found any issues
                total_findings = scan_results.get('total_findings', 0)
                
                if total_findings == 0:
                    logger.info(f"No security issues found in iteration {iteration_count}, ending workflow")
                    
                    # Record final iteration with no issues
                    iteration_result = IterationResult(
                        iteration_number=iteration_count,
                        scan_results=scan_results,
                        remediation_results={},
                        fixes_applied=0,
                        manual_items_added=0,
                        convergence_achieved=True,
                        iteration_duration=time.time() - iteration_start_time,
                        timestamp=datetime.utcnow().isoformat()
                    )
                    
                    workflow_progress.iterations.append(iteration_result)
                    workflow_progress.final_scan_results = scan_results
                    break
                
                # Step 2: Invoke remediation agent on working directory
                logger.info(f"Found {total_findings} issues, invoking remediation agent")
                remediation_results = self._invoke_remediation_for_local_source(scan_results, working_directory)
                
                # Count fixes applied in this iteration
                # Use the validated fields from remediation response
                fixes_applied = remediation_results.get('fixes_applied', 0)
                manual_items_added = remediation_results.get('manual_interventions', 0)
                
                # Record iteration results
                iteration_result = IterationResult(
                    iteration_number=iteration_count,
                    scan_results=scan_results,
                    remediation_results=remediation_results,
                    fixes_applied=fixes_applied,
                    manual_items_added=manual_items_added,
                    convergence_achieved=fixes_applied == 0,
                    iteration_duration=time.time() - iteration_start_time,
                    timestamp=datetime.utcnow().isoformat()
                )
                
                workflow_progress.iterations.append(iteration_result)
                workflow_progress.total_fixes_applied += fixes_applied
                workflow_progress.total_manual_items += manual_items_added
                
                # Step 3: Check for convergence
                if fixes_applied == 0:
                    logger.info(f"Convergence achieved in iteration {iteration_count} - no auto-fixes applied")
                    workflow_progress.final_scan_results = scan_results
                    break
                
                logger.info(f"Applied {fixes_applied} auto-fixes, will run scan again in next iteration")
                logger.info(f"Local iteration {iteration_count} completed: {fixes_applied} fixes applied, {manual_items_added} manual items")
            
            workflow_progress.total_iterations = iteration_count
            
            # Check if we reached max iterations without convergence
            if iteration_count >= self.max_iterations and not workflow_progress.iterations[-1].convergence_achieved:
                logger.warning(f"Reached maximum iterations ({self.max_iterations}) without full convergence")
                workflow_progress.workflow_status = 'max_iterations_reached'
        
        finally:
            # Preserve working directory (don't clean up)
            # Note: Working directory is preserved for review and debugging
            logger.info(f"Working directory preserved at: {working_directory}")
            logger.info(f"To clean up manually: rm -rf {working_directory}")
    
    def _download_from_s3(self, s3_uri: str, destination: str) -> None:
        """Download files from S3 to local directory"""
        import boto3
        import os
        
        # Parse S3 URI
        if not s3_uri.startswith('s3://'):
            raise ValueError(f"Invalid S3 URI: {s3_uri}")
        
        s3_path = s3_uri[5:]  # Remove 's3://'
        parts = s3_path.split('/', 1)
        bucket = parts[0]
        prefix = parts[1] if len(parts) > 1 else ''
        
        logger.info(f"Downloading from S3 bucket: {bucket}, prefix: {prefix}")
        
        s3_client = boto3.client('s3')
        
        # List and download all objects with the prefix
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get('Contents', []):
                key = obj['Key']
                
                # Skip if it's a directory marker
                if key.endswith('/'):
                    continue
                
                # Calculate relative path
                relative_path = key[len(prefix):].lstrip('/')
                local_file_path = os.path.join(destination, relative_path)
                
                # Create parent directories
                os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
                
                # Download file
                logger.debug(f"Downloading: {key} -> {local_file_path}")
                s3_client.download_file(bucket, key, local_file_path)
        
        logger.info(f"Downloaded files from S3 to: {destination}")
    
    def _copy_local_files(self, source_path: str, destination: str) -> None:
        """Copy files from local directory to working directory"""
        import shutil
        import os
        
        if not os.path.exists(source_path):
            raise FileNotFoundError(f"Source path does not exist: {source_path}")
        
        if not os.path.isdir(source_path):
            raise ValueError(f"Source path is not a directory: {source_path}")
        
        logger.info(f"Copying files from {source_path} to {destination}")
        
        # Copy all files and subdirectories
        for item in os.listdir(source_path):
            src_item = os.path.join(source_path, item)
            dst_item = os.path.join(destination, item)
            
            if os.path.isdir(src_item):
                shutil.copytree(src_item, dst_item)
            else:
                shutil.copy2(src_item, dst_item)
        
        logger.info(f"Copied files to: {destination}")
    

    def _invoke_scanner_for_local_source(self, source_type: str, source_path: str) -> Dict[str, Any]:
        """Invoke Checkov Scanner for local or S3 source"""
        logger.info(f"Invoking Checkov Scanner for {source_type} source: {source_path}")
        
        # Determine the appropriate scanner endpoint based on source type
        if source_type == 's3':
            endpoint_path = '/scan/s3'
            scan_request_data = {
                's3_uri': source_path,
                'scan_configuration': {
                    'frameworks': ['terraform'],
                    'severity_levels': ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
                }
            }
        else:  # local
            endpoint_path = '/scan/local'
            scan_request_data = {
                'folder_path': source_path,
                'scan_configuration': {
                    'frameworks': ['terraform'],
                    'severity_levels': ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
                }
            }
        
        # Use communication manager for reliable agent communication
        result = self.communication_manager.call_agent_with_retry(
            agent_name='checkov_scanner',
            endpoint_path=endpoint_path,
            request_data=scan_request_data,
            method='POST'
        )
        
        if result.success:
            # Validate scanner response
            self._validate_scanner_response(result.response_data)
            logger.info(f"Checkov scan completed with {result.response_data.get('total_findings', 0)} findings")
            return result.response_data
        else:
            logger.error(f"Checkov Scanner communication failed: {result.error_message}")
            # Raise exception instead of returning empty results
            raise Exception(f"Failed to invoke Checkov Scanner: {result.error_message}")
    
    def _validate_scanner_response(self, scan_results: Dict[str, Any]) -> None:
        """Validate scanner response has required fields and correct structure"""
        required_fields = ['total_findings', 'scan_id']
        
        for field in required_fields:
            if field not in scan_results:
                raise ValueError(f"Invalid scanner response: missing required field '{field}'")
        
        # Validate total_findings is a number
        if not isinstance(scan_results['total_findings'], (int, float)):
            raise ValueError(f"Invalid scanner response: 'total_findings' must be a number, got {type(scan_results['total_findings'])}")
        
        # Validate total_findings is non-negative
        if scan_results['total_findings'] < 0:
            raise ValueError(f"Invalid scanner response: 'total_findings' cannot be negative, got {scan_results['total_findings']}")
        
        logger.debug(f"Scanner response validation passed: {scan_results.get('total_findings')} findings")
    
    def _invoke_remediation_for_local_source(self, scan_results: Dict[str, Any], source_path: str) -> Dict[str, Any]:
        """Invoke Terraform Remediation for local source"""
        logger.info("Invoking Terraform Remediation Agent for local source")
        
        # Extract scan_id from scan results
        scan_id = scan_results.get('scan_id')
        if not scan_id:
            raise ValueError("Scan results missing 'scan_id' field")
        
        # Call remediation agent with scan_id
        remediation_request_data = {
            'scan_id': scan_id,
            'source_path': source_path
        }
        
        # Use communication manager for reliable agent communication
        result = self.communication_manager.call_agent_with_retry(
            agent_name='terraform_remediation',
            endpoint_path='/remediate/scan-id',
            request_data=remediation_request_data,
            method='POST'
        )
        
        if result.success:
            # Validate remediation response
            self._validate_remediation_response(result.response_data)
            # The response contains counts, not lists
            fixes_count = result.response_data.get('fixes_applied', 0)
            manual_count = result.response_data.get('manual_interventions', 0)
            logger.info(f"Remediation completed: {fixes_count} auto-fixes, {manual_count} manual items")
            return result.response_data
        else:
            logger.error(f"Terraform Remediation Agent communication failed: {result.error_message}")
            # Raise exception instead of returning empty results
            raise Exception(f"Failed to invoke Terraform Remediation Agent: {result.error_message}")
    
    def _validate_remediation_response(self, remediation_results: Dict[str, Any]) -> None:
        """Validate remediation response has required fields and correct structure"""
        required_fields = ['fixes_applied', 'manual_interventions']
        
        for field in required_fields:
            if field not in remediation_results:
                raise ValueError(f"Invalid remediation response: missing required field '{field}'")
        
        # Validate fixes_applied is a number
        if not isinstance(remediation_results['fixes_applied'], (int, float)):
            raise ValueError(f"Invalid remediation response: 'fixes_applied' must be a number, got {type(remediation_results['fixes_applied'])}")
        
        # Validate manual_interventions is a number
        if not isinstance(remediation_results['manual_interventions'], (int, float)):
            raise ValueError(f"Invalid remediation response: 'manual_interventions' must be a number, got {type(remediation_results['manual_interventions'])}")
        
        # Validate counts are non-negative
        if remediation_results['fixes_applied'] < 0:
            raise ValueError(f"Invalid remediation response: 'fixes_applied' cannot be negative, got {remediation_results['fixes_applied']}")
        
        if remediation_results['manual_interventions'] < 0:
            raise ValueError(f"Invalid remediation response: 'manual_interventions' cannot be negative, got {remediation_results['manual_interventions']}")
        
        logger.debug(f"Remediation response validation passed: {remediation_results.get('fixes_applied')} fixes, {remediation_results.get('manual_interventions')} manual items")
    
    def generate_audit_trail(self, workflow_progress: WorkflowProgress) -> List[Dict[str, Any]]:
        """Generate detailed audit trail for compliance and tracking"""
        logger.info(f"Generating audit trail for workflow {workflow_progress.workflow_id}")
        
        final_report = self.report_generator.generate_final_report(workflow_progress)
        
        # Add comprehensive logging and audit trail generation
        audit_trail = final_report.audit_trail
        
        # Add communication events from communication manager
        communication_stats = self.communication_manager.get_communication_stats()
        
        audit_trail.append({
            'event_type': 'communication_summary',
            'timestamp': datetime.utcnow().isoformat(),
            'details': {
                'total_agents': communication_stats['total_agents'],
                'healthy_agents': communication_stats['healthy_agents'],
                'health_percentage': communication_stats['health_percentage'],
                'circuit_breaker_events': communication_stats['circuit_breaker_status']
            }
        })
        
        return audit_trail
    
    def get_workflow_status(self, workflow_id: str) -> Dict[str, Any]:
        """Get status of a running or completed workflow"""
        # In a production system, this would query a database or cache
        # For now, return a basic status structure
        return {
            'workflow_id': workflow_id,
            'status': 'running',
            'message': 'Workflow status tracking not implemented in this version'
        }
    
    def health_check(self) -> Dict[str, Any]:
        """Health check for the orchestrator agent and connected services"""
        
        # Use communication manager for comprehensive health checking
        communication_stats = self.communication_manager.get_communication_stats()
        
        health_status = {
            'orchestrator': 'healthy',
            'communication_manager': 'healthy',
            'agent_health_summary': {
                'total_agents': communication_stats['total_agents'],
                'healthy_agents': communication_stats['healthy_agents'],
                'unhealthy_agents': communication_stats['unhealthy_agents'],
                'health_percentage': communication_stats['health_percentage']
            },
            'agent_details': communication_stats['agent_health_details'],
            'circuit_breaker_status': communication_stats['circuit_breaker_status'],
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Determine overall orchestrator health based on agent health
        if communication_stats['unhealthy_agents'] > 0:
            if communication_stats['health_percentage'] < 50:
                health_status['orchestrator'] = 'unhealthy'
            else:
                health_status['orchestrator'] = 'degraded'
        
        return health_status
    
    def get_agent_info(self) -> Dict[str, Any]:
        """Get orchestrator agent information and configuration"""
        return {
            'agent_name': 'orchestrator-agent',
            'version': '1.0.0',
            'max_iterations': self.max_iterations,
            'agentcore_base_url': self.agentcore_base_url,
            'agent_endpoints': self.agent_endpoints,
            'capabilities': [
                'Iterative Security Scanning',
                'Multi-Agent Coordination',
                'Workflow Progress Tracking',
                'Convergence Detection',
                'Final Report Generation',
                'PR Creation Coordination'
            ]
        }

def create_orchestrator_agent(
    agentcore_base_url: Optional[str] = None,
    checkov_scanner_url: Optional[str] = None,
    terraform_remediation_url: Optional[str] = None,
    github_integration_url: Optional[str] = None,
    use_agent: bool = False
) -> OrchestratorAgent:
    """Factory function to create Orchestrator Agent
    
    For local testing, provide direct agent URLs:
        checkov_scanner_url="http://localhost:8000"
        terraform_remediation_url="http://localhost:8001"
        github_integration_url="http://localhost:8002"
        use_agent=False (default, uses direct HTTP calls)
    
    For AgentCore deployment:
        use_agent=True (enables Strands Agent for orchestration)
    """
    return OrchestratorAgent(
        agentcore_base_url=agentcore_base_url,
        checkov_scanner_url=checkov_scanner_url,
        terraform_remediation_url=terraform_remediation_url,
        github_integration_url=github_integration_url,
        use_agent=use_agent
    )

if __name__ == "__main__":
    # Initialize orchestrator for testing
    orchestrator = OrchestratorAgent()
    
    # Print agent info
    agent_info = orchestrator.get_agent_info()
    print("Orchestrator Agent initialized:")
    print(json.dumps(agent_info, indent=2))
    
    # Health check
    health = orchestrator.health_check()
    print(f"\nHealth Status: {health['orchestrator']}")
    
    # Agent will be deployed on AgentCore runtime