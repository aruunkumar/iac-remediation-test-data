"""
Agent Communication Module - HTTP client functions and coordination logic
Handles inter-agent communication with retry logic and error handling
"""

import json
import logging
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger(__name__)

@dataclass
class AgentEndpoint:
    """Configuration for an agent endpoint"""
    name: str
    base_url: str
    health_endpoint: str = "/health"
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0
    retry_backoff: float = 2.0

@dataclass
class CommunicationResult:
    """Result of agent communication"""
    success: bool
    response_data: Optional[Dict[str, Any]]
    status_code: Optional[int]
    error_message: Optional[str]
    retry_count: int
    total_duration: float
    agent_name: str

@dataclass
class AgentHealthStatus:
    """Health status of an agent"""
    agent_name: str
    is_healthy: bool
    response_time: float
    last_check: str
    error_message: Optional[str]
    consecutive_failures: int

class AgentCommunicationManager:
    """Manages HTTP communication between agents with retry logic and error handling"""
    
    def __init__(self, orchestrator_agent, max_concurrent_requests: int = 5):
        self.orchestrator_agent = orchestrator_agent
        self.max_concurrent_requests = max_concurrent_requests
        self.agent_health_cache = {}
        self.health_check_interval = 60  # seconds
        self.circuit_breaker_threshold = 5  # consecutive failures
        self.circuit_breaker_timeout = 300  # seconds
        
        # Initialize agent endpoints
        self.agent_endpoints = {
            'checkov_scanner': AgentEndpoint(
                name='checkov_scanner',
                base_url=orchestrator_agent.agent_endpoints['checkov_scanner'],
                timeout=90,  # 90 seconds for scanning (increased from 60)
                max_retries=3
            ),
            'terraform_remediation': AgentEndpoint(
                name='terraform_remediation', 
                base_url=orchestrator_agent.agent_endpoints['terraform_remediation'],
                timeout=600,  # 600 seconds (10 minutes) for remediation - LLM calls take time
                max_retries=3
            ),
            'github_integration': AgentEndpoint(
                name='github_integration',
                base_url=orchestrator_agent.agent_endpoints['github_integration'],
                timeout=45,  # Moderate timeout for GitHub operations
                max_retries=2
            )
        }
        
        logger.info(f"Agent Communication Manager initialized with {len(self.agent_endpoints)} endpoints")
    
    def call_agent_with_retry(self, agent_name: str, endpoint_path: str, request_data: Dict[str, Any], method: str = 'POST') -> CommunicationResult:
        """Call an agent with retry logic and error handling"""
        
        if agent_name not in self.agent_endpoints:
            return CommunicationResult(
                success=False,
                response_data=None,
                status_code=None,
                error_message=f"Unknown agent: {agent_name}",
                retry_count=0,
                total_duration=0.0,
                agent_name=agent_name
            )
        
        agent_endpoint = self.agent_endpoints[agent_name]
        
        # Check circuit breaker
        if self._is_circuit_breaker_open(agent_name):
            return CommunicationResult(
                success=False,
                response_data=None,
                status_code=None,
                error_message=f"Circuit breaker open for {agent_name}",
                retry_count=0,
                total_duration=0.0,
                agent_name=agent_name
            )
        
        start_time = time.time()
        retry_count = 0
        last_error = None
        
        while retry_count <= agent_endpoint.max_retries:
            try:
                logger.info(f"Calling {agent_name} (attempt {retry_count + 1}/{agent_endpoint.max_retries + 1})")
                
                # Make the HTTP request
                response_data, status_code = self._make_http_request(
                    agent_endpoint,
                    endpoint_path,
                    request_data,
                    method
                )
                
                # Success - reset failure count and return
                self._reset_failure_count(agent_name)
                
                total_duration = time.time() - start_time
                
                return CommunicationResult(
                    success=True,
                    response_data=response_data,
                    status_code=status_code,
                    error_message=None,
                    retry_count=retry_count,
                    total_duration=total_duration,
                    agent_name=agent_name
                )
                
            except Exception as e:
                last_error = str(e)
                retry_count += 1
                
                logger.warning(f"Agent {agent_name} call failed (attempt {retry_count}): {e}")
                
                # Record failure
                self._record_failure(agent_name)
                
                # Wait before retry (with exponential backoff)
                if retry_count <= agent_endpoint.max_retries:
                    delay = agent_endpoint.retry_delay * (agent_endpoint.retry_backoff ** (retry_count - 1))
                    logger.info(f"Retrying {agent_name} in {delay:.1f} seconds...")
                    time.sleep(delay)
        
        # All retries exhausted
        total_duration = time.time() - start_time
        
        return CommunicationResult(
            success=False,
            response_data=None,
            status_code=None,
            error_message=f"All retries exhausted. Last error: {last_error}",
            retry_count=retry_count - 1,
            total_duration=total_duration,
            agent_name=agent_name
        )
    
    def _make_http_request(self, agent_endpoint: AgentEndpoint, endpoint_path: str, request_data: Dict[str, Any], method: str) -> tuple:
        """Make HTTP request directly using requests library"""
        import requests
        import os
        
        url = f"{agent_endpoint.base_url}{endpoint_path}"
        
        # Get auth token from environment or use default for local testing
        auth_token = os.getenv('AGENT_API_TOKEN', 'dev-token-123')
        
        # Special handling for GitHub integration agent - extract GitHub token from request data
        if 'github_integration' in agent_endpoint.base_url or 'github' in endpoint_path.lower():
            # Try to extract GitHub token from repository_data
            if 'repository_data' in request_data:
                repo_data = request_data['repository_data']
                if isinstance(repo_data, dict) and 'github_token' in repo_data:
                    auth_token = repo_data['github_token']
                    logger.info(f"Using GitHub token from repository_data for GitHub integration agent (token length: {len(auth_token) if auth_token else 0})")
                else:
                    logger.warning(f"repository_data exists but no github_token found. Keys: {list(repo_data.keys()) if isinstance(repo_data, dict) else 'not a dict'}")
            else:
                logger.warning("No repository_data in request_data for GitHub integration agent")
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {auth_token}"
        }
        
        try:
            if method.upper() == 'POST':
                response = requests.post(
                    url,
                    json=request_data,
                    headers=headers,
                    timeout=agent_endpoint.timeout
                )
            elif method.upper() == 'GET':
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=agent_endpoint.timeout
                )
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            # Raise exception for HTTP errors
            response.raise_for_status()
            
            # Parse JSON response
            response_data = response.json()
            status_code = response.status_code
            
            # Log response type for debugging
            if not isinstance(response_data, dict):
                logger.warning(f"Agent {url} returned non-dict response: type={type(response_data)}, value={response_data}")
            
            return response_data, status_code
            
        except requests.exceptions.Timeout:
            raise Exception(f"Request to {url} timed out after {agent_endpoint.timeout} seconds")
        except requests.exceptions.ConnectionError as e:
            raise Exception(f"Connection error to {url}: {str(e)}")
        except requests.exceptions.HTTPError as e:
            raise Exception(f"HTTP error from {url}: {response.status_code} - {response.text}")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request failed to {url}: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Invalid JSON response from {url}: {str(e)}")
    
    def _parse_http_response(self, response: Any) -> Dict[str, Any]:
        """Parse HTTP response from agent"""
        try:
            if hasattr(response, 'response'):
                response_data = response.response
                if isinstance(response_data, str):
                    return json.loads(response_data)
                else:
                    return response_data
            elif isinstance(response, str):
                return json.loads(response)
            elif isinstance(response, dict):
                return response
            else:
                return {'raw_response': str(response)}
                
        except (json.JSONDecodeError, AttributeError) as e:
            logger.warning(f"Failed to parse HTTP response: {e}")
            return {'parse_error': str(e), 'raw_response': str(response)}
    
    def _extract_status_code(self, response: Any) -> Optional[int]:
        """Extract HTTP status code from response"""
        try:
            if hasattr(response, 'status_code'):
                return response.status_code
            elif isinstance(response, dict) and 'status_code' in response:
                return response['status_code']
            else:
                # Assume success if no status code available
                return 200
        except Exception:
            return None
    
    def check_agent_health(self, agent_name: str) -> AgentHealthStatus:
        """Check health of a specific agent"""
        
        if agent_name not in self.agent_endpoints:
            return AgentHealthStatus(
                agent_name=agent_name,
                is_healthy=False,
                response_time=0.0,
                last_check=datetime.utcnow().isoformat(),
                error_message="Unknown agent",
                consecutive_failures=0
            )
        
        agent_endpoint = self.agent_endpoints[agent_name]
        start_time = time.time()
        
        try:
            # Make health check request
            health_data, status_code = self._make_http_request(
                agent_endpoint,
                agent_endpoint.health_endpoint,
                {},
                'GET'
            )
            
            response_time = time.time() - start_time
            is_healthy = status_code == 200 and health_data.get('status') != 'unhealthy'
            
            health_status = AgentHealthStatus(
                agent_name=agent_name,
                is_healthy=is_healthy,
                response_time=response_time,
                last_check=datetime.utcnow().isoformat(),
                error_message=None if is_healthy else health_data.get('error', 'Health check failed'),
                consecutive_failures=self._get_failure_count(agent_name) if not is_healthy else 0
            )
            
            # Update health cache
            self.agent_health_cache[agent_name] = health_status
            
            return health_status
            
        except Exception as e:
            response_time = time.time() - start_time
            
            health_status = AgentHealthStatus(
                agent_name=agent_name,
                is_healthy=False,
                response_time=response_time,
                last_check=datetime.utcnow().isoformat(),
                error_message=str(e),
                consecutive_failures=self._get_failure_count(agent_name) + 1
            )
            
            # Update health cache and record failure
            self.agent_health_cache[agent_name] = health_status
            self._record_failure(agent_name)
            
            return health_status
    
    def check_all_agents_health(self) -> Dict[str, AgentHealthStatus]:
        """Check health of all configured agents"""
        health_results = {}
        
        # Use ThreadPoolExecutor for concurrent health checks
        with ThreadPoolExecutor(max_workers=self.max_concurrent_requests) as executor:
            # Submit health check tasks
            future_to_agent = {
                executor.submit(self.check_agent_health, agent_name): agent_name
                for agent_name in self.agent_endpoints.keys()
            }
            
            # Collect results
            for future in as_completed(future_to_agent):
                agent_name = future_to_agent[future]
                try:
                    health_status = future.result(timeout=30)
                    health_results[agent_name] = health_status
                except Exception as e:
                    logger.error(f"Health check failed for {agent_name}: {e}")
                    health_results[agent_name] = AgentHealthStatus(
                        agent_name=agent_name,
                        is_healthy=False,
                        response_time=0.0,
                        last_check=datetime.utcnow().isoformat(),
                        error_message=str(e),
                        consecutive_failures=self._get_failure_count(agent_name) + 1
                    )
        
        return health_results
    
    def coordinate_parallel_agent_calls(self, agent_calls: List[Dict[str, Any]]) -> List[CommunicationResult]:
        """Coordinate multiple agent calls in parallel"""
        
        logger.info(f"Coordinating {len(agent_calls)} parallel agent calls")
        
        results = []
        
        # Use ThreadPoolExecutor for concurrent agent calls
        with ThreadPoolExecutor(max_workers=self.max_concurrent_requests) as executor:
            # Submit agent call tasks
            future_to_call = {}
            for call_config in agent_calls:
                future = executor.submit(
                    self.call_agent_with_retry,
                    call_config['agent_name'],
                    call_config['endpoint_path'],
                    call_config['request_data'],
                    call_config.get('method', 'POST')
                )
                future_to_call[future] = call_config
            
            # Collect results
            for future in as_completed(future_to_call):
                call_config = future_to_call[future]
                try:
                    result = future.result(timeout=120)  # 2 minute timeout for agent calls
                    results.append(result)
                    
                    if result.success:
                        logger.info(f"Parallel call to {result.agent_name} succeeded in {result.total_duration:.2f}s")
                    else:
                        logger.error(f"Parallel call to {result.agent_name} failed: {result.error_message}")
                        
                except Exception as e:
                    logger.error(f"Parallel call to {call_config['agent_name']} raised exception: {e}")
                    results.append(CommunicationResult(
                        success=False,
                        response_data=None,
                        status_code=None,
                        error_message=str(e),
                        retry_count=0,
                        total_duration=0.0,
                        agent_name=call_config['agent_name']
                    ))
        
        return results
    
    def _is_circuit_breaker_open(self, agent_name: str) -> bool:
        """Check if circuit breaker is open for an agent"""
        failure_count = self._get_failure_count(agent_name)
        
        if failure_count < self.circuit_breaker_threshold:
            return False
        
        # Check if timeout period has passed
        last_failure_time = self._get_last_failure_time(agent_name)
        if last_failure_time:
            time_since_failure = datetime.utcnow() - last_failure_time
            if time_since_failure.total_seconds() > self.circuit_breaker_timeout:
                # Reset circuit breaker
                self._reset_failure_count(agent_name)
                return False
        
        return True
    
    def _record_failure(self, agent_name: str) -> None:
        """Record a failure for an agent"""
        if not hasattr(self, '_failure_counts'):
            self._failure_counts = {}
        if not hasattr(self, '_last_failure_times'):
            self._last_failure_times = {}
        
        self._failure_counts[agent_name] = self._failure_counts.get(agent_name, 0) + 1
        self._last_failure_times[agent_name] = datetime.utcnow()
        
        logger.warning(f"Recorded failure for {agent_name} (count: {self._failure_counts[agent_name]})")
    
    def _reset_failure_count(self, agent_name: str) -> None:
        """Reset failure count for an agent"""
        if hasattr(self, '_failure_counts'):
            self._failure_counts[agent_name] = 0
        if hasattr(self, '_last_failure_times'):
            self._last_failure_times.pop(agent_name, None)
    
    def _get_failure_count(self, agent_name: str) -> int:
        """Get current failure count for an agent"""
        if not hasattr(self, '_failure_counts'):
            return 0
        return self._failure_counts.get(agent_name, 0)
    
    def _get_last_failure_time(self, agent_name: str) -> Optional[datetime]:
        """Get last failure time for an agent"""
        if not hasattr(self, '_last_failure_times'):
            return None
        return self._last_failure_times.get(agent_name)
    
    def get_communication_stats(self) -> Dict[str, Any]:
        """Get communication statistics and health summary"""
        
        # Get current health status for all agents
        health_status = self.check_all_agents_health()
        
        # Calculate statistics
        total_agents = len(self.agent_endpoints)
        healthy_agents = sum(1 for status in health_status.values() if status.is_healthy)
        
        stats = {
            'total_agents': total_agents,
            'healthy_agents': healthy_agents,
            'unhealthy_agents': total_agents - healthy_agents,
            'health_percentage': (healthy_agents / total_agents * 100) if total_agents > 0 else 0,
            'agent_health_details': {
                name: {
                    'is_healthy': status.is_healthy,
                    'response_time': status.response_time,
                    'consecutive_failures': status.consecutive_failures,
                    'last_check': status.last_check
                }
                for name, status in health_status.items()
            },
            'circuit_breaker_status': {
                name: self._is_circuit_breaker_open(name)
                for name in self.agent_endpoints.keys()
            },
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return stats

def create_agent_communication_manager(orchestrator_agent) -> AgentCommunicationManager:
    """Factory function to create Agent Communication Manager"""
    return AgentCommunicationManager(orchestrator_agent)