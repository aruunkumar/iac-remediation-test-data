"""
End-to-End Test for Orchestrator Agent
Tests complete workflows: GitHub, Local, and S3

Usage:
    # GitHub workflow
    python test_e2e.py --github

    # Local folder workflow
    python test_e2e.py --local /path/to/terraform

    # S3 bucket workflow
    python test_e2e.py --s3 s3://bucket/path

    # Custom timeout
    python test_e2e.py --local /path/to/terraform --timeout 600
"""

import requests
import time
import json
import argparse
import sys
import os

# Service URLs
ORCHESTRATOR_URL = "http://localhost:8080"
CHECKOV_SCANNER_URL = "http://localhost:8000"
TERRAFORM_REMEDIATION_URL = "http://localhost:8001"
GITHUB_INTEGRATION_URL = "http://localhost:8002"

# GitHub configuration (for GitHub workflow)
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "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")
GITHUB_REPOSITORY_DATA = {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "commit_sha": "HEAD",
    "source_branch": "main",
    "author": "aruunkumar",
    "default_branch": "main",
    "github_token": GITHUB_TOKEN
}

def print_section(title):
    """Print a section header"""
    print("\n" + "="*80)
    print(f"  {title}")
    print("="*80 + "\n")

def check_service_health(service_name, url):
    """Check if a service is healthy"""
    try:
        response = requests.get(f"{url}/health", timeout=5)
        if response.status_code == 200:
            print(f"✅ {service_name} is healthy")
            return True
        else:
            print(f"❌ {service_name} returned status {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ {service_name} is not reachable: {e}")
        return False

def start_github_workflow():
    """Start a GitHub workflow"""
    print(f"\n📤 Starting GitHub workflow for: {GITHUB_REPOSITORY_DATA['owner']}/{GITHUB_REPOSITORY_DATA['repo']}")
    
    request_data = {
        "repository_data": GITHUB_REPOSITORY_DATA,
        "workflow_configuration": {
            "max_iterations": 5,
            "auto_fix_enabled": True,
            "manual_guidance_enabled": True,
            "use_mcp_server": True,
            "use_bedrock_kb": True
        }
    }
    
    try:
        response = requests.post(
            f"{ORCHESTRATOR_URL}/orchestrate",
            json=request_data,
            timeout=60
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Workflow started successfully!")
            print(f"   Workflow ID: {result['workflow_id']}")
            print(f"   Status: {result['status']}")
            return result['workflow_id']
        else:
            print(f"❌ Error starting workflow: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Error starting workflow: {e}")
        return None

def start_local_workflow(folder_path):
    """Start a local folder workflow"""
    print(f"\n📤 Starting local workflow for: {folder_path}")
    
    request_data = {
        "source_type": "local",
        "source_path": folder_path,
        "workflow_configuration": {
            "max_iterations": 5,
            "auto_fix_enabled": True,
            "manual_guidance_enabled": True
        }
    }
    
    try:
        response = requests.post(
            f"{ORCHESTRATOR_URL}/orchestrate/local",
            json=request_data,
            timeout=60
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Workflow started successfully!")
            print(f"   Workflow ID: {result['workflow_id']}")
            print(f"   Status: {result['status']}")
            return result['workflow_id']
        else:
            print(f"❌ Error starting workflow: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Error starting workflow: {e}")
        return None

def start_s3_workflow(s3_uri):
    """Start an S3 bucket workflow"""
    print(f"\n📤 Starting S3 workflow for: {s3_uri}")
    
    request_data = {
        "source_type": "s3",
        "source_path": s3_uri,
        "workflow_configuration": {
            "max_iterations": 5,
            "auto_fix_enabled": True,
            "manual_guidance_enabled": True
        }
    }
    
    try:
        response = requests.post(
            f"{ORCHESTRATOR_URL}/orchestrate/local",
            json=request_data,
            timeout=60
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Workflow started successfully!")
            print(f"   Workflow ID: {result['workflow_id']}")
            print(f"   Status: {result['status']}")
            return result['workflow_id']
        else:
            print(f"❌ Error starting workflow: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Error starting workflow: {e}")
        return None

def poll_workflow_status(workflow_id, max_timeout=600):
    """Poll workflow status until completion or timeout"""
    print(f"\n⏳ Polling workflow status (max {max_timeout}s)...")
    
    start_time = time.time()
    last_status = None
    dots_printed = 0
    
    while time.time() - start_time < max_timeout:
        try:
            response = requests.get(
                f"{ORCHESTRATOR_URL}/workflows/{workflow_id}/status",
                timeout=10
            )
            
            if response.status_code == 200:
                status_data = response.json()
                current_status = status_data.get('workflow_status')
                
                # Print status update if changed
                if current_status != last_status:
                    iteration = status_data.get('current_iteration')
                    fixes = status_data.get('total_fixes_applied', 0)
                    manual = status_data.get('total_manual_interventions', 0)
                    convergence = status_data.get('convergence_achieved', False)
                    
                    print(f"\n📊 Iteration {iteration}:")
                    print(f"   Fixes applied: {fixes}")
                    print(f"   Manual items: {manual}")
                    print(f"   Convergence: {convergence}")
                    
                    last_status = current_status
                    dots_printed = 0
                
                # Check if completed
                if current_status in ['completed', 'failed', 'error']:
                    elapsed = time.time() - start_time
                    print(f"\n✅ Workflow {current_status} in {elapsed:.1f}s")
                    
                    # Get final stats
                    iterations = status_data.get('total_iterations', 0)
                    fixes = status_data.get('total_fixes_applied', 0)
                    manual = status_data.get('total_manual_interventions', 0)
                    pr_created = status_data.get('pr_created', False)
                    pr_url = status_data.get('pr_url')
                    
                    print(f"   Total iterations: {iterations}")
                    print(f"   Total fixes: {fixes}")
                    print(f"   Total manual items: {manual}")
                    print(f"   PR created: {pr_created}")
                    if pr_url:
                        print(f"   PR URL: {pr_url}")
                    
                    return status_data
            
            # Print progress dots
            if dots_printed < 40:
                print(".", end="", flush=True)
                dots_printed += 1
            
            time.sleep(5)
            
        except requests.exceptions.RequestException as e:
            print(f"\n⚠️  Error polling status: {e}")
            time.sleep(5)
    
    print(f"\n⏱️  Timeout reached after {max_timeout}s")
    return None

def get_workflow_report(workflow_id):
    """Get workflow report"""
    print(f"\n📄 Fetching workflow report...")
    
    try:
        response = requests.get(
            f"{ORCHESTRATOR_URL}/workflows/{workflow_id}/report",
            timeout=30
        )
        
        if response.status_code == 200:
            report_data = response.json()
            report = report_data.get('report', {})
            
            print(f"✅ Report generated successfully!")
            
            # Execution Summary
            exec_summary = report.get('execution_summary', {})
            print(f"\n📊 Execution Summary:")
            print(f"   Status: {exec_summary.get('status')}")
            print(f"   Duration: {exec_summary.get('duration_minutes', 0):.1f} minutes")
            print(f"   Iterations: {exec_summary.get('iterations_completed')}")
            print(f"   Fixes applied: {exec_summary.get('total_fixes_applied')}")
            print(f"   Manual items: {exec_summary.get('total_manual_interventions')}")
            
            # PR Information
            pr_info = report.get('pr_information', {})
            if pr_info.get('pr_created'):
                print(f"\n🔗 Pull Request:")
                print(f"   PR Number: #{pr_info.get('pr_number')}")
                print(f"   PR URL: {pr_info.get('pr_url')}")
                print(f"   Branch: {pr_info.get('branch_name')}")
            
            # Security Metrics
            sec_metrics = report.get('security_metrics', {})
            print(f"\n🔒 Security Metrics:")
            print(f"   Total issues: {sec_metrics.get('total_issues')}")
            print(f"   Fix success rate: {sec_metrics.get('fix_success_rate', 0):.1f}%")
            print(f"   Security improvement: {sec_metrics.get('security_improvement_score', 0):.1f}%")
            
            return report_data
            
        else:
            print(f"❌ Error getting report: {response.status_code}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Error fetching report: {e}")
        return None

def main():
    """Main test function"""
    parser = argparse.ArgumentParser(description='End-to-End Test for Orchestrator Agent')
    parser.add_argument('--github', action='store_true', help='Test GitHub workflow')
    parser.add_argument('--local', type=str, help='Test local folder workflow (provide path)')
    parser.add_argument('--s3', type=str, help='Test S3 bucket workflow (provide s3:// URI)')
    parser.add_argument('--timeout', type=int, default=600, help='Max timeout in seconds')
    args = parser.parse_args()
    
    # Validate arguments
    if not (args.github or args.local or args.s3):
        print("❌ Error: Must specify --github, --local, or --s3")
        parser.print_help()
        return False
    
    print_section("Orchestrator Agent E2E Test")
    
    # Determine workflow type
    if args.github:
        workflow_type = "GitHub"
        if not GITHUB_TOKEN:
            print("❌ Error: GITHUB_TOKEN environment variable not set")
            return False
    elif args.local:
        workflow_type = "Local"
        print(f"Source: {args.local}")
    else:
        workflow_type = "S3"
        print(f"Source: {args.s3}")
    
    print(f"Workflow Type: {workflow_type}")
    print(f"Orchestrator URL: {ORCHESTRATOR_URL}")
    print(f"Max Timeout: {args.timeout}s")
    
    # Step 1: Health Checks
    print_section("Step 1: Health Checks")
    
    services_healthy = True
    services_healthy &= check_service_health("Orchestrator", ORCHESTRATOR_URL)
    services_healthy &= check_service_health("Checkov Scanner", CHECKOV_SCANNER_URL)
    services_healthy &= check_service_health("Terraform Remediation", TERRAFORM_REMEDIATION_URL)
    
    if args.github:
        services_healthy &= check_service_health("GitHub Integration", GITHUB_INTEGRATION_URL)
    
    if not services_healthy:
        print("\n❌ Some services are not healthy. Please start all required services.")
        return False
    
    # Step 2: Start Workflow
    print_section(f"Step 2: Start {workflow_type} Workflow")
    
    if args.github:
        workflow_id = start_github_workflow()
    elif args.local:
        workflow_id = start_local_workflow(args.local)
    else:
        workflow_id = start_s3_workflow(args.s3)
    
    if not workflow_id:
        print("\n❌ Failed to start workflow")
        return False
    
    # Step 3: Monitor Progress
    print_section("Step 3: Monitor Workflow Progress")
    
    final_status = poll_workflow_status(workflow_id, args.timeout)
    if not final_status:
        print("\n❌ Workflow did not complete within timeout")
        return False
    
    # Step 4: Get Report
    print_section("Step 4: Retrieve Workflow Report")
    
    report = get_workflow_report(workflow_id)
    if not report:
        print("\n⚠️  Could not retrieve report")
    
    # Summary
    print_section("Test Summary")
    
    print(f"Workflow Type: {workflow_type}")
    print(f"Workflow ID: {workflow_id}")
    
    if final_status.get('workflow_status') == 'completed':
        print("\n✅ End-to-end test PASSED!")
        
        print(f"\n📊 Results:")
        print(f"   Status: {final_status.get('workflow_status')}")
        print(f"   Iterations: {final_status.get('total_iterations')}")
        print(f"   Fixes applied: {final_status.get('total_fixes_applied')}")
        print(f"   Manual items: {final_status.get('total_manual_interventions')}")
        
        if args.github and final_status.get('pr_created'):
            print(f"\n🎉 Pull Request Created!")
            print(f"   View PR: {final_status.get('pr_url')}")
        
        return True
    else:
        print(f"\n❌ Workflow failed with status: {final_status.get('workflow_status')}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
