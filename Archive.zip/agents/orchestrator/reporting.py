"""
Reporting Module - Final report generation and GitHub PR coordination
Consolidates iteration results and creates comprehensive audit trails
"""

import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import uuid

logger = logging.getLogger(__name__)

@dataclass
class SecurityMetrics:
    """Security metrics for the workflow"""
    total_issues_found: int
    critical_issues: int
    high_issues: int
    medium_issues: int
    low_issues: int
    auto_fixes_applied: int
    manual_interventions_required: int
    fix_success_rate: float
    security_improvement_score: float

@dataclass
class IterationSummary:
    """Summary of a single iteration"""
    iteration_number: int
    issues_found: int
    fixes_applied: int
    manual_items: int
    duration: float
    convergence_score: float
    key_improvements: List[str]

@dataclass
class WorkflowReport:
    """Comprehensive workflow report"""
    workflow_id: str
    repository_info: Dict[str, Any]
    execution_summary: Dict[str, Any]
    security_metrics: SecurityMetrics
    iteration_summaries: List[IterationSummary]
    final_status: str
    recommendations: List[str]
    audit_trail: List[Dict[str, Any]]
    generated_at: str

class ReportGenerator:
    """Generates comprehensive reports for security workflows"""
    
    def __init__(self, orchestrator_agent):
        self.orchestrator_agent = orchestrator_agent
        
    def generate_final_report(self, workflow_progress) -> WorkflowReport:
        """Generate comprehensive final report consolidating all iteration results"""
        logger.info(f"Generating final report for workflow {workflow_progress.workflow_id}")
        
        # Calculate security metrics
        security_metrics = self._calculate_security_metrics(workflow_progress)
        
        # Create iteration summaries
        iteration_summaries = self._create_iteration_summaries(workflow_progress)
        
        # Generate execution summary
        execution_summary = self._create_execution_summary(workflow_progress)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(workflow_progress, security_metrics)
        
        # Create audit trail
        audit_trail = self._create_audit_trail(workflow_progress)
        
        # Assemble final report
        final_report = WorkflowReport(
            workflow_id=workflow_progress.workflow_id,
            repository_info=self._extract_repository_info(workflow_progress.repository_data),
            execution_summary=execution_summary,
            security_metrics=security_metrics,
            iteration_summaries=iteration_summaries,
            final_status=workflow_progress.workflow_status,
            recommendations=recommendations,
            audit_trail=audit_trail,
            generated_at=datetime.utcnow().isoformat()
        )
        
        logger.info(f"Final report generated with {len(iteration_summaries)} iterations and {security_metrics.total_issues_found} total issues")
        
        return final_report
    
    def _calculate_security_metrics(self, workflow_progress) -> SecurityMetrics:
        """Calculate comprehensive security metrics"""
        
        # Aggregate findings from all iterations
        all_findings = []
        for iteration in workflow_progress.iterations:
            # Defensive check: ensure scan_results is a dict
            scan_results = iteration.scan_results if isinstance(iteration.scan_results, dict) else {}
            findings = scan_results.get('findings', [])
            # Defensive check: ensure findings is a list
            if isinstance(findings, list):
                all_findings.extend(findings)
        
        # Count by severity
        severity_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        for finding in all_findings:
            severity = finding.get('severity', 'LOW').upper()
            if severity in severity_counts:
                severity_counts[severity] += 1
        
        # Calculate security improvement score first (need initial_issues)
        if workflow_progress.iterations:
            first_scan = workflow_progress.iterations[0].scan_results if isinstance(workflow_progress.iterations[0].scan_results, dict) else {}
            initial_issues = first_scan.get('total_findings', 0)
        else:
            initial_issues = 0
        
        if workflow_progress.final_scan_results and isinstance(workflow_progress.final_scan_results, dict):
            final_issues = workflow_progress.final_scan_results.get('total_findings', 0)
        else:
            final_issues = initial_issues
        
        # Calculate fix success rate
        # Use total issues found as denominator since we don't reliably track which are auto-fixable
        total_issues = len(all_findings) if all_findings else initial_issues
        if total_issues > 0:
            fix_success_rate = (workflow_progress.total_fixes_applied / total_issues) * 100
        else:
            fix_success_rate = 0.0
        
        if initial_issues > 0:
            security_improvement_score = ((initial_issues - final_issues) / initial_issues) * 100
        else:
            security_improvement_score = 100.0 if final_issues == 0 else 0.0
        
        return SecurityMetrics(
            total_issues_found=len(all_findings),
            critical_issues=severity_counts['CRITICAL'],
            high_issues=severity_counts['HIGH'],
            medium_issues=severity_counts['MEDIUM'],
            low_issues=severity_counts['LOW'],
            auto_fixes_applied=workflow_progress.total_fixes_applied,
            manual_interventions_required=workflow_progress.total_manual_items,
            fix_success_rate=fix_success_rate,
            security_improvement_score=security_improvement_score
        )
    
    def _create_iteration_summaries(self, workflow_progress) -> List[IterationSummary]:
        """Create summaries for each iteration"""
        summaries = []
        
        for iteration in workflow_progress.iterations:
            # Extract key improvements from this iteration
            key_improvements = []
            
            # Add fixes as improvements
            # Defensive check: ensure remediation_results is a dict
            remediation_results = iteration.remediation_results if isinstance(iteration.remediation_results, dict) else {}
            for fix in remediation_results.get('fixes', []):
                improvement = f"Fixed {fix.get('check_id', 'security issue')} in {fix.get('file', 'unknown file')}"
                key_improvements.append(improvement)
            
            # Limit to top 5 improvements for readability
            key_improvements = key_improvements[:5]
            
            # Get convergence score if available
            convergence_score = 0.0
            if hasattr(iteration, 'convergence_metrics') and isinstance(iteration.convergence_metrics, dict):
                convergence_score = iteration.convergence_metrics.get('convergence_score', 0.0)
            
            summary = IterationSummary(
                iteration_number=iteration.iteration_number,
                issues_found=iteration.scan_results.get('total_findings', 0),
                fixes_applied=iteration.fixes_applied,
                manual_items=iteration.manual_items_added,
                duration=iteration.iteration_duration,
                convergence_score=convergence_score,
                key_improvements=key_improvements
            )
            
            summaries.append(summary)
        
        return summaries
    
    def _create_execution_summary(self, workflow_progress) -> Dict[str, Any]:
        """Create high-level execution summary"""
        
        start_time = datetime.fromisoformat(workflow_progress.start_time.replace('Z', '+00:00'))
        end_time = datetime.fromisoformat(workflow_progress.end_time.replace('Z', '+00:00')) if workflow_progress.end_time else datetime.utcnow()
        
        total_duration = (end_time - start_time).total_seconds()
        
        return {
            'workflow_id': workflow_progress.workflow_id,
            'status': workflow_progress.workflow_status,
            'total_iterations': workflow_progress.total_iterations,
            'max_iterations': workflow_progress.max_iterations,
            'total_duration_seconds': total_duration,
            'total_duration_formatted': self._format_duration(total_duration),
            'start_time': workflow_progress.start_time,
            'end_time': workflow_progress.end_time,
            'pr_created': workflow_progress.pr_created,
            'convergence_achieved': any(iteration.convergence_achieved for iteration in workflow_progress.iterations),
            'total_fixes_applied': workflow_progress.total_fixes_applied,
            'total_manual_items': workflow_progress.total_manual_items
        }
    
    def _generate_recommendations(self, workflow_progress, security_metrics: SecurityMetrics) -> List[str]:
        """Generate actionable recommendations based on workflow results"""
        recommendations = []
        
        # Security improvement recommendations
        if security_metrics.security_improvement_score < 50:
            recommendations.append("Consider reviewing manual intervention items to improve security posture")
        
        if security_metrics.critical_issues > 0:
            recommendations.append(f"Address {security_metrics.critical_issues} critical security issues immediately")
        
        if security_metrics.fix_success_rate < 70:
            recommendations.append("Review auto-fix capabilities - consider expanding automated remediation patterns")
        
        # Workflow efficiency recommendations
        if workflow_progress.total_iterations >= workflow_progress.max_iterations:
            recommendations.append("Workflow reached maximum iterations - consider increasing iteration limit or improving convergence detection")
        
        if workflow_progress.total_manual_items > workflow_progress.total_fixes_applied:
            recommendations.append("High ratio of manual interventions - consider enhancing automated remediation capabilities")
        
        # Process improvement recommendations
        if not workflow_progress.pr_created:
            recommendations.append("PR creation failed - review GitHub integration and permissions")
        
        # Add positive reinforcement
        if security_metrics.security_improvement_score >= 80:
            recommendations.append("Excellent security improvement achieved - maintain current security practices")
        
        if len(recommendations) == 0:
            recommendations.append("Workflow completed successfully with good security improvements")
        
        return recommendations
    
    def _create_audit_trail(self, workflow_progress) -> List[Dict[str, Any]]:
        """Create detailed audit trail of all workflow actions"""
        audit_events = []
        
        # Workflow start event
        audit_events.append({
            'event_type': 'workflow_started',
            'timestamp': workflow_progress.start_time,
            'details': {
                'workflow_id': workflow_progress.workflow_id,
                'repository': workflow_progress.repository_data.get('url', 'unknown'),
                'max_iterations': workflow_progress.max_iterations
            }
        })
        
        # Iteration events
        for iteration in workflow_progress.iterations:
            # Scan event
            audit_events.append({
                'event_type': 'security_scan_completed',
                'timestamp': iteration.timestamp,
                'details': {
                    'iteration': iteration.iteration_number,
                    'findings': iteration.scan_results.get('total_findings', 0),
                    'scan_duration': iteration.scan_results.get('scan_metadata', {}).get('scan_duration', 0)
                }
            })
            
            # Remediation event
            if iteration.fixes_applied > 0 or iteration.manual_items_added > 0:
                audit_events.append({
                    'event_type': 'remediation_completed',
                    'timestamp': iteration.timestamp,
                    'details': {
                        'iteration': iteration.iteration_number,
                        'auto_fixes': iteration.fixes_applied,
                        'manual_items': iteration.manual_items_added,
                        'convergence_achieved': iteration.convergence_achieved
                    }
                })
        
        # Workflow completion event
        if workflow_progress.end_time:
            audit_events.append({
                'event_type': 'workflow_completed',
                'timestamp': workflow_progress.end_time,
                'details': {
                    'workflow_id': workflow_progress.workflow_id,
                    'final_status': workflow_progress.workflow_status,
                    'total_iterations': workflow_progress.total_iterations,
                    'pr_created': workflow_progress.pr_created
                }
            })
        
        return audit_events
    
    def _extract_repository_info(self, repository_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract relevant repository information for the report"""
        return {
            'url': repository_data.get('url', 'unknown'),
            'owner': repository_data.get('owner', 'unknown'),
            'repo': repository_data.get('repo', 'unknown'),
            'branch': repository_data.get('default_branch', 'main'),
            'commit_sha': repository_data.get('commit_sha', 'unknown')
        }
    
    def _format_duration(self, seconds: float) -> str:
        """Format duration in human-readable format"""
        if seconds < 60:
            return f"{seconds:.1f} seconds"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f} minutes"
        else:
            hours = seconds / 3600
            return f"{hours:.1f} hours"

class GitHubPRCoordinator:
    """Coordinates GitHub PR creation with comprehensive reporting"""
    
    def __init__(self, orchestrator_agent):
        self.orchestrator_agent = orchestrator_agent
        self.report_generator = ReportGenerator(orchestrator_agent)
    
    def create_comprehensive_pr(self, workflow_progress) -> Dict[str, Any]:
        """Create GitHub PR with comprehensive reporting and coordination"""
        logger.info(f"Creating comprehensive PR for workflow {workflow_progress.workflow_id}")
        
        # Check if there are any fixes or manual interventions across all iterations
        total_fixes = workflow_progress.total_fixes_applied
        total_manual = workflow_progress.total_manual_items
        
        if total_fixes == 0 and total_manual == 0:
            logger.info("No fixes or manual interventions to commit - skipping PR creation")
            return {
                'success': False,
                'error': 'No changes to commit',
                'pr_created': False
            }
        
        # Generate final report
        final_report = self.report_generator.generate_final_report(workflow_progress)
        
        # Prepare enhanced PR data with report
        enhanced_pr_data = self._prepare_enhanced_pr_data(workflow_progress, final_report)
        
        # Use communication manager for reliable PR creation
        result = self.orchestrator_agent.communication_manager.call_agent_with_retry(
            agent_name='github_integration',
            endpoint_path='/api/v1/github/commit-and-create-pr',
            request_data=enhanced_pr_data,
            method='POST'
        )
        
        if result.success:
            # Add report metadata to PR result
            pr_result = result.response_data
            pr_result['final_report'] = asdict(final_report)
            pr_result['report_summary'] = self._create_report_summary(final_report)
            
            logger.info(f"Comprehensive PR created successfully: {pr_result.get('pr_url')}")
            return pr_result
        else:
            logger.error(f"Failed to create comprehensive PR: {result.error_message}")
            return {
                'success': False,
                'error': result.error_message,
                'final_report': asdict(final_report)
            }
    
    def _prepare_enhanced_pr_data(self, workflow_progress, final_report: WorkflowReport) -> Dict[str, Any]:
        """Prepare enhanced PR data with comprehensive reporting"""
        
        # Consolidate all fixes and manual interventions
        all_fixes = []
        all_manual_interventions = []
        
        for iteration in workflow_progress.iterations:
            remediation_results = iteration.remediation_results
            all_fixes.extend(remediation_results.get('fixes', []))
            all_manual_interventions.extend(remediation_results.get('manual_interventions', []))
        
        # Create enhanced remediation results with report data
        enhanced_remediation_results = {
            'workflow_id': workflow_progress.workflow_id,
            'total_iterations': workflow_progress.total_iterations,
            'fixes': all_fixes,
            'manual_interventions': all_manual_interventions,
            'final_report': asdict(final_report),
            'scan_metadata': {
                'total_findings': final_report.security_metrics.total_issues_found,
                'scan_date': workflow_progress.start_time,
                'scan_id': workflow_progress.workflow_id,
                'workflow_status': workflow_progress.workflow_status,
                'security_improvement_score': final_report.security_metrics.security_improvement_score,
                'fix_success_rate': final_report.security_metrics.fix_success_rate
            },
            'iteration_summaries': [asdict(summary) for summary in final_report.iteration_summaries],
            'recommendations': final_report.recommendations
        }
        
        return {
            'repository_data': workflow_progress.repository_data,
            'remediation_results': enhanced_remediation_results,
            'pr_configuration': {
                'include_detailed_report': True,
                'include_iteration_breakdown': True,
                'include_security_metrics': True,
                'include_recommendations': True
            }
        }
    
    def _create_report_summary(self, final_report: WorkflowReport) -> Dict[str, Any]:
        """Create a concise summary of the final report"""
        return {
            'workflow_id': final_report.workflow_id,
            'total_issues': final_report.security_metrics.total_issues_found,
            'fixes_applied': final_report.security_metrics.auto_fixes_applied,
            'manual_items': final_report.security_metrics.manual_interventions_required,
            'security_improvement': f"{final_report.security_metrics.security_improvement_score:.1f}%",
            'fix_success_rate': f"{final_report.security_metrics.fix_success_rate:.1f}%",
            'iterations_completed': len(final_report.iteration_summaries),
            'final_status': final_report.final_status,
            'key_recommendations': final_report.recommendations[:3]  # Top 3 recommendations
        }
    
    def generate_report_artifacts(self, final_report: WorkflowReport) -> Dict[str, str]:
        """Generate report artifacts in different formats"""
        
        # JSON report
        json_report = json.dumps(asdict(final_report), indent=2)
        
        # Markdown summary
        markdown_summary = self._generate_markdown_summary(final_report)
        
        # CSV metrics (for spreadsheet analysis)
        csv_metrics = self._generate_csv_metrics(final_report)
        
        return {
            'json_report': json_report,
            'markdown_summary': markdown_summary,
            'csv_metrics': csv_metrics
        }
    
    def _generate_markdown_summary(self, final_report: WorkflowReport) -> str:
        """Generate markdown summary of the report"""
        
        markdown = f"""# Security Workflow Report

## Summary
- **Workflow ID**: {final_report.workflow_id}
- **Repository**: {final_report.repository_info['url']}
- **Status**: {final_report.final_status}
- **Generated**: {final_report.generated_at}

## Security Metrics
- **Total Issues Found**: {final_report.security_metrics.total_issues_found}
- **Auto-Fixes Applied**: {final_report.security_metrics.auto_fixes_applied}
- **Manual Interventions**: {final_report.security_metrics.manual_interventions_required}
- **Security Improvement**: {final_report.security_metrics.security_improvement_score:.1f}%
- **Fix Success Rate**: {final_report.security_metrics.fix_success_rate:.1f}%

## Severity Breakdown
- **Critical**: {final_report.security_metrics.critical_issues}
- **High**: {final_report.security_metrics.high_issues}
- **Medium**: {final_report.security_metrics.medium_issues}
- **Low**: {final_report.security_metrics.low_issues}

## Iterations
"""
        
        for summary in final_report.iteration_summaries:
            markdown += f"""
### Iteration {summary.iteration_number}
- **Issues Found**: {summary.issues_found}
- **Fixes Applied**: {summary.fixes_applied}
- **Duration**: {summary.duration:.1f}s
- **Key Improvements**: {', '.join(summary.key_improvements[:3])}
"""
        
        markdown += f"""
## Recommendations
"""
        for i, rec in enumerate(final_report.recommendations, 1):
            markdown += f"{i}. {rec}\n"
        
        return markdown
    
    def _generate_csv_metrics(self, final_report: WorkflowReport) -> str:
        """Generate CSV format metrics for analysis"""
        
        csv_lines = [
            "Metric,Value",
            f"Workflow ID,{final_report.workflow_id}",
            f"Total Issues,{final_report.security_metrics.total_issues_found}",
            f"Critical Issues,{final_report.security_metrics.critical_issues}",
            f"High Issues,{final_report.security_metrics.high_issues}",
            f"Medium Issues,{final_report.security_metrics.medium_issues}",
            f"Low Issues,{final_report.security_metrics.low_issues}",
            f"Auto Fixes,{final_report.security_metrics.auto_fixes_applied}",
            f"Manual Items,{final_report.security_metrics.manual_interventions_required}",
            f"Security Improvement %,{final_report.security_metrics.security_improvement_score:.1f}",
            f"Fix Success Rate %,{final_report.security_metrics.fix_success_rate:.1f}",
            f"Total Iterations,{len(final_report.iteration_summaries)}",
            f"Final Status,{final_report.final_status}"
        ]
        
        return "\n".join(csv_lines)

def create_report_generator(orchestrator_agent) -> ReportGenerator:
    """Factory function to create Report Generator"""
    return ReportGenerator(orchestrator_agent)

def create_github_pr_coordinator(orchestrator_agent) -> GitHubPRCoordinator:
    """Factory function to create GitHub PR Coordinator"""
    return GitHubPRCoordinator(orchestrator_agent)