"""
Orchestrator Agent API - HTTP endpoint wrapper for AgentCore deployment
Provides REST API endpoints for orchestrating security workflows
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
import json
import logging
import os
import uuid
from datetime import datetime
import asyncio
from contextlib import asynccontextmanager

# Import the orchestrator agent
try:
    from .main import OrchestratorAgent, create_orchestrator_agent, WorkflowProgress
except ImportError:
    from main import OrchestratorAgent, create_orchestrator_agent, WorkflowProgress

logger = logging.getLogger(__name__)

# Pydantic models for request/response validation
class RepositoryData(BaseModel):
    """Repository data for security scanning"""
    url: str = Field(..., description="Repository URL")
    owner: str = Field(..., description="Repository owner")
    repo: str = Field(..., description="Repository name")
    commit_sha: Optional[str] = Field(None, description="Specific commit SHA")
    default_branch: str = Field("main", description="Default branch")
    files: Optional[Dict[str, str]] = Field(None, description="Terraform files content")
    github_token: Optional[str] = Field(None, description="GitHub personal access token for API operations")
    source_branch: Optional[str] = Field("main", description="Source branch that triggered the workflow")
    author: Optional[str] = Field(None, description="Original commit author")

class WorkflowConfiguration(BaseModel):
    """Configuration for security workflow"""
    max_iterations: int = Field(5, description="Maximum iterations", ge=1, le=10)
    auto_fix_enabled: bool = Field(True, description="Enable automatic fixes")
    manual_guidance_enabled: bool = Field(True, description="Enable manual guidance generation")
    use_mcp_server: bool = Field(True, description="Use MCP Terraform server capabilities")
    use_bedrock_kb: bool = Field(True, description="Use Bedrock Knowledge Bases")
    create_pr: bool = Field(True, description="Create GitHub pull request")

class SecurityWorkflowRequest(BaseModel):
    """Request to start security workflow"""
    repository_data: RepositoryData
    workflow_configuration: Optional[WorkflowConfiguration] = Field(default_factory=WorkflowConfiguration)
    webhook_data: Optional[Dict[str, Any]] = Field(None, description="GitHub webhook data")

class LocalWorkflowRequest(BaseModel):
    """Request to start local/S3 workflow (scan-only, no PR)"""
    source_type: str = Field(..., description="Source type: 'local' or 's3'")
    source_path: str = Field(..., description="Path to Terraform files: '/path/to/terraform' or 's3://bucket/path'")
    workflow_configuration: Optional[WorkflowConfiguration] = Field(default_factory=WorkflowConfiguration)

class WorkflowStatusResponse(BaseModel):
    """Response for workflow status"""
    workflow_id: str
    status: str
    progress: Dict[str, Any]
    current_iteration: Optional[int] = None
    total_iterations: Optional[int] = None
    start_time: str
    end_time: Optional[str] = None
    pr_created: bool = False
    working_directory: Optional[str] = None
    error_message: Optional[str] = None

class WorkflowReportResponse(BaseModel):
    """Response for workflow report"""
    workflow_id: str
    report: Dict[str, Any]
    artifacts: Dict[str, str]
    generated_at: str

class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: str
    orchestrator: str
    agent_health: Dict[str, Any]
    communication_stats: Dict[str, Any]
    timestamp: str

# Global orchestrator instance
orchestrator_agent: Optional[OrchestratorAgent] = None
active_workflows: Dict[str, WorkflowProgress] = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    global orchestrator_agent
    
    # Startup
    logger.info("Starting Orchestrator Agent API")
    # Create orchestrator with local agent URLs for testing
    # In production, these would be AgentCore URLs
    orchestrator_agent = create_orchestrator_agent(
        checkov_scanner_url=os.getenv('CHECKOV_SCANNER_URL', 'http://localhost:8000'),
        terraform_remediation_url=os.getenv('TERRAFORM_REMEDIATION_URL', 'http://localhost:8001'),
        github_integration_url=os.getenv('GITHUB_INTEGRATION_URL', 'http://localhost:8002')
    )
    logger.info("Orchestrator Agent initialized")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Orchestrator Agent API")

# Create FastAPI application
app = FastAPI(
    title="Terraform Security Platform - Orchestrator Agent",
    description="Orchestrates multi-agent security scanning and remediation workflows",
    version="1.0.0",
    lifespan=lifespan
)

def get_orchestrator() -> OrchestratorAgent:
    """Dependency to get orchestrator agent instance"""
    if orchestrator_agent is None:
        raise HTTPException(status_code=503, detail="Orchestrator agent not initialized")
    return orchestrator_agent

@app.post("/orchestrate", response_model=Dict[str, Any])
async def start_security_workflow(
    request: SecurityWorkflowRequest,
    background_tasks: BackgroundTasks,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Start a new security workflow for the given repository
    """
    try:
        logger.info(f"Starting security workflow for repository: {request.repository_data.url}")
        
        # Validate repository data
        if not request.repository_data.url or not request.repository_data.owner or not request.repository_data.repo:
            raise HTTPException(
                status_code=400,
                detail="Repository URL, owner, and repo name are required"
            )
        
        # Convert Pydantic models to dictionaries
        repository_data = request.repository_data.dict()
        workflow_config = request.workflow_configuration.dict()
        
        # Update orchestrator configuration
        orchestrator.max_iterations = workflow_config['max_iterations']
        
        # Start workflow in background
        workflow_id = str(uuid.uuid4())
        
        # Add to active workflows tracking
        background_tasks.add_task(
            execute_workflow_background,
            orchestrator,
            workflow_id,
            repository_data,
            workflow_config
        )
        
        return {
            "workflow_id": workflow_id,
            "status": "started",
            "message": "Security workflow initiated",
            "repository": {
                "url": request.repository_data.url,
                "owner": request.repository_data.owner,
                "repo": request.repository_data.repo
            },
            "configuration": workflow_config,
            "started_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error starting security workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start workflow: {str(e)}")

async def execute_workflow_background(
    orchestrator: OrchestratorAgent,
    workflow_id: str,
    repository_data: Dict[str, Any],
    workflow_config: Dict[str, Any]
) -> None:
    """Execute workflow in background task"""
    try:
        logger.info(f"Executing workflow {workflow_id} in background")
        
        # Add workflow ID to repository data
        repository_data['workflow_id'] = workflow_id
        
        # Execute the workflow with the provided workflow_id
        workflow_progress = orchestrator.orchestrate_security_workflow(repository_data, workflow_id=workflow_id)
        
        # Store in active workflows
        active_workflows[workflow_id] = workflow_progress
        
        logger.info(f"Workflow {workflow_id} completed with status: {workflow_progress.workflow_status}")
        
    except Exception as e:
        import traceback
        logger.error(f"Background workflow {workflow_id} failed: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        # Create error workflow progress
        error_progress = WorkflowProgress(
            workflow_id=workflow_id,
            repository_data=repository_data,
            total_iterations=0,
            max_iterations=workflow_config['max_iterations'],
            iterations=[],
            final_scan_results=None,
            pr_created=False,
            workflow_status='failed',
            start_time=datetime.utcnow().isoformat(),
            end_time=datetime.utcnow().isoformat(),
            total_fixes_applied=0,
            total_manual_items=0
        )
        active_workflows[workflow_id] = error_progress

@app.get("/workflows/{workflow_id}/status", response_model=WorkflowStatusResponse)
async def get_workflow_status(
    workflow_id: str,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> WorkflowStatusResponse:
    """
    Get status of a specific workflow
    """
    try:
        # Check active workflows first
        if workflow_id in active_workflows:
            workflow_progress = active_workflows[workflow_id]
            
            current_iteration = len(workflow_progress.iterations)
            
            progress_info = {
                "total_fixes_applied": workflow_progress.total_fixes_applied,
                "total_manual_items": workflow_progress.total_manual_items,
                "iterations_completed": current_iteration,
                "convergence_achieved": any(iter.convergence_achieved for iter in workflow_progress.iterations) if workflow_progress.iterations else False
            }
            
            return WorkflowStatusResponse(
                workflow_id=workflow_id,
                status=workflow_progress.workflow_status,
                progress=progress_info,
                current_iteration=current_iteration,
                total_iterations=workflow_progress.max_iterations,
                start_time=workflow_progress.start_time,
                end_time=workflow_progress.end_time,
                pr_created=workflow_progress.pr_created,
                working_directory=workflow_progress.working_directory
            )
        else:
            # Try to get status from orchestrator (for persistent storage)
            status_info = orchestrator.get_workflow_status(workflow_id)
            
            return WorkflowStatusResponse(
                workflow_id=workflow_id,
                status=status_info.get('status', 'unknown'),
                progress=status_info,
                start_time=datetime.utcnow().isoformat(),
                error_message=status_info.get('message')
            )
            
    except Exception as e:
        logger.error(f"Error getting workflow status for {workflow_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get workflow status: {str(e)}")

@app.get("/workflows/{workflow_id}/report", response_model=WorkflowReportResponse)
async def get_workflow_report(
    workflow_id: str,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> WorkflowReportResponse:
    """
    Get comprehensive report for a completed workflow
    """
    try:
        if workflow_id not in active_workflows:
            raise HTTPException(status_code=404, detail=f"Workflow {workflow_id} not found")
        
        workflow_progress = active_workflows[workflow_id]
        
        if workflow_progress.workflow_status not in ['completed', 'failed', 'max_iterations_reached']:
            raise HTTPException(status_code=400, detail=f"Workflow {workflow_id} is still running")
        
        # Generate comprehensive report
        report_data = orchestrator.generate_workflow_report(workflow_progress)
        
        return WorkflowReportResponse(
            workflow_id=workflow_id,
            report=report_data['report'],
            artifacts=report_data['artifacts'],
            generated_at=datetime.utcnow().isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating workflow report for {workflow_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate report: {str(e)}")

@app.get("/workflows/{workflow_id}/audit-trail")
async def get_workflow_audit_trail(
    workflow_id: str,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Get detailed audit trail for a workflow
    """
    try:
        if workflow_id not in active_workflows:
            raise HTTPException(status_code=404, detail=f"Workflow {workflow_id} not found")
        
        workflow_progress = active_workflows[workflow_id]
        
        # Generate audit trail
        audit_trail = orchestrator.generate_audit_trail(workflow_progress)
        
        return {
            "workflow_id": workflow_id,
            "audit_trail": audit_trail,
            "total_events": len(audit_trail),
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating audit trail for {workflow_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate audit trail: {str(e)}")

@app.get("/workflows")
async def list_workflows(
    status: Optional[str] = None,
    limit: int = 50
) -> Dict[str, Any]:
    """
    List all workflows with optional status filtering
    """
    try:
        workflows = []
        
        for workflow_id, workflow_progress in active_workflows.items():
            if status is None or workflow_progress.workflow_status == status:
                workflows.append({
                    "workflow_id": workflow_id,
                    "status": workflow_progress.workflow_status,
                    "repository": workflow_progress.repository_data.get('url', 'unknown'),
                    "start_time": workflow_progress.start_time,
                    "end_time": workflow_progress.end_time,
                    "total_fixes": workflow_progress.total_fixes_applied,
                    "pr_created": workflow_progress.pr_created
                })
        
        # Sort by start time (most recent first)
        workflows.sort(key=lambda x: x['start_time'], reverse=True)
        
        # Apply limit
        workflows = workflows[:limit]
        
        return {
            "workflows": workflows,
            "total_count": len(workflows),
            "filtered_by_status": status,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error listing workflows: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list workflows: {str(e)}")

@app.post("/webhook/github")
async def handle_github_webhook(
    webhook_data: Dict[str, Any],
    background_tasks: BackgroundTasks,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Handle GitHub webhook events to trigger security workflows
    
    Flow:
    1. Developer commits to ANY branch on GitHub
    2. GitHub Action triggers and sends webhook
    3. This endpoint receives webhook with repo and branch details
    4. Orchestrator workflow is triggered (if Terraform files changed)
    """
    try:
        # GitHub webhook structure
        repository = webhook_data.get('repository', {})
        ref = webhook_data.get('ref', '')  # e.g., "refs/heads/feature-branch"
        commits = webhook_data.get('commits', [])
        
        # Extract branch name from ref
        source_branch = ref.replace('refs/heads/', '') if ref.startswith('refs/heads/') else 'main'
        
        logger.info(f"Received GitHub webhook for {repository.get('full_name', 'unknown')} on branch {source_branch}")
        
        # Check if this push contains Terraform file changes
        if not _has_terraform_changes(webhook_data):
            return {
                "status": "ignored",
                "reason": "No Terraform file changes detected",
                "repository": repository.get('full_name', 'unknown'),
                "branch": source_branch
            }
        
        # Extract repository data from webhook
        repository_data = RepositoryData(
            url=repository.get('clone_url', ''),
            owner=repository.get('owner', {}).get('login', ''),
            repo=repository.get('name', ''),
            commit_sha=webhook_data.get('after', ''),
            default_branch=repository.get('default_branch', 'main'),
            files={
                'source_branch': source_branch,  # The branch that was pushed to
                'commits': commits
            }
        )
        
        # Add source_branch to repository_data for proper branch handling
        repo_dict = repository_data.dict()
        repo_dict['source_branch'] = source_branch
        
        logger.info(f"Terraform changes detected on branch {source_branch}, starting security workflow")
        
        # Start security workflow
        workflow_request = SecurityWorkflowRequest(
            repository_data=RepositoryData(**repo_dict),
            webhook_data=webhook_data
        )
        
        return await start_security_workflow(workflow_request, background_tasks, orchestrator)
            
    except Exception as e:
        logger.error(f"Error handling GitHub webhook: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to handle webhook: {str(e)}")

@app.post("/orchestrate/local")
async def start_local_workflow(
    request: LocalWorkflowRequest,
    background_tasks: BackgroundTasks,
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Start a local/S3 workflow (scan and remediate without GitHub integration)
    
    This endpoint supports:
    - Local filesystem paths: /absolute/path/to/terraform
    - S3 bucket paths: s3://bucket-name/path/to/terraform
    
    No PR is created - returns modified files and report only.
    """
    try:
        logger.info(f"Starting local workflow for {request.source_type} source: {request.source_path}")
        
        # Validate source type
        if request.source_type not in ['local', 's3']:
            raise HTTPException(
                status_code=400,
                detail="source_type must be 'local' or 's3'"
            )
        
        # Validate source path
        if request.source_type == 's3' and not request.source_path.startswith('s3://'):
            raise HTTPException(
                status_code=400,
                detail="S3 source_path must start with 's3://'"
            )
        
        # Convert to dictionary
        workflow_config = request.workflow_configuration.dict()
        
        # Update orchestrator configuration
        orchestrator.max_iterations = workflow_config['max_iterations']
        
        # Create workflow ID
        workflow_id = str(uuid.uuid4())
        
        # Prepare local workflow data
        local_workflow_data = {
            'source_type': request.source_type,
            'source_path': request.source_path,
            'workflow_id': workflow_id
        }
        
        # Start workflow in background using asyncio (not BackgroundTasks)
        # This ensures the response is sent immediately
        import asyncio
        asyncio.create_task(
            execute_local_workflow_background_async(
                orchestrator,
                workflow_id,
                local_workflow_data,
                workflow_config
            )
        )
        
        return {
            "workflow_id": workflow_id,
            "status": "started",
            "message": "Local security workflow initiated (scan-only, no PR)",
            "source": {
                "type": request.source_type,
                "path": request.source_path
            },
            "configuration": workflow_config,
            "started_at": datetime.utcnow().isoformat(),
            "note": "This workflow will not create a GitHub PR. Results available via /workflows/{workflow_id}/report"
        }
        
    except Exception as e:
        logger.error(f"Error starting local workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start local workflow: {str(e)}")

async def execute_local_workflow_background_async(
    orchestrator: OrchestratorAgent,
    workflow_id: str,
    local_workflow_data: Dict[str, Any],
    workflow_config: Dict[str, Any]
) -> None:
    """Execute local/S3 workflow in background (async version for immediate response)"""
    try:
        logger.info(f"Executing local workflow {workflow_id} in background (async)")
        
        # Execute the local workflow in a thread pool to avoid blocking
        import concurrent.futures
        loop = asyncio.get_event_loop()
        
        def run_workflow():
            return orchestrator.orchestrate_local_workflow(
                local_workflow_data,
                workflow_id=workflow_id
            )
        
        # Run in executor to not block the event loop
        with concurrent.futures.ThreadPoolExecutor() as pool:
            workflow_progress = await loop.run_in_executor(pool, run_workflow)
        
        # Store in active workflows
        active_workflows[workflow_id] = workflow_progress
        
        logger.info(f"Local workflow {workflow_id} completed with status: {workflow_progress.workflow_status}")
        
    except Exception as e:
        logger.error(f"Background local workflow {workflow_id} failed: {e}")
        import traceback
        traceback.print_exc()
        # Create error workflow progress
        error_progress = WorkflowProgress(
            workflow_id=workflow_id,
            repository_data=local_workflow_data,
            total_iterations=0,
            max_iterations=workflow_config['max_iterations'],
            iterations=[],
            final_scan_results=None,
            pr_created=False,
            workflow_status='failed',
            start_time=datetime.utcnow().isoformat(),
            end_time=datetime.utcnow().isoformat(),
            total_fixes_applied=0,
            total_manual_items=0
        )
        active_workflows[workflow_id] = error_progress

def _has_terraform_changes(webhook_data: Dict[str, Any]) -> bool:
    """Check if webhook contains Terraform file changes"""
    commits = webhook_data.get('commits', [])
    
    for commit in commits:
        added_files = commit.get('added', [])
        modified_files = commit.get('modified', [])
        all_files = added_files + modified_files
        
        if any(f.endswith('.tf') for f in all_files):
            return True
    
    return False

@app.get("/health", response_model=HealthCheckResponse)
async def health_check(
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> HealthCheckResponse:
    """
    Health check endpoint for the orchestrator agent
    """
    try:
        # Get comprehensive health status
        health_status = orchestrator.health_check()
        communication_stats = orchestrator.communication_manager.get_communication_stats()
        
        return HealthCheckResponse(
            status="healthy" if health_status['orchestrator'] == 'healthy' else "degraded",
            orchestrator=health_status['orchestrator'],
            agent_health=health_status.get('agent_health_summary', {}),
            communication_stats=communication_stats,
            timestamp=health_status['timestamp']
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthCheckResponse(
            status="unhealthy",
            orchestrator="error",
            agent_health={},
            communication_stats={},
            timestamp=datetime.utcnow().isoformat()
        )

@app.get("/info")
async def get_agent_info(
    orchestrator: OrchestratorAgent = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Get orchestrator agent information and configuration
    """
    try:
        agent_info = orchestrator.get_agent_info()
        
        # Add API-specific information
        agent_info['api_version'] = "1.0.0"
        agent_info['active_workflows'] = len(active_workflows)
        agent_info['endpoints'] = [
            "/orchestrate",
            "/workflows/{workflow_id}/status",
            "/workflows/{workflow_id}/report",
            "/workflows/{workflow_id}/audit-trail",
            "/workflows",
            "/webhook/github",
            "/health",
            "/info"
        ]
        
        return agent_info
        
    except Exception as e:
        logger.error(f"Error getting agent info: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get agent info: {str(e)}")

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Endpoint not found", "path": str(request.url.path)}
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    logger.error(f"Internal server error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error": str(exc)}
    )

if __name__ == "__main__":
    import uvicorn
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the API server
    uvicorn.run(
        "api:app",
        host="0.0.0.0",
        port=8080,
        reload=False,
        log_level="info"
    )