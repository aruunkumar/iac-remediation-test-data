"""
Comprehensive Manual Intervention Guidance Module
Combines MCP server's workflow guidance with Bedrock KB detailed recommendations
"""

import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum
import json

logger = logging.getLogger(__name__)

class GuidanceCategory(Enum):
    """Categories of manual intervention guidance"""
    SECURITY_ARCHITECTURE = "security_architecture"
    COMPLIANCE_REQUIREMENTS = "compliance_requirements"
    BUSINESS_LOGIC = "business_logic"
    PERFORMANCE_OPTIMIZATION = "performance_optimization"
    COST_OPTIMIZATION = "cost_optimization"
    OPERATIONAL_EXCELLENCE = "operational_excellence"

class InterventionPriority(Enum):
    """Priority levels for manual interventions"""
    CRITICAL = "critical"      # Security vulnerabilities requiring immediate attention
    HIGH = "high"             # Important security improvements
    MEDIUM = "medium"         # Best practice improvements
    LOW = "low"              # Optional optimizations

@dataclass
class GuidanceSource:
    """Source of guidance information"""
    source_type: str          # 'mcp_server', 'bedrock_kb', 'well_architected'
    resource_name: str        # Specific resource or KB name
    content: str             # Guidance content
    confidence: float        # Confidence score 0-1
    references: List[str]    # Source document references

@dataclass
class ManualInterventionGuidance:
    """Comprehensive manual intervention guidance"""
    finding_id: str
    check_id: str
    priority: InterventionPriority
    category: GuidanceCategory
    title: str
    description: str
    remediation_steps: List[str]
    code_examples: List[str]
    validation_criteria: List[str]
    guidance_sources: List[GuidanceSource]
    well_architected_principles: List[str]
    compliance_frameworks: List[str]
    estimated_effort: str
    business_impact: str
    risk_assessment: str

class ComprehensiveManualGuidance:
    """Comprehensive manual intervention guidance using MCP server and Bedrock KB"""
    
    def __init__(self, agent, terraform_kb_id: str, well_architected_kb_id: Optional[str] = None):
        self.agent = agent
        self.terraform_kb_id = terraform_kb_id
        self.well_architected_kb_id = well_architected_kb_id  # Can be None - use MCP server instead
        self.mcp_tools = {
            'search_aws_provider_docs': 'SearchAwsProviderDocs',
            'search_awscc_provider_docs': 'SearchAwsccProviderDocs',
            'search_aws_ia_modules': 'SearchSpecificAwsIaModules'
        }
        self.guidance_templates = self._initialize_guidance_templates()
    
    def _initialize_guidance_templates(self) -> Dict[str, Dict[str, Any]]:
        """Initialize guidance templates for common security patterns"""
        return {
            'iam_policy_overpermissive': {
                'category': GuidanceCategory.SECURITY_ARCHITECTURE,
                'priority': InterventionPriority.CRITICAL,
                'title': 'Overly Permissive IAM Policy Remediation',
                'base_steps': [
                    'Review current policy permissions against business requirements',
                    'Apply principle of least privilege',
                    'Implement resource-specific conditions',
                    'Add time-based or IP-based restrictions where appropriate',
                    'Test policy changes in non-production environment'
                ]
            },
            'network_security_group': {
                'category': GuidanceCategory.SECURITY_ARCHITECTURE,
                'priority': InterventionPriority.HIGH,
                'title': 'Network Security Group Configuration',
                'base_steps': [
                    'Analyze current network traffic requirements',
                    'Implement specific port and protocol restrictions',
                    'Use security group references instead of CIDR blocks where possible',
                    'Document business justification for each rule',
                    'Implement network monitoring and alerting'
                ]
            },
            'encryption_configuration': {
                'category': GuidanceCategory.COMPLIANCE_REQUIREMENTS,
                'priority': InterventionPriority.HIGH,
                'title': 'Encryption Configuration Enhancement',
                'base_steps': [
                    'Determine appropriate encryption requirements for data classification',
                    'Select appropriate KMS key management strategy',
                    'Implement encryption at rest and in transit',
                    'Configure key rotation policies',
                    'Validate encryption implementation'
                ]
            },
            'logging_monitoring': {
                'category': GuidanceCategory.OPERATIONAL_EXCELLENCE,
                'priority': InterventionPriority.MEDIUM,
                'title': 'Logging and Monitoring Enhancement',
                'base_steps': [
                    'Define logging requirements based on compliance needs',
                    'Implement centralized logging strategy',
                    'Configure appropriate log retention policies',
                    'Set up monitoring and alerting for security events',
                    'Ensure log integrity and tamper protection'
                ]
            }
        }
    
    def generate_comprehensive_guidance(self, finding) -> ManualInterventionGuidance:
        """Generate comprehensive manual intervention guidance"""
        try:
            # Step 1: Gather guidance from all sources
            mcp_guidance = self._get_mcp_workflow_guidance(finding)
            terraform_kb_guidance = self._get_terraform_kb_guidance(finding)
            well_arch_guidance = self._get_well_architected_guidance(finding)  # Now uses MCP server
            
            # Step 2: Determine guidance category and priority
            category, priority = self._categorize_finding(finding)
            
            # Step 3: Generate comprehensive remediation steps
            remediation_steps = self._generate_remediation_steps(
                finding, mcp_guidance, terraform_kb_guidance, well_arch_guidance
            )
            
            # Step 4: Create code examples
            code_examples = self._generate_code_examples(finding, mcp_guidance, terraform_kb_guidance)
            
            # Step 5: Define validation criteria
            validation_criteria = self._generate_validation_criteria(finding, well_arch_guidance)
            
            # Step 6: Extract Well-Architected principles
            wa_principles = self._extract_well_architected_principles(well_arch_guidance)
            
            # Step 7: Identify compliance frameworks
            compliance_frameworks = self._identify_compliance_frameworks(finding, well_arch_guidance)
            
            # Step 8: Assess effort and impact
            effort_assessment = self._assess_implementation_effort(finding, remediation_steps)
            business_impact = self._assess_business_impact(finding, category, priority)
            risk_assessment = self._assess_security_risk(finding, mcp_guidance)
            
            return ManualInterventionGuidance(
                finding_id=finding.id,
                check_id=finding.check_id,
                priority=priority,
                category=category,
                title=self._generate_guidance_title(finding, category),
                description=self._generate_guidance_description(finding, mcp_guidance),
                remediation_steps=remediation_steps,
                code_examples=code_examples,
                validation_criteria=validation_criteria,
                guidance_sources=[
                    GuidanceSource('mcp_server', 'aws_best_practices', mcp_guidance, 0.9, []),
                    GuidanceSource('bedrock_kb', self.terraform_kb_id, terraform_kb_guidance, 0.8, []),
                    GuidanceSource('mcp_server', 'well_architected_guidance', well_arch_guidance, 0.9, [])
                ],
                well_architected_principles=wa_principles,
                compliance_frameworks=compliance_frameworks,
                estimated_effort=effort_assessment,
                business_impact=business_impact,
                risk_assessment=risk_assessment
            )
            
        except Exception as e:
            logger.error(f"Error generating comprehensive guidance: {e}")
            return self._generate_fallback_guidance(finding)
    
    def _get_mcp_workflow_guidance(self, finding) -> str:
        """Get workflow guidance from MCP server resources"""
        mcp_prompt = f"""
        Use MCP Terraform server's workflow guide and AWS best practices to provide 
        comprehensive manual remediation guidance for:
        
        Check ID: {finding.check_id}
        Resource Type: {finding.resource_type}
        Description: {finding.description}
        Severity: {finding.severity.value}
        
        Use these MCP tools:
        - {self.mcp_tools['search_aws_provider_docs']} for AWS provider documentation
        - {self.mcp_tools['search_awscc_provider_docs']} for AWSCC provider documentation
        - {self.mcp_tools['search_aws_ia_modules']} for AWS-IA module guidance
        
        Provide:
        1. Detailed workflow steps for manual remediation
        2. Security considerations and risk factors
        3. AWS-specific best practices and recommendations
        4. Integration with existing infrastructure considerations
        5. Testing and validation approaches
        
        Focus on actionable, step-by-step guidance that follows AWS security best practices.
        """
        
        return self.agent(mcp_prompt)
    
    def _get_terraform_kb_guidance(self, finding) -> str:
        """Get detailed guidance from Terraform Best Practices Knowledge Base"""
        terraform_kb_prompt = f"""
        Query the Terraform Best Practices Knowledge Base ({self.terraform_kb_id}) for detailed 
        remediation guidance for this security finding:
        
        Check ID: {finding.check_id}
        Resource Type: {finding.resource_type}
        Resource: {finding.resource}
        
        Focus on:
        1. Terraform AWS provider best practices and patterns
        2. Resource-specific security configuration patterns
        3. Advanced Terraform techniques for security implementation
        4. Provider-specific implementation best practices
        5. Common pitfalls and recommended approaches
        
        Use bedrock_knowledge_base_query tool to get comprehensive Terraform-specific guidance.
        """
        
        return self.agent(terraform_kb_prompt)
    
    def _get_well_architected_guidance(self, finding) -> str:
        """Get Well-Architected Framework guidance from MCP server"""
        well_arch_prompt = f"""
        Use MCP Terraform server's SearchAwsProviderDocs tool to get AWS provider documentation 
        and Well-Architected Framework security guidance for:
        
        Check ID: {finding.check_id}
        Resource Type: {finding.resource_type}
        Security Domain: {self._determine_security_domain(finding)}
        
        Focus on:
        1. Security pillar principles and best practices
        2. Compliance framework alignment
        3. Risk assessment and mitigation strategies
        4. Operational security considerations
        5. Cost and performance implications of security measures
        
        Access the MCP server's SearchAwsProviderDocs tool for comprehensive AWS documentation and guidance.
        """
        
        return self.agent(well_arch_prompt)
    
    def _categorize_finding(self, finding) -> tuple[GuidanceCategory, InterventionPriority]:
        """Categorize finding to determine guidance approach"""
        check_id = finding.check_id.lower()
        description = finding.description.lower()
        severity = finding.severity.value.lower()
        
        # Determine category based on check ID and description patterns
        if any(term in check_id or term in description for term in ['iam', 'policy', 'role', 'permission']):
            category = GuidanceCategory.SECURITY_ARCHITECTURE
        elif any(term in check_id or term in description for term in ['encrypt', 'kms', 'ssl', 'tls']):
            category = GuidanceCategory.COMPLIANCE_REQUIREMENTS
        elif any(term in check_id or term in description for term in ['network', 'security_group', 'nacl', 'vpc']):
            category = GuidanceCategory.SECURITY_ARCHITECTURE
        elif any(term in check_id or term in description for term in ['log', 'monitor', 'cloudtrail', 'cloudwatch']):
            category = GuidanceCategory.OPERATIONAL_EXCELLENCE
        elif any(term in check_id or term in description for term in ['backup', 'snapshot', 'retention']):
            category = GuidanceCategory.OPERATIONAL_EXCELLENCE
        else:
            category = GuidanceCategory.SECURITY_ARCHITECTURE
        
        # Determine priority based on severity and category
        if severity == 'critical':
            priority = InterventionPriority.CRITICAL
        elif severity == 'high':
            priority = InterventionPriority.HIGH
        elif severity == 'medium':
            priority = InterventionPriority.MEDIUM
        else:
            priority = InterventionPriority.LOW
        
        return category, priority
    
    def _generate_remediation_steps(self, finding, mcp_guidance: str, terraform_kb: str, well_arch: str) -> List[str]:
        """Generate comprehensive remediation steps combining all guidance sources"""
        steps_prompt = f"""
        Generate comprehensive, actionable remediation steps by combining guidance from:
        
        MCP Server Guidance:
        {mcp_guidance}
        
        Terraform KB Guidance:
        {terraform_kb}
        
        Well-Architected Guidance:
        {well_arch}
        
        For finding: {finding.check_id} - {finding.description}
        
        Create a prioritized list of specific, actionable steps that:
        1. Address the security vulnerability
        2. Follow AWS Well-Architected principles
        3. Use latest Terraform provider features
        4. Include validation and testing steps
        5. Consider business impact and implementation complexity
        
        Return as numbered list of concrete actions.
        """
        
        steps_response = self.agent(steps_prompt)
        return self._parse_remediation_steps(steps_response)
    
    def _generate_code_examples(self, finding, mcp_guidance: str, terraform_kb: str) -> List[str]:
        """Generate code examples for manual remediation"""
        code_prompt = f"""
        Generate specific Terraform code examples for manual remediation of:
        
        Check ID: {finding.check_id}
        Resource: {finding.resource}
        Resource Type: {finding.resource_type}
        
        Based on guidance from:
        - MCP Server: {mcp_guidance[:500]}...
        - Terraform KB: {terraform_kb[:500]}...
        
        Provide:
        1. Before/after code comparison
        2. Complete resource configuration example
        3. Variable definitions if needed
        4. Comments explaining security improvements
        
        Focus on practical, implementable code that addresses the security issue.
        """
        
        code_response = self.agent(code_prompt)
        return self._parse_code_examples(code_response)
    
    def _generate_validation_criteria(self, finding, well_arch_guidance: str) -> List[str]:
        """Generate validation criteria for manual remediation"""
        validation_prompt = f"""
        Define validation criteria to verify successful remediation of:
        
        Check ID: {finding.check_id}
        Description: {finding.description}
        
        Based on Well-Architected guidance:
        {well_arch_guidance}
        
        Include:
        1. Security validation tests
        2. Functional validation steps
        3. Compliance verification criteria
        4. Performance impact assessment
        5. Monitoring and alerting validation
        
        Return specific, measurable validation criteria.
        """
        
        validation_response = self.agent(validation_prompt)
        return self._parse_validation_criteria(validation_response)
    
    def _determine_security_domain(self, finding) -> str:
        """Determine security domain for Well-Architected guidance"""
        check_id = finding.check_id.lower()
        description = finding.description.lower()
        
        if any(term in check_id or term in description for term in ['encrypt', 'kms']):
            return 'data_protection'
        elif any(term in check_id or term in description for term in ['iam', 'policy', 'role']):
            return 'identity_access_management'
        elif any(term in check_id or term in description for term in ['network', 'vpc', 'security_group']):
            return 'infrastructure_protection'
        elif any(term in check_id or term in description for term in ['log', 'monitor', 'detect']):
            return 'detective_controls'
        elif any(term in check_id or term in description for term in ['incident', 'response']):
            return 'incident_response'
        else:
            return 'general_security'
    
    def _extract_well_architected_principles(self, well_arch_guidance: str) -> List[str]:
        """Extract Well-Architected principles from guidance"""
        principles = []
        guidance_lower = well_arch_guidance.lower()
        
        wa_principles_map = {
            'implement a strong identity foundation': 'strong_identity_foundation',
            'apply security at all layers': 'defense_in_depth',
            'enable traceability': 'traceability',
            'automate security best practices': 'automation',
            'protect data in transit and at rest': 'data_protection',
            'keep people away from data': 'data_access_control',
            'prepare for security events': 'incident_preparedness'
        }
        
        for principle_text, principle_key in wa_principles_map.items():
            if principle_text in guidance_lower:
                principles.append(principle_key)
        
        return principles
    
    def _identify_compliance_frameworks(self, finding, well_arch_guidance: str) -> List[str]:
        """Identify relevant compliance frameworks"""
        frameworks = []
        
        # Check for common compliance frameworks
        compliance_indicators = {
            'pci': ['payment', 'card', 'pci'],
            'hipaa': ['health', 'medical', 'hipaa', 'phi'],
            'sox': ['financial', 'sox', 'sarbanes'],
            'gdpr': ['privacy', 'personal data', 'gdpr'],
            'iso27001': ['iso', '27001', 'information security'],
            'nist': ['nist', 'cybersecurity framework'],
            'cis': ['cis', 'center for internet security']
        }
        
        finding_text = f"{finding.description} {well_arch_guidance}".lower()
        
        for framework, indicators in compliance_indicators.items():
            if any(indicator in finding_text for indicator in indicators):
                frameworks.append(framework.upper())
        
        return frameworks
    
    def _assess_implementation_effort(self, finding, remediation_steps: List[str]) -> str:
        """Assess implementation effort for remediation"""
        step_count = len(remediation_steps)
        complexity_indicators = ['review', 'analyze', 'coordinate', 'test', 'validate']
        
        complexity_score = sum(1 for step in remediation_steps 
                             for indicator in complexity_indicators 
                             if indicator in step.lower())
        
        if step_count <= 3 and complexity_score <= 2:
            return "Low (1-2 hours)"
        elif step_count <= 6 and complexity_score <= 4:
            return "Medium (4-8 hours)"
        elif step_count <= 10 and complexity_score <= 8:
            return "High (1-2 days)"
        else:
            return "Very High (3+ days)"
    
    def _assess_business_impact(self, finding, category: GuidanceCategory, priority: InterventionPriority) -> str:
        """Assess business impact of the security finding"""
        impact_matrix = {
            (GuidanceCategory.SECURITY_ARCHITECTURE, InterventionPriority.CRITICAL): "High - Critical security vulnerability with potential for data breach",
            (GuidanceCategory.COMPLIANCE_REQUIREMENTS, InterventionPriority.CRITICAL): "High - Compliance violation with potential regulatory penalties",
            (GuidanceCategory.SECURITY_ARCHITECTURE, InterventionPriority.HIGH): "Medium-High - Significant security risk requiring prompt attention",
            (GuidanceCategory.COMPLIANCE_REQUIREMENTS, InterventionPriority.HIGH): "Medium - Compliance gap that should be addressed soon",
            (GuidanceCategory.OPERATIONAL_EXCELLENCE, InterventionPriority.MEDIUM): "Medium - Operational improvement with security benefits",
            (GuidanceCategory.COST_OPTIMIZATION, InterventionPriority.LOW): "Low - Cost optimization with minimal security impact"
        }
        
        return impact_matrix.get((category, priority), "Medium - Security improvement recommended")
    
    def _assess_security_risk(self, finding, mcp_guidance: str) -> str:
        """Assess security risk based on finding and MCP guidance"""
        severity = finding.severity.value.lower()
        guidance_lower = mcp_guidance.lower()
        
        high_risk_indicators = ['exploit', 'breach', 'unauthorized access', 'data exposure']
        medium_risk_indicators = ['misconfiguration', 'best practice', 'hardening']
        
        high_risk_count = sum(1 for indicator in high_risk_indicators if indicator in guidance_lower)
        medium_risk_count = sum(1 for indicator in medium_risk_indicators if indicator in guidance_lower)
        
        if severity == 'critical' or high_risk_count > 0:
            return "High - Immediate security risk requiring urgent remediation"
        elif severity == 'high' or medium_risk_count > 0:
            return "Medium - Security risk that should be addressed promptly"
        elif severity == 'medium':
            return "Medium-Low - Security improvement recommended"
        else:
            return "Low - Minor security enhancement"
    
    def _generate_guidance_title(self, finding, category: GuidanceCategory) -> str:
        """Generate descriptive title for guidance"""
        template = self.guidance_templates.get(self._map_finding_to_template(finding))
        if template:
            return template['title']
        
        return f"{category.value.replace('_', ' ').title()} - {finding.check_id}"
    
    def _generate_guidance_description(self, finding, mcp_guidance: str) -> str:
        """Generate comprehensive description"""
        return f"""
Security Finding: {finding.check_id}
Resource: {finding.resource} ({finding.resource_type})
Severity: {finding.severity.value}

Issue Description:
{finding.description}

This finding requires manual intervention due to the complexity of the required changes 
and the need for business logic decisions. The remediation involves security architecture 
considerations that require human review and validation.

MCP Server Assessment:
{mcp_guidance[:300]}...
        """.strip()
    
    def _map_finding_to_template(self, finding) -> str:
        """Map finding to guidance template"""
        check_id = finding.check_id.lower()
        
        if 'iam' in check_id or 'policy' in check_id:
            return 'iam_policy_overpermissive'
        elif 'security_group' in check_id or 'sg' in check_id:
            return 'network_security_group'
        elif 'encrypt' in check_id or 'kms' in check_id:
            return 'encryption_configuration'
        elif 'log' in check_id or 'cloudtrail' in check_id:
            return 'logging_monitoring'
        else:
            return 'default'
    
    def _generate_fallback_guidance(self, finding) -> ManualInterventionGuidance:
        """Generate fallback guidance when main process fails"""
        return ManualInterventionGuidance(
            finding_id=finding.id,
            check_id=finding.check_id,
            priority=InterventionPriority.MEDIUM,
            category=GuidanceCategory.SECURITY_ARCHITECTURE,
            title=f"Manual Remediation Required - {finding.check_id}",
            description=f"Security finding {finding.check_id} requires manual intervention: {finding.description}",
            remediation_steps=[
                "Review the security finding details and impact",
                "Consult AWS documentation for best practices",
                "Implement appropriate security controls",
                "Test changes in non-production environment",
                "Validate security improvements"
            ],
            code_examples=[],
            validation_criteria=[
                "Security vulnerability is resolved",
                "No functional regression introduced",
                "Changes follow AWS best practices"
            ],
            guidance_sources=[],
            well_architected_principles=[],
            compliance_frameworks=[],
            estimated_effort="Medium (4-8 hours)",
            business_impact="Medium - Security improvement recommended",
            risk_assessment="Medium - Security risk that should be addressed promptly"
        )
    
    # Helper methods for parsing responses
    def _parse_remediation_steps(self, response: str) -> List[str]:
        """Parse remediation steps from agent response"""
        steps = []
        lines = response.split('\n')
        
        for line in lines:
            line = line.strip()
            # Look for numbered or bulleted items
            if (line and (line[0].isdigit() or line.startswith('-') or line.startswith('*'))):
                # Clean up the step text
                step = line.lstrip('0123456789.-* ').strip()
                if step:
                    steps.append(step)
        
        return steps if steps else ["Review and implement appropriate security controls"]
    
    def _parse_code_examples(self, response: str) -> List[str]:
        """Parse code examples from agent response"""
        examples = []
        
        # Look for code blocks
        import re
        code_blocks = re.findall(r'```(?:hcl|terraform)?\n(.*?)\n```', response, re.DOTALL)
        
        for block in code_blocks:
            if block.strip():
                examples.append(block.strip())
        
        return examples
    
    def _parse_validation_criteria(self, response: str) -> List[str]:
        """Parse validation criteria from agent response"""
        criteria = []
        lines = response.split('\n')
        
        for line in lines:
            line = line.strip()
            if (line and (line[0].isdigit() or line.startswith('-') or line.startswith('*')) 
                and ('validate' in line.lower() or 'verify' in line.lower() or 'check' in line.lower())):
                criterion = line.lstrip('0123456789.-* ').strip()
                if criterion:
                    criteria.append(criterion)
        
        return criteria if criteria else ["Verify security configuration is properly implemented"]