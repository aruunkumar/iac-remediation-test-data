#!/usr/bin/env python3
"""
Test script for Terraform Remediation Agent
Runs remediation on scan results and copies output to Source&Output
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from main import TerraformRemediationAgent
import time
import shutil

def remediate_from_scan(scan_id: str, source_path: str = None):
    """
    Run remediation on scan results
    
    Args:
        scan_id: Scan ID from Checkov scanner
        source_path: Optional S3 URI or local path. If not provided, will be read from scan metadata.
    """
    print('⏱️  Running Terraform Remediation with batch processing...')
    print(f'Scan ID: {scan_id}')
    if source_path:
        print(f'Source: {source_path}')
    else:
        print('Source: Will be read from scan metadata')
    print()

    # Initialize agent
    start = time.time()
    agent = TerraformRemediationAgent()
    init_time = time.time() - start
    print(f'✅ Agent initialized in {init_time:.2f}s')
    print()

    # Run remediation
    remediation_start = time.time()
    results = agent.remediate_violations_from_scan_id(scan_id, source_path)
    remediation_time = time.time() - remediation_start

    print()
    print(f'✅ Remediation completed in {remediation_time:.2f}s')
    print()
    print(f'📊 Results:')
    print(f'   Auto-fixes: {results["auto_fixes_applied"]}')
    print(f'   Manual interventions: {results["todos_added"]}')
    print(f'   Total findings: {results["total_findings"]}')
    print(f'   Working directory: {results["working_directory"]}')
    print()

    # Extract folder name from source path
    actual_source = source_path or results.get('scan_metadata', {}).get('source', '')
    if actual_source.startswith('s3://'):
        folder_name = actual_source.rstrip('/').split('/')[-1]
    else:
        folder_name = os.path.basename(actual_source.rstrip('/')) if actual_source else 'output'
    
    # Copy to Source&Output directory
    output_dir = f'Source&Output/{folder_name}/{scan_id}/remediation_output'
    
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    
    shutil.copytree(results['working_directory'], output_dir)
    
    print(f'📁 Copied remediation output to: {output_dir}')
    print(f'📄 Check REMEDIATION_REPORT.md in the output directory')
    print()
    
    return results

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python test_remediation.py <scan_id> [source_path]")
        print()
        print("Arguments:")
        print("  scan_id      - Required: Scan ID from Checkov scanner")
        print("  source_path  - Optional: S3 URI or local path (will use scan metadata if not provided)")
        print()
        print("Examples:")
        print("  python test_remediation.py 3c09ec34")
        print("  python test_remediation.py 3c09ec34 s3://terraform-accelerator-tf-input/test/")
        print("  python test_remediation.py abc123 /path/to/local/terraform")
        sys.exit(1)
    
    scan_id = sys.argv[1]
    source_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Run remediation
    try:
        results = remediate_from_scan(scan_id, source_path)
        
        print("=" * 70)
        print("✅ Remediation test completed successfully!")
        print()
        print(f"📊 Summary:")
        print(f"   - Processed {results['total_findings']} findings")
        print(f"   - Applied {results['auto_fixes_applied']} auto-fixes")
        print(f"   - Generated {results['todos_added']} manual guidance items")
        print(f"   - Modified {len(results['modified_files'])} files")
        print("=" * 70)
        
    except Exception as e:
        print(f"❌ Remediation failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
