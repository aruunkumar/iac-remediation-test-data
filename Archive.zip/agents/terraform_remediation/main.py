"""
Terraform Remediation Agent - Specialized code remediation agent
Built with Strands SDK for deployment on AWS Bedrock AgentCore
Combines MCP Terraform Server capabilities with Bedrock Knowledge Bases
"""

import os
# Bypass tool consent prompts for automated API usage
os.environ['BYPASS_TOOL_CONSENT'] = 'true'

from strands import Agent
from strands_tools import file_read, file_write, http_request
# Mock bedrock tool for testing - replace with actual bedrock tool when available
def bedrock_knowledge_base_query(kb_id: str, query: str) -> str:
    """Mock bedrock knowledge base query for testing"""
    return f"Mock response for KB {kb_id} query: {query}"
from strands.tools.mcp import MCPClient
from mcp.client.stdio import stdio_client
from mcp import StdioServerParameters
from typing import Dict, List, Any, Optional
import json
import logging
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from shared.interfaces import RemediationResults, RemediationFix, ManualIntervention, SecurityFinding, SeverityLevel, RemediationType
from shared.utils import ValidationUtils, FileUtils
try:
    from .auto_remediation import EnhancedAutoRemediation
    from .manual_guidance import ComprehensiveManualGuidance
except ImportError:
    # Fallback for direct execution
    from auto_remediation import EnhancedAutoRemediation
    from manual_guidance import ComprehensiveManualGuidance

logger = logging.getLogger(__name__)

def get_terraform_mcp_client():
    """Get MCP client for Terraform server - reusing existing pattern"""
    return MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["awslabs.terraform-mcp-server@latest"],
                env={"FASTMCP_LOG_LEVEL": "ERROR"},
                disabled=False,
                auto_approve=[],
                debug=True,
            )
        )
    )

def get_terraform_remediation_system_prompt() -> str:
    """System prompt for the Terraform Remediation Agent with intelligent single-call remediation"""
    return """
    You are the Terraform Remediation Agent specialized in intelligent security remediation.
    
    Your responsibility: Perform single-call remediation that either applies safe auto-fixes 
    or generates concise manual intervention guidance with code examples.
    
    ## Auto-Remediation Criteria:
    **SAFE TO AUTO-FIX:** Missing encryption, insecure defaults, hardcoded values, missing backups, 
    insecure protocols, missing monitoring/logging, simple compliance violations
    
    **REQUIRES MANUAL:** Network architecture changes, resource dependencies that could break functionality, 
    business logic decisions, multi-resource coordination, custom security requirements
    
    ## Execution Guidelines:
    - **Safety First**: Never modify code if there's risk of breaking functionality
    - **Preserve Intent**: Maintain original code purpose and behavior
    - **Document Changes**: Always add clear comments for modifications
    
    Use tools intelligently and only when needed. Prioritize safety and functionality preservation.
    """

class TerraformRemediationAgent:
    """Terraform Remediation Agent combining MCP server and Bedrock Knowledge Base capabilities"""
    
    def __init__(self):
        self.tf_mcp_client = get_terraform_mcp_client()
        self.agent = None
        self.terraform_best_practices_kb_id = "LZ2DEM1204"  # KB for Terraform AWS Provider best practices only
        self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Strands agent with MCP tools and Bedrock capabilities"""
        try:
            with self.tf_mcp_client:
                # Get MCP tools from Terraform server
                mcp_tools = self.tf_mcp_client.list_tools_sync()
                logger.info(f"Available MCP tools: {[tool.tool_name for tool in mcp_tools]}")
                
                # Combine MCP tools with Bedrock and file system tools
                all_tools = mcp_tools + [
                    file_read, 
                    file_write, 
                    http_request,
                    bedrock_knowledge_base_query
                ]
                
                self.agent = Agent(
                    system_prompt=get_terraform_remediation_system_prompt(),
                    tools=all_tools,
                    model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
                )
                
                # Initialize enhanced auto-remediation module
                self.auto_remediation = EnhancedAutoRemediation(
                    agent=self.agent,
                    terraform_kb_id=self.terraform_best_practices_kb_id,
                    well_architected_kb_id=None  # Use MCP server for Well-Architected guidance
                )
                
                # Initialize comprehensive manual guidance module
                self.manual_guidance = ComprehensiveManualGuidance(
                    agent=self.agent,
                    terraform_kb_id=self.terraform_best_practices_kb_id,
                    well_architected_kb_id=None  # Use MCP server for Well-Architected guidance
                )
                
                logger.info("Terraform Remediation Agent initialized with MCP and Bedrock capabilities")
                
        except Exception as e:
            logger.error(f"Failed to initialize agent with MCP tools: {e}")
            # Fallback to basic tools if MCP fails
            self.agent = Agent(
                system_prompt=get_terraform_remediation_system_prompt(),
                tools=[file_read, file_write, http_request, bedrock_knowledge_base_query],
                model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
            )
            
            # Initialize auto-remediation with fallback agent
            self.auto_remediation = EnhancedAutoRemediation(
                agent=self.agent,
                terraform_kb_id=self.terraform_best_practices_kb_id,
                well_architected_kb_id=None  # Use MCP server for Well-Architected guidance
            )
            
            # Initialize manual guidance with fallback agent
            self.manual_guidance = ComprehensiveManualGuidance(
                agent=self.agent,
                terraform_kb_id=self.terraform_best_practices_kb_id,
                well_architected_kb_id=None  # Use MCP server for Well-Architected guidance
            )
    
    def remediate_violations_from_scan_id(self, scan_id: str, source_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Load scan results from scan ID and apply remediation to working copy
        
        Args:
            scan_id: Scan ID from Checkov scanner
            source_path: Optional source path (S3 URI or local path) to create working copy.
                        If not provided, will try to get from scan_metadata.
        
        Returns:
            Dict with remediation results and working directory path
        """
        logger.info(f"Loading scan results from scan ID: {scan_id}")
        
        # Load scan results from temporary file location
        scan_results = self._load_scan_results_from_file(scan_id)
        
        # Get source path from scan metadata if not provided
        if not source_path and 'scan_metadata' in scan_results:
            source_path = scan_results['scan_metadata'].get('source')
            if source_path:
                logger.info(f"Retrieved source path from scan metadata: {source_path}")
        
        # Create working copy if source_path available
        working_dir = None
        if source_path:
            working_dir = self._create_working_copy(source_path, scan_id)
            logger.info(f"Created working copy in {working_dir}")
        else:
            logger.warning("No source_path provided and none found in scan metadata. "
                         "Remediation will return results without applying to files.")
        
        # Apply remediation using the loaded results
        remediation_results = self.remediate_violations(scan_results, working_dir)
        
        # Return enhanced results with working directory info
        return {
            'scan_id': scan_id,
            'remediation_results': remediation_results,
            'working_directory': working_dir,
            'modified_files': self._get_modified_files(working_dir) if working_dir else [],
            'auto_fixes_applied': len(remediation_results.fixes),
            'todos_added': len(remediation_results.manual_interventions),
            'total_findings': len(remediation_results.fixes) + len(remediation_results.manual_interventions)
        }
    
    def _create_finding_batches(self, findings: List[SecurityFinding], max_batch_size: int = 5) -> List[Dict[str, Any]]:
        """
        Group findings by file for batch processing
        
        Returns list of batches with metadata:
        - file: target file
        - findings: list of findings (up to max_batch_size)
        - batch_size: number of findings
        """
        batches = []
        
        # Group by file
        by_file = {}
        for finding in findings:
            file = finding.file
            if file not in by_file:
                by_file[file] = []
            by_file[file].append(finding)
        
        # Create batches of max_batch_size for each file
        for file, file_findings in by_file.items():
            for i in range(0, len(file_findings), max_batch_size):
                batch_findings = file_findings[i:i + max_batch_size]
                batches.append({
                    'file': file,
                    'findings': batch_findings,
                    'batch_size': len(batch_findings)
                })
        
        logger.info(f"Created {len(batches)} batches from {len(findings)} findings")
        for i, batch in enumerate(batches, 1):
            logger.info(f"  Batch {i}: {batch['file']} - {batch['batch_size']} finding(s)")
        
        return batches
    
    def remediate_violations(self, scan_results: Dict[str, Any], working_dir: Optional[str] = None) -> RemediationResults:
        """
        Process scan results using batch processing for efficiency
        Groups findings by file and complexity, processes in optimized batches
        """
        import time
        
        total_start = time.time()
        logger.info(f"Starting remediation for {scan_results.get('total_findings', 0)} findings")
        
        if not ValidationUtils.validate_scan_results(scan_results):
            raise ValueError("Invalid scan results format")
        
        remediation_results = RemediationResults(
            scan_id=scan_results.get('scan_id', ''),
            fixes=[],
            manual_interventions=[],
            validation_errors=[],
            knowledge_base_queries=[]
        )
        
        findings_data = scan_results.get('findings', [])
        
        # Convert all findings to SecurityFinding objects
        findings = []
        for finding_data in findings_data:
            try:
                if isinstance(finding_data, dict):
                    finding = self._convert_dict_to_security_finding(finding_data)
                else:
                    finding = finding_data
                findings.append(finding)
            except Exception as e:
                logger.error(f"Error converting finding: {e}")
                remediation_results.validation_errors.append(str(e))
        
        # Filter out findings that have already been addressed
        if working_dir:
            findings = self._filter_already_addressed_findings(findings, working_dir)
            logger.info(f"After filtering already-addressed findings: {len(findings)} remaining")
        
        if not findings:
            logger.info("No findings to remediate (all already addressed)")
            # If report exists, just return; otherwise create initial report from existing comments
            if working_dir:
                report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
                if not os.path.exists(report_path):
                    logger.info("Creating initial report from existing comments in code")
                    self._create_initial_report_from_comments(working_dir, scan_results)
            return remediation_results
        
        # Create batches using Option B: Batch by Complexity + File
        batches = self._create_finding_batches(findings, max_batch_size=5)
        
        # Initialize report if working directory is provided
        report_path = None
        if working_dir:
            report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
            self._initialize_report(report_path, scan_results, len(batches))
        
        # Wrap the entire remediation process in MCP context
        mcp_start = time.time()
        with self.tf_mcp_client:
            logger.info(f"⏱️  MCP context opened in {time.time() - mcp_start:.2f}s")
            
            # Process each batch
            for batch_idx, batch in enumerate(batches, 1):
                batch_start = time.time()
                
                logger.info(f"⏱️  [{batch_idx}/{len(batches)}] Processing batch: {batch['file']} - "
                          f"{batch['batch_size']} finding(s)")
                
                try:
                    # Process batch together
                    if batch['batch_size'] > 1:
                        # Batch process multiple findings together
                        batch_result = self._remediate_batch(batch['findings'], working_dir, working_dir)
                        
                        # Add results
                        remediation_results.fixes.extend(batch_result.get('fixes', []))
                        remediation_results.manual_interventions.extend(batch_result.get('manual_interventions', []))
                        remediation_results.validation_errors.extend(batch_result.get('errors', []))
                    else:
                        # Single finding in batch
                        finding = batch['findings'][0]
                        remediation_result = self._remediate_finding_intelligently(finding, working_dir)
                        
                        if remediation_result['type'] == 'auto_fix':
                            remediation_results.fixes.append(remediation_result['fix'])
                        elif remediation_result['type'] == 'manual_guidance':
                            remediation_results.manual_interventions.append(remediation_result['guidance'])
                        else:
                            remediation_results.validation_errors.append(remediation_result.get('error', 'Unknown error'))
                    
                    batch_time = time.time() - batch_start
                    logger.info(f"⏱️  [{batch_idx}/{len(batches)}] Completed batch in {batch_time:.2f}s")
                    
                    # Update report after each batch
                    if report_path:
                        self._update_report(report_path, batch_idx, len(batches), batch_time, remediation_results)
                    
                except Exception as e:
                    batch_time = time.time() - batch_start
                    logger.error(f"⏱️  [{batch_idx}/{len(batches)}] Error processing batch in {batch_time:.2f}s: {e}")
                    remediation_results.validation_errors.append(str(e))
                    
                    # Update report with error
                    if report_path:
                        self._update_report(report_path, batch_idx, len(batches), batch_time, remediation_results, error=str(e))
        
        remediation_time = time.time() - total_start
        logger.info(f"⏱️  Total remediation time: {remediation_time:.2f}s for {len(findings)} findings "
                   f"in {len(batches)} batches (avg: {remediation_time/len(batches):.2f}s per batch)")
        logger.info(f"Applied {len(remediation_results.fixes)} auto-fixes, "
                   f"generated {len(remediation_results.manual_interventions)} manual guidance items")
        
        # Extract summaries from actual file comments before finalizing report
        if report_path and working_dir:
            self._extract_summaries_from_files(remediation_results, working_dir)
        
        # Finalize report
        if report_path:
            self._finalize_report(report_path, remediation_time, remediation_results)
        
        logger.info(f"⏱️  TOTAL TIME: {time.time() - total_start:.2f}s")
        
        return remediation_results
    
    def _filter_already_addressed_findings(self, findings: List[SecurityFinding], working_dir: str) -> List[SecurityFinding]:
        """Filter out findings that have already been addressed using remediation report"""
        import os
        
        logger.info("Checking for already-addressed findings...")
        
        report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
        
        # Try to load existing remediation report first
        if os.path.exists(report_path):
            logger.info("Found existing remediation report, using it to filter findings")
            addressed_findings = self._parse_remediation_report(report_path)
        else:
            logger.info("No remediation report found, scanning code for existing comments")
            addressed_findings = self._scan_code_for_addressed_findings(working_dir)
        
        if not addressed_findings:
            logger.info("No previously addressed findings found")
            return findings
        
        # Filter findings by comparing (check_id, resource) tuples
        original_count = len(findings)
        filtered_findings = []
        skipped_findings = []
        
        for finding in findings:
            finding_key = (finding.check_id, finding.resource)
            
            if finding_key in addressed_findings:
                skipped_findings.append(finding)
                logger.debug(f"  Skipping {finding.check_id} for {finding.resource} (already addressed)")
            else:
                filtered_findings.append(finding)
        
        skipped_count = len(skipped_findings)
        if skipped_count > 0:
            logger.info(f"Skipping {skipped_count} already-addressed findings:")
            for f in skipped_findings:
                logger.info(f"  {f.check_id}: {f.resource}")
        
        return filtered_findings
    
    def _parse_remediation_report(self, report_path: str) -> set:
        """Parse remediation report to extract addressed findings as (check_id, resource) tuples"""
        import re
        
        addressed_findings = set()
        
        try:
            with open(report_path, 'r') as f:
                content = f.read()
            
            # Parse both Auto-Fixed and Manual Intervention tables
            # Table format: | Check ID | Resource | File | ... |
            table_row_pattern = re.compile(r'\|\s*(\S+)\s*\|\s*([^|]+?)\s*\|')
            
            in_table = False
            for line in content.split('\n'):
                # Detect table start
                if '| Check ID | Resource |' in line:
                    in_table = True
                    continue
                
                # Skip table separator
                if in_table and line.startswith('|---'):
                    continue
                
                # End of table
                if in_table and not line.startswith('|'):
                    in_table = False
                    continue
                
                # Parse table row
                if in_table:
                    match = table_row_pattern.match(line)
                    if match:
                        check_id = match.group(1).strip()
                        resource = match.group(2).strip()
                        
                        # Skip header row
                        if check_id != 'Check ID':
                            addressed_findings.add((check_id, resource))
                            logger.debug(f"  From report: {check_id} -> {resource}")
        
        except Exception as e:
            logger.warning(f"Error parsing remediation report: {e}")
        
        logger.info(f"Loaded {len(addressed_findings)} addressed findings from report")
        return addressed_findings
    
    def _scan_code_for_addressed_findings(self, working_dir: str) -> set:
        """Scan code files for AGENT-FIXED and TODO comments as fallback"""
        import re
        import os
        
        addressed_findings = set()
        comment_pattern = re.compile(r'#\s*(?:AGENT-FIXED|TODO):\s*(\S+)', re.IGNORECASE)
        
        for root, dirs, files in os.walk(working_dir):
            for file in files:
                if file.endswith('.tf'):
                    file_path = os.path.join(root, file)
                    
                    try:
                        with open(file_path, 'r') as f:
                            content = f.read()
                            lines = content.split('\n')
                            
                            for i, line in enumerate(lines):
                                match = comment_pattern.search(line)
                                if match:
                                    check_id = match.group(1)
                                    
                                    # Look backwards for resource declaration
                                    resource = None
                                    for j in range(max(0, i - 10), i):
                                        resource_match = re.search(
                                            r'resource\s+"([^"]+)"\s+"([^"]+)"',
                                            lines[j]
                                        )
                                        if resource_match:
                                            # Build full resource identifier
                                            resource_type = resource_match.group(1)
                                            resource_name = resource_match.group(2)
                                            resource = f"{resource_type}.{resource_name}"
                                            break
                                    
                                    if resource:
                                        addressed_findings.add((check_id, resource))
                                        logger.debug(f"  From code: {check_id} -> {resource}")
                    
                    except Exception as e:
                        logger.warning(f"Could not read file {file_path}: {e}")
        
        logger.info(f"Found {len(addressed_findings)} addressed findings in code")
        return addressed_findings
    
    def _create_initial_report_from_comments(self, working_dir: str, scan_results: Dict[str, Any]) -> None:
        """Create initial remediation report from existing comments in code"""
        import os
        
        logger.info("Creating initial remediation report from existing code comments")
        
        # Scan code for addressed findings
        addressed_findings = self._scan_code_for_addressed_findings(working_dir)
        
        if not addressed_findings:
            logger.info("No existing comments found, skipping report creation")
            return
        
        # Create a minimal report
        report_path = os.path.join(working_dir, 'REMEDIATION_REPORT.md')
        
        # Separate auto-fixes from manual interventions based on comment type
        auto_fixes = []
        manual_interventions = []
        
        # Re-scan to categorize
        import re
        for root, dirs, files in os.walk(working_dir):
            for file in files:
                if file.endswith('.tf'):
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, working_dir)
                    
                    try:
                        with open(file_path, 'r') as f:
                            lines = f.readlines()
                            
                            for i, line in enumerate(lines):
                                if 'AGENT-FIXED:' in line:
                                    match = re.search(r'AGENT-FIXED:\s*(\S+)\s*-\s*(.+)', line)
                                    if match:
                                        check_id = match.group(1)
                                        description = match.group(2).strip()
                                        
                                        # Find resource
                                        resource = self._find_resource_for_line(lines, i)
                                        if resource:
                                            auto_fixes.append({
                                                'check_id': check_id,
                                                'resource': resource,
                                                'file': '/' + rel_path,
                                                'description': description
                                            })
                                
                                elif 'TODO:' in line:
                                    match = re.search(r'TODO:\s*(\S+)\s*-\s*(.+)', line)
                                    if match:
                                        check_id = match.group(1)
                                        description = match.group(2).strip()
                                        
                                        # Find resource
                                        resource = self._find_resource_for_line(lines, i)
                                        if resource:
                                            manual_interventions.append({
                                                'check_id': check_id,
                                                'resource': resource,
                                                'file': '/' + rel_path,
                                                'description': description
                                            })
                    
                    except Exception as e:
                        logger.warning(f"Error reading {file_path}: {e}")
        
        # Write report
        with open(report_path, 'w') as f:
            f.write("# Remediation Report\n\n")
            f.write(f"**Scan ID:** {scan_results.get('scan_id', 'N/A')}\n")
            f.write(f"**Generated from existing code comments**\n\n")
            f.write("---\n\n")
            
            f.write("## Auto-Fixed Issues\n\n")
            if auto_fixes:
                f.write("| Check ID | Resource | File | What Changed |\n")
                f.write("|----------|----------|------|--------------|\n")
                for fix in auto_fixes:
                    f.write(f"| {fix['check_id']} | {fix['resource']} | {fix['file']} | {fix['description']} |\n")
            else:
                f.write("No auto-fixes found.\n")
            
            f.write("\n---\n\n")
            f.write("## Manual Intervention Required\n\n")
            if manual_interventions:
                f.write("| Check ID | Resource | File | Action Needed |\n")
                f.write("|----------|----------|------|---------------|\n")
                for mi in manual_interventions:
                    f.write(f"| {mi['check_id']} | {mi['resource']} | {mi['file']} | {mi['description']} |\n")
            else:
                f.write("No manual interventions found.\n")
        
        logger.info(f"Created initial report with {len(auto_fixes)} auto-fixes and {len(manual_interventions)} manual interventions")
    
    def _find_resource_for_line(self, lines: list, line_index: int) -> str:
        """Find the resource declaration for a given line by looking backwards"""
        import re
        
        for j in range(max(0, line_index - 10), line_index):
            resource_match = re.search(r'resource\s+"([^"]+)"\s+"([^"]+)"', lines[j])
            if resource_match:
                resource_type = resource_match.group(1)
                resource_name = resource_match.group(2)
                return f"{resource_type}.{resource_name}"
        
        return "unknown"
    
    def _extract_summaries_from_files(self, results: RemediationResults, working_dir: str) -> None:
        """Extract summaries from AGENT-FIXED and TODO comments in actual files"""
        import re
        import os
        
        logger.info("Extracting summaries from file comments...")
        
        # Pattern to match AGENT-FIXED comments: # AGENT-FIXED: CKV_AWS_123 - Description here
        agent_fixed_pattern = re.compile(r'#\s*AGENT-FIXED:\s*(\S+)\s*-\s*(.+?)(?:\n|$)', re.IGNORECASE)
        
        # Pattern to match TODO comments with multiple check IDs: # TODO: CKV_AWS_123, CKV_AWS_456 - Description here
        # This pattern captures comma-separated check IDs
        todo_pattern = re.compile(r'#\s*TODO:\s*([A-Z0-9_,\s]+?)\s*-\s*(.+?)(?:\n|$)', re.IGNORECASE)
        
        # Create lookup maps by check_id
        fixes_by_check_id = {fix.check_id: fix for fix in results.fixes}
        manual_by_check_id = {mi.check_id: mi for mi in results.manual_interventions}
        
        # Scan all .tf files in working directory
        for root, dirs, files in os.walk(working_dir):
            for file in files:
                if file.endswith('.tf'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r') as f:
                            content = f.read()
                            
                            # Find AGENT-FIXED comments
                            for match in agent_fixed_pattern.finditer(content):
                                check_id = match.group(1)
                                description = match.group(2).strip()
                                
                                if check_id in fixes_by_check_id:
                                    fixes_by_check_id[check_id].fix_applied = description
                                    logger.debug(f"  Found AGENT-FIXED: {check_id} - {description}")
                            
                            # Find TODO comments (supports multiple check IDs)
                            for match in todo_pattern.finditer(content):
                                check_ids_str = match.group(1)
                                description = match.group(2).strip()
                                
                                # Split by comma to handle multiple check IDs
                                check_ids = [cid.strip() for cid in check_ids_str.split(',')]
                                
                                for check_id in check_ids:
                                    if check_id in manual_by_check_id:
                                        manual_by_check_id[check_id].todo_comment = description
                                        logger.debug(f"  Found TODO: {check_id} - {description}")
                    
                    except Exception as e:
                        logger.warning(f"Could not read file {file_path}: {e}")
        
        # Provide fallback descriptions for any missing summaries
        for fix in results.fixes:
            if not fix.fix_applied:
                fix.fix_applied = f"Applied security fix for {fix.check_id}"
                logger.warning(f"No AGENT-FIXED comment found for {fix.check_id}, using fallback")
        
        for mi in results.manual_interventions:
            if not mi.todo_comment:
                mi.todo_comment = f"Manual intervention required for {mi.check_id}"
                logger.warning(f"No TODO comment found for {mi.check_id}, using fallback")
        
        logger.info(f"Extracted summaries for {len([f for f in results.fixes if f.fix_applied])} auto-fixes and {len([m for m in results.manual_interventions if m.todo_comment])} manual interventions")
    
    def _initialize_report(self, report_path: str, scan_results: Dict[str, Any], total_batches: int) -> None:
        """Initialize the remediation report at the start or append iteration info"""
        from datetime import datetime
        import os
        
        # Check if report already exists (subsequent iteration)
        if os.path.exists(report_path):
            logger.info("Report exists, appending new iteration info")
            
            # Read existing report
            with open(report_path, 'r') as f:
                content = f.read()
            
            # Extract iteration number from existing progress sections
            import re
            iteration_matches = re.findall(r'### Iteration (\d+)', content)
            next_iteration = max([int(m) for m in iteration_matches], default=0) + 1
            
            # Find the Progress section and append new iteration
            progress_marker = "## Progress\n"
            if progress_marker in content:
                # Insert new iteration header after Progress section
                insert_pos = content.find(progress_marker) + len(progress_marker)
                new_iteration_header = f"\n### Iteration {next_iteration}\n**Started:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n**Findings in this iteration:** {scan_results.get('total_findings', 0)}  \n**Batches:** {total_batches}\n\nProcessing batches...\n"
                content = content[:insert_pos] + new_iteration_header + content[insert_pos:]
                
                with open(report_path, 'w') as f:
                    f.write(content)
                
                logger.info(f"Appended iteration {next_iteration} to existing report")
            else:
                logger.warning("Could not find Progress section in existing report, will overwrite")
                self._create_new_report(report_path, scan_results, total_batches)
        else:
            # First iteration - create new report
            self._create_new_report(report_path, scan_results, total_batches)
    
    def _create_new_report(self, report_path: str, scan_results: Dict[str, Any], total_batches: int) -> None:
        """Create a new remediation report"""
        from datetime import datetime
        
        report_content = f"""# Remediation Report

**Scan ID:** {scan_results.get('scan_id', 'N/A')}  
**First Started:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  

---

## Progress

### Iteration 1
**Started:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Findings in this iteration:** {scan_results.get('total_findings', 0)}  
**Batches:** {total_batches}

Processing batches...

"""
        
        with open(report_path, 'w') as f:
            f.write(report_content)
        logger.info(f"Created new remediation report: {report_path}")
    
    def _update_report(self, report_path: str, batch_idx: int, total_batches: int, 
                      batch_time: float, results: RemediationResults, error: str = None) -> None:
        """Update the report after each batch"""
        
        # Read current report
        with open(report_path, 'r') as f:
            content = f.read()
        
        # Update progress section
        progress_line = f"- Batch {batch_idx}/{total_batches}: Completed in {batch_time:.2f}s"
        if error:
            progress_line += f" ⚠️ Error: {error}"
        progress_line += "\n"
        
        # Insert progress update in the current iteration section
        if "Processing batches..." in content:
            # Replace the last occurrence (current iteration)
            parts = content.rsplit("Processing batches...\n", 1)
            if len(parts) == 2:
                content = parts[0] + "Processing batches...\n" + progress_line + parts[1]
            else:
                content = content.replace("Processing batches...\n", f"Processing batches...\n{progress_line}")
        else:
            # Fallback: find the most recent iteration section
            import re
            # Find the last "### Iteration" section
            matches = list(re.finditer(r'### Iteration \d+', content))
            if matches:
                last_match = matches[-1]
                insert_pos = last_match.end()
                # Find the next line after the iteration header
                next_newline = content.find('\n', insert_pos)
                if next_newline != -1:
                    content = content[:next_newline + 1] + progress_line + content[next_newline + 1:]
        
        # Write updated content
        with open(report_path, 'w') as f:
            f.write(content)
    
    def _finalize_report(self, report_path: str, total_time: float, results: RemediationResults) -> None:
        """Finalize the report with summary and results, merging with existing findings"""
        from datetime import datetime
        import os
        
        # Check if report already exists (subsequent iteration)
        existing_fixes = []
        existing_manual = []
        
        if os.path.exists(report_path):
            # Parse existing report to preserve previous findings
            existing_addressed = self._parse_remediation_report(report_path)
            
            # Read the full report to extract descriptions
            with open(report_path, 'r') as f:
                old_content = f.read()
            
            # Extract existing entries from tables
            import re
            
            # Parse Auto-Fixed table
            auto_fixed_section = re.search(
                r'## Auto-Fixed Issues\s*\n\n(.*?)\n---',
                old_content,
                re.DOTALL
            )
            if auto_fixed_section:
                table_content = auto_fixed_section.group(1)
                for line in table_content.split('\n'):
                    if line.startswith('|') and 'Check ID' not in line and '---' not in line:
                        parts = [p.strip() for p in line.split('|')[1:-1]]
                        if len(parts) >= 4:
                            existing_fixes.append({
                                'check_id': parts[0],
                                'resource': parts[1],
                                'file': parts[2],
                                'description': parts[3]
                            })
            
            # Parse Manual Intervention table
            manual_section = re.search(
                r'## Manual Intervention Required\s*\n\n(.*?)(?:\n---|$)',
                old_content,
                re.DOTALL
            )
            if manual_section:
                table_content = manual_section.group(1)
                for line in table_content.split('\n'):
                    if line.startswith('|') and 'Check ID' not in line and '---' not in line:
                        parts = [p.strip() for p in line.split('|')[1:-1]]
                        if len(parts) >= 4:
                            existing_manual.append({
                                'check_id': parts[0],
                                'resource': parts[1],
                                'file': parts[2],
                                'description': parts[3]
                            })
        
        # Merge new findings with existing ones (avoid duplicates)
        all_fixes = existing_fixes.copy()
        all_manual = existing_manual.copy()
        
        # Add new fixes (check for duplicates by check_id + resource)
        existing_fix_keys = {(f['check_id'], f['resource']) for f in existing_fixes}
        for fix in results.fixes:
            key = (fix.check_id, fix.resource)
            if key not in existing_fix_keys:
                description = fix.fix_applied[:100] + "..." if len(fix.fix_applied) > 100 else fix.fix_applied
                description = description.replace('\n', ' ').replace('|', '\\|')
                all_fixes.append({
                    'check_id': fix.check_id,
                    'resource': fix.resource,
                    'file': fix.file,
                    'description': description
                })
        
        # Add new manual interventions (check for duplicates)
        existing_manual_keys = {(m['check_id'], m['resource']) for m in existing_manual}
        for mi in results.manual_interventions:
            key = (mi.check_id, mi.resource)
            if key not in existing_manual_keys:
                description = mi.todo_comment[:100] + "..." if len(mi.todo_comment) > 100 else mi.todo_comment
                description = description.replace('\n', ' ').replace('|', '\\|')
                all_manual.append({
                    'check_id': mi.check_id,
                    'resource': mi.resource,
                    'file': mi.file,
                    'description': description
                })
        
        # Read current report to preserve header and progress
        with open(report_path, 'r') as f:
            content = f.read()
        
        # Replace "Processing batches..." with completion message for current iteration
        # Find the last occurrence (current iteration)
        if "Processing batches..." in content:
            parts = content.rsplit("Processing batches...\n", 1)
            if len(parts) == 2:
                completion_msg = f"**Completed:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n**Time:** {total_time:.2f}s  \n**New Auto-Fixes:** {len(results.fixes)}  \n**New Manual Interventions:** {len(results.manual_interventions)}\n\n"
                content = parts[0] + completion_msg + parts[1]
            else:
                content = content.replace("Processing batches...\n", "")
        
        # Build new summary section with merged findings
        summary = f"""
---

## Summary

**Completed:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Total Time:** {total_time:.2f}s  
**Auto-Fixes Applied:** {len(all_fixes)}  
**Manual Interventions:** {len(all_manual)}  
**Errors:** {len(results.validation_errors)}

---

## Auto-Fixed Issues

"""
        
        if all_fixes:
            summary += "| Check ID | Resource | File | What Changed |\n"
            summary += "|----------|----------|------|--------------|\n"
            for fix in all_fixes:
                summary += f"| {fix['check_id']} | {fix['resource']} | {fix['file']} | {fix['description']} |\n"
        else:
            summary += "No auto-fixes were applied.\n"
        
        summary += "\n---\n\n## Manual Intervention Required\n\n"
        
        if all_manual:
            summary += "| Check ID | Resource | File | Action Needed |\n"
            summary += "|----------|----------|------|---------------|\n"
            for mi in all_manual:
                summary += f"| {mi['check_id']} | {mi['resource']} | {mi['file']} | {mi['description']} |\n"
        else:
            summary += "No manual interventions required.\n"
        
        if results.validation_errors:
            summary += "\n---\n\n## Errors Encountered\n\n"
            for i, error in enumerate(results.validation_errors, 1):
                summary += f"{i}. {error}\n"
        
        summary += "\n---\n\n## Next Steps\n\n"
        if all_manual:
            summary += "1. Review the TODO comments added to the Terraform files\n"
            summary += "2. Implement the recommended security fixes\n"
            summary += "3. Test changes in a non-production environment\n"
            summary += "4. Apply to production after validation\n"
        else:
            summary += "All findings have been auto-fixed. Review the changes and test before deploying.\n"
        
        # Append summary to content
        content += summary
        
        # Write final report
        with open(report_path, 'w') as f:
            f.write(content)
        
        logger.info(f"Finalized remediation report: {report_path}")
    
    def _remediate_batch(self, findings: List[SecurityFinding], working_dir: Optional[str] = None, file_check_dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Process a batch of findings together for efficiency
        
        Args:
            findings: List of findings to process (should be from same file)
            working_dir: Working directory path
        
        Returns:
            Dict with fixes, manual_interventions, and errors lists
        """
        if not findings:
            return {'fixes': [], 'manual_interventions': [], 'errors': []}
        
        # All findings should be from the same file
        file_path = findings[0].file
        file_location = f"{working_dir}/{file_path}" if working_dir else file_path
        
        # Build batch prompt
        findings_summary = "\n\n".join([
            f"**Finding {idx+1}:**\n"
            f"- Check ID: {f.check_id}\n"
            f"- Resource: {f.resource} ({f.resource_type})\n"
            f"- Issue: {f.description}"
            for idx, f in enumerate(findings)
        ])
        
        batch_prompt = f"""
Fix these {len(findings)} Terraform security findings in the same file:

**File**: {file_location}

{findings_summary}

## Decision Framework

For each finding, evaluate if it is **safe to auto-fix** or **requires manual intervention** based on risk and complexity.

**SAFE TO AUTO-FIX** - Low risk, well-understood fixes (examples):
• Missing encryption settings (S3, RDS, CloudWatch, Lambda env vars)
• Insecure default values or protocols 
• Hardcoded sensitive values (passwords, keys)
• Missing backup configurations
• Missing monitoring/logging configurations
• Simple compliance violations

**REQUIRES MANUAL INTERVENTION** - High risk, complex changes (examples):
• Network architecture changes (VPC, subnets, security groups)
• Resource dependencies that could break functionality
• Business logic decisions (retention periods, access patterns, cost implications)
• Multi-resource coordination changes
• Custom security requirements specific to organization

## Instructions

1. **Read the file once** to understand the complete configuration
2. **Analyze each finding** against the decision framework above
3. **Apply all safe fixes together** in a single file modification
4. **For each auto-fix**, add a comment: `# AGENT-FIXED: {{check_id}} - [brief description]`
5. **For findings requiring manual intervention**, add TODO comment:
   ```
   # TODO: {{check_id}} - {{description}}
   # Resource: {{resource}}
   # Reason: [why manual intervention is needed]
   # Fix: [specific remediation steps or code example]
   ```

## CRITICAL Requirements

1. **100% Coverage**: Add a comment for EVERY finding - no exceptions. If uncertain, add TODO with "Requires manual review"
2. **Multiple findings on same resource**: Combine related checks with comma-separated IDs: `# TODO: CKV_AWS_260, CKV_AWS_24 - Description`
3. **All-ports rules**: `from_port=0, to_port=0, protocol="-1"` means ALL ports including 22, 3389, etc. These are NOT false positives.
4. **Verify before finishing**: Total comments added must equal {len(findings)} findings

## Guidelines
- **Safety First**: Never modify code if there's risk of breaking functionality
- **Preserve Intent**: Maintain original code purpose and behavior
- **Knowledge Base**: Use bedrock_knowledge_base_query (KB: '{self.terraform_best_practices_kb_id}') only for non-obvious cases or if unsure of the fix
- **AWS Provider Docs**: Use SearchAwsProviderDocs only if unsure of AWS resource syntax - not for every fix
- **Be Decisive**: Make clear choices between auto-fix and manual intervention for each finding
- Process all findings efficiently in one pass

Apply fixes or generate TODO comments now.
"""
        
        try:
            import time
            agent_start = time.time()
            
            result = self.agent(batch_prompt)
            
            agent_time = time.time() - agent_start
            logger.info(f"    🤖 Batch agent inference time: {agent_time:.2f}s for {len(findings)} findings")
            
            result_text = str(result)
            
            # Parse results based on agent's structured summary
            # Agent outputs findings as "Finding 1", "Finding 2", etc.
            # with clear categorization under "Auto-Fixed" or "Manual Intervention Required"
            fixes = []
            manual_interventions = []
            errors = []
            
            # Instead of parsing agent output (unreliable), scan files for comments (reliable)
            # The agent adds comments to files: # AGENT-FIXED: CKV_XXX or # TODO: CKV_XXX
            # This is the actual work product and is deterministic
            import re
            
            logger.info("Scanning files for AGENT-FIXED and TODO comments...")
            
            # Scan files for each finding
            for finding in findings:
                check_id = finding.check_id
                found_in_file = False
                
                if file_check_dir and finding.file:
                    # Strip leading slash from finding.file to avoid os.path.join treating it as absolute
                    relative_file = finding.file.lstrip('/')
                    file_path = os.path.join(file_check_dir, relative_file)
                    
                    if os.path.exists(file_path):
                        try:
                            with open(file_path, 'r') as f:
                                file_content = f.read()
                                
                                # Check for AGENT-FIXED comment
                                if f"AGENT-FIXED: {check_id}" in file_content or f"AGENT-FIXED:{check_id}" in file_content:
                                    # Extract description from comment
                                    match = re.search(rf'#\s*AGENT-FIXED:\s*{re.escape(check_id)}\s*-\s*(.+?)(?:\n|$)', file_content, re.IGNORECASE)
                                    description = match.group(1).strip() if match else f"Applied fix for {check_id}"
                                    
                                    fix = self._create_auto_fix_from_result(finding, result_text)
                                    fix.fix_applied = description
                                    fixes.append(fix)
                                    found_in_file = True
                                    logger.debug(f"  Found AGENT-FIXED: {check_id} in {relative_file}")
                                
                                # Check for TODO comment (supports comma-separated check IDs)
                                # Pattern matches: # TODO: CKV_AWS_123 - desc OR # TODO: CKV_AWS_123, CKV_AWS_456 - desc
                                elif f"TODO:" in file_content and check_id in file_content:
                                    # Look for TODO comments that include this check_id (possibly with others)
                                    # Pattern: # TODO: <check_ids> - <description>
                                    todo_pattern = rf'#\s*TODO:\s*([A-Z0-9_,\s]+?)\s*-\s*(.+?)(?:\n|$)'
                                    for todo_match in re.finditer(todo_pattern, file_content, re.IGNORECASE):
                                        check_ids_str = todo_match.group(1)
                                        description = todo_match.group(2).strip()
                                        
                                        # Split by comma to get all check IDs in this TODO
                                        check_ids_in_todo = [cid.strip() for cid in check_ids_str.split(',')]
                                        
                                        # Check if our check_id is in this TODO comment
                                        if check_id in check_ids_in_todo:
                                            guidance = self._create_manual_guidance_from_result(finding, result_text)
                                            guidance.todo_comment = description
                                            manual_interventions.append(guidance)
                                            found_in_file = True
                                            logger.debug(f"  Found TODO: {check_id} in {relative_file} (combined with {len(check_ids_in_todo)} checks)")
                                            break
                        
                        except Exception as e:
                            logger.warning(f"Could not read file {file_path}: {e}")
                    else:
                        logger.warning(f"File not found: {file_path}")
                
                # If not found in file, check if finding was addressed elsewhere
                # This handles cases where the agent didn't add a comment (shouldn't happen but defensive)
                if not found_in_file:
                    logger.warning(f"No comment found for {check_id} in {finding.file}, marking as unprocessed")
                    # Add as manual intervention with generic message
                    guidance = self._create_manual_guidance_from_result(finding, result_text)
                    guidance.todo_comment = f"Requires review - no agent comment found for {check_id}"
                    manual_interventions.append(guidance)
            
            return {
                'fixes': fixes,
                'manual_interventions': manual_interventions,
                'errors': errors
            }
            
        except Exception as e:
            logger.error(f"Error in batch remediation: {e}")
            return {
                'fixes': [],
                'manual_interventions': [],
                'errors': [str(e)]
            }
    
    def _remediate_finding_intelligently(self, finding: SecurityFinding, working_dir: Optional[str] = None) -> Dict[str, Any]:
        """Single intelligent remediation attempt with on-demand tool usage"""
        try:
            # Build file path information
            file_location = f"{working_dir}/{finding.file}" if working_dir else finding.file
            
            remediation_prompt = f"""
Fix this Terraform security finding:

**Check ID**: {finding.check_id}
**Resource**: {finding.resource} ({finding.resource_type})
**File**: {file_location}
**Issue**: {finding.description}

## Decision Framework

Evaluate if this issue is **safe to auto-fix** or **requires manual intervention** based on risk and complexity.

**SAFE TO AUTO-FIX** - Low risk, well-understood fixes (examples):
• Missing encryption settings (S3, RDS, CloudWatch, Lambda env vars)
• Insecure default values or protocols 
• Hardcoded sensitive values (passwords, keys)
• Missing backup configurations
• Missing monitoring/logging configurations
• Simple compliance violations

**REQUIRES MANUAL INTERVENTION** - High risk, complex changes (examples):
• Network architecture changes (VPC, subnets, security groups)
• Resource dependencies that could break functionality
• Business logic decisions (retention periods, access patterns, cost implications)
• Multi-resource coordination changes
• Custom security requirements specific to organization

## Instructions

1. **Read the file** to understand current configuration and context
2. **Analyze the issue** against the decision framework above
3. **Choose path**:

   **If SAFE TO AUTO-FIX**:
   - Apply the fix directly to the file
   - Add comment: `# AGENT-FIXED: {finding.check_id} - [brief description of what was fixed]`
   - Ensure fix follows Terraform best practices and AWS provider syntax
   
   **If REQUIRES MANUAL**:
   - Generate a concise TODO comment with clear guidance
   - Return it prefixed with "MANUAL_FIX_REQUIRED:"
   - Format:
     ```
     # TODO: {finding.check_id} - {finding.description}
     # Resource: {finding.resource}
     # Reason: [why manual intervention is needed]
     # Fix: [specific remediation steps or code example]
     ```

## Guidelines
- **Safety First**: Never modify code if there's risk of breaking functionality
- **Preserve Intent**: Maintain original code purpose and behavior
- **Knowledge Base**: Use bedrock_knowledge_base_query (KB: '{self.terraform_best_practices_kb_id}') only for non-obvious cases or if unsure of the fix
- **AWS Provider Docs**: Use SearchAwsProviderDocs only if unsure of AWS resource syntax - not for every fix
- **Be Decisive**: Make a clear choice between auto-fix and manual intervention

Apply the fix or generate TODO comment now.
"""
            
            import time
            agent_start = time.time()
            result = self.agent(remediation_prompt)
            agent_time = time.time() - agent_start
            logger.info(f"    🤖 Agent inference time: {agent_time:.2f}s for {finding.check_id}")
            
            result_text = str(result)
            
            # Parse result to determine outcome
            if "MANUAL_FIX_REQUIRED" in result_text:
                return {
                    'type': 'manual_guidance',
                    'guidance': self._create_manual_guidance_from_result(finding, result_text)
                }
            else:
                return {
                    'type': 'auto_fix',
                    'fix': self._create_auto_fix_from_result(finding, result_text)
                }
                
        except Exception as e:
            logger.error(f"Error in intelligent remediation for {finding.id}: {e}")
            return {
                'type': 'error',
                'error': str(e)
            }
    

    
    def _create_manual_guidance_from_result(self, finding: SecurityFinding, agent_result: str) -> ManualIntervention:
        """Create manual intervention guidance from agent result - agent already generated the TODO comment"""
        # Extract the TODO comment that the agent already generated in the same call
        todo_start = agent_result.find("MANUAL_FIX_REQUIRED:")
        
        if todo_start != -1:
            # Agent provided the TODO comment after MANUAL_FIX_REQUIRED:
            todo_comment = agent_result[todo_start + len("MANUAL_FIX_REQUIRED:"):].strip()
        else:
            # Fallback: create basic TODO if agent didn't follow format
            todo_comment = f"""# TODO: {finding.check_id} - {finding.description}
# Resource: {finding.resource}
# Reason: Manual intervention required
#
# Fix: Review security configuration and apply appropriate controls
# See AWS documentation for {finding.resource_type} security best practices"""
        
        return ManualIntervention(
            violation_id=finding.id,
            check_id=finding.check_id,
            file=finding.file,
            resource=finding.resource,
            todo_comment="",  # Will be populated from file comments
            detailed_guidance={
                'single_call_guidance': True,
                'agent_result': agent_result,
                'full_todo_comment': todo_comment
            }
        )
    
    def _create_auto_fix_from_result(self, finding: SecurityFinding, agent_result: str) -> RemediationFix:
        """Create auto-fix result from agent result"""
        # Summary will be extracted from file comments later
        return RemediationFix(
            violation_id=finding.id,
            check_id=finding.check_id,
            file=finding.file,
            resource=finding.resource,
            fix_applied="",  # Will be populated from file comments
            knowledge_base_reference={
                'intelligent_remediation': True,
                'agent_result': agent_result,
                'fix_summary': f"Intelligent auto-remediation applied for {finding.check_id}",
                'agent_comment': f"# AGENT-FIXED: {finding.check_id}",
                'execution_guidelines': [
                    'Safety First: Code modified with minimal risk of breaking functionality',
                    'Preserve Intent: Original code purpose and behavior maintained',
                    'Document Changes: Clear comments added for agent modifications',
                    'Comprehensive Coverage: Vulnerability addressed through automated fix'
                ]
            }
        )

    def get_agent_info(self) -> Dict[str, Any]:
        """Get agent information and capabilities"""
        return {
            'agent_name': 'terraform-remediation-agent',
            'version': '1.0.0',
            'capabilities': [
                'MCP Terraform Server Integration',
                'Bedrock Knowledge Base Queries',
                'Automated Security Fixes',
                'Manual Intervention Guidance',
                'Terraform Syntax Validation'
            ],
            'mcp_tools': [
                'SearchAwsProviderDocs',
                'SearchAwsccProviderDocs',
                'SearchSpecificAwsIaModules'
            ],
            'knowledge_bases': [
                self.terraform_best_practices_kb_id
            ]
        }
    
    def health_check(self) -> Dict[str, Any]:
        """Health check for the agent"""
        try:
            # Test MCP client connection
            with self.tf_mcp_client:
                mcp_tools = self.tf_mcp_client.list_tools_sync()
                mcp_healthy = len(mcp_tools) > 0
            
            return {
                'status': 'healthy' if mcp_healthy else 'degraded',
                'mcp_connection': mcp_healthy,
                'agent_initialized': self.agent is not None,
                'timestamp': self._get_timestamp()
            }
            
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': self._get_timestamp()
            }
    
    def _convert_dict_to_security_finding(self, finding_data: Dict[str, Any]) -> SecurityFinding:
        """Convert dictionary finding data to SecurityFinding object"""
        try:
            # Map severity string to SeverityLevel enum
            severity_str = finding_data.get('severity', 'MEDIUM').upper()
            try:
                severity = SeverityLevel(severity_str)
            except ValueError:
                logger.warning(f"Unknown severity level: {severity_str}, defaulting to MEDIUM")
                severity = SeverityLevel.MEDIUM
            
            # Map remediation_type string to RemediationType enum
            remediation_type_str = finding_data.get('remediation_type', 'manual').lower()
            try:
                remediation_type = RemediationType(remediation_type_str)
            except ValueError:
                logger.warning(f"Unknown remediation type: {remediation_type_str}, defaulting to manual")
                remediation_type = RemediationType.MANUAL
            
            # Create SecurityFinding with required fields and optional Checkov fields
            # Note: Checkov uses 'id' for check_id, and 'file_path' for file
            check_id = finding_data.get('check_id') or finding_data.get('id', '')
            file_path = finding_data.get('file') or finding_data.get('file_path', '')
            
            finding = SecurityFinding(
                id=finding_data.get('id', ''),
                check_id=check_id,
                severity=severity,
                resource=finding_data.get('resource', ''),
                resource_type=finding_data.get('resource_type', ''),
                file=file_path,
                line_number=finding_data.get('line_number') or finding_data.get('line'),
                description=finding_data.get('description', ''),
                remediation_type=remediation_type,
                remediation_guidance=finding_data.get('remediation_guidance'),
                # Additional Checkov fields
                type=finding_data.get('type'),
                fixed=finding_data.get('fixed'),
                fix_details=finding_data.get('fix_details')
            )
            
            return finding
            
        except Exception as e:
            logger.error(f"Error converting finding data to SecurityFinding: {e}")
            logger.error(f"Finding data: {finding_data}")
            raise
    
    def _load_scan_results_from_file(self, scan_id: str) -> Dict[str, Any]:
        """Load scan results from temporary file location using scan ID"""
        import tempfile
        import json
        
        # Construct the file path following the same pattern as Checkov Scanner
        temp_dir = tempfile.gettempdir()
        scan_file_path = os.path.join(temp_dir, scan_id, "checkov_result.json")
        
        logger.info(f"Loading scan results from: {scan_file_path}")
        
        try:
            if not os.path.exists(scan_file_path):
                raise FileNotFoundError(f"Scan results file not found: {scan_file_path}")
            
            with open(scan_file_path, 'r') as f:
                scan_results = json.load(f)
            
            # Ensure the scan results have the expected format for validation
            if 'total_findings' not in scan_results and 'scan_metadata' in scan_results:
                scan_results['total_findings'] = scan_results['scan_metadata'].get('total_findings', len(scan_results.get('findings', [])))
            
            # Add missing fields if needed for validation
            if 'repository_url' not in scan_results:
                scan_results['repository_url'] = 'loaded-from-scan-file'
            if 'commit_sha' not in scan_results:
                scan_results['commit_sha'] = 'unknown'
            
            logger.info(f"Successfully loaded scan results with {scan_results.get('total_findings', 0)} findings")
            return scan_results
            
        except Exception as e:
            logger.error(f"Failed to load scan results from {scan_file_path}: {e}")
            raise
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.utcnow().isoformat()
    
    def _create_working_copy(self, source_path: str, scan_id: str = None) -> str:
        """
        Create a working copy of the Terraform project OR use existing working directory
        
        Args:
            source_path: S3 URI (s3://bucket/path), local folder path, or existing working directory
            scan_id: Optional scan ID for naming the working directory
        
        Returns:
            Path to working directory
        """
        import tempfile
        import shutil
        
        # Check if source_path is an existing directory with Terraform files
        # If it is, use it directly instead of creating a copy
        if os.path.exists(source_path) and os.path.isdir(source_path):
            # Check if it contains Terraform files
            tf_files = [f for f in os.listdir(source_path) if f.endswith('.tf')]
            if tf_files:
                logger.info(f"Using existing working directory: {source_path}")
                return source_path
        
        # Generate working directory name for new copies
        if scan_id:
            working_dir = tempfile.mkdtemp(prefix=f'terraform_remediation_{scan_id}_')
        else:
            working_dir = tempfile.mkdtemp(prefix='terraform_remediation_')
        
        try:
            if source_path.startswith('s3://'):
                # Download from S3
                self._download_from_s3(source_path, working_dir)
                logger.info(f"Downloaded S3 project from {source_path} to {working_dir}")
            else:
                # Copy from local path (only if not already a working directory)
                if not os.path.exists(source_path):
                    raise ValueError(f"Source path does not exist: {source_path}")
                
                # Copy all files from source to working directory
                for item in os.listdir(source_path):
                    src_item = os.path.join(source_path, item)
                    dst_item = os.path.join(working_dir, item)
                    
                    if os.path.isdir(src_item):
                        shutil.copytree(src_item, dst_item)
                    else:
                        shutil.copy2(src_item, dst_item)
                
                logger.info(f"Copied local project from {source_path} to {working_dir}")
            
            return working_dir
            
        except Exception as e:
            # Clean up on error
            if os.path.exists(working_dir):
                shutil.rmtree(working_dir)
            logger.error(f"Failed to create working copy: {e}")
            raise
    
    def _download_from_s3(self, s3_uri: str, destination: str):
        """Download Terraform project from S3 to local directory"""
        try:
            import boto3
            from urllib.parse import urlparse
            
            # Parse S3 URI
            parsed = urlparse(s3_uri)
            bucket = parsed.netloc
            prefix = parsed.path.lstrip('/')
            
            # Initialize S3 client
            s3_client = boto3.client('s3')
            
            # List and download all objects with the prefix
            paginator = s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket, Prefix=prefix)
            
            for page in pages:
                if 'Contents' not in page:
                    continue
                
                for obj in page['Contents']:
                    key = obj['Key']
                    
                    # Skip if it's a directory marker
                    if key.endswith('/'):
                        continue
                    
                    # Calculate relative path
                    relative_path = key[len(prefix):].lstrip('/')
                    local_path = os.path.join(destination, relative_path)
                    
                    # Create directories if needed
                    os.makedirs(os.path.dirname(local_path), exist_ok=True)
                    
                    # Download file
                    s3_client.download_file(bucket, key, local_path)
                    logger.debug(f"Downloaded {key} to {local_path}")
            
            logger.info(f"Downloaded {bucket}/{prefix} to {destination}")
            
        except Exception as e:
            logger.error(f"Failed to download from S3: {e}")
            raise
    
    def _get_modified_files(self, working_dir: str) -> List[str]:
        """Get list of modified Terraform files in working directory"""
        if not working_dir or not os.path.exists(working_dir):
            return []
        
        modified_files = []
        
        try:
            # Walk through working directory and find .tf files
            for root, dirs, files in os.walk(working_dir):
                for file in files:
                    if file.endswith(('.tf', '.tfvars')):
                        # Get relative path from working directory
                        full_path = os.path.join(root, file)
                        relative_path = os.path.relpath(full_path, working_dir)
                        modified_files.append(relative_path)
            
            return modified_files
            
        except Exception as e:
            logger.error(f"Error getting modified files: {e}")
            return []
    
    def cleanup_working_directory(self, working_dir: str):
        """Clean up working directory after remediation"""
        import shutil
        
        try:
            if working_dir and os.path.exists(working_dir):
                shutil.rmtree(working_dir)
                logger.info(f"Cleaned up working directory: {working_dir}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to cleanup working directory {working_dir}: {e}")
            return False

def create_terraform_remediation_agent() -> TerraformRemediationAgent:
    """Factory function to create Terraform Remediation Agent"""
    return TerraformRemediationAgent()

if __name__ == "__main__":
    # Initialize agent for testing
    remediation_agent = TerraformRemediationAgent()
    
    # Print agent info
    agent_info = remediation_agent.get_agent_info()
    print("Terraform Remediation Agent initialized:")
    print(json.dumps(agent_info, indent=2))
    
    # Health check
    health = remediation_agent.health_check()
    print(f"\nHealth Status: {health['status']}")
    
    # Agent will be deployed on AgentCore runtime