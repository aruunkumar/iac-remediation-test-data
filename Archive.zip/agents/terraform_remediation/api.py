"""
HTTP API Wrapper for Terraform Remediation Agent
Provides REST endpoints for AgentCore deployment
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, validator
from typing import Dict, List, Any, Optional
import logging
import json
import os
from datetime import datetime
import traceback

try:
    from .main import TerraformRemediationAgent, create_terraform_remediation_agent
except ImportError:
    # Fallback for direct execution
    from main import TerraformRemediationAgent, create_terraform_remediation_agent
from shared.interfaces import SecurityFinding, SeverityLevel, RemediationType
from shared.utils import ValidationUtils, SecurityUtils

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Terraform Remediation Agent API",
    description="HTTP API for Terraform security remediation using MCP server and Bedrock Knowledge Bases",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Global agent instance
remediation_agent: Optional[TerraformRemediationAgent] = None

# Pydantic models for request/response validation
class SecurityFindingRequest(BaseModel):
    """Security finding input model"""
    id: str = Field(..., description="Unique finding identifier")
    check_id: str = Field(..., description="Checkov check ID")
    severity: str = Field(..., description="Severity level: CRITICAL, HIGH, MEDIUM, LOW")
    resource: str = Field(..., description="Terraform resource name")
    resource_type: str = Field(..., description="AWS resource type")
    file: str = Field(..., description="Terraform file path")
    line_number: Optional[int] = Field(None, description="Line number in file")
    description: str = Field(..., description="Finding description")
    remediation_type: str = Field(..., description="Remediation type: auto or manual")
    
    @validator('severity')
    def validate_severity(cls, v):
        valid_severities = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
        if v.upper() not in valid_severities:
            raise ValueError(f'Severity must be one of: {valid_severities}')
        return v.upper()
    
    @validator('remediation_type')
    def validate_remediation_type(cls, v):
        valid_types = ['auto', 'manual']
        if v.lower() not in valid_types:
            raise ValueError(f'Remediation type must be one of: {valid_types}')
        return v.lower()

class ScanResultsRequest(BaseModel):
    """Scan results input model"""
    scan_id: str = Field(..., description="Unique scan identifier")
    repository_url: str = Field(..., description="Repository URL")
    commit_sha: str = Field(..., description="Git commit SHA")
    total_findings: int = Field(..., ge=0, description="Total number of findings")
    findings: List[SecurityFindingRequest] = Field(..., description="List of security findings")
    scan_metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional scan metadata")
    
    @validator('repository_url')
    def validate_repository_url(cls, v):
        # Basic URL validation and sanitization
        sanitized_url = SecurityUtils.sanitize_repository_url(v)
        if not sanitized_url or len(sanitized_url) < 10:
            raise ValueError('Invalid repository URL')
        return sanitized_url

class ScanIdOnlyRequest(BaseModel):
    """Scan ID input model for loading results from file"""
    scan_id: str = Field(..., description="Unique scan identifier to load results from temporary file")
    source_path: Optional[str] = Field(None, description="Optional source path (S3 URI or local path) to create working copy. If not provided, will be retrieved from scan metadata if available.")

class RemediationResponse(BaseModel):
    """Remediation response model"""
    success: bool = Field(..., description="Whether remediation was successful")
    scan_id: str = Field(..., description="Scan identifier")
    fixes_applied: int = Field(..., description="Number of auto-fixes applied")
    manual_interventions: int = Field(..., description="Number of manual interventions required")
    validation_errors: List[str] = Field(default_factory=list, description="Validation errors")
    processing_time_seconds: float = Field(..., description="Processing time in seconds")
    agent_info: Dict[str, Any] = Field(default_factory=dict, description="Agent information")

class RemediationDetailsResponse(BaseModel):
    """Detailed remediation response model"""
    scan_id: str
    fixes: List[Dict[str, Any]]
    manual_interventions: List[Dict[str, Any]]
    validation_errors: List[str]
    knowledge_base_queries: List[Dict[str, Any]]
    processing_metadata: Dict[str, Any]

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = Field(..., description="Health status: healthy, degraded, unhealthy")
    timestamp: str = Field(..., description="Health check timestamp")
    agent_status: Dict[str, Any] = Field(default_factory=dict, description="Agent status details")
    mcp_connection: bool = Field(..., description="MCP server connection status")
    version: str = Field(..., description="API version")

class ErrorResponse(BaseModel):
    """Error response model"""
    error: str = Field(..., description="Error message")
    error_code: str = Field(..., description="Error code")
    timestamp: str = Field(..., description="Error timestamp")
    request_id: Optional[str] = Field(None, description="Request identifier")

# Dependency functions
async def get_current_agent() -> TerraformRemediationAgent:
    """Get current agent instance"""
    global remediation_agent
    if remediation_agent is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Remediation agent not initialized"
        )
    return remediation_agent

async def validate_auth_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Validate authentication token"""
    token = credentials.credentials
    
    # In production, implement proper JWT validation
    # For now, check for basic API key
    expected_token = os.getenv('REMEDIATION_API_TOKEN', 'dev-token-123')
    
    if token != expected_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return token

# API Endpoints
@app.on_event("startup")
async def startup_event():
    """Initialize agent on startup"""
    global remediation_agent
    try:
        logger.info("Initializing Terraform Remediation Agent...")
        remediation_agent = create_terraform_remediation_agent()
        logger.info("Terraform Remediation Agent initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}")
        logger.error(traceback.format_exc())

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    global remediation_agent
    logger.info("Shutting down Terraform Remediation Agent API")
    remediation_agent = None

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        global remediation_agent
        
        if remediation_agent is None:
            return HealthResponse(
                status="unhealthy",
                timestamp=datetime.utcnow().isoformat(),
                agent_status={"initialized": False},
                mcp_connection=False,
                version="1.0.0"
            )
        
        agent_health = remediation_agent.health_check()
        
        return HealthResponse(
            status=agent_health.get('status', 'unknown'),
            timestamp=agent_health.get('timestamp', datetime.utcnow().isoformat()),
            agent_status=agent_health,
            mcp_connection=agent_health.get('mcp_connection', False),
            version="1.0.0"
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            timestamp=datetime.utcnow().isoformat(),
            agent_status={"error": str(e)},
            mcp_connection=False,
            version="1.0.0"
        )

@app.get("/info")
async def get_agent_info(agent: TerraformRemediationAgent = Depends(get_current_agent)):
    """Get agent information and capabilities"""
    try:
        return agent.get_agent_info()
    except Exception as e:
        logger.error(f"Error getting agent info: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get agent info: {str(e)}"
        )

@app.post("/remediate/scan-id")
async def remediate_from_scan_id(
    scan_request: ScanIdOnlyRequest,
    agent: TerraformRemediationAgent = Depends(get_current_agent),
    token: str = Depends(validate_auth_token)
):
    """Process scan results from scan ID and apply remediation to working copy"""
    start_time = datetime.utcnow()
    request_id = f"rem_sid_{int(start_time.timestamp())}"
    
    try:
        logger.info(f"Processing remediation request {request_id} for scan ID {scan_request.scan_id}")
        
        # Apply remediation using scan ID with optional working copy
        result = agent.remediate_violations_from_scan_id(
            scan_request.scan_id,
            source_path=scan_request.source_path
        )
        
        # Calculate processing time
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        remediation_results = result['remediation_results']
        
        # Prepare enhanced response
        response = {
            'success': True,
            'scan_id': scan_request.scan_id,
            'fixes_applied': len(remediation_results.fixes),
            'manual_interventions': len(remediation_results.manual_interventions),
            'validation_errors': remediation_results.validation_errors,
            'processing_time_seconds': processing_time,
            'working_directory': result.get('working_directory'),
            'modified_files': result.get('modified_files', []),
            'agent_info': agent.get_agent_info(),
            'next_steps': _generate_next_steps(result) if result.get('working_directory') else []
        }
        
        logger.info(f"Remediation completed for {request_id}: "
                   f"{response['fixes_applied']} fixes, {response['manual_interventions']} manual items")
        
        if result.get('working_directory'):
            logger.info(f"Working directory created at: {result['working_directory']}")
        
        return JSONResponse(content=response)
        
    except FileNotFoundError as e:
        logger.error(f"Scan results not found for {request_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan results not found for scan ID: {scan_request.scan_id}"
        )
    except Exception as e:
        logger.error(f"Remediation failed for {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        return RemediationResponse(
            success=False,
            scan_id=scan_request.scan_id,
            fixes_applied=0,
            manual_interventions=0,
            validation_errors=[f"Remediation error: {str(e)}"],
            processing_time_seconds=processing_time,
            agent_info={}
        )

@app.post("/remediate", response_model=RemediationResponse)
async def remediate_scan_results(
    scan_request: ScanResultsRequest,
    agent: TerraformRemediationAgent = Depends(get_current_agent),
    token: str = Depends(validate_auth_token)
):
    """Process scan results and apply remediation"""
    start_time = datetime.utcnow()
    request_id = f"rem_{int(start_time.timestamp())}"
    
    try:
        logger.info(f"Processing remediation request {request_id} for scan {scan_request.scan_id}")
        
        # Validate scan results format
        if not ValidationUtils.validate_scan_results(scan_request.dict()):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid scan results format"
            )
        
        # Convert request to internal format
        scan_results = _convert_request_to_scan_results(scan_request)
        
        # Apply remediation
        remediation_results = agent.remediate_violations(scan_results)
        
        # Calculate processing time
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        # Prepare response
        response = RemediationResponse(
            success=True,
            scan_id=scan_request.scan_id,
            fixes_applied=len(remediation_results.fixes),
            manual_interventions=len(remediation_results.manual_interventions),
            validation_errors=remediation_results.validation_errors,
            processing_time_seconds=processing_time,
            agent_info=agent.get_agent_info()
        )
        
        logger.info(f"Remediation completed for {request_id}: "
                   f"{response.fixes_applied} fixes, {response.manual_interventions} manual items")
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Remediation failed for {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        return RemediationResponse(
            success=False,
            scan_id=scan_request.scan_id,
            fixes_applied=0,
            manual_interventions=0,
            validation_errors=[f"Remediation error: {str(e)}"],
            processing_time_seconds=processing_time,
            agent_info={}
        )

@app.post("/remediate/scan-id/detailed", response_model=RemediationDetailsResponse)
async def remediate_from_scan_id_detailed(
    scan_request: ScanIdOnlyRequest,
    agent: TerraformRemediationAgent = Depends(get_current_agent),
    token: str = Depends(validate_auth_token)
):
    """Process scan results from scan ID and return detailed remediation information"""
    start_time = datetime.utcnow()
    request_id = f"rem_sid_det_{int(start_time.timestamp())}"
    
    try:
        logger.info(f"Processing detailed remediation request {request_id} for scan ID {scan_request.scan_id}")
        
        # Apply remediation using scan ID
        result = agent.remediate_violations_from_scan_id(scan_request.scan_id)
        
        # Extract the nested remediation_results object from the dict
        remediation_results = result['remediation_results']
        
        # Calculate processing time
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        # Convert results to response format
        response = RemediationDetailsResponse(
            scan_id=scan_request.scan_id,
            fixes=_convert_fixes_to_dict(remediation_results.fixes),
            manual_interventions=_convert_manual_interventions_to_dict(remediation_results.manual_interventions),
            validation_errors=remediation_results.validation_errors,
            knowledge_base_queries=remediation_results.knowledge_base_queries,
            processing_metadata={
                'processing_time_seconds': processing_time,
                'request_id': request_id,
                'timestamp': datetime.utcnow().isoformat(),
                'agent_version': agent.get_agent_info().get('version', '1.0.0'),
                'loaded_from_scan_id': True,
                'working_directory': result.get('working_directory'),
                'modified_files': result.get('modified_files', [])
            }
        )
        
        logger.info(f"Detailed remediation completed for {request_id}")
        
        return response
        
    except FileNotFoundError as e:
        logger.error(f"Scan results not found for {request_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan results not found for scan ID: {scan_request.scan_id}"
        )
    except Exception as e:
        logger.error(f"Detailed remediation failed for {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Detailed remediation failed: {str(e)}"
        )

@app.post("/remediate/detailed", response_model=RemediationDetailsResponse)
async def remediate_scan_results_detailed(
    scan_request: ScanResultsRequest,
    agent: TerraformRemediationAgent = Depends(get_current_agent),
    token: str = Depends(validate_auth_token)
):
    """Process scan results and return detailed remediation information"""
    start_time = datetime.utcnow()
    request_id = f"rem_det_{int(start_time.timestamp())}"
    
    try:
        logger.info(f"Processing detailed remediation request {request_id} for scan {scan_request.scan_id}")
        
        # Validate scan results format
        if not ValidationUtils.validate_scan_results(scan_request.dict()):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid scan results format"
            )
        
        # Convert request to internal format
        scan_results = _convert_request_to_scan_results(scan_request)
        
        # Apply remediation
        remediation_results = agent.remediate_violations(scan_results)
        
        # Calculate processing time
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        # Convert results to response format
        response = RemediationDetailsResponse(
            scan_id=scan_request.scan_id,
            fixes=_convert_fixes_to_dict(remediation_results.fixes),
            manual_interventions=_convert_manual_interventions_to_dict(remediation_results.manual_interventions),
            validation_errors=remediation_results.validation_errors,
            knowledge_base_queries=remediation_results.knowledge_base_queries,
            processing_metadata={
                'processing_time_seconds': processing_time,
                'request_id': request_id,
                'timestamp': datetime.utcnow().isoformat(),
                'agent_version': agent.get_agent_info().get('version', '1.0.0')
            }
        )
        
        logger.info(f"Detailed remediation completed for {request_id}")
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Detailed remediation failed for {request_id}: {e}")
        logger.error(traceback.format_exc())
        
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Detailed remediation failed: {str(e)}"
        )

@app.post("/validate")
async def validate_scan_results(
    scan_request: ScanResultsRequest,
    token: str = Depends(validate_auth_token)
):
    """Validate scan results format without processing"""
    try:
        # Validate request format
        is_valid = ValidationUtils.validate_scan_results(scan_request.dict())
        
        validation_result = {
            'valid': is_valid,
            'scan_id': scan_request.scan_id,
            'total_findings': scan_request.total_findings,
            'findings_count': len(scan_request.findings),
            'validation_timestamp': datetime.utcnow().isoformat()
        }
        
        if not is_valid:
            validation_result['errors'] = ['Invalid scan results format']
        
        return validation_result
        
    except Exception as e:
        logger.error(f"Validation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Validation error: {str(e)}"
        )

@app.delete("/remediation/cleanup/{working_dir_name}")
async def cleanup_working_directory(
    working_dir_name: str,
    agent: TerraformRemediationAgent = Depends(get_current_agent),
    token: str = Depends(validate_auth_token)
):
    """Clean up working directory after remediation review"""
    try:
        import tempfile
        
        # Construct full path (security: only allow cleanup of our temp directories)
        if not working_dir_name.startswith('terraform_remediation_'):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid working directory name"
            )
        
        working_dir = os.path.join(tempfile.gettempdir(), working_dir_name)
        
        if not os.path.exists(working_dir):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Working directory not found: {working_dir_name}"
            )
        
        # Clean up
        success = agent.cleanup_working_directory(working_dir)
        
        if success:
            return {
                'message': f'Successfully cleaned up working directory',
                'working_directory': working_dir_name,
                'timestamp': datetime.utcnow().isoformat()
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to cleanup working directory"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Cleanup error: {str(e)}"
        )

def _generate_next_steps(result: Dict[str, Any]) -> List[str]:
    """Generate next steps for user after remediation"""
    steps = []
    
    if result.get('working_directory'):
        steps.append(f"Review changes in working directory: {result['working_directory']}")
        
        if result.get('modified_files'):
            steps.append(f"Modified files: {', '.join(result['modified_files'][:5])}")
            if len(result['modified_files']) > 5:
                steps.append(f"... and {len(result['modified_files']) - 5} more files")
        
        steps.append("Run 'terraform plan' in working directory to validate changes")
        steps.append("Review TODO comments for manual interventions")
        steps.append("Copy changes back to your repository when ready")
        steps.append("Use DELETE /remediation/cleanup/{working_dir_name} to clean up")
    
    return steps

# Helper functions
def _convert_request_to_scan_results(request: ScanResultsRequest) -> Dict[str, Any]:
    """Convert API request to internal scan results format"""
    findings = []
    
    for finding_req in request.findings:
        finding = SecurityFinding(
            id=finding_req.id,
            check_id=finding_req.check_id,
            severity=SeverityLevel(finding_req.severity),
            resource=finding_req.resource,
            resource_type=finding_req.resource_type,
            file=finding_req.file,
            line_number=finding_req.line_number,
            description=finding_req.description,
            remediation_type=RemediationType(finding_req.remediation_type)
        )
        findings.append(finding)
    
    return {
        'scan_id': request.scan_id,
        'repository_url': request.repository_url,
        'commit_sha': request.commit_sha,
        'total_findings': request.total_findings,
        'findings': findings,
        'scan_metadata': request.scan_metadata
    }

def _convert_fixes_to_dict(fixes: List) -> List[Dict[str, Any]]:
    """Convert remediation fixes to dictionary format"""
    result = []
    
    for fix in fixes:
        fix_dict = {
            'violation_id': fix.violation_id,
            'check_id': fix.check_id,
            'file': fix.file,
            'resource': fix.resource,
            'fix_applied': fix.fix_applied,
            'knowledge_base_reference': fix.knowledge_base_reference
        }
        result.append(fix_dict)
    
    return result

def _convert_manual_interventions_to_dict(interventions: List) -> List[Dict[str, Any]]:
    """Convert manual interventions to dictionary format"""
    result = []
    
    for intervention in interventions:
        intervention_dict = {
            'violation_id': intervention.violation_id,
            'check_id': intervention.check_id,
            'file': intervention.file,
            'resource': intervention.resource,
            'todo_comment': intervention.todo_comment,
            'detailed_guidance': intervention.detailed_guidance
        }
        result.append(intervention_dict)
    
    return result

# Error handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handle HTTP exceptions"""
    return {
        "error": exc.detail,
        "error_code": f"HTTP_{exc.status_code}",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}")
    logger.error(traceback.format_exc())
    
    return {
        "error": "Internal server error",
        "error_code": "INTERNAL_ERROR",
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    
    # Configuration
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8001"))
    log_level = os.getenv("LOG_LEVEL", "info")
    
    logger.info(f"Starting Terraform Remediation Agent API on {host}:{port}")
    
    uvicorn.run(
        "api:app",
        host=host,
        port=port,
        log_level=log_level,
        reload=False
    )