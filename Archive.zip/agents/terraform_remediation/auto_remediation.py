"""
Enhanced Auto-Remediation Module
Leverages MCP server's built-in automatic fix capabilities with Bedrock Knowledge Base enhancement
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import json
import re

logger = logging.getLogger(__name__)

class RemediationComplexity(Enum):
    """Complexity levels for auto-remediation"""
    SIMPLE = "simple"           # Direct configuration changes
    MODERATE = "moderate"       # Multiple related changes
    COMPLEX = "complex"         # Requires business logic decisions
    UNSAFE = "unsafe"           # High risk of breaking functionality

class AutoRemediationCapability(Enum):
    """MCP server auto-remediation capabilities"""
    ENCRYPTION_FIXES = "encryption_fixes"
    ACCESS_CONTROL_FIXES = "access_control_fixes"
    LOGGING_FIXES = "logging_fixes"
    BACKUP_FIXES = "backup_fixes"
    NETWORK_SECURITY_FIXES = "network_security_fixes"
    COMPLIANCE_FIXES = "compliance_fixes"

@dataclass
class RemediationPattern:
    """Auto-remediation pattern definition"""
    check_id: str
    resource_types: List[str]
    complexity: RemediationComplexity
    mcp_capability: AutoRemediationCapability
    fix_template: str
    validation_rules: List[str]
    prerequisites: List[str]

class EnhancedAutoRemediation:
    """Enhanced auto-remediation using MCP server capabilities and Bedrock KB"""
    
    def __init__(self, agent, terraform_kb_id: str, well_architected_kb_id: Optional[str] = None):
        self.agent = agent
        self.terraform_kb_id = terraform_kb_id
        self.well_architected_kb_id = well_architected_kb_id  # Can be None - use MCP server instead
        self.remediation_patterns = self._initialize_remediation_patterns()
        self.mcp_tools = {
            'search_aws_provider_docs': 'SearchAwsProviderDocs',
            'search_awscc_provider_docs': 'SearchAwsccProviderDocs',
            'search_aws_ia_modules': 'SearchSpecificAwsIaModules'
        }
    
    def _initialize_remediation_patterns(self) -> Dict[str, RemediationPattern]:
        """Initialize known auto-remediation patterns"""
        patterns = {}
        
        # S3 Bucket Encryption
        patterns['CKV_AWS_141'] = RemediationPattern(
            check_id='CKV_AWS_141',
            resource_types=['aws_s3_bucket'],
            complexity=RemediationComplexity.SIMPLE,
            mcp_capability=AutoRemediationCapability.ENCRYPTION_FIXES,
            fix_template='server_side_encryption_configuration',
            validation_rules=['encryption_enabled', 'kms_key_valid'],
            prerequisites=[]
        )
        
        # S3 Public Access Block
        patterns['CKV_AWS_53'] = RemediationPattern(
            check_id='CKV_AWS_53',
            resource_types=['aws_s3_bucket', 'aws_s3_bucket_public_access_block'],
            complexity=RemediationComplexity.SIMPLE,
            mcp_capability=AutoRemediationCapability.ACCESS_CONTROL_FIXES,
            fix_template='public_access_block',
            validation_rules=['public_access_blocked'],
            prerequisites=[]
        )
        
        # RDS Encryption
        patterns['CKV_AWS_16'] = RemediationPattern(
            check_id='CKV_AWS_16',
            resource_types=['aws_db_instance'],
            complexity=RemediationComplexity.SIMPLE,
            mcp_capability=AutoRemediationCapability.ENCRYPTION_FIXES,
            fix_template='storage_encrypted',
            validation_rules=['encryption_enabled'],
            prerequisites=[]
        )
        
        # CloudTrail Logging
        patterns['CKV_AWS_35'] = RemediationPattern(
            check_id='CKV_AWS_35',
            resource_types=['aws_cloudtrail'],
            complexity=RemediationComplexity.MODERATE,
            mcp_capability=AutoRemediationCapability.LOGGING_FIXES,
            fix_template='cloudwatch_logs_group_arn',
            validation_rules=['logging_enabled', 'log_group_exists'],
            prerequisites=['cloudwatch_log_group']
        )
        
        # Security Group Ingress
        patterns['CKV_AWS_24'] = RemediationPattern(
            check_id='CKV_AWS_24',
            resource_types=['aws_security_group', 'aws_security_group_rule'],
            complexity=RemediationComplexity.COMPLEX,  # Requires business logic
            mcp_capability=AutoRemediationCapability.NETWORK_SECURITY_FIXES,
            fix_template='restrict_ingress_rules',
            validation_rules=['no_wide_open_ingress'],
            prerequisites=[]
        )
        
        return patterns
    
    def assess_auto_fix_capability(self, finding) -> Dict[str, Any]:
        """Assess if finding can be auto-fixed using MCP server capabilities"""
        try:
            check_id = finding.check_id
            resource_type = finding.resource_type
            
            # Check if we have a known pattern
            pattern = self.remediation_patterns.get(check_id)
            
            if not pattern:
                return self._assess_unknown_finding(finding)
            
            # Check resource type compatibility
            if resource_type not in pattern.resource_types:
                return {
                    'can_auto_fix': False,
                    'reason': f'Resource type {resource_type} not supported for {check_id}',
                    'complexity': RemediationComplexity.UNSAFE.value
                }
            
            # Use MCP server to validate fix capability
            mcp_assessment = self._query_mcp_fix_capability(finding, pattern)
            
            # Enhance with Bedrock KB guidance
            kb_assessment = self._query_kb_fix_guidance(finding)
            
            # Combine assessments
            final_assessment = self._combine_assessments(pattern, mcp_assessment, kb_assessment)
            
            return final_assessment
            
        except Exception as e:
            logger.error(f"Error assessing auto-fix capability: {e}")
            return {
                'can_auto_fix': False,
                'reason': f'Assessment error: {e}',
                'complexity': RemediationComplexity.UNSAFE.value
            }
    
    def apply_enhanced_auto_fix(self, finding) -> Dict[str, Any]:
        """Apply auto-fix using MCP server's built-in capabilities enhanced with KB guidance"""
        try:
            assessment = self.assess_auto_fix_capability(finding)
            
            if not assessment.get('can_auto_fix', False):
                return {
                    'success': False,
                    'reason': assessment.get('reason', 'Cannot auto-fix'),
                    'fix_applied': None
                }
            
            pattern = self.remediation_patterns.get(finding.check_id)
            
            # Step 1: Get MCP server's automatic fix
            mcp_fix = self._apply_mcp_automatic_fix(finding, pattern)
            
            # Step 2: Enhance with Bedrock KB best practices
            enhanced_fix = self._enhance_fix_with_kb_guidance(finding, mcp_fix)
            
            # Step 3: Validate using MCP server's validation tools
            validation_result = self._validate_fix_with_mcp(finding, enhanced_fix)
            
            if not validation_result.get('valid', False):
                return {
                    'success': False,
                    'reason': 'Fix validation failed',
                    'validation_errors': validation_result.get('errors', []),
                    'fix_applied': None
                }
            
            # Step 4: Apply the validated fix
            applied_fix = self._apply_validated_fix(finding, enhanced_fix)
            
            return {
                'success': True,
                'fix_applied': applied_fix,
                'mcp_fix': mcp_fix,
                'kb_enhancements': enhanced_fix.get('kb_enhancements', {}),
                'validation_result': validation_result
            }
            
        except Exception as e:
            logger.error(f"Error applying enhanced auto-fix: {e}")
            return {
                'success': False,
                'reason': f'Auto-fix error: {e}',
                'fix_applied': None
            }
    
    def _assess_unknown_finding(self, finding) -> Dict[str, Any]:
        """Assess unknown finding using MCP server's general capabilities"""
        assessment_prompt = f"""
        Use MCP Terraform server's AWS best practices resource to assess if this security finding 
        can be automatically fixed:
        
        Check ID: {finding.check_id}
        Resource Type: {finding.resource_type}
        Description: {finding.description}
        
        Use MCP server's SearchAwsProviderDocs tool to determine:
        1. Is this a known security pattern with standard fixes?
        2. What is the complexity and risk level of automatic remediation?
        3. Are there MCP server tools available for this type of fix?
        
        Return assessment with can_auto_fix recommendation and reasoning.
        """
        
        assessment_response = self.agent(assessment_prompt)
        
        # Parse the response to determine capability
        can_auto_fix = self._parse_mcp_assessment(assessment_response)
        complexity = self._determine_complexity_from_response(assessment_response)
        
        return {
            'can_auto_fix': can_auto_fix,
            'reason': assessment_response,
            'complexity': complexity.value,
            'mcp_assessment': assessment_response
        }
    
    def _query_mcp_fix_capability(self, finding, pattern: RemediationPattern) -> Dict[str, Any]:
        """Query MCP server for specific fix capability"""
        mcp_query_prompt = f"""
        Use MCP Terraform server's automatic fix capabilities to assess this security finding:
        
        Check ID: {finding.check_id}
        Resource: {finding.resource}
        Resource Type: {finding.resource_type}
        File: {finding.file}
        
        Use these MCP tools:
        - {self.mcp_tools['search_aws_provider_docs']} for AWS provider documentation
        - {self.mcp_tools['search_awscc_provider_docs']} for AWSCC provider documentation
        - {self.mcp_tools['search_aws_ia_modules']} for AWS-IA module guidance
        
        Determine:
        1. Can MCP server automatically fix this issue?
        2. What specific MCP tools/capabilities are available?
        3. What are the prerequisites and validation requirements?
        
        Pattern complexity: {pattern.complexity.value}
        MCP capability: {pattern.mcp_capability.value}
        """
        
        mcp_response = self.agent(mcp_query_prompt)
        
        return {
            'mcp_can_fix': self._parse_mcp_capability(mcp_response),
            'mcp_tools_available': self._extract_mcp_tools(mcp_response),
            'prerequisites': self._extract_prerequisites(mcp_response),
            'mcp_response': mcp_response
        }
    
    def _query_kb_fix_guidance(self, finding) -> Dict[str, Any]:
        """Query Bedrock Knowledge Base for enhanced fix guidance"""
        kb_query_prompt = f"""
        Query Bedrock Knowledge Base for enhanced Terraform remediation guidance:
        
        Finding: {finding.check_id} - {finding.description}
        Resource Type: {finding.resource_type}
        
        Query the Terraform Best Practices KB ({self.terraform_kb_id}) for:
        - Terraform AWS Provider best practices and patterns
        - Resource-specific security configurations
        - Advanced remediation techniques
        
        For Well-Architected guidance, use MCP server's SearchAwsProviderDocs tool.
        
        Focus on:
        - Latest Terraform AWS provider patterns
        - Implementation best practices
        - Security configuration patterns
        """
        
        kb_response = self.agent(kb_query_prompt)
        
        return {
            'kb_guidance': kb_response,
            'enhanced_patterns': self._extract_enhanced_patterns(kb_response),
            'security_principles': self._extract_security_principles(kb_response)
        }
    
    def _combine_assessments(self, pattern: RemediationPattern, mcp_assessment: Dict, kb_assessment: Dict) -> Dict[str, Any]:
        """Combine MCP and KB assessments to make final auto-fix decision"""
        
        # Base decision on pattern complexity
        base_can_fix = pattern.complexity in [RemediationComplexity.SIMPLE, RemediationComplexity.MODERATE]
        
        # Factor in MCP capability
        mcp_can_fix = mcp_assessment.get('mcp_can_fix', False)
        
        # Consider KB guidance
        kb_supports_fix = 'safe to automate' in kb_assessment.get('kb_guidance', '').lower()
        
        # Final decision logic
        can_auto_fix = base_can_fix and mcp_can_fix and (
            pattern.complexity == RemediationComplexity.SIMPLE or kb_supports_fix
        )
        
        return {
            'can_auto_fix': can_auto_fix,
            'complexity': pattern.complexity.value,
            'mcp_capability': pattern.mcp_capability.value,
            'mcp_assessment': mcp_assessment,
            'kb_assessment': kb_assessment,
            'decision_factors': {
                'pattern_complexity': pattern.complexity.value,
                'mcp_supports': mcp_can_fix,
                'kb_supports': kb_supports_fix
            }
        }
    
    def _apply_mcp_automatic_fix(self, finding, pattern: RemediationPattern) -> Dict[str, Any]:
        """Apply MCP server's built-in automatic fix"""
        fix_prompt = f"""
        Use MCP Terraform server's automatic fix capabilities to generate the fix for:
        
        Check ID: {finding.check_id}
        Resource: {finding.resource}
        File: {finding.file}
        
        Apply the {pattern.mcp_capability.value} using:
        - MCP server's {self.mcp_tools['search_aws_provider_docs']} for AWS documentation
        - MCP server's {self.mcp_tools['search_awscc_provider_docs']} for AWSCC documentation
        - Fix template pattern: {pattern.fix_template}
        
        Generate the specific Terraform configuration changes needed.
        """
        
        mcp_fix_response = self.agent(fix_prompt)
        
        return {
            'fix_type': pattern.mcp_capability.value,
            'fix_template': pattern.fix_template,
            'terraform_changes': mcp_fix_response,
            'mcp_tools_used': self._extract_mcp_tools_used(mcp_fix_response)
        }
    
    def _enhance_fix_with_kb_guidance(self, finding, mcp_fix: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance MCP fix with Bedrock Knowledge Base best practices"""
        enhancement_prompt = f"""
        Enhance this MCP-generated fix with Terraform best practices from Bedrock Knowledge Base:
        
        Original MCP Fix:
        {mcp_fix.get('terraform_changes', '')}
        
        Query the Terraform Best Practices KB ({self.terraform_kb_id}) to enhance the fix with:
        - Latest Terraform AWS provider patterns and best practices
        - Advanced security configurations
        - Performance optimizations
        - Compliance enhancements
        - Latest provider features and recommended patterns
        
        For Well-Architected security principles, use MCP server's SearchAwsProviderDocs tool.
        
        Return enhanced Terraform configuration with best practice improvements.
        """
        
        enhanced_response = self.agent(enhancement_prompt)
        
        return {
            'original_mcp_fix': mcp_fix,
            'enhanced_terraform': enhanced_response,
            'kb_enhancements': self._extract_kb_enhancements(enhanced_response),
            'additional_security': self._extract_additional_security(enhanced_response)
        }
    
    def _validate_fix_with_mcp(self, finding, enhanced_fix: Dict[str, Any]) -> Dict[str, Any]:
        """Validate enhanced fix using MCP server's validation tools"""
        validation_prompt = f"""
        Use MCP Terraform server's validation tools to validate this enhanced fix:
        
        Enhanced Fix:
        {enhanced_fix.get('enhanced_terraform', '')}
        
        Validate:
        1. Terraform syntax correctness
        2. AWS provider resource configuration
        3. Security configuration completeness
        4. No breaking changes to existing functionality
        
        Use MCP server's built-in validation capabilities.
        """
        
        validation_response = self.agent(validation_prompt)
        
        return {
            'valid': self._parse_validation_result(validation_response),
            'validation_response': validation_response,
            'errors': self._extract_validation_errors(validation_response),
            'warnings': self._extract_validation_warnings(validation_response)
        }
    
    def _apply_validated_fix(self, finding, enhanced_fix: Dict[str, Any]) -> Dict[str, Any]:
        """Apply the validated enhanced fix"""
        apply_prompt = f"""
        Apply this validated enhanced fix to the Terraform file:
        
        File: {finding.file}
        Resource: {finding.resource}
        Enhanced Fix: {enhanced_fix.get('enhanced_terraform', '')}
        
        Apply the changes while:
        1. Preserving existing functionality
        2. Adding security improvements
        3. Including descriptive comments about the changes
        4. Following Terraform best practices
        """
        
        apply_response = self.agent(apply_prompt)
        
        return {
            'file_modified': finding.file,
            'resource_updated': finding.resource,
            'changes_applied': apply_response,
            'fix_summary': self._generate_fix_summary(finding, enhanced_fix),
            'agent_comment': f"# AGENT-FIXED: {finding.check_id} - Enhanced auto-remediation with MCP + Bedrock KB"
        }
    
    # Helper methods for parsing responses
    def _parse_mcp_assessment(self, response: str) -> bool:
        """Parse MCP assessment response"""
        response_lower = response.lower()
        positive_indicators = ['can be auto-fixed', 'automatic fix available', 'mcp can handle']
        return any(indicator in response_lower for indicator in positive_indicators)
    
    def _parse_mcp_capability(self, response: str) -> bool:
        """Parse MCP capability response"""
        response_lower = response.lower()
        capability_indicators = ['mcp tools available', 'automatic fix supported', 'built-in capability']
        return any(indicator in response_lower for indicator in capability_indicators)
    
    def _determine_complexity_from_response(self, response: str) -> RemediationComplexity:
        """Determine complexity from assessment response"""
        response_lower = response.lower()
        
        if any(term in response_lower for term in ['simple', 'straightforward', 'direct']):
            return RemediationComplexity.SIMPLE
        elif any(term in response_lower for term in ['moderate', 'multiple changes', 'coordination']):
            return RemediationComplexity.MODERATE
        elif any(term in response_lower for term in ['complex', 'business logic', 'manual review']):
            return RemediationComplexity.COMPLEX
        else:
            return RemediationComplexity.UNSAFE
    
    def _extract_mcp_tools(self, response: str) -> List[str]:
        """Extract MCP tools mentioned in response"""
        tools = []
        # Look for MCP tool names
        mcp_tool_names = [
            'SearchAwsProviderDocs', 'SearchAwsccProviderDocs', 'SearchSpecificAwsIaModules'
        ]
        
        for tool_name in mcp_tool_names:
            if tool_name in response:
                tools.append(tool_name)
        
        return tools
    
    def _extract_prerequisites(self, response: str) -> List[str]:
        """Extract prerequisites from response"""
        # Simple extraction - look for prerequisite patterns
        prerequisites = []
        if 'kms key' in response.lower():
            prerequisites.append('kms_key')
        if 'log group' in response.lower():
            prerequisites.append('cloudwatch_log_group')
        return prerequisites
    
    def _extract_enhanced_patterns(self, response: str) -> List[str]:
        """Extract enhanced patterns from KB response"""
        patterns = []
        if 'encryption' in response.lower():
            patterns.append('enhanced_encryption')
        if 'monitoring' in response.lower():
            patterns.append('enhanced_monitoring')
        return patterns
    
    def _extract_security_principles(self, response: str) -> List[str]:
        """Extract security principles from response"""
        principles = []
        if 'least privilege' in response.lower():
            principles.append('least_privilege')
        if 'defense in depth' in response.lower():
            principles.append('defense_in_depth')
        return principles
    
    def _extract_mcp_tools_used(self, response: str) -> List[str]:
        """Extract MCP tools used in fix"""
        return self._extract_mcp_tools(response)
    
    def _extract_kb_enhancements(self, response: str) -> Dict[str, Any]:
        """Extract KB enhancements from response"""
        return {
            'additional_configs': self._extract_additional_configs(response),
            'best_practices': self._extract_best_practices(response)
        }
    
    def _extract_additional_security(self, response: str) -> List[str]:
        """Extract additional security measures"""
        security_measures = []
        if 'access logging' in response.lower():
            security_measures.append('access_logging')
        if 'versioning' in response.lower():
            security_measures.append('versioning')
        return security_measures
    
    def _extract_additional_configs(self, response: str) -> List[str]:
        """Extract additional configurations"""
        configs = []
        # Simple pattern matching for common configurations
        if 'lifecycle' in response.lower():
            configs.append('lifecycle_configuration')
        if 'notification' in response.lower():
            configs.append('notification_configuration')
        return configs
    
    def _extract_best_practices(self, response: str) -> List[str]:
        """Extract best practices mentioned"""
        practices = []
        if 'tagging' in response.lower():
            practices.append('resource_tagging')
        if 'naming convention' in response.lower():
            practices.append('naming_conventions')
        return practices
    
    def _parse_validation_result(self, response: str) -> bool:
        """Parse validation result"""
        response_lower = response.lower()
        success_indicators = ['validation passed', 'no errors', 'syntax correct']
        error_indicators = ['validation failed', 'errors found', 'syntax error']
        
        has_success = any(indicator in response_lower for indicator in success_indicators)
        has_errors = any(indicator in response_lower for indicator in error_indicators)
        
        return has_success and not has_errors
    
    def _extract_validation_errors(self, response: str) -> List[str]:
        """Extract validation errors"""
        errors = []
        if 'syntax error' in response.lower():
            errors.append('syntax_error')
        if 'invalid configuration' in response.lower():
            errors.append('invalid_configuration')
        return errors
    
    def _extract_validation_warnings(self, response: str) -> List[str]:
        """Extract validation warnings"""
        warnings = []
        if 'deprecated' in response.lower():
            warnings.append('deprecated_usage')
        if 'best practice' in response.lower():
            warnings.append('best_practice_violation')
        return warnings
    
    def _generate_fix_summary(self, finding, enhanced_fix: Dict[str, Any]) -> str:
        """Generate summary of applied fix"""
        return f"""
Enhanced auto-remediation applied for {finding.check_id}:
- MCP server automatic fix: {enhanced_fix.get('original_mcp_fix', {}).get('fix_type', 'N/A')}
- Bedrock KB enhancements: {len(enhanced_fix.get('kb_enhancements', {}).get('additional_configs', []))} additional configs
- Security improvements: {len(enhanced_fix.get('additional_security', []))} measures
- Resource: {finding.resource} in {finding.file}
        """.strip()