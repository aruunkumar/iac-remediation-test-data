# Terraform Remediation Agent

A specialized Terraform security remediation agent that intelligently fixes security vulnerabilities found by the Checkov Scanner. Combines MCP (Model Context Protocol) server capabilities with AWS Bedrock for automated fixes and comprehensive manual intervention guidance. Built for AWS Bedrock AgentCore deployment with risk-aware automation.

## Overview

The Terraform Remediation Agent processes security scan results from the Checkov Scanner and applies intelligent remediation using AWS Labs Terraform MCP Server tools and Bedrock Knowledge Bases. It provides automated fixes for safe, well-understood security issues and generates comprehensive TODO comments with detailed guidance for complex vulnerabilities requiring human review.

## Key Design Principles

### 1. **Intelligent Risk-Aware Remediation**
- **Batch Processing**: Groups findings by file (max 5 per batch) for efficient processing
- **Safety-First Approach**: Only auto-fixes low-risk, well-understood security issues
- **Preserve Functionality**: Ensures original code behavior is maintained
- **On-Demand Tool Usage**: Uses MCP tools and Bedrock KB only when needed
- **Idempotent Operations**: Skips already-addressed findings across multiple iterations
- **Report-Based Filtering**: Uses remediation report as source of truth for addressed findings

### 2. **Dual Knowledge Sources**
- **MCP Server Integration**: Direct access to AWS Provider documentation and best practices
- **Bedrock Knowledge Base**: Terraform-specific security patterns and implementation guides
- **Dynamic Guidance**: Agent decides which knowledge sources to query based on finding complexity

### 3. **Incremental Documentation & Iteration Support**
- **Real-Time Updates**: Report created at start and updated after each batch
- **Auto-Fix Comments**: All automated fixes marked with `# AGENT-FIXED: CKV_XXX - Description` comments
- **TODO Comments**: Detailed guidance for manual interventions added directly to files
- **Progress Tracking**: Shows batch completion times and captures any errors
- **No Separate Agent Call**: Report generation doesn't require additional LLM calls
- **Iteration Tracking**: Each remediation run tracked as separate iteration in report
- **Report Merging**: New findings merged with existing report across iterations
- **Comment-Based Summaries**: Report tables populated from actual code comments

## High-Level Architecture

```
┌─────────────────────┐    ┌──────────────────────┐    ┌─────────────────┐
│  Checkov Scanner    │───▶│  Scan Results        │───▶│  Remediation    │
│  (Port 8000)        │    │  /tmp/{scan_id}/     │    │  Agent          │
│                     │    │  checkov_result.json │    │  (Port 8001)    │
└─────────────────────┘    └──────────────────────┘    └─────────────────┘
                                                                 │
                                                                 ▼
┌─────────────────────┐    ┌──────────────────────┐    ┌─────────────────┐
│  Source Files       │    │  Working Copy        │    │  Modified Files │
│  (Local/S3)         │───▶│  /tmp/terraform_     │───▶│  + TODO         │
│                     │    │  remediation_{id}/   │    │  + AGENT-FIXED  │
└─────────────────────┘    └──────────────────────┘    └─────────────────┘
                                                                 │
                                                                 ▼
                           ┌──────────────────────┐    ┌─────────────────┐
                           │  MCP Server          │    │  Bedrock KB     │
                           │  • AWS Docs          │    │  • Terraform    │
                           │  • Provider Guide    │    │    Best         │
                           │  • Module Patterns   │    │    Practices    │
                           └──────────────────────┘    └─────────────────┘
```

## Idempotency & Iteration Support

### Multiple Iteration Handling

The agent supports iterative remediation for convergence, where it may be invoked multiple times on the same repository:

**Iteration 1:**
- Scan finds 13 findings
- Agent processes all 13
- Report shows: 4 auto-fixes, 9 manual interventions

**Iteration 2 (after adding new resource):**
- Scan finds 14 findings (13 old + 1 new)
- Agent filters: Skips 13 already-addressed, processes 1 new
- Report merges: Shows 4 auto-fixes, 10 manual interventions (9 old + 1 new)

**Iteration 3:**
- Scan finds 14 findings (all previously addressed)
- Agent filters: Skips all 14
- No processing needed, report unchanged

### Filtering Logic

1. **Primary: Parse Remediation Report**
   - Reads `REMEDIATION_REPORT.md` if it exists
   - Extracts `(check_id, resource)` tuples from tables
   - Skips any finding matching an existing tuple

2. **Fallback: Scan Code Comments**
   - If no report exists, scans `.tf` files
   - Finds `# AGENT-FIXED: CKV_XXX` and `# TODO: CKV_XXX` comments
   - Associates comments with resources
   - Creates initial report from existing comments

3. **Resource-Aware Matching**
   - Uses `(check_id, resource)` tuples, not just check_id
   - Correctly handles same check_id on different resources
   - Example: `CKV_AWS_119` on `table_a` vs `table_b` treated separately

### Report Merging

When finalizing the report on subsequent iterations:

1. **Parse existing report** to extract all previous findings
2. **Merge with new findings** from current iteration
3. **Deduplicate** by `(check_id, resource)` tuple
4. **Write merged report** with complete history

### Iteration Metadata

Each iteration is tracked in the report:

```markdown
## Progress

### Iteration 1
**Started:** 2025-11-10 14:00:00  
**Findings in this iteration:** 13  
**Batches:** 5
- Batch 1/5: Completed in 64.21s
...
**Completed:** 2025-11-10 14:05:22  
**Time:** 274.12s  
**New Auto-Fixes:** 4  
**New Manual Interventions:** 9

### Iteration 2
**Started:** 2025-11-10 14:30:00  
**Findings in this iteration:** 14  
**Batches:** 1
- Batch 1/1: Completed in 28.45s
**Completed:** 2025-11-10 14:30:28  
**Time:** 28.45s  
**New Auto-Fixes:** 0  
**New Manual Interventions:** 1
```

## Workflow

### End-to-End Remediation Flow

1. **Scanner Agent** scans Terraform code → stores results in `/tmp/{scan_id}/checkov_result.json`
2. **Remediation Agent** receives scan_id via API
3. **Load Scan Results**: Reads scan results and extracts source path from metadata
4. **Create Working Copy**: Copies source files to isolated working directory
5. **Process Findings**: For each security finding:
   - Agent analyzes finding and determines if auto-fixable or manual
   - Auto-fixable: Applies fix and adds `# AGENT-FIXED:` comment
   - Manual: Adds detailed TODO comment with guidance
6. **Generate Documentation**: Creates `REMEDIATION_REPORT.md` in working directory
7. **Return Results**: API returns working directory path and summary

### File Flow Example

```
Input:  Source&Output/tf-input/main.tf
        └─ Security issues: CKV_AWS_50, CKV_AWS_117, CKV_AWS_158

Process: Remediation Agent
        ├─ Creates: /tmp/terraform_remediation_{scan_id}_{random}/
        ├─ Copies all files from source
        ├─ Applies fixes to main.tf
        └─ Generates REMEDIATION_REPORT.md

Output: /tmp/terraform_remediation_{scan_id}_{random}/
        ├─ main.tf (with fixes and TODOs)
        ├─ REMEDIATION_REPORT.md
        └─ [other original files]
```

## Core Components

### 1. **TerraformRemediationAgent** (`main.py`)
- **Purpose**: Core agent that processes security scan results with intelligent batch remediation
- **Architecture**: 
  - Uses Strands SDK with Claude Sonnet 4.5 for intelligent decision-making
  - Integrates MCP client for AWS documentation access
  - Queries Bedrock Knowledge Base (KB ID: LZ2DEM1204) for Terraform best practices
  - Operates within MCP context manager for tool access
- **Key Methods**:
  - `remediate_violations_from_scan_id()`: Main entry point - loads scan results and creates working copy
  - `remediate_violations()`: Processes findings using batch processing
  - `_filter_already_addressed_findings()`: Skips findings already addressed in previous iterations
  - `_parse_remediation_report()`: Extracts addressed findings from existing report
  - `_scan_code_for_addressed_findings()`: Fallback to scan code comments if no report exists
  - `_create_finding_batches()`: Groups findings by file (max 5 per batch)
  - `_remediate_batch()`: Processes multiple findings from same file together
  - `_remediate_finding_intelligently()`: Processes individual findings
  - `_initialize_report()`: Creates report at start or appends new iteration
  - `_update_report()`: Updates report after each batch
  - `_extract_summaries_from_files()`: Extracts descriptions from code comments for report
  - `_finalize_report()`: Merges new findings with existing report and completes summary
  - `create_working_copy()`: Creates isolated working directory from source
- **Batch Processing Workflow**:
  1. Loads scan results from `/tmp/{scan_id}/checkov_result.json`
  2. Extracts source path from `scan_metadata.source`
  3. Creates working copy in `/tmp/terraform_remediation_{scan_id}_{random}/`
  4. Groups findings by file into batches (max 5 per batch)
  5. Initializes REMEDIATION_REPORT.md with scan info
  6. Wraps remediation in MCP context: `with self.tf_mcp_client:`
  7. For each batch:
     - Processes multiple findings together (if batch_size > 1)
     - Or processes single finding individually (if batch_size = 1)
     - Updates report with batch progress and timing
  8. Finalizes report with summary tables and next steps
  9. Returns working directory path and results
- **Key Features**:
  - **Batch Processing**: Up to 5x fewer API calls for files with multiple findings
  - **Automatic Source Retrieval**: Gets source path from scan metadata
  - **Isolated Working Copy**: Never modifies original files
  - **Incremental Reporting**: Report updated in real-time, no separate agent call
  - **MCP Context Management**: Properly manages MCP client lifecycle
  - **Non-Interactive Mode**: `BYPASS_TOOL_CONSENT=true` for automated operation
  - **Error Resilience**: Batch failures don't affect other batches

### 2. **FastAPI Wrapper** (`api.py`)
- **Purpose**: HTTP API interface for remediation operations
- **Features**:
  - **Scan ID Based**: Primary endpoint accepts only scan_id
  - **Auto Source Detection**: Retrieves source path from scan metadata
  - **Working Copy Management**: Creates and manages isolated working directories
  - **Authentication**: Bearer token authentication (dev-token-123 for development)
  - **OpenAPI Documentation**: Auto-generated docs at `/docs`
- **Key Endpoints**:
  - `POST /remediate/scan-id`: Process scan results by scan_id (recommended)
  - `POST /remediate`: Process raw scan results with optional source path
  - `DELETE /remediation/cleanup/{working_dir}`: Clean up working directory
  - `GET /health`: Service health check with MCP connection status
- **Response Format**: Returns working directory path, fix counts, and next steps

### 3. **Auto-Remediation Categories**

#### SAFE TO AUTO-FIX:
- **Missing encryption settings**: S3 encryption, RDS encryption, CloudWatch Logs KMS
- **Insecure default values**: Public access blocks, versioning, logging
- **Missing monitoring/logging**: X-Ray tracing, CloudWatch log groups
- **Simple compliance violations**: Backup configurations, retention policies
- **Hardcoded values**: Moving to variables or secure parameter stores

#### REQUIRES MANUAL INTERVENTION:
- **Network architecture changes**: VPC configuration, subnet placement
- **Resource dependencies**: Changes that could break functionality
- **Business logic decisions**: Retention periods, access patterns, cost implications
- **Multi-resource coordination**: Changes requiring multiple resource updates
- **Custom security requirements**: Organization-specific policies

### 4. **Documentation Generation**

The agent automatically generates `REMEDIATION_REPORT.md` in the working directory with:

- **Executive Summary**: Total findings, auto-fixed count, success rate
- **Vulnerability Analysis Table**: All findings with status and actions
- **Auto-Remediation Details**: Code snippets and explanations for each fix
- **Manual Intervention Guidance**: Prioritized by severity with detailed steps
- **Recommended Actions**: Immediate, short-term, and long-term priorities
- **Code Quality Assessment**: Overall analysis of fixes and remaining work
- **Compliance Status**: Security posture and remaining risks

## API Endpoints

| Endpoint | Method | Purpose | Input | Authentication |
|----------|--------|---------|-------|----------------|
| `/health` | GET | Health check | None | None |
| `/remediate/scan-id` | POST | Remediate from scan ID | `{"scan_id": "uuid"}` | Bearer token |
| `/remediate` | POST | Remediate with raw results | Scan results JSON | Bearer token |
| `/remediation/cleanup/{dir}` | DELETE | Clean up working directory | Directory name | Bearer token |

## Dependencies

### Core Dependencies
```
fastapi>=0.104.0            # Web framework
uvicorn>=0.24.0             # ASGI server
pydantic>=2.0.0             # Data validation
strands>=1.0.0              # Strands SDK for agent
mcp>=1.0.0                  # Model Context Protocol client
boto3>=1.34.0               # AWS SDK for S3 and Bedrock
```

### MCP Integration
- **MCP Server**: `awslabs.terraform-mcp-server@latest` (auto-installed via `uvx`)
- **Primary Tools**: 
  - `SearchAwsProviderDocs`: AWS resource documentation
  - `SearchAwsccProviderDocs`: AWSCC provider alternatives
  - `SearchSpecificAwsIaModules`: Secure AWS-IA patterns
- **Configuration**: Auto-configured MCP client with stdio connection
- **Context Management**: Uses `with self.tf_mcp_client:` for proper lifecycle

### AWS Requirements
- **Bedrock Access**: For Claude Sonnet 4.5 model and Knowledge Base queries
- **Knowledge Base ID**: LZ2DEM1204 (Terraform AWS Provider best practices)
- **Credentials**: Via environment variables, IAM roles, or AWS CLI
- **Region**: us-east-1 (default for Bedrock)

## Installation & Setup

### 1. Environment Setup
```bash
# Clone repository
git clone <repository-url>
cd agents/terraform_remediation

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. AWS Configuration
```bash
# Option 1: Environment variables
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1

# Option 2: AWS CLI
aws configure

# Option 3: IAM roles (for EC2/Lambda deployment)
# Automatically detected
```

### 3. MCP Server Setup
The MCP Terraform server is automatically managed via `uvx`. Ensure you have `uv` installed:
```bash
# Install uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 4. Start the Server
```bash
# Start the API server
python api.py

# Server will start on http://0.0.0.0:8001
# Health check: curl http://localhost:8001/health
```

## Usage Examples

### Python API
```python
from agents.terraform_remediation import TerraformRemediationAgent

# Create agent
agent = TerraformRemediationAgent()

# Remediate from scan ID (recommended)
result = agent.remediate_violations_from_scan_id('scan-uuid-here')

print(f"Working directory: {result['working_directory']}")
print(f"Auto-fixes applied: {len(result['remediation_results'].fixes)}")
print(f"Manual interventions: {len(result['remediation_results'].manual_interventions)}")

# Check the working directory for modified files and REMEDIATION_REPORT.md
```

### HTTP API
```bash
# Start the server
export PORT=8001
python api.py

# Remediate from scan ID (recommended workflow)
curl -X POST "http://localhost:8001/remediate/scan-id" \
  -H "Authorization: Bearer dev-token-123" \
  -H "Content-Type: application/json" \
  -d '{"scan_id": "b9889c99-b99d-4267-8424-147bbacc0230"}'

# Response includes working directory path
{
  "success": true,
  "scan_id": "b9889c99-b99d-4267-8424-147bbacc0230",
  "fixes_applied": 6,
  "manual_interventions": 3,
  "working_directory": "/tmp/terraform_remediation_scan_id_random/",
  "modified_files": ["main.tf", "variables.tf"],
  "next_steps": [
    "Review changes in working directory",
    "Check REMEDIATION_REPORT.md for details",
    "Run 'terraform plan' to validate",
    "Copy changes back to repository when ready"
  ]
}

# Clean up working directory when done
curl -X DELETE "http://localhost:8001/remediation/cleanup/terraform_remediation_scan_id_random" \
  -H "Authorization: Bearer dev-token-123"
```

### Complete Workflow Example
```bash
# Step 1: Scan Terraform code (Scanner Agent on port 8000)
curl -X POST "http://localhost:8000/scan/local" \
  -H "Content-Type: application/json" \
  -d '{"folder_path": "/absolute/path/to/terraform"}'

# Response: {"scan_id": "b9889c99-b99d-4267-8424-147bbacc0230", ...}

# Step 2: Remediate findings (Remediation Agent on port 8001)
curl -X POST "http://localhost:8001/remediate/scan-id" \
  -H "Authorization: Bearer dev-token-123" \
  -H "Content-Type: application/json" \
  -d '{"scan_id": "b9889c99-b99d-4267-8424-147bbacc0230"}'

# Response: {"working_directory": "/tmp/terraform_remediation_...", ...}

# Step 3: Review changes
cd /tmp/terraform_remediation_b9889c99-b99d-4267-8424-147bbacc0230_random/
cat REMEDIATION_REPORT.md
terraform plan

# Step 4: Copy changes back to your repository
cp -r /tmp/terraform_remediation_*/* /path/to/your/terraform/

# Step 5: Clean up
curl -X DELETE "http://localhost:8001/remediation/cleanup/terraform_remediation_..." \
  -H "Authorization: Bearer dev-token-123"
```

## Response Format

### Successful Remediation Response
```json
{
  "success": true,
  "scan_id": "b9889c99-b99d-4267-8424-147bbacc0230",
  "fixes_applied": 6,
  "manual_interventions": 3,
  "validation_errors": [],
  "processing_time_seconds": 45.2,
  "working_directory": "/tmp/terraform_remediation_b9889c99-b99d-4267-8424-147bbacc0230_abc123/",
  "modified_files": ["main.tf", "data.tf"],
  "agent_info": {
    "agent_name": "terraform-remediation-agent",
    "version": "1.0.0",
    "knowledge_bases": ["LZ2DEM1204"],
    "mcp_tools": ["SearchAwsProviderDocs", "SearchAwsccProviderDocs", "SearchSpecificAwsIaModules"]
  },
  "next_steps": [
    "Review changes in working directory: /tmp/terraform_remediation_...",
    "Modified files: main.tf, data.tf",
    "Run 'terraform plan' in working directory to validate changes",
    "Review TODO comments for manual interventions",
    "Check REMEDIATION_REPORT.md for comprehensive documentation",
    "Copy changes back to your repository when ready",
    "Use DELETE /remediation/cleanup/{working_dir_name} to clean up"
  ]
}
```

### Working Directory Contents
```
/tmp/terraform_remediation_b9889c99-b99d-4267-8424-147bbacc0230_abc123/
├── main.tf                    # Modified with fixes and TODOs
├── variables.tf               # Original or modified
├── data.tf                    # Modified with fixes
├── REMEDIATION_REPORT.md      # Comprehensive documentation
└── [other original files]     # Preserved as-is
```

### REMEDIATION_REPORT.md Structure
```markdown
# Remediation Report

**Scan ID:** daf14c9b  
**First Started:** 2025-11-10 14:00:00  

---

## Progress

### Iteration 1
**Started:** 2025-11-10 14:00:00  
**Findings in this iteration:** 13  
**Batches:** 5
- Batch 1/5: Completed in 64.21s
- Batch 2/5: Completed in 92.23s
...
**Completed:** 2025-11-10 14:05:22  
**Time:** 274.12s  
**New Auto-Fixes:** 4  
**New Manual Interventions:** 9

---

## Summary

**Completed:** 2025-11-10 14:05:22  
**Total Time:** 274.12s  
**Auto-Fixes Applied:** 4  
**Manual Interventions:** 9  
**Errors:** 0

---

## Auto-Fixed Issues

| Check ID | Resource | File | What Changed |
|----------|----------|------|--------------|
| CKV_AWS_237 | aws_api_gateway_rest_api.api | /main.tf | Added lifecycle policy |
| CKV_AWS_73 | aws_api_gateway_stage.prod | /main.tf | Enabled X-Ray tracing |
| CKV_AWS_28 | aws_dynamodb_table.table_a | /dynamodb.tf | Enabled PITR |
| CKV2_AWS_39 | aws_route53_zone.zone | /route53.tf | DNS query logging |

---

## Manual Intervention Required

| Check ID | Resource | File | Action Needed |
|----------|----------|------|---------------|
| CKV_AWS_119 | aws_dynamodb_table.table_a | /dynamodb.tf | KMS encryption |
| CKV_AWS_76 | aws_api_gateway_stage.prod | /main.tf | Access logging |
... (7 more)

---

## Next Steps

1. Review the TODO comments added to the Terraform files
2. Implement the recommended security fixes
3. Test changes in a non-production environment
4. Apply to production after validation
```

**Key Features:**
- **Scan ID preserved** across all iterations
- **Progress section** shows all iterations with timing
- **Summary tables** show cumulative findings from all iterations
- **Descriptions extracted** from actual code comments (`AGENT-FIXED` and `TODO`)
- **Resource-specific** entries prevent duplicate check_ids from being confused

## Testing

### End-to-End Test Script

The `test_remediation.py` script provides a complete end-to-end test with real scan results:

```bash
# Prerequisites
source venv/bin/activate
export AWS_PROFILE=your-profile-name  # For S3 access

# Step 1: Run Checkov scan (saves to temp folder and Source&Output)
cd agents/checkov_scanner
python test_scan_s3.py s3://your-bucket/terraform-project/

# Output:
# ✅ Scan completed in 12.34s
# Scan ID: 3c09ec34
# Total Findings: 19
# 📁 Saved to temp folder: /tmp/3c09ec34/checkov_result.json
# 📁 Saved to output folder: Source&Output/terraform-project/3c09ec34/checkov_scan_terraform-project_results.json
# 🔑 Scan ID for remediation: 3c09ec34

# Step 2: Run remediation (source path optional, reads from scan metadata)
cd ../terraform_remediation
python test_remediation.py 3c09ec34

# Or with explicit source path:
python test_remediation.py 3c09ec34 s3://your-bucket/terraform-project/

# Output:
# ⏱️  Running Terraform Remediation with batch processing...
# Scan ID: 3c09ec34
# Source: Will be read from scan metadata
# 
# ✅ Agent initialized in 1.56s
# 
# INFO: Created 4 batches from 19 findings
# INFO:   Batch 1:  - 5 finding(s)
# INFO:   Batch 2:  - 5 finding(s)
# INFO:   Batch 3:  - 5 finding(s)
# INFO:   Batch 4:  - 4 finding(s)
# INFO: Initialized remediation report: .../REMEDIATION_REPORT.md
# INFO: ⏱️  [1/4] Processing batch:  - 5 finding(s)
# INFO:     🤖 Batch agent inference time: 44.64s for 5 findings
# INFO: ⏱️  [1/4] Completed batch in 44.64s
# ...
# INFO: ⏱️  Total remediation time: 231.18s for 19 findings in 4 batches
# 
# ✅ Remediation completed in 236.42s
# 
# 📊 Results:
#    Auto-fixes: 3
#    Manual interventions: 16
#    Total findings: 19
#    Working directory: /tmp/terraform_remediation_3c09ec34_abc123/
# 
# 📁 Copied remediation output to: Source&Output/terraform-project/3c09ec34/remediation_output
# 📄 Check REMEDIATION_REPORT.md in the output directory
# 
# ======================================================================
# ✅ Remediation test completed successfully!
# 
# 📊 Summary:
#    - Processed 19 findings
#    - Applied 3 auto-fixes
#    - Generated 16 manual guidance items
#    - Modified 4 files
# ======================================================================

# Step 3: Review results
cd Source&Output/terraform-project/3c09ec34/remediation_output/
cat REMEDIATION_REPORT.md
ls -la  # See all modified files
```

### Test Script Features

- **Automatic Source Detection**: Reads source path from scan metadata (no need to provide it)
- **Organized Output**: Results saved to `Source&Output/{folder_name}/{scan_id}/remediation_output/`
- **Batch Processing**: Shows real-time progress for each batch
- **Timing Metrics**: Displays batch processing times and total duration
- **Complete Results**: Includes all modified files and REMEDIATION_REPORT.md

### Output Structure

```
Source&Output/
└── terraform-project/
    └── 3c09ec34/
        ├── checkov_scan_terraform-project_results.json  (from scanner)
        └── remediation_output/                          (from remediation)
            ├── REMEDIATION_REPORT.md
            ├── main.tf                                  (modified)
            ├── variables.tf                             (modified)
            └── ... (other files)
```

### Quick API Test
```bash
# Start both agents
# Terminal 1: Scanner Agent
cd agents/checkov_scanner
python api.py  # Port 8000

# Terminal 2: Remediation Agent
cd agents/terraform_remediation
export PORT=8001
python api.py  # Port 8001

# Terminal 3: Test workflow
# Scan
curl -X POST "http://localhost:8000/scan/local" \
  -H "Content-Type: application/json" \
  -d '{"folder_path": "/absolute/path/to/terraform"}' | jq -r '.scan_id'

# Remediate (use scan_id from above)
curl -X POST "http://localhost:8001/remediate/scan-id" \
  -H "Authorization: Bearer dev-token-123" \
  -H "Content-Type: application/json" \
  -d '{"scan_id": "SCAN_ID_HERE"}' | jq

# Review results
cd /tmp/terraform_remediation_*/
cat REMEDIATION_REPORT.md
```

## Error Handling

### Common Issues

1. **Scan Results Not Found**
   ```json
   {"detail": "Scan results not found for scan ID: xyz"}
   ```
   - Ensure scanner agent has completed the scan
   - Check that scan results exist in `/tmp/{scan_id}/checkov_result.json`

2. **Source Path Not Found**
   ```json
   {"detail": "Source path not found in scan metadata"}
   ```
   - Scan metadata must include `source` field
   - Ensure scanner agent is storing source path in metadata

3. **MCP Connection Issues**
   ```json
   {"status": "degraded", "mcp_connection": false}
   ```
   - Check that `uv` and `uvx` are installed
   - Verify MCP server can be launched: `uvx awslabs.terraform-mcp-server@latest`

4. **AWS Credentials**
   ```json
   {"detail": "Unable to locate credentials"}
   ```
   - Configure AWS credentials via environment variables or AWS CLI
   - Ensure IAM permissions for Bedrock access

5. **Interactive Prompts Blocking**
   - Issue: Agent prompts for file write confirmation
   - Solution: `BYPASS_TOOL_CONSENT=true` is set in main.py
   - Verify: Check that environment variable is set before agent initialization

## Troubleshooting

### Debug Mode
Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
python api.py
```

### Verify MCP Integration
Check MCP server connection:
```bash
curl http://localhost:8001/health | jq

# Should show:
# {
#   "status": "healthy",
#   "mcp_connection": true,
#   "agent_initialized": true
# }
```

### Check Working Directory
If remediation completes but files aren't modified:
```bash
# List working directories
ls -la /tmp/terraform_remediation_*/

# Check specific working directory
cd /tmp/terraform_remediation_SCAN_ID_*/
ls -la
cat REMEDIATION_REPORT.md
```

### Verify Scan Results Format
```bash
# Check scan results structure
cat /tmp/SCAN_ID/checkov_result.json | jq '.scan_metadata.source'

# Should return the source path
```

## Production Considerations

### Deployment
- **Container**: Use Docker for consistent environment
- **Scaling**: Deploy behind load balancer for high throughput
- **Security**: Implement proper JWT authentication (replace dev-token-123)
- **Monitoring**: Set up CloudWatch or similar monitoring
- **Cleanup**: Implement automated cleanup of old working directories

### Security
- **Authentication**: Replace dev-token-123 with proper JWT validation
- **Authorization**: Implement role-based access control
- **Audit Logging**: Log all remediation operations
- **Working Directory**: Ensure proper permissions and cleanup

### Performance
- **Batch Processing**: Up to 5x fewer API calls with batch size of 5
- **Processing Time**: ~47s per batch (avg), ~11s per finding
- **Efficiency**: Files with multiple findings processed together in single agent call
- **MCP Connection**: Reuses connection across requests
- **Memory**: ~500MB per agent instance
- **Incremental Reporting**: No additional time for report generation (updated in real-time)

## Contributing

1. Follow existing code structure and patterns
2. Add tests for new functionality
3. Update documentation for API changes
4. Ensure compatibility with Strands SDK and MCP integration

## License

[Add appropriate license information]


## API Input/Output Reference

### POST /remediate (Primary Endpoint for Orchestrator)

**Input:**
```json
{
  "scan_results": {
    "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
    "repository_url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "commit_sha": "HEAD",
    "total_findings": 19,
    "findings": [
      {
        "check_id": "CKV_AWS_23",
        "resource": "aws_security_group.fleet_sg",
        "resource_type": "aws_security_group",
        "file": "/main.tf",
        "line_range": [105, 112],
        "severity": "LOW",
        "description": "Security group egress rule is missing description"
      }
    ],
    "scan_metadata": {
      "source": "/tmp/github_repos/iac-remediation-test-data",
      "source_type": "local"
    }
  },
  "remediation_configuration": {
    "auto_fix_enabled": true,
    "manual_guidance_enabled": true,
    "use_mcp_server": true,
    "use_bedrock_kb": true
  }
}
```

**Output:**
```json
{
  "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
  "remediation_results": {
    "fixes": [
      {
        "check_id": "CKV_AWS_23",
        "resource": "aws_security_group.fleet_sg",
        "file": "/main.tf",
        "severity": "LOW",
        "fix_applied": "Added description to egress rule"
      }
    ],
    "manual_interventions": [
      {
        "check_id": "CKV_AWS_382",
        "resource": "aws_security_group.fleet_sg",
        "file": "/main.tf",
        "severity": "HIGH",
        "todo_comment": "Restrict egress traffic from 0.0.0.0/0"
      }
    ],
    "validation_errors": [],
    "knowledge_base_queries": []
  },
  "working_directory": "/tmp/github_repos/iac-remediation-test-data",
  "modified_files": [
    "/main.tf",
    "/modules/api_gateway/main.tf"
  ],
  "auto_fixes_applied": 4,
  "todos_added": 15
}
```

**Key Points:**
- Extracts `source` from `scan_metadata` to find working directory
- Uses existing directory directly (no copying) if it contains `.tf` files
- Modifies files in-place at the working directory
- Adds `# AGENT-FIXED:` comments for auto-fixes
- Adds `# TODO:` comments for manual interventions
- Returns list of modified files for tracking
