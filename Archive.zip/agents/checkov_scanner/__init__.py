"""
Checkov Scanner Agent Package
Terraform security scanning using MCP Terraform Server integration
Supports S3 buckets, local folders, and individual files
"""

from .main import (
    CheckovScannerAgent, 
    create_checkov_scanner_agent, 
    run_checkov_scan,
    scan_terraform_project,
    scan_s3_terraform_project,
    scan_local_terraform_project
)
from .scan_processor import MCPScanResultProcessor, create_scan_processor
from .terraform_loader import (
    TerraformProjectLoader,
    create_terraform_loader,
    load_terraform_from_s3,
    load_terraform_from_folder,
    load_terraform_project
)
from .api import app as scanner_api

__version__ = "1.1.0"
__all__ = [
    "CheckovScannerAgent",
    "create_checkov_scanner_agent", 
    "run_checkov_scan",
    "scan_terraform_project",
    "scan_s3_terraform_project", 
    "scan_local_terraform_project",
    "MCPScanResultProcessor",
    "create_scan_processor",
    "TerraformProjectLoader",
    "create_terraform_loader",
    "load_terraform_from_s3",
    "load_terraform_from_folder", 
    "load_terraform_project",
    "scanner_api"
]