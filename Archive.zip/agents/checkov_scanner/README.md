# Checkov Scanner Agent

A streamlined Terraform security scanning agent that provides direct access to Checkov security findings through MCP (Model Context Protocol) integration. Built for AWS Bedrock AgentCore deployment with minimal processing overhead.

## Overview

The Checkov Scanner Agent provides automated security scanning for Terraform infrastructure code using the AWS Labs Terraform MCP Server. It supports scanning from multiple sources (local folders, S3 buckets, individual files) and returns pure Checkov findings without artificial enhancements or processing logic.

## Key Design Principles

### 1. **Direct MCP Integration**
- **No AI Model Overhead**: Direct tool calls to MCP server without LLM intermediation
- **Raw Checkov Data**: Returns exactly what Checkov provides without modification
- **Efficient Processing**: Minimal latency and resource usage

### 2. **No Artificial Logic**
- **Pure Checkov Findings**: Severity, descriptions, and fix_details directly from Checkov
- **No Enhancement Rules**: No static rules for severity upgrades or business impact
- **No Auto-fix Claims**: Realistic approach - all findings marked as manual intervention
- **No Compliance Mapping**: Removed artificial compliance framework associations

### 3. **Clean Data Flow**
- **Field Normalization Only**: Maps MCP field names (`id` → `check_id`) for consistency
- **Preserve Original Fields**: Keeps all Checkov fields (`type`, `fixed`, `fix_details`)
- **Simple Categorization**: Groups by severity without artificial enhancement
- **Minimal Processing**: Focus on data transport, not data transformation

## High-Level Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   HTTP API      │    │  Core Agent      │    │  MCP Server     │
│   (FastAPI)     │───▶│  (main.py)       │───▶│  (Terraform)    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Input Sources  │    │  Scan Processor  │    │  Checkov Tool   │
│  • Local Files  │    │  • Field Mapping │    │  • Raw Findings │
│  • S3 Buckets   │    │  • Categorization│    │  • Severity     │
│  • Individual   │    │  • Pass-through  │    │  • Descriptions │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Core Components

### 1. **CheckovScannerAgent** (`main.py`)
- **Purpose**: Core agent that provides direct access to Checkov security scanning via MCP integration
- **Architecture**: 
  - Direct MCP client connection to AWS Labs Terraform MCP Server
  - Calls `RunCheckovScan` tool directly without AI model intermediation
  - Minimal processing - returns raw Checkov findings with basic field normalization
- **Key Methods**:
  - `run_security_scan()`: Main entry point for scanning Terraform files
  - `scan_terraform_project()`: Handles project-level scanning with auto-detection
  - `scan_local_terraform_project()` / `scan_s3_terraform_project()`: Source-specific scanning
  - `_execute_mcp_checkov_scan()`: Direct MCP tool call with proper `tool_use_id`
- **Workflow**:
  1. Prepares Terraform files in temporary directory
  2. Calls MCP `RunCheckovScan` tool directly with `tool_use_id`
  3. Parses MCP response structure (`structuredContent.vulnerabilities`)
  4. Extracts raw Checkov findings without modification
  5. Returns findings with basic metadata (file count, duration, etc.)
- **Key Features**:
  - **Direct MCP Integration**: No AI model overhead - direct tool calls
  - **Raw Checkov Data**: Returns exactly what Checkov provides
  - **Multiple Input Sources**: Local folders, S3 buckets, individual files
  - **Absolute Path Support**: Proper handling of absolute vs relative paths
- **Dependencies**: MCP client, boto3 (for S3), tempfile management

### 2. **TerraformProjectLoader** (`terraform_loader.py`)
- **Purpose**: Handles loading Terraform files from various sources with proper path resolution
- **Features**:
  - **Recursive file discovery**: Finds `.tf`, `.tfvars`, `.tf.json` files
  - **S3 bucket integration**: Downloads files from S3 with AWS SDK
  - **Local folder scanning**: Supports both absolute and relative paths
  - **Path resolution**: Uses `Path(folder_path).resolve()` for proper absolute path handling
  - **File validation**: Checks file extensions and content accessibility
- **Key Methods**:
  - `load_terraform_project()`: Auto-detects source type (S3 vs local)
  - `load_from_s3()`: Downloads Terraform files from S3 bucket
  - `load_from_local_folder()`: Recursively scans local directory
  - `validate_terraform_files()`: Provides file statistics and validation report

### 3. **MCPScanResultProcessor** (`scan_processor.py`)
- **Purpose**: Minimal processor that normalizes MCP response formats without adding artificial logic
- **Core Processing**:
  1. **Field Normalization**: Maps MCP field names (`id` → `check_id`, `file_path` → `file`)
  2. **Format Handling**: Supports different MCP response structures
  3. **Pass-through Processing**: Preserves all original Checkov fields (`fix_details`, `type`, `fixed`)
  4. **Simple Categorization**: Groups findings by severity (from Checkov) without enhancement
- **Key Principles**:
  - **No Artificial Logic**: Uses only what Checkov provides
  - **No Severity Enhancement**: Respects Checkov's original severity assessment
  - **No Auto-fix Logic**: All findings marked as manual intervention (realistic)
  - **No Business Impact**: Removed artificial impact assessment
  - **No Compliance Mapping**: Removed static compliance framework rules
- **Key Methods**:
  - `process_mcp_scan_results()`: Main processing entry point
  - `_process_individual_finding()`: Normalizes individual finding fields
  - `_categorize_findings()`: Simple grouping by severity and type
- **Output Structure**: Clean, minimal structure with:
  - Original Checkov findings with normalized field names
  - Simple severity distribution (CRITICAL/HIGH/MEDIUM/LOW)
  - Realistic remediation distribution (all manual)
  - Basic scan metadata (file count, duration)

### 4. **FastAPI Wrapper** (`api.py`)
- **Purpose**: HTTP API interface providing RESTful endpoints for security scanning
- **Features**:
  - **Multiple Input Types**: Individual files, local folders, S3 buckets
  - **Absolute Path Support**: Proper handling of absolute paths for local scans
  - **Simplified Response**: Aligned with simplified scan processor
  - **File-based Storage**: Results stored in `/tmp/{scan_id}/checkov_result.json`
  - **OpenAPI Documentation**: Auto-generated docs at `/docs`
- **Key Endpoints**:
  - `POST /scan`: Individual Terraform files
  - `POST /scan/local`: Local folder (requires absolute path)
  - `POST /scan/s3`: S3 bucket scanning
  - `GET /scan/{scan_id}`: Retrieve stored results
  - `GET /health`: Service health check

## API Endpoints

| Endpoint | Method | Purpose | Input |
|----------|--------|---------|-------|
| `/health` | GET | Health check | None |
| `/tools` | GET | Available capabilities | None |
| `/scan` | POST | Individual files | JSON file objects |
| `/scan/local` | POST | Local folder | `{"folder_path": "/path"}` |
| `/scan/s3` | POST | S3 bucket | `{"s3_uri": "s3://bucket/path"}` |
| `/scan/project` | POST | Auto-detect source | `{"source": "path or s3://"}` |
| `/scan/{scan_id}` | GET | Detailed results | Scan ID |
| `/scan/{scan_id}/path` | GET | Get file path to results | Scan ID |
| `/scans` | GET | List all stored scans | None |
| `/scan/{scan_id}` | DELETE | Clean up scan results | Scan ID |

## Result Storage

Scan results are stored in the system's temporary directory using file-based storage for efficient inter-agent communication:

### Storage Location
```
{system_temp_dir}/{scan_id}/checkov_result.json
```

Where `{system_temp_dir}` is:
- **Linux**: `/tmp`
- **macOS**: `/var/folders/...` 
- **Windows**: `C:\Users\{user}\AppData\Local\Temp`

The exact path is determined by Python's `tempfile.gettempdir()`

### Benefits
- **Efficient**: Avoids passing large payloads between agents
- **Reference-based**: Other agents can reference results by scan_id
- **File-based**: Easy to inspect and debug scan results
- **Raw Checkov Data**: Stored results contain pure Checkov findings
- **Automatic cleanup**: Can be cleaned up via API or system temp cleanup

### Storage Content
The stored JSON contains:
```json
{
  "scan_id": "uuid",
  "findings": [
    {
      "id": "CKV_AWS_23",
      "check_id": "CKV_AWS_23", 
      "severity": "MEDIUM",
      "resource": "aws_security_group.example",
      "file": "/main.tf",
      "line_number": 10,
      "description": "Ensure every security group rule has a description",
      "type": "terraform",
      "fixed": false,
      "fix_details": null
    }
  ],
  "scan_metadata": {
    "total_findings": 19,
    "files_scanned": 6,
    "scan_duration": 7.2,
    "source_type": "s3",
    "source": "s3://bucket/path"
  }
}
```

### Usage by Other Agents
Other agents can efficiently access scan results by:

1. **Get file path**: `GET /scan/{scan_id}/path`
2. **Read JSON directly**: Use the returned file path to read results
3. **No API overhead**: Direct file access without HTTP calls

Example for other agents:
```python
import requests
import json

# Get the file path
response = requests.get(f"http://scanner-api:8000/scan/{scan_id}/path")
file_path = response.json()["file_path"]

# Read results directly
with open(file_path, 'r') as f:
    scan_results = json.load(f)

# Access raw Checkov findings
findings = scan_results["findings"]
for finding in findings:
    print(f"Check: {finding['check_id']}, Severity: {finding['severity']}")
```

## Dependencies

### Core Dependencies
```
fastapi>=0.104.0            # Web framework
uvicorn>=0.24.0             # ASGI server
pydantic>=2.0.0             # Data validation
mcp>=1.0.0                  # Model Context Protocol client
boto3>=1.34.0               # AWS SDK for S3 integration
httpx>=0.25.0               # HTTP client for MCP
aiofiles>=23.0.0            # Async file operations
```

### MCP Integration
- **MCP Server**: `awslabs.terraform-mcp-server@latest` (auto-installed via `uvx`)
- **Primary Tool**: `RunCheckovScan` for direct Checkov execution
- **Configuration**: Auto-configured MCP client with stdio connection
- **No AI Model**: Direct tool calls without LLM intermediation

### AWS Requirements
- **S3 Permissions**: For bucket scanning (optional)
- **Credentials**: Via environment variables, IAM roles, or AWS CLI
- **No Bedrock**: Direct MCP integration eliminates need for AI model access

## Installation & Setup

### 1. Environment Setup
```bash
# Clone repository
git clone <repository-url>
cd agents/checkov_scanner

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. AWS Configuration
```bash
# Option 1: Environment variables
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-west-2

# Option 2: AWS CLI
aws configure

# Option 3: IAM roles (for EC2/Lambda deployment)
# Automatically detected
```

### 3. MCP Server Setup
The MCP Terraform server is automatically managed via `uvx`. Ensure you have `uv` installed:
```bash
# Install uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh
```

## Usage Examples

### Python API
```python
from agents.checkov_scanner import (
    scan_local_terraform_project,
    scan_s3_terraform_project,
    CheckovScannerAgent
)

# Scan local folder (use absolute path)
results = scan_local_terraform_project('/absolute/path/to/terraform/project')

# Scan S3 bucket
results = scan_s3_terraform_project('s3://my-bucket/terraform-project')

# Direct agent usage
agent = CheckovScannerAgent()
results = agent.run_security_scan(terraform_files_dict)

# Results contain raw Checkov findings
print(f"Found {results['scan_metadata']['total_findings']} findings")
for finding in results['findings']:
    print(f"  {finding['check_id']}: {finding['description']}")
```

### HTTP API
```bash
# Start the server
python api.py

# Scan local folder (use absolute path)
curl -X POST "http://localhost:8000/scan/local" \
  -H "Content-Type: application/json" \
  -d '{"folder_path": "/absolute/path/to/terraform-project"}'

# Scan S3 bucket
curl -X POST "http://localhost:8000/scan/s3" \
  -H "Content-Type: application/json" \
  -d '{"s3_uri": "s3://my-bucket/terraform-project"}'

# Generic project scan (auto-detects source type)
curl -X POST "http://localhost:8000/scan/project" \
  -H "Content-Type: application/json" \
  -d '{"source": "/absolute/path/to/terraform"}'

# Individual files
curl -X POST "http://localhost:8000/scan" \
  -H "Content-Type: application/json" \
  -d '{
    "terraform_files": [
      {
        "filename": "main.tf",
        "content": "resource \"aws_s3_bucket\" \"test\" { bucket = \"test\" }"
      }
    ]
  }'
```

## Response Format

The API returns clean scan results with raw Checkov findings and simple categorization:

```json
{
  "request_id": "uuid-here",
  "scan_id": "scan-123",
  "status": "completed",
  "total_findings": 19,
  "fixable_count": 0,
  "manual_count": 19,
  "scan_duration": 7.2,
  "findings_summary": {
    "severity_distribution": {
      "critical": 0,
      "high": 0,
      "medium": 19,
      "low": 0
    },
    "remediation_distribution": {
      "auto_fixable": 0,
      "manual_intervention": 19
    },
    "source_info": {
      "source": "s3://bucket/path",
      "source_type": "s3",
      "files_scanned": 19
    }
  },
  "findings_by_severity": {
    "MEDIUM": [
      {
        "id": "CKV_AWS_23_8733",
        "check_id": "CKV_AWS_23",
        "severity": "MEDIUM",
        "resource": "aws_security_group.fleet_sg",
        "resource_type": "aws_security_group",
        "file": "/main.tf",
        "line_number": 73,
        "description": "Ensure every security group and rule has a description",
        "type": "terraform",
        "fixed": false,
        "fix_details": null
      }
    ]
  },
  "findings_by_type": {
    "auto_fixable": [],
    "manual_intervention": [
      // All findings - realistic approach
    ]
  }
}
```

### Key Response Features
- **Raw Checkov Data**: Severity, descriptions, and fix_details directly from Checkov
- **No Artificial Enhancement**: No artificial severity upgrades or business impact
- **Realistic Categorization**: All findings marked as manual intervention
- **Original Fields Preserved**: `type`, `fixed`, `fix_details` from Checkov
- **Simple Metadata**: File counts, scan duration, source information

## Testing

### Quick Test
```bash
# Start the API server (with AWS profile if needed for S3)
export AWS_PROFILE=your-profile
python api.py

# Test health endpoint
curl http://localhost:8000/health

# Test with sample Terraform files (use absolute path)
mkdir -p ~/test-terraform
echo 'resource "aws_s3_bucket" "test" { bucket = "test-bucket" }' > ~/test-terraform/main.tf

curl -X POST "http://localhost:8000/scan/local" \
  -H "Content-Type: application/json" \
  -d '{"folder_path": "'$HOME'/test-terraform"}'

# Test the comprehensive test suite
python test_scanner_api.py
```

### Comprehensive Testing
```bash
# Run the provided test suite
python test_scanner_api.py

# Expected output:
# ✅ Local Folder Scan: 9 findings (Lambda/CloudWatch)
# ✅ Individual File Scan: 10 findings (Security Groups)  
# ✅ S3 Scan: 19 findings (AppStream project)

# Manual testing with different sources
python -c "
from agents.checkov_scanner import scan_local_terraform_project
results = scan_local_terraform_project('/absolute/path/to/terraform')
print(f'Found {results[\"scan_metadata\"][\"total_findings\"]} findings')
for finding in results['findings'][:3]:  # Show first 3
    print(f'  {finding[\"check_id\"]}: {finding[\"severity\"]}')
"
```

## Supported File Types

- **`.tf`** - Terraform configuration files
- **`.tfvars`** - Terraform variable files
- **`.tf.json`** - JSON-formatted Terraform files

## Project Structure Support

The agent supports various Terraform project structures:

### Simple Project
```
terraform-project/
├── main.tf
├── variables.tf
├── outputs.tf
└── terraform.tfvars
```

### Complex Project with Modules
```
terraform-project/
├── main.tf
├── variables.tf
├── modules/
│   ├── database/
│   │   ├── main.tf
│   │   └── variables.tf
│   └── storage/
│       └── main.tf
├── environments/
│   ├── dev.tfvars
│   └── prod.tfvars
└── policies/
    └── security.tf
```

## Error Handling

Common error scenarios and responses:

### Local Folder Issues
```json
{
  "error": "Folder does not exist: /invalid/path",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### S3 Access Issues
```json
{
  "error": "Access denied to S3 bucket: my-bucket",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

### No Terraform Files
```json
{
  "error": "No Terraform files found in folder: /empty/folder",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

## Deployment

### Docker Deployment
```bash
# Build container
docker build -t checkov-scanner .

# Run container
docker run -p 8000:8000 \
  -e AWS_ACCESS_KEY_ID=your_key \
  -e AWS_SECRET_ACCESS_KEY=your_secret \
  checkov-scanner
```

### AWS Lambda Deployment
The agent is designed for deployment on AWS Bedrock AgentCore but can also be deployed as a Lambda function with appropriate configuration.

### Production Considerations
- **Scaling**: Use load balancers for high-throughput scenarios
- **Security**: Implement proper authentication and authorization
- **Monitoring**: Set up CloudWatch or similar monitoring
- **Caching**: Consider caching scan results for frequently scanned projects

## Troubleshooting

### Common Issues

1. **Local Path Errors**: Use absolute paths for local folder scanning (not relative paths)
2. **AWS Credentials**: Verify AWS credentials for S3 scanning (not needed for local scans)
3. **MCP Server**: Check that `uv` and `uvx` are properly installed for MCP server
4. **S3 Permissions**: Ensure S3 read permissions for bucket scanning
5. **No Findings**: Check that Terraform files contain actual security issues to detect

### Debug Mode
Enable debug logging by setting:
```bash
export LOG_LEVEL=DEBUG
python api.py
```

### Verify MCP Integration
Check that the MCP server is working:
```bash
# Check available MCP tools
curl http://localhost:8000/health

# Should show: "RunCheckovScan" in mcp_tools_available
```

### Test Direct MCP Call
The agent makes direct MCP calls - check server logs for:
```
INFO:agents.checkov_scanner.main:Found MCP server format with X vulnerabilities
INFO:agents.checkov_scanner.main:Found X failed_checks from Checkov JSON
```

## Contributing

1. Follow the existing code structure and patterns
2. Add tests for new functionality
3. Update documentation for API changes
4. Ensure compatibility with Strands SDK and MCP integration

## License

[Add appropriate license information]


## API Input/Output Reference

### POST /scan/local (Primary Endpoint for Orchestrator)

**Input:**
```json
{
  "folder_path": "/tmp/github_repos/iac-remediation-test-data",
  "scan_options": {
    "frameworks": ["terraform"],
    "severity_levels": ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
  },
  "repository_info": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git"
  }
}
```

**Output:**
```json
{
  "request_id": "scan-123",
  "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
  "status": "completed",
  "total_findings": 19,
  "fixable_count": 4,
  "findings": [
    {
      "check_id": "CKV_AWS_23",
      "check_name": "Ensure security group egress rule has description",
      "resource": "aws_security_group.fleet_sg",
      "resource_type": "aws_security_group",
      "file": "/main.tf",
      "line_range": [105, 112],
      "severity": "LOW",
      "description": "Security group egress rule is missing description",
      "guideline": "Add description field to egress rules for better documentation"
    }
  ],
  "scan_metadata": {
    "source": "/tmp/github_repos/iac-remediation-test-data",
    "source_type": "local",
    "total_findings": 19,
    "files_scanned": 8,
    "scan_duration": 2.5
  }
}
```

**Key Points:**
- Scanner discovers all `.tf` files in `folder_path` recursively
- Returns findings with file paths relative to `folder_path`
- Includes `source` in `scan_metadata` for remediation agent to use
- No need to pass file lists - scanner handles discovery
