"""
MCP Scan Result Processing Module
Simple processing of Checkov scan results from MCP Terraform Server
"""

from typing import Dict, List, Any, Optional
import json
import logging

logger = logging.getLogger(__name__)

class MCPScanResultProcessor:
    """Simple processor for MCP Terraform Server Checkov scan results"""
    
    def __init__(self):
        pass
    
    def process_mcp_scan_results(self, raw_results: Dict[str, Any], terraform_files: Dict[str, str], scan_id: str = None) -> Dict[str, Any]:
        """Process raw MCP scan results into simple categorized format"""
        logger.info("Processing MCP scan results")
        
        # Handle different MCP response formats
        if 'results' in raw_results and 'failed_checks' in raw_results['results']:
            # Standard Checkov JSON format: {"results": {"failed_checks": [...]}}
            findings = raw_results['results']['failed_checks']
        elif 'findings' in raw_results:
            # MCP integration format: {"findings": [...], "scan_metadata": {...}}
            findings = raw_results['findings']
            logger.info(f"Using MCP integration format with {len(findings)} findings")
        else:
            # Fallback for other formats
            findings = raw_results.get('vulnerabilities', [])
            logger.warning(f"Using fallback format, found {len(findings)} findings")
        
        # Process findings with minimal transformation
        processed_findings = []
        for finding in findings:
            processed_finding = self._process_individual_finding(finding)
            if processed_finding:
                processed_findings.append(processed_finding)
        
        # Generate simple categorized results
        categorized_results = self._categorize_findings(processed_findings, scan_id)
        
        logger.info(f"Processed {len(processed_findings)} findings")
        
        return categorized_results
    
    def _process_individual_finding(self, finding: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Process individual finding with minimal transformation"""
        try:
            # Handle different field names for check ID
            check_id = finding.get('check_id') or finding.get('id', '')
            if not check_id:
                logger.warning(f"Finding missing check_id/id field, available keys: {list(finding.keys())}")
                return None
            
            # Handle different MCP formats for field extraction
            if 'check_name' in finding:
                # Standard MCP Checkov format
                description = finding.get('check_name', '')
                resource = finding.get('resource', '')
                file_path = finding.get('file_path', '')
                
                # Extract line number from file_line_range if available
                file_line_range = finding.get('file_line_range')
                if file_line_range and isinstance(file_line_range, list) and len(file_line_range) > 0:
                    line_number = file_line_range[0]
                else:
                    line_number = None
                    
            elif 'description' in finding and 'file_path' in finding:
                # MCP server format
                description = finding.get('description', '')
                resource = finding.get('resource', '')
                file_path = finding.get('file_path', '')
                line_number = finding.get('line')
                    
            else:
                # Legacy format
                description = finding.get('description', '')
                resource = finding.get('resource', '')
                file_path = finding.get('file', '')
                line_number = finding.get('line_number')
            
            # Use severity directly from Checkov
            severity = finding.get('severity', 'MEDIUM').upper()
            
            # Simple processed finding - just normalize the fields
            processed_finding = {
                'id': f"{check_id}_{hash(str(finding)) % 10000}",
                'check_id': check_id,
                'severity': severity,
                'resource': resource,
                'resource_type': self._extract_resource_type(resource),
                'file': file_path,
                'line_number': line_number,
                'description': description,
                # Keep any additional fields from the original finding
                **{k: v for k, v in finding.items() if k not in ['id', 'check_id', 'severity', 'resource', 'file_path', 'line', 'description']}
            }
            
            return processed_finding
            
        except Exception as e:
            logger.error(f"Error processing finding: {e}")
            return None
    

    
    def _categorize_findings(self, findings: List[Dict[str, Any]], scan_id: str = None) -> Dict[str, Any]:
        """Categorize findings into simple response format"""
        
        # Use provided scan_id or generate one
        if scan_id is None:
            scan_id = self._generate_scan_id()
        
        # Simple categorization by severity
        findings_by_severity = {
            'CRITICAL': [f for f in findings if f.get('severity') == 'CRITICAL'],
            'HIGH': [f for f in findings if f.get('severity') == 'HIGH'],
            'MEDIUM': [f for f in findings if f.get('severity') == 'MEDIUM'],
            'LOW': [f for f in findings if f.get('severity') == 'LOW']
        }
        
        # Simple categorization - all findings are manual since we don't have auto-fix logic
        findings_by_type = {
            'auto_fixable': [],  # No auto-fix logic
            'manual_intervention': findings  # All findings require manual review
        }
        
        categorized = {
            'scan_id': scan_id,
            'total_findings': len(findings),
            'fixable_count': 0,  # No auto-fix logic
            'manual_count': len(findings),  # All manual
            'findings_by_severity': findings_by_severity,
            'findings_by_type': findings_by_type
        }
        
        return categorized
    

    
    def _extract_resource_type(self, resource: str) -> str:
        """Extract AWS resource type from resource identifier"""
        if '.' in resource:
            return resource.split('.')[0]
        return resource
    
    def _generate_scan_id(self) -> str:
        """Generate unique scan ID"""
        import uuid
        return str(uuid.uuid4())[:8]

def create_scan_processor() -> MCPScanResultProcessor:
    """Factory function to create scan result processor"""
    return MCPScanResultProcessor()