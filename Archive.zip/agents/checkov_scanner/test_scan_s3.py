#!/usr/bin/env python3
"""
Test script for Checkov Scanner Agent with S3 input
Saves results to both temp folder and Source&Output directory
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from main import CheckovScannerAgent
import json
import time
import tempfile

def scan_s3_project(s3_uri: str):
    """
    Run Checkov scan on S3 project and save results
    
    Args:
        s3_uri: S3 URI like 's3://bucket-name/path/to/terraform'
    """
    print(f'🔍 Running Checkov scan on: {s3_uri}')
    print()

    # Extract folder name from S3 URI
    folder_name = s3_uri.rstrip('/').split('/')[-1]
    print(f'📁 Extracted folder name: {folder_name}')
    print()

    # Run scan
    start = time.time()
    scanner = CheckovScannerAgent()
    scan_results = scanner.scan_s3_terraform_project(s3_uri)
    scan_time = time.time() - start

    scan_id = scan_results['scan_id']
    print(f'✅ Scan completed in {scan_time:.2f}s')
    print(f'Scan ID: {scan_id}')
    print(f'Total Findings: {scan_results["scan_metadata"]["total_findings"]}')
    print(f'Files Scanned: {scan_results["scan_metadata"]["files_scanned"]}')
    print()

    # Add required fields for remediation
    scan_results['repository_url'] = s3_uri
    scan_results['commit_sha'] = 'n/a'
    scan_results['total_findings'] = scan_results['scan_metadata']['total_findings']

    # Save to temp folder (for remediation agent to read)
    temp_dir = os.path.join(tempfile.gettempdir(), scan_id)
    os.makedirs(temp_dir, exist_ok=True)
    temp_file = os.path.join(temp_dir, 'checkov_result.json')
    
    with open(temp_file, 'w') as f:
        json.dump(scan_results, f, indent=2, default=str)
    
    print(f'📁 Saved to temp folder: {temp_file}')

    # Save to Source&Output directory (for user access)
    output_dir = f'Source&Output/{folder_name}/{scan_id}'
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f'checkov_scan_{folder_name}_results.json')

    with open(output_file, 'w') as f:
        json.dump(scan_results, f, indent=2, default=str)

    print(f'📁 Saved to output folder: {output_file}')
    print()
    print(f'🔑 Scan ID for remediation: {scan_id}')
    print(f'📂 Output directory: {output_dir}')
    
    return scan_id, scan_results

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python test_scan_s3.py <s3_uri>")
        print("Example: python test_scan_s3.py s3://terraform-accelerator-tf-input/test/")
        sys.exit(1)
    
    s3_uri = sys.argv[1]
    
    # Validate S3 URI format
    if not s3_uri.startswith('s3://'):
        print(f"❌ Error: Invalid S3 URI format: {s3_uri}")
        print("   S3 URI must start with 's3://'")
        sys.exit(1)
    
    # Run scan
    scan_id, results = scan_s3_project(s3_uri)
    
    print()
    print("✅ Scan completed successfully!")
    print(f"   Use scan_id '{scan_id}' with the remediation agent")

if __name__ == "__main__":
    main()
