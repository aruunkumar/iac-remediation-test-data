"""
Checkov Scanner Agent - Specialized security scanning agent
Built with Strands SDK for deployment on AWS Bedrock AgentCore
Uses MCP Terraform Server for enhanced Checkov integration
"""

from strands import Agent
from strands.tools.mcp import MCPClient
from strands_tools import file_read, file_write
from mcp.client.stdio import stdio_client
from mcp import StdioServerParameters
from typing import Dict, List, Any
import json
import logging
import tempfile
import os
import time
import uuid

# Import the terraform loader
try:
    from .terraform_loader import TerraformProjectLoader, create_terraform_loader
except ImportError:
    # Fallback for direct execution
    from terraform_loader import TerraformProjectLoader, create_terraform_loader

logger = logging.getLogger(__name__)

def get_terraform_mcp_client():
    """Get MCP Terraform client - reused from mcp_terraform.py"""
    return MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["awslabs.terraform-mcp-server@latest"],
                env={"FASTMCP_LOG_LEVEL": "ERROR"},
                disabled=False,
                auto_approve=[],
                debug=True,
            )
        )
    )

def get_checkov_scanner_system_prompt() -> str:
    """System prompt for the Checkov Scanner Agent with MCP integration"""
    return """
    You are the Checkov Scanner Agent specialized in running security scans on Terraform code 
    using the AWS Labs Terraform MCP Server.
    
    Your responsibilities:
    1. Use MCP Terraform server's Checkov integration to scan Terraform files
    2. Return raw Checkov scan results without additional processing
    3. Provide basic scan metadata including total findings, file coverage, and scan duration
    
    You do NOT:
    - Categorize findings by severity
    - Provide remediation guidance or recommendations
    - Process or enhance the findings beyond basic cleanup
    
    The MCP server provides built-in Checkov capabilities - use these to get raw scan results.
    Return the findings as-is for downstream agents (like remediation agents) to process.
    
    Available MCP tools for Checkov operations:
    - Use MCP server's Checkov integration for security scanning
    - Return structured scan results from MCP server output
    """

class CheckovScannerAgent:
    """Checkov Scanner Agent for security scanning operations using MCP Terraform Server"""
    
    def __init__(self):
        self.tf_mcp_client = get_terraform_mcp_client()
        self.terraform_loader = create_terraform_loader()
        self.agent = None
        self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Strands agent with MCP tools"""
        with self.tf_mcp_client:
            # Get MCP tools from Terraform server
            mcp_tools = self.tf_mcp_client.list_tools_sync()
            
            # Combine MCP tools with file system tools
            all_tools = mcp_tools + [file_read, file_write]
            
            # Create Strands agent with MCP integration
            self.agent = Agent(
                system_prompt=get_checkov_scanner_system_prompt(),
                tools=all_tools,
                model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
            )
            
            logger.info(f"Initialized Checkov Scanner Agent with {len(mcp_tools)} MCP tools")
    
    def run_security_scan(self, terraform_files: Dict[str, str], scan_id: str = None) -> Dict[str, Any]:
        """Execute Checkov scan using MCP Terraform Server - returns raw results"""
        logger.info(f"Starting MCP Checkov scan on {len(terraform_files)} files")
        
        start_time = time.time()
        
        try:
            with self.tf_mcp_client:
                # Prepare files for scanning
                temp_dir = self._prepare_scan_files(terraform_files)
                
                # Execute MCP-based Checkov scan
                raw_scan_results = self._execute_mcp_checkov_scan(temp_dir, terraform_files)
                
                # Extract failed_checks from Checkov JSON response
                failed_checks = []
                total_failed = 0
                
                if isinstance(raw_scan_results, dict):
                    # Checkov JSON format: {"results": {"failed_checks": [...]}, "summary": {"failed": N}}
                    if 'results' in raw_scan_results and 'summary' in raw_scan_results:
                        # This is the standard Checkov JSON format
                        results = raw_scan_results['results']
                        summary = raw_scan_results['summary']
                        
                        if isinstance(results, dict) and 'failed_checks' in results:
                            failed_checks = results['failed_checks']
                            total_failed = summary.get('failed', len(failed_checks))
                            logger.info(f"Found {len(failed_checks)} failed_checks from Checkov JSON (summary says {total_failed} failed)")
                        else:
                            logger.warning(f"Checkov results structure unexpected: {list(results.keys()) if isinstance(results, dict) else type(results)}")
                    
                    # Fallback formats
                    elif 'failed_checks' in raw_scan_results:
                        failed_checks = raw_scan_results['failed_checks']
                        total_failed = len(failed_checks)
                        logger.info(f"Found {len(failed_checks)} failed_checks in direct format")
                    
                    elif 'findings' in raw_scan_results:
                        failed_checks = raw_scan_results['findings']
                        total_failed = raw_scan_results.get('total_findings', len(failed_checks))
                        logger.info(f"Found {len(failed_checks)} findings in findings format")
                    
                    elif 'vulnerabilities' in raw_scan_results:
                        # Agent formatted the Checkov output into vulnerabilities structure
                        failed_checks = raw_scan_results['vulnerabilities']
                        total_failed = len(failed_checks)
                        logger.info(f"Found {len(failed_checks)} vulnerabilities in agent-formatted structure")
                    
                    else:
                        logger.warning(f"Could not find failed_checks in raw_scan_results keys: {list(raw_scan_results.keys())}")
                
                # If still no findings, try text parsing fallback
                if not failed_checks and isinstance(raw_scan_results, dict) and 'total_findings' in raw_scan_results:
                    total_failed = raw_scan_results['total_findings']
                    failed_checks = raw_scan_results.get('findings', [])
                    logger.info(f"Using text parsing fallback: {total_failed} total, {len(failed_checks)} detailed findings")
                
                # Clean up findings - remove verbose fields but keep essential data
                clean_findings = []
                for finding in failed_checks:
                    if isinstance(finding, dict):
                        clean_finding = finding.copy()
                        # Remove verbose fields to reduce payload size
                        clean_finding.pop('code_block', None)
                        clean_finding.pop('guideline', None)
                        clean_finding.pop('details', None)
                        clean_finding.pop('definition', None)
                        clean_findings.append(clean_finding)
                    else:
                        # Handle non-dict findings
                        clean_findings.append({'raw_finding': str(finding)})
                
                # Create simple response with scan metadata
                scan_duration = time.time() - start_time
                
                simple_results = {
                    'scan_id': scan_id or str(uuid.uuid4())[:8],
                    'findings': clean_findings,
                    'scan_metadata': {
                        'total_findings': total_failed if total_failed > 0 else len(clean_findings),
                        'files_scanned': len(terraform_files),
                        'scan_duration': scan_duration,
                        'source_type': 'mcp_checkov',
                        'checkov_summary': raw_scan_results.get('summary', {}) if isinstance(raw_scan_results, dict) else {}
                    }
                }
                
                logger.info(f"MCP scan completed with {len(clean_findings)} findings in {scan_duration:.2f}s")
                
                # Cleanup temporary directory
                self._cleanup_temp_directory(temp_dir)
                
                return simple_results
                
        except Exception as e:
            logger.error(f"MCP Checkov scan failed: {e}")
            raise
    
    def scan_terraform_project(self, source: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan a complete Terraform project from S3 or local folder
        
        Args:
            source: Either S3 URI (s3://bucket/path) or local folder path
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        logger.info(f"Starting Terraform project scan from source: {source}")
        
        try:
            # Load Terraform files from source
            terraform_files = self.terraform_loader.load_terraform_project(source)
            
            # Validate the loaded files
            validation_report = self.terraform_loader.validate_terraform_files(terraform_files)
            logger.info(f"Loaded {validation_report['total_files']} files, "
                       f"total size: {validation_report['total_size_bytes']} bytes")
            
            if validation_report['issues']:
                logger.warning(f"Validation issues found: {validation_report['issues']}")
            
            # Run security scan
            scan_results = self.run_security_scan(terraform_files, scan_id)
            
            # Add source information to metadata
            scan_results['scan_metadata'].update({
                'source': source,
                'source_type': 's3' if source.startswith('s3://') else 'local',
                'validation_report': validation_report
            })
            
            return scan_results
            
        except Exception as e:
            logger.error(f"Terraform project scan failed for source {source}: {e}")
            raise
    
    def scan_s3_terraform_project(self, s3_uri: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan Terraform project from S3 bucket
        
        Args:
            s3_uri: S3 URI in format 's3://bucket-name/path/to/terraform/project'
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        return self.scan_terraform_project(s3_uri, scan_id)
    
    def scan_local_terraform_project(self, folder_path: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan Terraform project from local folder
        
        Args:
            folder_path: Path to local folder containing Terraform files
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        return self.scan_terraform_project(folder_path, scan_id)
    
    def _prepare_scan_files(self, terraform_files: Dict[str, str]) -> str:
        """Prepare Terraform files for MCP scanning"""
        temp_dir = tempfile.mkdtemp(prefix='mcp_checkov_scan_')
        
        for filename, content in terraform_files.items():
            file_path = os.path.join(temp_dir, filename)
            
            # Create subdirectories if needed
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w') as f:
                f.write(content)
        
        logger.info(f"Prepared {len(terraform_files)} files in {temp_dir}")
        return temp_dir
    
    def _execute_mcp_checkov_scan(self, temp_dir: str, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """Execute Checkov scan directly using MCP Terraform Server"""
        
        logger.info(f"Calling MCP RunCheckovScan tool directly on {temp_dir}")
        
        try:
            # Generate a unique tool use ID for the MCP call
            import uuid
            tool_use_id = str(uuid.uuid4())
            
            # Call the MCP tool directly without model intermediation
            tool_result = self.tf_mcp_client.call_tool_sync(
                name="RunCheckovScan",
                arguments={
                    "working_directory": temp_dir
                },
                tool_use_id=tool_use_id
            )
            
            logger.info(f"MCP tool result type: {type(tool_result)}")
            logger.info(f"MCP tool result keys: {list(tool_result.keys()) if isinstance(tool_result, dict) else 'Not a dict'}")
            
            # Extract the actual result from the MCP response
            if isinstance(tool_result, dict):
                # Direct dict response from MCP
                raw_response = tool_result
                logger.info(f"Using direct dict response with keys: {list(raw_response.keys())}")
            elif hasattr(tool_result, 'content'):
                raw_response = tool_result.content
                logger.info(f"Using content attribute: {type(raw_response)}")
            elif hasattr(tool_result, 'result'):
                raw_response = tool_result.result
                logger.info(f"Using result attribute: {type(raw_response)}")
            else:
                raw_response = str(tool_result)
                logger.info(f"Using string conversion: {len(raw_response)} chars")
            
            # Parse Checkov JSON from the MCP response structure
            if isinstance(raw_response, dict):
                logger.info(f"MCP response is a dict with keys: {list(raw_response.keys())}")
                
                # Check if it's the MCP wrapper format with content/structuredContent
                if 'content' in raw_response or 'structuredContent' in raw_response:
                    # Try structuredContent first (should be parsed JSON)
                    if 'structuredContent' in raw_response:
                        structured_content = raw_response['structuredContent']
                        logger.info(f"Found structuredContent: {type(structured_content)}")
                        if isinstance(structured_content, dict):
                            logger.info(f"StructuredContent keys: {list(structured_content.keys())}")
                            
                            # Check if it's the MCP server's own format with vulnerabilities
                            if 'vulnerabilities' in structured_content and 'summary' in structured_content:
                                vulnerabilities = structured_content['vulnerabilities']
                                summary = structured_content['summary']
                                logger.info(f"Found MCP server format with {len(vulnerabilities)} vulnerabilities")
                                
                                # Convert to Checkov format
                                checkov_format = {
                                    'results': {
                                        'failed_checks': vulnerabilities
                                    },
                                    'summary': summary
                                }
                                return checkov_format
                            
                            # Check if it's standard Checkov JSON format
                            elif 'results' in structured_content and 'summary' in structured_content:
                                logger.info(f"Found Checkov JSON in structuredContent with {structured_content.get('summary', {}).get('failed', 0)} failed checks")
                                return structured_content
                    
                    # Try content field (might be string or dict)
                    if 'content' in raw_response:
                        content = raw_response['content']
                        logger.info(f"Found content: {type(content)}")
                        
                        if isinstance(content, dict):
                            logger.info(f"Content is dict with keys: {list(content.keys())}")
                            if 'results' in content and 'summary' in content:
                                logger.info(f"Found Checkov JSON in content dict with {content.get('summary', {}).get('failed', 0)} failed checks")
                                return content
                        
                        elif isinstance(content, str):
                            logger.info(f"Content is string, length: {len(content)}")
                            # Try to parse JSON from string content
                            try:
                                parsed_content = json.loads(content)
                                if isinstance(parsed_content, dict) and 'results' in parsed_content and 'summary' in parsed_content:
                                    logger.info(f"Parsed Checkov JSON from content string with {parsed_content.get('summary', {}).get('failed', 0)} failed checks")
                                    return parsed_content
                            except json.JSONDecodeError:
                                logger.warning("Failed to parse content as JSON")
                
                # Check if it's already in Checkov format
                elif 'results' in raw_response and 'summary' in raw_response:
                    logger.info(f"MCP response is already Checkov JSON format with {raw_response.get('summary', {}).get('failed', 0)} failed checks")
                    return raw_response
                
                else:
                    logger.warning(f"Unknown MCP response structure with keys: {list(raw_response.keys())}")
            
            elif isinstance(raw_response, str) and "Checkov stdout:" in raw_response:
                # Handle string response with Checkov output
                json_start = raw_response.find("Checkov stdout:") + len("Checkov stdout:")
                json_content = raw_response[json_start:].strip()
                
                # Find complete JSON structure
                brace_start = json_content.find('{')
                if brace_start != -1:
                    json_content = json_content[brace_start:]
                    
                    # Count braces to find complete JSON
                    brace_count = 0
                    json_end = -1
                    for idx, char in enumerate(json_content):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                json_end = idx + 1
                                break
                    
                    if json_end != -1:
                        json_str = json_content[:json_end]
                        try:
                            checkov_results = json.loads(json_str)
                            logger.info(f"Successfully parsed Checkov JSON from string with {checkov_results.get('summary', {}).get('failed', 0)} failed checks")
                            return checkov_results
                        except json.JSONDecodeError as e:
                            logger.error(f"Failed to parse Checkov JSON: {e}")
            
            # Fallback
            logger.warning("Could not parse MCP response, returning empty results")
            return {"results": {"failed_checks": []}, "summary": {"failed": 0}}
            
        except Exception as e:
            logger.error(f"Direct MCP tool call failed: {e}")
            return {"results": {"failed_checks": []}, "summary": {"failed": 0}}
    
    def _execute_mcp_checkov_scan_old(self, temp_dir: str, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """Execute Checkov scan directly using MCP Terraform Server"""
        
        logger.info(f"Calling MCP RunCheckovScan tool directly on {temp_dir}")
        
        try:
            # Call the MCP tool directly without model intermediation
            tool_result = self.tf_mcp_client.call_tool_sync(
                name="mcp_awslabsterraform_mcp_server_RunCheckovScan",
                arguments={
                    "working_directory": temp_dir
                }
            )
            
            logger.info(f"MCP tool result type: {type(tool_result)}")
            
            # Extract the actual result from the MCP response
            if hasattr(tool_result, 'content'):
                scan_response = tool_result.content
            elif hasattr(tool_result, 'result'):
                scan_response = tool_result.result
            else:
                scan_response = str(tool_result)
                
            logger.info(f"Raw MCP response length: {len(str(scan_response))}")
            
        except Exception as e:
            logger.error(f"Direct MCP tool call failed: {e}")
            # Return empty results if direct call fails
            return {"results": {"failed_checks": []}, "summary": {"failed": 0}}
        
        # Parse the MCP response to extract Checkov JSON
        try:
            import json
            
            logger.info(f"MCP response type: {type(scan_response)}")
            
            # Handle different MCP response formats
            if isinstance(scan_response, str):
                message_content = scan_response.message
                logger.info(f"Found message content, type: {type(message_content)}, length: {len(str(message_content))}")
                
                # If message is already a dict, check if it's the Checkov JSON structure
                if isinstance(message_content, dict):
                    logger.info(f"Message is dict with keys: {list(message_content.keys())}")
                    if 'results' in message_content and 'summary' in message_content:
                        response_content = message_content
                        logger.info(f"Found Checkov JSON structure in message dict with {message_content['summary'].get('failed', 0)} failed checks")
                    else:
                        # Check if it contains the raw Checkov output in a text field
                        for key, value in message_content.items():
                            if isinstance(value, str):
                                logger.info(f"Checking message dict key '{key}' for Checkov output (length: {len(value)})")
                                if "Checkov stdout:" in value:
                                    logger.info(f"Found 'Checkov stdout:' in message dict key: {key}")
                                # Extract JSON from the string value
                                json_start = value.find("Checkov stdout:") + len("Checkov stdout:")
                                json_content = value[json_start:].strip()
                                
                                # Find the JSON object boundaries
                                brace_start = json_content.find('{')
                                if brace_start != -1:
                                    json_content = json_content[brace_start:]
                                    
                                    # Find the end of the JSON by counting braces
                                    brace_count = 0
                                    json_end = -1
                                    for idx, char in enumerate(json_content):
                                        if char == '{':
                                            brace_count += 1
                                        elif char == '}':
                                            brace_count -= 1
                                            if brace_count == 0:
                                                json_end = idx + 1
                                                break
                                    
                                    if json_end != -1:
                                        json_str = json_content[:json_end]
                                        try:
                                            parsed_json = json.loads(json_str)
                                            logger.info(f"Successfully parsed Checkov JSON from message dict with keys: {list(parsed_json.keys())}")
                                            if 'results' in parsed_json and 'summary' in parsed_json:
                                                response_content = parsed_json
                                                logger.info(f"Found Checkov JSON in message dict with {parsed_json['summary'].get('failed', 0)} failed checks")
                                                break
                                        except json.JSONDecodeError as e:
                                            logger.error(f"Failed to parse Checkov JSON from message dict: {e}")
                
                # If message is a string, check if it contains the Checkov JSON
                elif isinstance(message_content, str) and "Checkov stdout:" in message_content:
                    logger.info("Found 'Checkov stdout:' in message content")
                    # Extract JSON after "Checkov stdout:"
                    json_start = message_str.find("Checkov stdout:") + len("Checkov stdout:")
                    json_content = message_str[json_start:].strip()
                    
                    # Find the JSON object boundaries
                    brace_start = json_content.find('{')
                    if brace_start != -1:
                        json_content = json_content[brace_start:]
                        
                        # Find the end of the JSON by counting braces
                        brace_count = 0
                        json_end = -1
                        for idx, char in enumerate(json_content):
                            if char == '{':
                                brace_count += 1
                            elif char == '}':
                                brace_count -= 1
                                if brace_count == 0:
                                    json_end = idx + 1
                                    break
                        
                        if json_end != -1:
                            json_str = json_content[:json_end]
                            try:
                                parsed_json = json.loads(json_str)
                                logger.info(f"Successfully parsed Checkov JSON from message with keys: {list(parsed_json.keys())}")
                                if 'results' in parsed_json and 'summary' in parsed_json:
                                    response_content = parsed_json
                                    logger.info(f"Found Checkov JSON in message with {parsed_json['summary'].get('failed', 0)} failed checks")
                                else:
                                    logger.warning(f"Parsed JSON doesn't have expected Checkov structure: {list(parsed_json.keys())}")
                            except json.JSONDecodeError as e:
                                logger.error(f"Failed to parse Checkov JSON from message: {e}")
            
            # If no JSON found in message, try tool_results
            if response_content is None and hasattr(scan_response, 'tool_results') and scan_response.tool_results:
                logger.info(f"Found {len(scan_response.tool_results)} tool results")
                for i, tool_result in enumerate(scan_response.tool_results):
                    logger.info(f"Tool result {i}: type={type(tool_result)}")
                    
                    # Try different ways to extract content from tool result
                    if hasattr(tool_result, 'content') and tool_result.content:
                        content = tool_result.content
                        logger.info(f"Tool result {i} content type: {type(content)}")
                        
                        # If content is already a dict, use it directly
                        if isinstance(content, dict):
                            logger.info(f"Found dict content with keys: {list(content.keys())}")
                            if 'results' in content or 'failed_checks' in content or 'summary' in content:
                                response_content = content
                                logger.info(f"Using dict content from tool result {i}")
                                break
                        
                        # If content is a string, look for the Checkov JSON output
                        elif isinstance(content, str):
                            logger.info(f"Tool result {i} content length: {len(content)}")
                            
                            # Look specifically for the Checkov stdout JSON that starts after "Checkov stdout:"
                            if "Checkov stdout:" in content:
                                # Extract JSON after "Checkov stdout:"
                                json_start = content.find("Checkov stdout:") + len("Checkov stdout:")
                                json_content = content[json_start:].strip()
                                
                                # Find the JSON object boundaries
                                brace_start = json_content.find('{')
                                if brace_start != -1:
                                    json_content = json_content[brace_start:]
                                    
                                    # Find the end of the JSON by counting braces
                                    brace_count = 0
                                    json_end = -1
                                    for idx, char in enumerate(json_content):
                                        if char == '{':
                                            brace_count += 1
                                        elif char == '}':
                                            brace_count -= 1
                                            if brace_count == 0:
                                                json_end = idx + 1
                                                break
                                    
                                    if json_end != -1:
                                        json_str = json_content[:json_end]
                                        try:
                                            parsed_json = json.loads(json_str)
                                            logger.info(f"Successfully parsed Checkov JSON with keys: {list(parsed_json.keys())}")
                                            if 'results' in parsed_json and 'summary' in parsed_json:
                                                response_content = parsed_json
                                                logger.info(f"Found Checkov JSON with {parsed_json['summary'].get('failed', 0)} failed checks")
                                                break
                                        except json.JSONDecodeError as e:
                                            logger.error(f"Failed to parse Checkov JSON: {e}")
                            
                            # Fallback: Look for any JSON structure
                            json_match = re.search(r'\{.*\}', content, re.DOTALL)
                            if json_match and response_content is None:
                                try:
                                    parsed_json = json.loads(json_match.group())
                                    logger.info(f"Parsed fallback JSON from tool result {i} with keys: {list(parsed_json.keys()) if isinstance(parsed_json, dict) else 'Not a dict'}")
                                    if isinstance(parsed_json, dict) and ('results' in parsed_json or 'failed_checks' in parsed_json or 'summary' in parsed_json):
                                        response_content = parsed_json
                                        break
                                except json.JSONDecodeError:
                                    logger.warning(f"Failed to parse fallback JSON from tool result {i}")
                    
                    # Try result attribute
                    elif hasattr(tool_result, 'result') and tool_result.result:
                        result = tool_result.result
                        logger.info(f"Tool result {i} result type: {type(result)}")
                        
                        if isinstance(result, dict):
                            logger.info(f"Found dict result with keys: {list(result.keys())}")
                            if 'results' in result or 'failed_checks' in result or 'summary' in result:
                                response_content = result
                                break
                        elif isinstance(result, str):
                            # Try to parse JSON from result string
                            try:
                                parsed_result = json.loads(result)
                                logger.info(f"Parsed JSON from tool result {i} with keys: {list(parsed_result.keys()) if isinstance(parsed_result, dict) else 'Not a dict'}")
                                if isinstance(parsed_result, dict) and ('results' in parsed_result or 'failed_checks' in parsed_result or 'summary' in parsed_result):
                                    response_content = parsed_result
                                    break
                            except json.JSONDecodeError:
                                logger.warning(f"Failed to parse JSON from tool result {i}")
            
            # Fallback to other response attributes
            if response_content is None:
                if hasattr(scan_response, 'content'):
                    response_content = scan_response.content
                elif hasattr(scan_response, 'text'):
                    response_content = scan_response.text
                else:
                    response_content = str(scan_response)
                    logger.warning(f"Using string representation of AgentResult")
            
            # Process the response content
            if isinstance(response_content, dict):
                # Already a dictionary - this is the ideal case
                scan_results = response_content
                logger.info(f"Using dict response with keys: {list(scan_results.keys())}")
            elif isinstance(response_content, str):
                # Try to extract JSON from string content
                logger.info(f"Processing string response, length: {len(response_content)}")
                
                # Look for JSON structure in the string
                json_match = re.search(r'\{.*\}', response_content, re.DOTALL)
                if json_match:
                    try:
                        scan_results = json.loads(json_match.group())
                        logger.info(f"Parsed JSON from string with keys: {list(scan_results.keys()) if isinstance(scan_results, dict) else 'Not a dict'}")
                    except json.JSONDecodeError as e:
                        logger.error(f"JSON decode error: {e}")
                        scan_results = self._parse_text_scan_results(response_content)
                else:
                    logger.warning("No JSON structure found in string response")
                    scan_results = self._parse_text_scan_results(response_content)
            else:
                # Fallback: create structured results from text response
                scan_results = self._parse_text_scan_results(str(response_content))
                
            return scan_results
            
        except Exception as e:
            logger.error(f"Failed to parse MCP scan results: {e}")
            logger.error(f"Response type: {type(scan_response)}")
            if hasattr(scan_response, '__dict__'):
                logger.error(f"Response attributes: {list(scan_response.__dict__.keys())}")
            # Create fallback structured results
            return self._create_fallback_scan_results(scan_response, terraform_files)
    
    def _parse_text_scan_results(self, text_response: str) -> Dict[str, Any]:
        """Parse text-based scan results into structured format"""
        import re
        
        findings = []
        total_findings = 0
        
        # Try multiple patterns to extract the total failed checks count
        failed_patterns = [
            r'Failed Checks:\s*(\d+)',
            r'Failed:\s*(\d+)', 
            r'Total Checks Failed\*\*\s*\|\s*(\d+)',
            r'failed["\s:]*(\d+)',
            r'(\d+)\s+failed\s+checks?',
            r'Vulnerabilities Found:\s*(\d+)',
        ]
        
        for pattern in failed_patterns:
            failed_match = re.search(pattern, text_response, re.IGNORECASE)
            if failed_match:
                total_findings = int(failed_match.group(1))
                logger.info(f"Found total findings using pattern '{pattern}': {total_findings}")
                break
        
        # Extract individual findings with various CKV_ patterns
        ckv_patterns = [
            r'(\d+)\.\s*\*\*([CKV_\w+]+)\*\*\s*-\s*([^\n]+)',  # Numbered list format
            r'\*\*([CKV_\w+]+)\*\*\s*-\s*([^\n]+)',  # Bold format
            r'([CKV_\w+]+):\s*([^\n]+)',  # Simple colon format
            r'Check ID.*?([CKV_\w+]+).*?Description.*?([^\n]+)',  # Table format
        ]
        
        for pattern in ckv_patterns:
            ckv_matches = re.findall(pattern, text_response)
            if ckv_matches:
                logger.info(f"Found {len(ckv_matches)} CKV matches using pattern: {pattern}")
                for match in ckv_matches:
                    if len(match) == 3:  # Numbered format
                        finding_num, check_id, description = match
                    elif len(match) == 2:  # Other formats
                        check_id, description = match
                        finding_num = len(findings) + 1
                    else:
                        continue
                    
                    finding = {
                        'check_id': check_id,
                        'description': description.strip(),
                        'severity': 'MEDIUM',  # Default severity
                        'resource': 'unknown',
                        'file': 'unknown',
                        'finding_number': finding_num
                    }
                    findings.append(finding)
                break  # Use the first pattern that matches
        
        # If we have a total count but no detailed findings, create basic findings from CKV mentions
        if total_findings > 0 and len(findings) == 0:
            all_ckv_matches = re.findall(r'(CKV_[A-Z_0-9]+)', text_response)
            unique_checks = list(set(all_ckv_matches))
            logger.info(f"Creating {len(unique_checks)} basic findings from CKV mentions")
            
            for i, check_id in enumerate(unique_checks):
                finding = {
                    'check_id': check_id,
                    'description': f'Security check failed: {check_id}',
                    'severity': 'MEDIUM',
                    'resource': 'unknown',
                    'file': 'unknown',
                    'finding_number': i + 1
                }
                findings.append(finding)
        
        # Use the higher of the two counts (total from summary vs detailed findings)
        final_count = max(total_findings, len(findings))
        
        return {
            'findings': findings,
            'total_findings': final_count,
            'scan_status': 'completed_from_text_parsing'
        }
    
    def _create_fallback_scan_results(self, response: Any, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """Create fallback scan results when MCP parsing fails"""
        return {
            'findings': [],
            'total_findings': 0,
            'scan_status': 'completed_with_parsing_issues',
            'raw_response': str(response),
            'files_processed': list(terraform_files.keys())
        }
    

    
    def _extract_check_id(self, text: str) -> str:
        """Extract Checkov check ID from text"""
        import re
        match = re.search(r'CKV_[A-Z]+_\d+', text)
        return match.group() if match else ''
    
    def _determine_severity_from_text(self, text: str) -> str:
        """Determine severity level from text content"""
        text_lower = text.lower()
        if any(word in text_lower for word in ['critical', 'severe']):
            return 'CRITICAL'
        elif any(word in text_lower for word in ['high', 'important']):
            return 'HIGH'
        elif any(word in text_lower for word in ['medium', 'moderate']):
            return 'MEDIUM'
        else:
            return 'LOW'
    

    
    def _extract_file_from_text(self, text: str) -> str:
        """Extract filename from text"""
        import re
        # Look for file patterns like "file.tf" or "/path/to/file.tf"
        match = re.search(r'[\w/.-]+\.tf\w*', text)
        return match.group() if match else ''
    
    def _extract_resource_from_text(self, text: str) -> str:
        """Extract resource name from text"""
        import re
        # Look for AWS resource patterns
        match = re.search(r'aws_\w+\.\w+', text)
        return match.group() if match else ''
    
    def _extract_check_context(self, text: str, check_id: str) -> Dict[str, Any]:
        """Extract context information around a specific check ID"""
        import re
        
        # Find the section of text around this check ID
        lines = text.split('\n')
        context_lines = []
        
        for i, line in enumerate(lines):
            if check_id in line:
                # Get surrounding lines for context
                start = max(0, i - 3)
                end = min(len(lines), i + 4)
                context_lines = lines[start:end]
                break
        
        context_text = '\n'.join(context_lines)
        
        # Extract information from context
        context = {
            'description': '',
            'severity': 'MEDIUM',
            'file': '',
            'resource': '',
            'line_number': None
        }
        
        # Look for file references
        file_match = re.search(r'[\w/.-]+\.tf\w*', context_text)
        if file_match:
            context['file'] = file_match.group()
        
        # Look for resource references
        resource_match = re.search(r'aws_\w+\.\w+', context_text)
        if resource_match:
            context['resource'] = resource_match.group()
        
        # Look for line numbers
        line_match = re.search(r'line[:\s]*(\d+)', context_text, re.IGNORECASE)
        if line_match:
            context['line_number'] = int(line_match.group(1))
        
        # Look for severity indicators
        if any(word in context_text.lower() for word in ['critical', 'high']):
            context['severity'] = 'HIGH'
        elif any(word in context_text.lower() for word in ['low', 'info']):
            context['severity'] = 'LOW'
        
        # Extract description from the context
        desc_patterns = [
            r'description[:\s]*([^\n]+)',
            r'message[:\s]*([^\n]+)',
            r'summary[:\s]*([^\n]+)',
        ]
        
        for pattern in desc_patterns:
            desc_match = re.search(pattern, context_text, re.IGNORECASE)
            if desc_match:
                context['description'] = desc_match.group(1).strip()
                break
        
        return context
    
    def _cleanup_temp_directory(self, temp_dir: str) -> None:
        """Clean up temporary directory"""
        import shutil
        try:
            shutil.rmtree(temp_dir)
            logger.info(f"Cleaned up temporary directory: {temp_dir}")
        except Exception as e:
            logger.error(f"Failed to cleanup directory {temp_dir}: {e}")
    
    def get_mcp_tools_info(self) -> List[str]:
        """Get information about available MCP tools"""
        with self.tf_mcp_client:
            tools = self.tf_mcp_client.list_tools_sync()
            return [tool.tool_name for tool in tools]

def create_checkov_scanner_agent() -> CheckovScannerAgent:
    """Factory function to create Checkov Scanner Agent instance"""
    return CheckovScannerAgent()

def run_checkov_scan(terraform_files: Dict[str, str], scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to run Checkov scan on file dictionary"""
    agent = create_checkov_scanner_agent()
    return agent.run_security_scan(terraform_files, scan_id)

def scan_terraform_project(source: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from S3 or local folder"""
    agent = create_checkov_scanner_agent()
    return agent.scan_terraform_project(source, scan_id)

def scan_s3_terraform_project(s3_uri: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from S3"""
    agent = create_checkov_scanner_agent()
    return agent.scan_s3_terraform_project(s3_uri, scan_id)

def scan_local_terraform_project(folder_path: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from local folder"""
    agent = create_checkov_scanner_agent()
    return agent.scan_local_terraform_project(folder_path, scan_id)

# Agent will be deployed on AgentCore runtime