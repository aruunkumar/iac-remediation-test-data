"""
Checkov Scanner Agent - Specialized security scanning agent
Built with Strands SDK for deployment on AWS Bedrock AgentCore
Uses MCP Terraform Server for enhanced Checkov integration
"""

from strands import Agent
from strands.tools.mcp import MCPClient
from strands_tools import file_read, file_write
from mcp.client.stdio import stdio_client
from mcp import StdioServerParameters
from typing import Dict, List, Any
import json
import logging
import tempfile
import os
import time

# Import the enhanced scan processor and terraform loader
try:
    from .scan_processor import MCPScanResultProcessor, create_scan_processor
    from .terraform_loader import TerraformProjectLoader, create_terraform_loader
except ImportError:
    # Fallback for direct execution
    from scan_processor import MCPScanResultProcessor, create_scan_processor
    from terraform_loader import TerraformProjectLoader, create_terraform_loader

logger = logging.getLogger(__name__)

def get_terraform_mcp_client():
    """Get MCP Terraform client - reused from mcp_terraform.py"""
    return MCPClient(
        lambda: stdio_client(
            StdioServerParameters(
                command="uvx",
                args=["awslabs.terraform-mcp-server@latest"],
                env={"FASTMCP_LOG_LEVEL": "ERROR"},
                disabled=False,
                auto_approve=[],
                debug=True,
            )
        )
    )

def get_checkov_scanner_system_prompt() -> str:
    """System prompt for the Checkov Scanner Agent with MCP integration"""
    return """
    You are the Checkov Scanner Agent specialized in running security scans on Terraform code 
    using the AWS Labs Terraform MCP Server.
    
    Your responsibilities:
    1. Use MCP Terraform server's Checkov integration to scan Terraform files
    2. Process and normalize scan results from the MCP server
    3. Categorize findings by severity (CRITICAL, HIGH, MEDIUM, LOW) and remediability
    4. Provide scan metadata including total findings, file coverage, and scan duration
    
    The MCP server provides built-in Checkov capabilities - use these instead of direct CLI calls.
    Always return results in a consistent format that other agents can process.
    
    Available MCP tools for Checkov operations:
    - Use file_read and file_write tools for file operations
    - Use MCP server's Checkov integration for security scanning
    - Process structured scan results from MCP server output
    """

class CheckovScannerAgent:
    """Checkov Scanner Agent for security scanning operations using MCP Terraform Server"""
    
    def __init__(self):
        self.tf_mcp_client = get_terraform_mcp_client()
        self.scan_processor = create_scan_processor()
        self.terraform_loader = create_terraform_loader()
        self.agent = None
        self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Strands agent with MCP tools"""
        with self.tf_mcp_client:
            # Get MCP tools from Terraform server
            mcp_tools = self.tf_mcp_client.list_tools_sync()
            
            # Combine MCP tools with file system tools
            all_tools = mcp_tools + [file_read, file_write]
            
            # Create Strands agent with MCP integration
            self.agent = Agent(
                system_prompt=get_checkov_scanner_system_prompt(),
                tools=all_tools,
                model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"
            )
            
            logger.info(f"Initialized Checkov Scanner Agent with {len(mcp_tools)} MCP tools")
    
    def run_security_scan(self, terraform_files: Dict[str, str], scan_id: str = None) -> Dict[str, Any]:
        """Execute Checkov scan using MCP Terraform Server"""
        logger.info(f"Starting MCP Checkov scan on {len(terraform_files)} files")
        
        start_time = time.time()
        
        try:
            with self.tf_mcp_client:
                # Prepare files for scanning
                temp_dir = self._prepare_scan_files(terraform_files)
                
                # Execute MCP-based Checkov scan
                scan_results = self._execute_mcp_checkov_scan(temp_dir, terraform_files)
                
                # Process and categorize results using enhanced processor
                categorized_results = self.scan_processor.process_mcp_scan_results(scan_results, terraform_files, scan_id)
                
                # Add scan metadata
                scan_duration = time.time() - start_time
                categorized_results['scan_metadata']['scan_duration'] = scan_duration
                categorized_results['scan_metadata']['files_scanned'] = len(terraform_files)
                
                logger.info(f"MCP scan completed with {categorized_results.get('total_findings', 0)} findings in {scan_duration:.2f}s")
                
                # Cleanup temporary directory
                self._cleanup_temp_directory(temp_dir)
                
                return categorized_results
                
        except Exception as e:
            logger.error(f"MCP Checkov scan failed: {e}")
            raise
    
    def scan_terraform_project(self, source: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan a complete Terraform project from S3 or local folder
        
        Args:
            source: Either S3 URI (s3://bucket/path) or local folder path
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        logger.info(f"Starting Terraform project scan from source: {source}")
        
        try:
            # Load Terraform files from source
            terraform_files = self.terraform_loader.load_terraform_project(source)
            
            # Validate the loaded files
            validation_report = self.terraform_loader.validate_terraform_files(terraform_files)
            logger.info(f"Loaded {validation_report['total_files']} files, "
                       f"total size: {validation_report['total_size_bytes']} bytes")
            
            if validation_report['issues']:
                logger.warning(f"Validation issues found: {validation_report['issues']}")
            
            # Run security scan
            scan_results = self.run_security_scan(terraform_files, scan_id)
            
            # Add source information to metadata
            scan_results['scan_metadata'].update({
                'source': source,
                'source_type': 's3' if source.startswith('s3://') else 'local',
                'validation_report': validation_report
            })
            
            return scan_results
            
        except Exception as e:
            logger.error(f"Terraform project scan failed for source {source}: {e}")
            raise
    
    def scan_s3_terraform_project(self, s3_uri: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan Terraform project from S3 bucket
        
        Args:
            s3_uri: S3 URI in format 's3://bucket-name/path/to/terraform/project'
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        return self.scan_terraform_project(s3_uri, scan_id)
    
    def scan_local_terraform_project(self, folder_path: str, scan_id: str = None) -> Dict[str, Any]:
        """
        Scan Terraform project from local folder
        
        Args:
            folder_path: Path to local folder containing Terraform files
            scan_id: Optional scan ID to use for results storage
            
        Returns:
            Scan results with findings and metadata
        """
        return self.scan_terraform_project(folder_path, scan_id)
    
    def _prepare_scan_files(self, terraform_files: Dict[str, str]) -> str:
        """Prepare Terraform files for MCP scanning"""
        temp_dir = tempfile.mkdtemp(prefix='mcp_checkov_scan_')
        
        for filename, content in terraform_files.items():
            file_path = os.path.join(temp_dir, filename)
            
            # Create subdirectories if needed
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w') as f:
                f.write(content)
        
        logger.info(f"Prepared {len(terraform_files)} files in {temp_dir}")
        return temp_dir
    
    def _execute_mcp_checkov_scan(self, temp_dir: str, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """Execute Checkov scan using MCP Terraform Server capabilities"""
        
        # Use the Strands agent to perform MCP-based Checkov scan
        scan_prompt = f"""
        Use the MCP Terraform server to run a comprehensive Checkov security scan on the Terraform files 
        in directory: {temp_dir}
        
        Files to scan: {list(terraform_files.keys())}
        
        Please:
        1. Use the MCP server's Checkov integration to scan all Terraform files
        2. Return structured scan results with findings, severity levels, and check IDs
        3. Include metadata about the scan execution
        4. Ensure results are in JSON format for processing
        """
        
        scan_response = self.agent(scan_prompt)
        
        # Parse the agent response to extract structured results
        try:
            # Handle AgentResult object from Strands
            response_content = None
            
            # Try different ways to extract content from AgentResult
            if hasattr(scan_response, 'content'):
                response_content = scan_response.content
            elif hasattr(scan_response, 'text'):
                response_content = scan_response.text
            elif hasattr(scan_response, 'tool_results') and scan_response.tool_results:
                # Extract from tool results - this is likely where MCP results are
                for tool_result in scan_response.tool_results:
                    if hasattr(tool_result, 'content'):
                        response_content = tool_result.content
                        break
                    elif hasattr(tool_result, 'result'):
                        response_content = tool_result.result
                        break
            
            if response_content is None:
                # Fallback to string representation
                response_content = str(scan_response)
                logger.warning(f"Using string representation of AgentResult")
            
            # Try to extract JSON from the response content
            if isinstance(response_content, str):
                # Clean up the content - remove markdown code blocks if present
                cleaned_content = response_content.strip()
                if cleaned_content.startswith('```'):
                    # Remove markdown code blocks
                    lines = cleaned_content.split('\n')
                    if len(lines) > 2:
                        cleaned_content = '\n'.join(lines[1:-1])
                
                import re
                import json
                
                # Try to find JSON structure more carefully
                # Look for the start of JSON and try to parse from there
                json_start = cleaned_content.find('{')
                if json_start != -1:
                    # Try to parse JSON from the first brace
                    json_candidate = cleaned_content[json_start:]
                    
                    # Try to find the complete JSON by counting braces
                    brace_count = 0
                    json_end = -1
                    
                    for i, char in enumerate(json_candidate):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                json_end = i + 1
                                break
                    
                    if json_end != -1:
                        json_str = json_candidate[:json_end]
                        try:
                            scan_results = json.loads(json_str)
                        except json.JSONDecodeError as e:
                            logger.error(f"JSON decode error: {e}")
                            scan_results = self._parse_text_scan_results(cleaned_content)
                    else:
                        logger.warning("Could not find complete JSON structure")
                        scan_results = self._parse_text_scan_results(cleaned_content)
                else:
                    # Fallback: create structured results from text response
                    scan_results = self._parse_text_scan_results(cleaned_content)
            elif isinstance(response_content, dict):
                # Already a dictionary
                scan_results = response_content
            else:
                # Fallback: create structured results from text response
                scan_results = self._parse_text_scan_results(str(response_content))
                
            return scan_results
            
        except (json.JSONDecodeError, AttributeError) as e:
            logger.warning(f"Failed to parse MCP scan results: {e}")
            logger.warning(f"Response type: {type(scan_response)}")
            if hasattr(scan_response, '__dict__'):
                logger.warning(f"Response attributes: {list(scan_response.__dict__.keys())}")
            # Create fallback structured results
            return self._create_fallback_scan_results(scan_response, terraform_files)
    
    def _parse_text_scan_results(self, text_response: str) -> Dict[str, Any]:
        """Parse text-based scan results into structured format"""
        # Extract findings from text response
        findings = []
        
        # Look for MCP tool results or Checkov patterns in the response
        lines = text_response.split('\n')
        current_finding = {}
        
        # Check if this looks like MCP tool output
        if 'failed_checks' in text_response.lower() or 'summary' in text_response.lower():
            # Try to extract structured data from what looks like MCP output
            import re
            
            # Look for failed checks count
            failed_match = re.search(r'failed["\s:]*(\d+)', text_response, re.IGNORECASE)
            if failed_match:
                failed_count = int(failed_match.group(1))
                return {
                    'findings': [],
                    'total_findings': failed_count,
                    'scan_status': 'completed_from_text'
                }
        
        # Fallback: Look for common Checkov patterns in the response
        for line in lines:
            line = line.strip()
            if 'CKV_' in line:  # Checkov check ID pattern
                if current_finding:
                    findings.append(current_finding)
                current_finding = {
                    'check_id': self._extract_check_id(line),
                    'description': line,
                    'severity': self._determine_severity_from_text(line),
                    'file': self._extract_file_from_text(line),
                    'resource': self._extract_resource_from_text(line)
                }
        
        if current_finding:
            findings.append(current_finding)
        
        return {
            'findings': findings,
            'total_findings': len(findings),
            'scan_status': 'completed_from_text_parsing'
        }
    
    def _create_fallback_scan_results(self, response: Any, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """Create fallback scan results when MCP parsing fails"""
        return {
            'findings': [],
            'total_findings': 0,
            'scan_status': 'completed_with_parsing_issues',
            'raw_response': str(response),
            'files_processed': list(terraform_files.keys())
        }
    

    
    def _extract_check_id(self, text: str) -> str:
        """Extract Checkov check ID from text"""
        import re
        match = re.search(r'CKV_[A-Z]+_\d+', text)
        return match.group() if match else ''
    
    def _determine_severity_from_text(self, text: str) -> str:
        """Determine severity level from text content"""
        text_lower = text.lower()
        if any(word in text_lower for word in ['critical', 'severe']):
            return 'CRITICAL'
        elif any(word in text_lower for word in ['high', 'important']):
            return 'HIGH'
        elif any(word in text_lower for word in ['medium', 'moderate']):
            return 'MEDIUM'
        else:
            return 'LOW'
    

    
    def _extract_file_from_text(self, text: str) -> str:
        """Extract filename from text"""
        import re
        # Look for file patterns like "file.tf" or "/path/to/file.tf"
        match = re.search(r'[\w/.-]+\.tf\w*', text)
        return match.group() if match else ''
    
    def _extract_resource_from_text(self, text: str) -> str:
        """Extract resource name from text"""
        import re
        # Look for AWS resource patterns
        match = re.search(r'aws_\w+\.\w+', text)
        return match.group() if match else ''
    
    def _extract_check_context(self, text: str, check_id: str) -> Dict[str, Any]:
        """Extract context information around a specific check ID"""
        import re
        
        # Find the section of text around this check ID
        lines = text.split('\n')
        context_lines = []
        
        for i, line in enumerate(lines):
            if check_id in line:
                # Get surrounding lines for context
                start = max(0, i - 3)
                end = min(len(lines), i + 4)
                context_lines = lines[start:end]
                break
        
        context_text = '\n'.join(context_lines)
        
        # Extract information from context
        context = {
            'description': '',
            'severity': 'MEDIUM',
            'file': '',
            'resource': '',
            'line_number': None
        }
        
        # Look for file references
        file_match = re.search(r'[\w/.-]+\.tf\w*', context_text)
        if file_match:
            context['file'] = file_match.group()
        
        # Look for resource references
        resource_match = re.search(r'aws_\w+\.\w+', context_text)
        if resource_match:
            context['resource'] = resource_match.group()
        
        # Look for line numbers
        line_match = re.search(r'line[:\s]*(\d+)', context_text, re.IGNORECASE)
        if line_match:
            context['line_number'] = int(line_match.group(1))
        
        # Look for severity indicators
        if any(word in context_text.lower() for word in ['critical', 'high']):
            context['severity'] = 'HIGH'
        elif any(word in context_text.lower() for word in ['low', 'info']):
            context['severity'] = 'LOW'
        
        # Extract description from the context
        desc_patterns = [
            r'description[:\s]*([^\n]+)',
            r'message[:\s]*([^\n]+)',
            r'summary[:\s]*([^\n]+)',
        ]
        
        for pattern in desc_patterns:
            desc_match = re.search(pattern, context_text, re.IGNORECASE)
            if desc_match:
                context['description'] = desc_match.group(1).strip()
                break
        
        return context
    
    def _cleanup_temp_directory(self, temp_dir: str) -> None:
        """Clean up temporary directory"""
        import shutil
        try:
            shutil.rmtree(temp_dir)
            logger.info(f"Cleaned up temporary directory: {temp_dir}")
        except Exception as e:
            logger.error(f"Failed to cleanup directory {temp_dir}: {e}")
    
    def get_mcp_tools_info(self) -> List[str]:
        """Get information about available MCP tools"""
        with self.tf_mcp_client:
            tools = self.tf_mcp_client.list_tools_sync()
            return [tool.tool_name for tool in tools]

def create_checkov_scanner_agent() -> CheckovScannerAgent:
    """Factory function to create Checkov Scanner Agent instance"""
    return CheckovScannerAgent()

def run_checkov_scan(terraform_files: Dict[str, str], scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to run Checkov scan on file dictionary"""
    agent = create_checkov_scanner_agent()
    return agent.run_security_scan(terraform_files, scan_id)

def scan_terraform_project(source: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from S3 or local folder"""
    agent = create_checkov_scanner_agent()
    return agent.scan_terraform_project(source, scan_id)

def scan_s3_terraform_project(s3_uri: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from S3"""
    agent = create_checkov_scanner_agent()
    return agent.scan_s3_terraform_project(s3_uri, scan_id)

def scan_local_terraform_project(folder_path: str, scan_id: str = None) -> Dict[str, Any]:
    """Convenience function to scan Terraform project from local folder"""
    agent = create_checkov_scanner_agent()
    return agent.scan_local_terraform_project(folder_path, scan_id)

# Agent will be deployed on AgentCore runtime