"""
HTTP API Wrapper for Checkov Scanner Agent
FastAPI-based service for AgentCore deployment
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
import logging
import asyncio
import uuid
from datetime import datetime
import json

try:
    from .main import CheckovScannerAgent, create_checkov_scanner_agent
except ImportError:
    from main import CheckovScannerAgent, create_checkov_scanner_agent

try:
    from shared.interfaces import AgentRequest, AgentResponse
    from shared.utils import ValidationUtils, SecurityUtils
except ImportError:
    # Fallback for development
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from shared.interfaces import AgentRequest, AgentResponse
    from shared.utils import ValidationUtils, SecurityUtils

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app instance
app = FastAPI(
    title="Checkov Scanner Agent API",
    description="HTTP API for Terraform security scanning using MCP Terraform Server",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware for cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response validation

class TerraformFile(BaseModel):
    """Terraform file model"""
    filename: str = Field(..., description="Name of the Terraform file")
    content: str = Field(..., description="Content of the Terraform file")

class ScanRequest(BaseModel):
    """Security scan request model (legacy - individual files)"""
    request_id: Optional[str] = Field(default=None, description="Unique request identifier")
    terraform_files: List[TerraformFile] = Field(..., description="List of Terraform files to scan")
    scan_options: Optional[Dict[str, Any]] = Field(default={}, description="Additional scan options")
    repository_info: Optional[Dict[str, str]] = Field(default={}, description="Repository metadata")

class ProjectScanRequest(BaseModel):
    """Terraform project scan request model"""
    request_id: Optional[str] = Field(default=None, description="Unique request identifier")
    source: str = Field(..., description="S3 URI (s3://bucket/path) or local folder path")
    scan_options: Optional[Dict[str, Any]] = Field(default={}, description="Additional scan options")
    repository_info: Optional[Dict[str, str]] = Field(default={}, description="Repository metadata")

class S3ScanRequest(BaseModel):
    """S3 Terraform project scan request model"""
    request_id: Optional[str] = Field(default=None, description="Unique request identifier")
    s3_uri: str = Field(..., description="S3 URI in format 's3://bucket-name/path/to/terraform/project'")
    scan_options: Optional[Dict[str, Any]] = Field(default={}, description="Additional scan options")
    repository_info: Optional[Dict[str, str]] = Field(default={}, description="Repository metadata")

class LocalScanRequest(BaseModel):
    """Local folder Terraform project scan request model"""
    request_id: Optional[str] = Field(default=None, description="Unique request identifier")
    folder_path: str = Field(..., description="Path to local folder containing Terraform files")
    scan_options: Optional[Dict[str, Any]] = Field(default={}, description="Additional scan options")
    repository_info: Optional[Dict[str, str]] = Field(default={}, description="Repository metadata")

class ScanResponse(BaseModel):
    """Security scan response model"""
    request_id: str = Field(..., description="Request identifier")
    scan_id: str = Field(..., description="Unique scan identifier")
    status: str = Field(..., description="Scan status")
    total_findings: int = Field(..., description="Total number of findings")
    fixable_count: int = Field(..., description="Number of auto-fixable findings")
    manual_count: int = Field(..., description="Number of manual intervention findings")
    scan_duration: float = Field(..., description="Scan duration in seconds")
    findings_summary: Dict[str, Any] = Field(..., description="Summary of findings by category")
    findings_by_severity: Dict[str, List[Dict]] = Field(..., description="Findings grouped by severity")
    findings_by_type: Dict[str, List[Dict]] = Field(..., description="Findings grouped by remediation type")

class DetailedScanResponse(ScanResponse):
    """Detailed scan response with full findings"""
    findings_by_severity: Dict[str, List[Dict]] = Field(..., description="Findings grouped by severity")
    findings_by_type: Dict[str, List[Dict]] = Field(..., description="Findings grouped by remediation type")
    priority_matrix: Dict[str, List[Dict]] = Field(..., description="Priority-based categorization")
    analysis_metadata: Dict[str, Any] = Field(..., description="Analysis metadata and statistics")

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = Field(..., description="Service health status")
    agent_name: str = Field(..., description="Agent name")
    mcp_tools_available: List[str] = Field(..., description="Available MCP tools")
    timestamp: str = Field(..., description="Health check timestamp")

class ErrorResponse(BaseModel):
    """Error response model"""
    error: str = Field(..., description="Error message")
    request_id: Optional[str] = Field(default=None, description="Request identifier")
    timestamp: str = Field(..., description="Error timestamp")

# Global agent instance
scanner_agent: Optional[CheckovScannerAgent] = None

def get_scanner_agent() -> CheckovScannerAgent:
    """Dependency to get scanner agent instance"""
    global scanner_agent
    if scanner_agent is None:
        scanner_agent = create_checkov_scanner_agent()
    return scanner_agent

@app.on_event("startup")
async def startup_event():
    """Initialize agent on startup"""
    global scanner_agent
    try:
        logger.info("Initializing Checkov Scanner Agent...")
        scanner_agent = create_checkov_scanner_agent()
        logger.info("Checkov Scanner Agent initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize agent: {e}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("Shutting down Checkov Scanner Agent API")

@app.get("/health", response_model=HealthResponse)
async def health_check(agent: CheckovScannerAgent = Depends(get_scanner_agent)):
    """Health check endpoint"""
    try:
        mcp_tools = agent.get_mcp_tools_info()
        
        return HealthResponse(
            status="healthy",
            agent_name="checkov-scanner-agent",
            mcp_tools_available=mcp_tools,
            timestamp=datetime.utcnow().isoformat()
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail="Service unhealthy")

@app.post("/scan", response_model=ScanResponse)
async def run_security_scan(
    request: ScanRequest,
    background_tasks: BackgroundTasks,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Execute security scan on individual Terraform files (legacy endpoint)"""
    
    # Generate request ID if not provided
    request_id = request.request_id or str(uuid.uuid4())
    
    try:
        # Validate request
        if not request.terraform_files:
            raise HTTPException(
                status_code=400, 
                detail="No Terraform files provided for scanning"
            )
        
        # Convert files to dictionary format
        terraform_files = {
            tf_file.filename: tf_file.content 
            for tf_file in request.terraform_files
        }
        
        # Validate Terraform files
        for filename, content in terraform_files.items():
            if not filename.endswith(('.tf', '.tfvars', '.tf.json')):
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid file type: {filename}. Only .tf, .tfvars, and .tf.json files are supported"
                )
        
        logger.info(f"Starting individual file scan for request {request_id} with {len(terraform_files)} files")
        
        # Execute scan with request_id as scan_id
        scan_results = agent.run_security_scan(terraform_files, scan_id=request_id)
        
        # Create response
        response = _create_scan_response(request_id, scan_results)
        
        # Store detailed results for later retrieval
        _store_scan_results(scan_results['scan_id'], scan_results)
        
        logger.info(f"Individual file scan completed for request {request_id}: {scan_results['total_findings']} findings")
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Individual file scan failed for request {request_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during scan: {str(e)}"
        )

@app.post("/scan/project", response_model=ScanResponse)
async def scan_terraform_project(
    request: ProjectScanRequest,
    background_tasks: BackgroundTasks,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Execute security scan on complete Terraform project from S3 or local folder"""
    
    # Generate request ID if not provided
    request_id = request.request_id or str(uuid.uuid4())
    
    try:
        logger.info(f"Starting project scan for request {request_id} from source: {request.source}")
        
        # Execute project scan
        scan_results = agent.scan_terraform_project(request.source, scan_id=request_id)
        
        # Create response
        response = _create_scan_response(request_id, scan_results)
        
        # Store detailed results for later retrieval
        _store_scan_results(scan_results['scan_id'], scan_results)
        
        logger.info(f"Project scan completed for request {request_id}: {scan_results['total_findings']} findings")
        
        return response
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Project scan validation error for request {request_id}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Project scan failed for request {request_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during project scan: {str(e)}"
        )

@app.post("/scan/s3", response_model=ScanResponse)
async def scan_s3_terraform_project(
    request: S3ScanRequest,
    background_tasks: BackgroundTasks,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Execute security scan on Terraform project from S3 bucket"""
    
    # Generate request ID if not provided
    request_id = request.request_id or str(uuid.uuid4())
    
    try:
        logger.info(f"Starting S3 scan for request {request_id} from: {request.s3_uri}")
        
        # Execute S3 scan
        scan_results = agent.scan_s3_terraform_project(request.s3_uri, scan_id=request_id)
        
        # Create response
        response = _create_scan_response(request_id, scan_results)
        
        # Store detailed results for later retrieval
        _store_scan_results(scan_results['scan_id'], scan_results)
        
        logger.info(f"S3 scan completed for request {request_id}: {scan_results['total_findings']} findings")
        
        return response
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"S3 scan validation error for request {request_id}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"S3 scan failed for request {request_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during S3 scan: {str(e)}"
        )

@app.post("/scan/local", response_model=ScanResponse)
async def scan_local_terraform_project(
    request: LocalScanRequest,
    background_tasks: BackgroundTasks,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Execute security scan on Terraform project from local folder"""
    
    # Generate request ID if not provided
    request_id = request.request_id or str(uuid.uuid4())
    
    try:
        logger.info(f"Starting local scan for request {request_id} from: {request.folder_path}")
        
        # Execute local scan
        scan_results = agent.scan_local_terraform_project(request.folder_path, scan_id=request_id)
        
        # Create response
        response = _create_scan_response(request_id, scan_results)
        
        # Store detailed results for later retrieval
        _store_scan_results(scan_results['scan_id'], scan_results)
        
        logger.info(f"Local scan completed for request {request_id}: {scan_results['total_findings']} findings")
        
        return response
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Local scan validation error for request {request_id}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Local scan failed for request {request_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during local scan: {str(e)}"
        )

@app.get("/scan/{scan_id}", response_model=DetailedScanResponse)
async def get_scan_results(scan_id: str):
    """Get detailed scan results by scan ID"""
    try:
        # Retrieve stored results from file system
        scan_results = _get_stored_scan_results(scan_id)
        
        if not scan_results:
            raise HTTPException(
                status_code=404,
                detail=f"Scan results not found for scan ID: {scan_id}"
            )
        
        # Convert to detailed response format
        response = DetailedScanResponse(
            request_id=scan_id,  # Using scan_id as request_id for simplicity
            scan_id=scan_id,
            status="completed",
            total_findings=scan_results['total_findings'],
            fixable_count=scan_results['fixable_count'],
            manual_count=scan_results['manual_count'],
            scan_duration=scan_results['scan_metadata']['scan_duration'],
            findings_summary={
                'severity_distribution': {
                    'critical': len(scan_results['findings_by_severity']['CRITICAL']),
                    'high': len(scan_results['findings_by_severity']['HIGH']),
                    'medium': len(scan_results['findings_by_severity']['MEDIUM']),
                    'low': len(scan_results['findings_by_severity']['LOW'])
                },
                'remediation_distribution': {
                    'auto_fixable': len(scan_results['findings_by_type']['auto_fixable']),
                    'manual_intervention': len(scan_results['findings_by_type']['manual_intervention'])
                }
            },
            findings_by_severity=_serialize_findings(scan_results['findings_by_severity']),
            findings_by_type=_serialize_findings(scan_results['findings_by_type']),
            priority_matrix=_serialize_findings(scan_results.get('priority_matrix', {})),
            analysis_metadata=scan_results.get('analysis_metadata', {})
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve scan results for {scan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error retrieving results: {str(e)}"
        )

@app.get("/scan/{scan_id}/path")
async def get_scan_results_path(scan_id: str):
    """Get file path to stored scan results - useful for other agents"""
    try:
        # Check if scan results exist
        if not _get_stored_scan_results(scan_id):
            raise HTTPException(
                status_code=404,
                detail=f"Scan results not found for scan ID: {scan_id}"
            )
        
        file_path = get_scan_results_file_path(scan_id)
        
        return {
            "scan_id": scan_id,
            "file_path": file_path,
            "exists": Path(file_path).exists(),
            "directory": str(Path(file_path).parent),
            "filename": "checkov_result.json"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get scan results path for {scan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error getting path: {str(e)}"
        )

@app.post("/agent/request", response_model=Dict[str, Any])
async def process_agent_request(
    request: AgentRequest,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Process standardized agent communication request"""
    try:
        logger.info(f"Processing agent request: {request.action} from {request.source_agent}")
        
        if request.action == "run_security_scan":
            # Extract terraform files from payload
            terraform_files = request.payload.get('terraform_files', {})
            
            if not terraform_files:
                raise HTTPException(
                    status_code=400,
                    detail="No terraform_files provided in request payload"
                )
            
            # Execute scan
            scan_results = agent.run_security_scan(terraform_files, scan_id=request.request_id)
            
            # Create standardized response
            response = AgentResponse(
                request_id=request.request_id,
                source_agent="checkov-scanner-agent",
                status="success",
                payload=scan_results,
                timestamp=datetime.utcnow().isoformat()
            )
            
            return response.dict()
            
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported action: {request.action}"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Agent request processing failed: {e}")
        
        error_response = AgentResponse(
            request_id=request.request_id,
            source_agent="checkov-scanner-agent",
            status="error",
            payload={},
            error_message=str(e),
            timestamp=datetime.utcnow().isoformat()
        )
        
        return error_response.dict()

@app.get("/scans", response_model=Dict[str, Any])
async def list_stored_scans():
    """List all stored scan results"""
    try:
        scan_ids = _list_stored_scan_results()
        
        return {
            "stored_scans": scan_ids,
            "total_count": len(scan_ids),
            "storage_location": f"{tempfile.gettempdir()}/{{scan_id}}/checkov_result.json"
        }
    except Exception as e:
        logger.error(f"Failed to list stored scans: {e}")
        raise HTTPException(status_code=500, detail="Failed to list stored scans")

@app.delete("/scan/{scan_id}")
async def cleanup_scan_results(scan_id: str):
    """Clean up stored scan results for a specific scan ID"""
    try:
        # Check if scan results exist
        if not _get_stored_scan_results(scan_id):
            raise HTTPException(
                status_code=404,
                detail=f"Scan results not found for scan ID: {scan_id}"
            )
        
        # Clean up the results
        _cleanup_scan_results(scan_id)
        
        return {
            "message": f"Successfully cleaned up scan results for {scan_id}",
            "scan_id": scan_id,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to cleanup scan results for {scan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during cleanup: {str(e)}"
        )

@app.post("/debug/scan")
async def debug_scan_response(
    request: ScanRequest,
    agent: CheckovScannerAgent = Depends(get_scanner_agent)
):
    """Debug endpoint to see raw scan response without processing"""
    
    request_id = request.request_id or str(uuid.uuid4())
    
    try:
        # Convert files to dictionary format
        terraform_files = {
            tf_file.filename: tf_file.content 
            for tf_file in request.terraform_files
        }
        
        # Prepare files for scanning
        temp_dir = agent._prepare_scan_files(terraform_files)
        
        # Execute MCP scan and get raw response
        with agent.tf_mcp_client:
            scan_prompt = f"""
            Use the MCP Terraform server to run a comprehensive Checkov security scan on the Terraform files 
            in directory: {temp_dir}
            
            Files to scan: {list(terraform_files.keys())}
            
            Please use the MCP server's Checkov integration to scan all Terraform files and return the results.
            """
            
            scan_response = agent.agent(scan_prompt)
            
            # Return debug information
            debug_info = {
                "request_id": request_id,
                "response_type": str(type(scan_response)),
                "response_attributes": list(scan_response.__dict__.keys()) if hasattr(scan_response, '__dict__') else [],
                "response_str": str(scan_response)[:1000],  # First 1000 chars
                "tool_results_count": len(scan_response.tool_results) if hasattr(scan_response, 'tool_results') and scan_response.tool_results else 0,
                "temp_dir": temp_dir,
                "files_prepared": list(terraform_files.keys())
            }
            
            # Add tool results details if available
            if hasattr(scan_response, 'tool_results') and scan_response.tool_results:
                debug_info["tool_results"] = []
                for i, tool_result in enumerate(scan_response.tool_results):
                    tool_info = {
                        "index": i,
                        "type": str(type(tool_result)),
                        "attributes": list(tool_result.__dict__.keys()) if hasattr(tool_result, '__dict__') else [],
                        "content_preview": str(tool_result)[:500] if tool_result else "None"
                    }
                    debug_info["tool_results"].append(tool_info)
            
            # Cleanup
            agent._cleanup_temp_directory(temp_dir)
            
            return debug_info
            
    except Exception as e:
        return {
            "error": str(e),
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat()
        }

@app.get("/tools", response_model=Dict[str, Any])
async def get_available_tools(agent: CheckovScannerAgent = Depends(get_scanner_agent)):
    """Get available MCP tools and capabilities"""
    try:
        mcp_tools = agent.get_mcp_tools_info()
        
        return {
            "mcp_tools": mcp_tools,
            "agent_capabilities": [
                "terraform_security_scanning",
                "checkov_integration", 
                "finding_categorization",
                "severity_assessment",
                "remediability_analysis",
                "s3_project_scanning",
                "local_folder_scanning",
                "recursive_file_discovery",
                "file_based_result_storage"
            ],
            "supported_sources": [
                "individual_files",
                "s3_buckets", 
                "local_folders"
            ],
            "supported_file_types": [".tf", ".tfvars", ".tf.json"],
            "api_endpoints": {
                "individual_files": "/scan",
                "terraform_project": "/scan/project", 
                "s3_project": "/scan/s3",
                "local_project": "/scan/local",
                "get_results": "/scan/{scan_id}",
                "list_scans": "/scans",
                "cleanup_scan": "/scan/{scan_id} (DELETE)"
            },
            "storage_info": {
                "type": "file_based",
                "location": f"{tempfile.gettempdir()}/{{scan_id}}/checkov_result.json",
                "cleanup_required": "Manual or via DELETE endpoint"
            }
        }
    except Exception as e:
        logger.error(f"Failed to get tools info: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve tools information")

# Error handlers

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handle HTTP exceptions"""
    return ErrorResponse(
        error=exc.detail,
        timestamp=datetime.utcnow().isoformat()
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}")
    return ErrorResponse(
        error="Internal server error",
        timestamp=datetime.utcnow().isoformat()
    )

# Utility functions for result storage using tmp folder with scan_id prefix

import tempfile
import json
from pathlib import Path

def _store_scan_results(scan_id: str, results: Dict[str, Any]) -> None:
    """Store scan results in tmp folder with scan_id prefix"""
    try:
        # Create tmp directory with scan_id prefix
        tmp_dir = Path(tempfile.gettempdir()) / f"{scan_id}"
        tmp_dir.mkdir(exist_ok=True)
        
        # Store results as JSON file
        results_file = tmp_dir / "checkov_result.json"
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Stored scan results for {scan_id} in {results_file} ({results_file.stat().st_size} bytes)")
        
    except Exception as e:
        logger.error(f"Failed to store scan results for {scan_id}: {e}")
        # Don't raise the exception to avoid breaking the scan response
        pass

def _get_stored_scan_results(scan_id: str) -> Optional[Dict[str, Any]]:
    """Retrieve stored scan results from tmp folder"""
    try:
        # Construct path to results file
        tmp_dir = Path(tempfile.gettempdir()) / f"{scan_id}"
        results_file = tmp_dir / "checkov_result.json"
        
        if not results_file.exists():
            logger.warning(f"Scan results file not found: {results_file}")
            return None
        
        # Load and return results
        with open(results_file, 'r') as f:
            results = json.load(f)
        
        logger.info(f"Retrieved scan results for {scan_id} from {results_file}")
        return results
        
    except Exception as e:
        logger.error(f"Failed to retrieve scan results for {scan_id}: {e}")
        return None

def _cleanup_scan_results(scan_id: str) -> None:
    """Clean up stored scan results for a specific scan_id"""
    try:
        import shutil
        tmp_dir = Path(tempfile.gettempdir()) / f"{scan_id}"
        
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
            logger.info(f"Cleaned up scan results directory: {tmp_dir}")
        
    except Exception as e:
        logger.error(f"Failed to cleanup scan results for {scan_id}: {e}")

def _list_stored_scan_results() -> List[str]:
    """List all stored scan result IDs"""
    try:
        tmp_base = Path(tempfile.gettempdir())
        scan_dirs = [d.name for d in tmp_base.iterdir() 
                    if d.is_dir() and len(d.name) == 8 and 
                    (d / "checkov_result.json").exists()]
        return scan_dirs
        
    except Exception as e:
        logger.error(f"Failed to list stored scan results: {e}")
        return []

def get_scan_results_file_path(scan_id: str) -> str:
    """Get the file path for stored scan results - useful for other agents"""
    tmp_dir = Path(tempfile.gettempdir()) / f"{scan_id}"
    results_file = tmp_dir / "checkov_result.json"
    return str(results_file)

def _create_scan_response(request_id: str, scan_results: Dict[str, Any]) -> ScanResponse:
    """Create standardized scan response from results"""
    return ScanResponse(
        request_id=request_id,
        scan_id=scan_results['scan_id'],
        status="completed",
        total_findings=scan_results['total_findings'],
        fixable_count=scan_results['fixable_count'],
        manual_count=scan_results['manual_count'],
        scan_duration=scan_results['scan_metadata']['scan_duration'],
        findings_summary={
            'severity_distribution': {
                'critical': len(scan_results['findings_by_severity']['CRITICAL']),
                'high': len(scan_results['findings_by_severity']['HIGH']),
                'medium': len(scan_results['findings_by_severity']['MEDIUM']),
                'low': len(scan_results['findings_by_severity']['LOW'])
            },
            'remediation_distribution': {
                'auto_fixable': len(scan_results['findings_by_type']['auto_fixable']),
                'manual_intervention': len(scan_results['findings_by_type']['manual_intervention'])
            },
            'source_info': {
                'source': scan_results['scan_metadata'].get('source', 'individual_files'),
                'source_type': scan_results['scan_metadata'].get('source_type', 'files'),
                'files_scanned': scan_results['scan_metadata']['files_scanned']
            }
        },
        findings_by_severity=_serialize_findings(scan_results['findings_by_severity']),
        findings_by_type=_serialize_findings(scan_results['findings_by_type'])
    )

def _serialize_findings(findings_dict: Dict[str, Any]) -> Dict[str, List[Dict]]:
    """Serialize findings for JSON response"""
    serialized = {}
    
    for key, findings in findings_dict.items():
        if isinstance(findings, list):
            serialized[key] = [
                finding.__dict__ if hasattr(finding, '__dict__') else finding
                for finding in findings
            ]
        else:
            serialized[key] = findings
    
    return serialized

# Main entry point for AgentCore deployment
if __name__ == "__main__":
    import uvicorn
    
    # Configuration for AgentCore deployment
    uvicorn.run(
        "agents.checkov_scanner.api:app",
        host="0.0.0.0",
        port=8000,
        log_level="info",
        reload=False  # Set to False for production
    )