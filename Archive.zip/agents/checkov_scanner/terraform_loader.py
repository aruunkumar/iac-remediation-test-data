"""
Terraform Project Loader
Handles loading Terraform files from various sources (S3, local folders)
"""

import os
import tempfile
import shutil
import logging
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

logger = logging.getLogger(__name__)

class TerraformProjectLoader:
    """Loads Terraform projects from various sources"""
    
    def __init__(self):
        self.supported_extensions = {'.tf', '.tfvars', '.tf.json'}
        self.s3_client = None
        
    def _get_s3_client(self):
        """Get or create S3 client"""
        if self.s3_client is None:
            try:
                self.s3_client = boto3.client('s3')
            except NoCredentialsError:
                logger.error("AWS credentials not configured for S3 access")
                raise
        return self.s3_client
    
    def load_from_s3(self, s3_uri: str, temp_dir: Optional[str] = None) -> Dict[str, str]:
        """
        Load Terraform files from S3 bucket
        
        Args:
            s3_uri: S3 URI in format 's3://bucket-name/path/to/terraform/project'
            temp_dir: Optional temporary directory to download files to
            
        Returns:
            Dict mapping relative file paths to file contents
        """
        logger.info(f"Loading Terraform project from S3: {s3_uri}")
        
        # Parse S3 URI
        if not s3_uri.startswith('s3://'):
            raise ValueError("S3 URI must start with 's3://'")
        
        uri_parts = s3_uri[5:].split('/', 1)  # Remove 's3://' prefix
        bucket_name = uri_parts[0]
        prefix = uri_parts[1] if len(uri_parts) > 1 else ''
        
        # Create temporary directory if not provided
        if temp_dir is None:
            temp_dir = tempfile.mkdtemp(prefix='terraform_s3_')
            cleanup_temp = True
        else:
            cleanup_temp = False
        
        try:
            # Download files from S3
            terraform_files = self._download_s3_terraform_files(bucket_name, prefix, temp_dir)
            
            if not terraform_files:
                raise ValueError(f"No Terraform files found in S3 path: {s3_uri}")
            
            logger.info(f"Successfully loaded {len(terraform_files)} Terraform files from S3")
            return terraform_files
            
        finally:
            if cleanup_temp:
                shutil.rmtree(temp_dir, ignore_errors=True)
    
    def load_from_local_folder(self, folder_path: str) -> Dict[str, str]:
        """
        Load Terraform files from local folder
        
        Args:
            folder_path: Path to local folder containing Terraform files
            
        Returns:
            Dict mapping relative file paths to file contents
        """
        logger.info(f"Loading Terraform project from local folder: {folder_path}")
        
        folder_path = Path(folder_path).resolve()
        
        if not folder_path.exists():
            raise ValueError(f"Folder does not exist: {folder_path}")
        
        if not folder_path.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path}")
        
        terraform_files = {}
        
        # Recursively find all Terraform files
        for file_path in folder_path.rglob('*'):
            if file_path.is_file() and file_path.suffix in self.supported_extensions:
                try:
                    # Get relative path from the root folder
                    relative_path = file_path.relative_to(folder_path)
                    
                    # Read file content
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    terraform_files[str(relative_path)] = content
                    logger.debug(f"Loaded file: {relative_path}")
                    
                except Exception as e:
                    logger.warning(f"Failed to read file {file_path}: {e}")
                    continue
        
        if not terraform_files:
            raise ValueError(f"No Terraform files found in folder: {folder_path}")
        
        logger.info(f"Successfully loaded {len(terraform_files)} Terraform files from local folder")
        return terraform_files
    
    def _download_s3_terraform_files(self, bucket_name: str, prefix: str, temp_dir: str) -> Dict[str, str]:
        """Download Terraform files from S3 bucket"""
        s3_client = self._get_s3_client()
        terraform_files = {}
        
        try:
            # List objects in the bucket with the given prefix
            paginator = s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
            
            for page in pages:
                if 'Contents' not in page:
                    continue
                
                for obj in page['Contents']:
                    key = obj['Key']
                    
                    # Check if it's a Terraform file
                    if not any(key.endswith(ext) for ext in self.supported_extensions):
                        continue
                    
                    # Skip directories
                    if key.endswith('/'):
                        continue
                    
                    try:
                        # Download file content
                        response = s3_client.get_object(Bucket=bucket_name, Key=key)
                        content = response['Body'].read().decode('utf-8')
                        
                        # Use relative path from prefix
                        if prefix and key.startswith(prefix):
                            relative_key = key[len(prefix):].lstrip('/')
                        else:
                            relative_key = key
                        
                        terraform_files[relative_key] = content
                        logger.debug(f"Downloaded S3 file: {key}")
                        
                    except Exception as e:
                        logger.warning(f"Failed to download S3 file {key}: {e}")
                        continue
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'NoSuchBucket':
                raise ValueError(f"S3 bucket does not exist: {bucket_name}")
            elif error_code == 'AccessDenied':
                raise ValueError(f"Access denied to S3 bucket: {bucket_name}")
            else:
                raise ValueError(f"S3 error: {e}")
        
        return terraform_files
    
    def load_terraform_project(self, source: str) -> Dict[str, str]:
        """
        Load Terraform project from various sources
        
        Args:
            source: Either S3 URI (s3://bucket/path) or local folder path
            
        Returns:
            Dict mapping relative file paths to file contents
        """
        if source.startswith('s3://'):
            return self.load_from_s3(source)
        else:
            return self.load_from_local_folder(source)
    
    def validate_terraform_files(self, terraform_files: Dict[str, str]) -> Dict[str, Any]:
        """
        Validate loaded Terraform files
        
        Returns:
            Validation report with statistics and issues
        """
        validation_report = {
            'total_files': len(terraform_files),
            'file_types': {},
            'total_size_bytes': 0,
            'issues': [],
            'files_by_type': {
                'terraform': [],
                'variables': [],
                'outputs': [],
                'other': []
            }
        }
        
        for file_path, content in terraform_files.items():
            file_size = len(content.encode('utf-8'))
            validation_report['total_size_bytes'] += file_size
            
            # Categorize file types
            file_ext = Path(file_path).suffix
            validation_report['file_types'][file_ext] = validation_report['file_types'].get(file_ext, 0) + 1
            
            # Categorize by purpose
            if 'variable' in file_path.lower():
                validation_report['files_by_type']['variables'].append(file_path)
            elif 'output' in file_path.lower():
                validation_report['files_by_type']['outputs'].append(file_path)
            elif file_ext == '.tf':
                validation_report['files_by_type']['terraform'].append(file_path)
            else:
                validation_report['files_by_type']['other'].append(file_path)
            
            # Basic content validation
            if not content.strip():
                validation_report['issues'].append(f"Empty file: {file_path}")
            
            # Check for common Terraform syntax
            if file_ext == '.tf' and not any(keyword in content for keyword in ['resource', 'data', 'variable', 'output', 'locals', 'module']):
                validation_report['issues'].append(f"No Terraform blocks found in: {file_path}")
        
        return validation_report

def create_terraform_loader() -> TerraformProjectLoader:
    """Factory function to create Terraform project loader"""
    return TerraformProjectLoader()

# Convenience functions
def load_terraform_from_s3(s3_uri: str) -> Dict[str, str]:
    """Load Terraform files from S3 bucket"""
    loader = create_terraform_loader()
    return loader.load_from_s3(s3_uri)

def load_terraform_from_folder(folder_path: str) -> Dict[str, str]:
    """Load Terraform files from local folder"""
    loader = create_terraform_loader()
    return loader.load_from_local_folder(folder_path)

def load_terraform_project(source: str) -> Dict[str, str]:
    """Load Terraform project from S3 or local folder"""
    loader = create_terraform_loader()
    return loader.load_terraform_project(source)