#!/usr/bin/env python3
"""
Simple server startup script for Checkov Scanner Agent
Handles common startup issues and provides helpful output
"""

import sys
import os
import subprocess
import time
import signal
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are available"""
    print("🔍 Checking dependencies...")
    
    missing_deps = []
    
    try:
        import fastapi
        print("   ✅ FastAPI")
    except ImportError:
        missing_deps.append("fastapi")
        print("   ❌ FastAPI")
    
    try:
        import uvicorn
        print("   ✅ Uvicorn")
    except ImportError:
        missing_deps.append("uvicorn[standard]")
        print("   ❌ Uvicorn")
    
    try:
        import pydantic
        print("   ✅ Pydantic")
    except ImportError:
        missing_deps.append("pydantic")
        print("   ❌ Pydantic")
    
    if missing_deps:
        print(f"\n❌ Missing dependencies: {', '.join(missing_deps)}")
        print("💡 Install with:")
        print(f"   pip install {' '.join(missing_deps)}")
        return False
    
    print("✅ All dependencies available")
    return True

def find_free_port(start_port=8000):
    """Find a free port starting from start_port"""
    import socket
    
    for port in range(start_port, start_port + 10):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('localhost', port))
                return port
        except OSError:
            continue
    
    return None

def start_server(port=8000, reload=False):
    """Start the FastAPI server"""
    
    # Add project root to Python path
    project_root = Path(__file__).parent.parent.parent
    sys.path.insert(0, str(project_root))
    
    print(f"🚀 Starting Checkov Scanner Agent API server on port {port}...")
    print(f"📁 Project root: {project_root}")
    
    try:
        import uvicorn
        
        # Configure uvicorn
        config = uvicorn.Config(
            "agents.checkov_scanner.api:app",
            host="0.0.0.0",
            port=port,
            log_level="info",
            reload=reload,
            access_log=True
        )
        
        server = uvicorn.Server(config)
        
        print(f"🌐 Server will be available at:")
        print(f"   • Health check: http://localhost:{port}/health")
        print(f"   • API docs: http://localhost:{port}/docs")
        print(f"   • ReDoc: http://localhost:{port}/redoc")
        print(f"\n⏹️  Press Ctrl+C to stop the server")
        
        # Start server
        server.run()
        
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Server failed to start: {e}")
        return False
    
    return True

def test_server_startup(port=8000):
    """Test if server starts successfully"""
    print("🧪 Testing server startup...")
    
    try:
        import requests
        import threading
        import time
        
        # Start server in background thread
        def run_server():
            start_server(port, reload=False)
        
        server_thread = threading.Thread(target=run_server, daemon=True)
        server_thread.start()
        
        # Wait for server to start
        print("⏳ Waiting for server to start...")
        time.sleep(3)
        
        # Test health endpoint
        try:
            response = requests.get(f"http://localhost:{port}/health", timeout=5)
            if response.status_code == 200:
                print("✅ Server started successfully!")
                health_data = response.json()
                print(f"   Agent: {health_data.get('agent_name')}")
                print(f"   Status: {health_data.get('status')}")
                return True
            else:
                print(f"⚠️  Server responded with status {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            print(f"❌ Failed to connect to server: {e}")
            return False
            
    except ImportError:
        print("⚠️  requests not available for testing")
        return True  # Assume it's working
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Start Checkov Scanner Agent API server")
    parser.add_argument("--port", type=int, default=8000, help="Port to run server on")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    parser.add_argument("--test", action="store_true", help="Test server startup and exit")
    parser.add_argument("--check-deps", action="store_true", help="Check dependencies and exit")
    
    args = parser.parse_args()
    
    print("🔧 Checkov Scanner Agent - Server Startup")
    print("=" * 50)
    
    # Check dependencies if requested
    if args.check_deps:
        success = check_dependencies()
        sys.exit(0 if success else 1)
    
    # Check dependencies
    if not check_dependencies():
        print("\n💡 Run with --check-deps to see detailed dependency status")
        sys.exit(1)
    
    # Find free port if default is busy
    if args.port == 8000:
        free_port = find_free_port(8000)
        if free_port != 8000:
            print(f"⚠️  Port 8000 is busy, using port {free_port}")
            args.port = free_port
        elif free_port is None:
            print("❌ No free ports found in range 8000-8009")
            sys.exit(1)
    
    # Test mode
    if args.test:
        success = test_server_startup(args.port)
        sys.exit(0 if success else 1)
    
    # Start server
    try:
        success = start_server(args.port, args.reload)
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
        sys.exit(0)

if __name__ == "__main__":
    main()