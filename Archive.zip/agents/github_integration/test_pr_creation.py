"""
Test script to verify PR creation functionality in isolation
Tests only the PR creation using an existing pushed branch
"""

import os
import sys
import requests
import json

# Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "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")
GITHUB_INTEGRATION_URL = "http://localhost:8002"

# Repository and branch info
REPOSITORY_DATA = {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "source_branch": "main",
    "author": "aruunkumar",
    "default_branch": "main",
    "github_token": GITHUB_TOKEN
}

# Existing branch that was already pushed
EXISTING_BRANCH = "iac-remediation/main-20251124-230258"
REPO_PATH = "/tmp/github_repos/iac-remediation-test-data"  # Adjust if needed

# Sample remediation results (minimal for testing)
REMEDIATION_RESULTS = {
    "scan_metadata": {
        "scan_id": "test-pr-creation",
        "scan_date": "2024-11-24T23:00:00Z",
        "total_findings": 13,
        "scan_duration": 10.5
    },
    "fixes": [
        {
            "check_id": "CKV_AWS_237",
            "file": "/modules/api_gateway/main.tf",
            "resource": "aws_api_gateway_rest_api.api",
            "severity": "MEDIUM",
            "description": "Added create_before_destroy lifecycle policy",
            "original_content": "",
            "fix_applied": "Added lifecycle block with create_before_destroy",
            "knowledge_base_reference": "AWS API Gateway best practices"
        },
        {
            "check_id": "CKV_AWS_73",
            "file": "/modules/api_gateway/main.tf",
            "resource": "aws_api_gateway_stage.prod",
            "severity": "LOW",
            "description": "Enabled X-Ray tracing",
            "original_content": "",
            "fix_applied": "Added xray_tracing_enabled = true",
            "knowledge_base_reference": "AWS X-Ray documentation"
        },
        {
            "check_id": "CKV_AWS_28",
            "file": "/modules/dynamodb/main.tf",
            "resource": "aws_dynamodb_table.main_table",
            "severity": "HIGH",
            "description": "Enabled point-in-time recovery",
            "original_content": "",
            "fix_applied": "Added point_in_time_recovery block",
            "knowledge_base_reference": "DynamoDB backup best practices"
        }
    ],
    "manual_interventions": [
        {
            "check_id": "CKV_AWS_120",
            "file": "/modules/api_gateway/main.tf",
            "resource": "aws_api_gateway_stage.prod",
            "severity": "MEDIUM",
            "description": "Enable API Gateway caching for better performance",
            "todo_comment": "# TODO: Enable API Gateway caching",
            "line_number": 45,
            "knowledge_base_reference": "API Gateway caching guide"
        }
    ]
}

def print_section(title):
    """Print a section header"""
    print("\n" + "="*80)
    print(f"  {title}")
    print("="*80 + "\n")

def test_pr_creation():
    """Test PR creation using the GitHub Integration API"""
    
    print_section("GitHub Integration - PR Creation Test")
    
    print(f"Repository: {REPOSITORY_DATA['owner']}/{REPOSITORY_DATA['repo']}")
    print(f"Branch: {EXISTING_BRANCH}")
    print(f"Token length: {len(GITHUB_TOKEN)}")
    print(f"Token preview: {GITHUB_TOKEN[:10]}...{GITHUB_TOKEN[-4:]}")
    
    # Step 1: Check GitHub Integration health
    print_section("Step 1: Health Check")
    try:
        response = requests.get(f"{GITHUB_INTEGRATION_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ GitHub Integration agent is healthy")
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Cannot reach GitHub Integration agent: {e}")
        return False
    
    # Step 2: Prepare PR creation request
    print_section("Step 2: Prepare PR Creation Request")
    
    pr_request = {
        "repo_path": REPO_PATH,
        "repository_data": REPOSITORY_DATA,
        "remediation_results": REMEDIATION_RESULTS
    }
    
    print(f"Request structure:")
    print(f"  - repo_path: {pr_request['repo_path']}")
    print(f"  - repository_data keys: {list(pr_request['repository_data'].keys())}")
    print(f"  - fixes: {len(pr_request['remediation_results']['fixes'])}")
    print(f"  - manual_interventions: {len(pr_request['remediation_results']['manual_interventions'])}")
    
    # Step 3: Call PR creation endpoint
    print_section("Step 3: Create Pull Request")
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {GITHUB_TOKEN}"
    }
    
    print(f"Calling: POST {GITHUB_INTEGRATION_URL}/api/v1/github/commit-and-create-pr")
    print(f"Authorization header: Bearer {GITHUB_TOKEN[:10]}...{GITHUB_TOKEN[-4:]}")
    
    try:
        response = requests.post(
            f"{GITHUB_INTEGRATION_URL}/api/v1/github/commit-and-create-pr",
            json=pr_request,
            headers=headers,
            timeout=60
        )
        
        print(f"\nResponse status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("\n✅ PR Created Successfully!")
            print(f"   PR Number: {result.get('pr_number')}")
            print(f"   PR URL: {result.get('pr_url')}")
            print(f"   Branch: {result.get('branch_name')}")
            print(f"   Status: {result.get('status')}")
            return True
        else:
            print(f"\n❌ PR Creation Failed")
            print(f"   Status: {response.status_code}")
            print(f"   Response: {response.text[:500]}")
            
            # Try to parse error details
            try:
                error_detail = response.json()
                print(f"\n   Error details:")
                print(json.dumps(error_detail, indent=2))
            except:
                pass
            
            return False
            
    except requests.exceptions.Timeout:
        print("❌ Request timed out after 60 seconds")
        return False
    except Exception as e:
        print(f"❌ Error calling PR creation endpoint: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("\n" + "="*80)
    print("  GitHub Integration - PR Creation Isolated Test")
    print("="*80)
    print("\nThis test verifies PR creation using an existing pushed branch")
    print("without running the full workflow.\n")
    
    success = test_pr_creation()
    
    print_section("Test Result")
    if success:
        print("✅ TEST PASSED - PR creation works correctly")
        sys.exit(0)
    else:
        print("❌ TEST FAILED - PR creation has issues")
        print("\nTroubleshooting:")
        print("1. Check GitHub Integration agent logs")
        print("2. Verify GitHub token is valid and has correct permissions")
        print("3. Verify branch exists: iac-remediation/main-20251124-230258")
        print("4. Check repo_path exists and has commits")
        sys.exit(1)
