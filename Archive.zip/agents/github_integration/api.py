"""
GitHub Integration Agent API - HTTP endpoint wrapper for AgentCore deployment
Provides RESTful API endpoints for GitHub operations and webhook processing
"""

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
import json
import logging
import os
from datetime import datetime

# Import the GitHub integration agent
try:
    from .main import GitHubIntegrationAgent
except ImportError:
    from main import GitHubIntegrationAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="GitHub Integration Agent API",
    description="API endpoints for GitHub repository operations and PR management",
    version="1.0.0"
)

# Security
security = HTTPBearer()

# Startup event to initialize GitHub agent
@app.on_event("startup")
async def startup_event():
    """Initialize GitHub Integration Agent on startup"""
    try:
        initialize_github_agent()
        logger.info("GitHub Integration Agent API started successfully")
    except Exception as e:
        logger.error(f"Failed to initialize GitHub Integration Agent: {e}")
        # Exit the application if initialization fails
        import sys
        sys.exit(1)

# Initialize GitHub Integration Agent (singleton)
github_agent = None

def initialize_github_agent():
    """Initialize GitHub Integration Agent with environment variable validation"""
    global github_agent
    
    github_token = os.getenv('GITHUB_TOKEN')
    
    if not github_token:
        logger.error("GITHUB_TOKEN environment variable is not set!")
        raise ValueError(
            "GITHUB_TOKEN environment variable is required to start the GitHub Integration Agent. "
            "Please set it before starting the server: export GITHUB_TOKEN=your_token_here"
        )
    
    if len(github_token) < 20:
        logger.error(f"GITHUB_TOKEN appears to be invalid (length: {len(github_token)})")
        raise ValueError(
            "GITHUB_TOKEN appears to be invalid. GitHub personal access tokens should be at least 20 characters. "
            "Please verify your token and try again."
        )
    
    logger.info(f"Initializing GitHub Integration Agent with token from environment (length: {len(github_token)})")
    github_agent = GitHubIntegrationAgent(github_token=github_token)
    logger.info("GitHub Integration Agent initialized successfully")
    
    return github_agent

def get_github_agent():
    """Get the GitHub Integration Agent singleton instance"""
    global github_agent
    if github_agent is None:
        raise RuntimeError("GitHub Integration Agent not initialized. This should not happen.")
    return github_agent

# Request/Response Models
class RepositoryData(BaseModel):
    """Repository data model"""
    owner: str = Field(..., description="Repository owner")
    repo: str = Field(..., description="Repository name")
    url: str = Field(..., description="Repository clone URL")
    commit_sha: Optional[str] = Field(None, description="Specific commit SHA")
    source_branch: str = Field("main", description="Source branch that triggered scan")
    author: Optional[str] = Field(None, description="Original commit author")
    default_branch: str = Field("main", description="Default branch name")
    scan_id: Optional[str] = Field(None, description="Associated scan ID")

class SecurityFix(BaseModel):
    """Security fix model"""
    check_id: str = Field(..., description="Checkov check ID")
    file: str = Field(..., description="File path")
    resource: str = Field(..., description="Terraform resource")
    severity: str = Field(..., description="Issue severity")
    description: str = Field(..., description="Fix description")
    original_content: str = Field(..., description="Original code content")
    fix_applied: str = Field(..., description="Fixed code content")
    knowledge_base_reference: Optional[str] = Field(None, description="Knowledge base reference")

class ManualIntervention(BaseModel):
    """Manual intervention model"""
    check_id: str = Field(..., description="Checkov check ID")
    file: str = Field(..., description="File path")
    resource: str = Field(..., description="Terraform resource")
    severity: str = Field(..., description="Issue severity")
    description: str = Field(..., description="Issue description")
    todo_comment: str = Field(..., description="TODO comment for manual fix")
    line_number: Optional[int] = Field(1, description="Line number for TODO comment")
    knowledge_base_reference: Optional[str] = Field(None, description="Knowledge base reference")

class ScanMetadata(BaseModel):
    """Scan metadata model"""
    scan_id: str = Field(..., description="Unique scan identifier")
    scan_date: str = Field(..., description="Scan execution date")
    total_findings: int = Field(..., description="Total number of findings")
    scan_duration: Optional[float] = Field(None, description="Scan duration in seconds")

class RemediationResults(BaseModel):
    """Remediation results model"""
    scan_metadata: ScanMetadata = Field(..., description="Scan metadata")
    fixes: List[SecurityFix] = Field(default=[], description="Applied security fixes")
    manual_interventions: List[ManualIntervention] = Field(default=[], description="Manual intervention items")

class CreatePRRequest(BaseModel):
    """Create pull request request model"""
    repository_data: RepositoryData = Field(..., description="Repository information")
    remediation_results: RemediationResults = Field(..., description="Remediation results")

class CreatePRResponse(BaseModel):
    """Create pull request response model"""
    pr_number: Optional[int] = Field(None, description="Pull request number")
    pr_url: str = Field(..., description="Pull request URL")
    branch_name: str = Field(..., description="Branch name")
    workflow_triggered: bool = Field(..., description="Whether approval workflow was triggered")
    labels_added: List[str] = Field(default=[], description="Labels added to PR")
    reviewers_requested: bool = Field(..., description="Whether reviewers were requested")
    status: str = Field(..., description="Operation status")

class CloneRepositoryRequest(BaseModel):
    """Clone repository request model"""
    repository_data: RepositoryData = Field(..., description="Repository information")

class CloneRepositoryResponse(BaseModel):
    """Clone repository response model"""
    success: bool = Field(..., description="Whether clone was successful")
    repo_path: str = Field(..., description="Local path to cloned repository")
    terraform_files: List[str] = Field(default=[], description="Found Terraform files")
    message: str = Field(..., description="Operation message")

class FileContentRequest(BaseModel):
    """File content request model"""
    repository_data: RepositoryData = Field(..., description="Repository information")
    file_path: str = Field(..., description="File path to read")

class FileContentResponse(BaseModel):
    """File content response model"""
    content: Optional[str] = Field(None, description="File content")
    exists: bool = Field(..., description="Whether file exists")

class UpdateFileRequest(BaseModel):
    """Update file request model"""
    repository_data: RepositoryData = Field(..., description="Repository information")
    file_path: str = Field(..., description="File path to update")
    new_content: str = Field(..., description="New file content")

class UpdateFileResponse(BaseModel):
    """Update file response model"""
    success: bool = Field(..., description="Whether update was successful")
    message: str = Field(..., description="Operation message")

# Authentication and validation functions
def verify_github_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Verify GitHub token authentication"""
    token = credentials.credentials
    
    # In production, validate the token against GitHub API
    # For now, just check if token is provided
    if not token:
        raise HTTPException(status_code=401, detail="GitHub token required")
    
    return token

# API Endpoints

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "GitHub Integration Agent",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/v1/github/setup", response_model=Dict[str, Any])
async def setup_repository_and_branch(
    request: CloneRepositoryRequest
):
    """
    Setup repository and create remediation branch (Step 1 - called BEFORE scanning)
    
    This endpoint:
    1. Clones the repository at the specified source branch
    2. Creates a remediation branch for fixes
    3. Returns the local path for other agents to use
    """
    try:
        logger.info(f"Setting up repository: {request.repository_data.owner}/{request.repository_data.repo} at branch {request.repository_data.source_branch}")
        
        repository_data = request.repository_data.dict()
        # Use singleton agent (initialized at startup with GITHUB_TOKEN env var)
        agent = get_github_agent()
        
        # Setup repository and branch
        result = agent.setup_repository_and_branch(repository_data)
        
        return {
            "success": True,
            "repo_path": result["repo_path"],
            "branch_name": result["branch_name"],
            "message": f"Successfully setup repository at {result['repo_path']} with remediation branch {result['branch_name']}"
        }
        
    except Exception as e:
        logger.error(f"Error setting up repository: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to setup repository: {str(e)}")

class CommitAndCreatePRRequest(BaseModel):
    """Commit and create PR request model"""
    repo_path: str = Field(..., description="Local path to repository with fixes")
    repository_data: RepositoryData = Field(..., description="Repository information")
    remediation_results: RemediationResults = Field(..., description="Remediation results")

@app.post("/api/v1/github/commit-and-create-pr", response_model=CreatePRResponse)
async def commit_and_create_pr(
    request: CommitAndCreatePRRequest
):
    """
    Commit changes and create pull request (Step 4 - called AFTER remediation)
    
    This endpoint:
    1. Commits all changes in the repository
    2. Pushes the remediation branch
    3. Creates a pull request with detailed description
    4. Adds labels and requests reviewers
    """
    try:
        logger.info(f"Committing and creating PR for repository at: {request.repo_path}")
        
        # Convert Pydantic models to dictionaries
        # Handle both Pydantic models and plain dicts
        if hasattr(request.repository_data, 'dict'):
            repository_data = request.repository_data.dict()
        else:
            repository_data = request.repository_data if isinstance(request.repository_data, dict) else {}
        
        if hasattr(request.remediation_results, 'dict'):
            remediation_results = request.remediation_results.dict()
        else:
            remediation_results = request.remediation_results if isinstance(request.remediation_results, dict) else {}
        
        # Use singleton agent (initialized at startup with GITHUB_TOKEN env var)
        agent = get_github_agent()
        
        # Commit and create PR
        result = agent.commit_and_create_pr(
            request.repo_path,
            repository_data,
            remediation_results
        )
        
        return CreatePRResponse(**result)
        
    except Exception as e:
        logger.error(f"Error committing and creating PR: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to commit and create PR: {str(e)}")



@app.post("/api/v1/github/file-content", response_model=FileContentResponse)
async def get_file_content(
    request: FileContentRequest
):
    """Get content of a specific file from repository"""
    try:
        repository_data = request.repository_data.dict()
        agent = get_github_agent()
        
        content = agent.get_file_content(repository_data, request.file_path)
        
        return FileContentResponse(
            content=content,
            exists=content is not None
        )
        
    except Exception as e:
        logger.error(f"Error getting file content: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get file content: {str(e)}")

@app.post("/api/v1/github/update-file", response_model=UpdateFileResponse)
async def update_file_content(
    request: UpdateFileRequest
):
    """Update content of a specific file in repository"""
    try:
        repository_data = request.repository_data.dict()
        agent = get_github_agent()
        
        success = agent.update_file_content(
            repository_data,
            request.file_path,
            request.new_content
        )
        
        return UpdateFileResponse(
            success=success,
            message="File updated successfully" if success else "Failed to update file"
        )
        
    except Exception as e:
        logger.error(f"Error updating file: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update file: {str(e)}")

@app.delete("/api/v1/github/cleanup")
async def cleanup_repository(
    repository_data: RepositoryData
):
    """Clean up local repository directory"""
    try:
        agent = get_github_agent()
        agent.cleanup_repository(repository_data.dict())
        
        return {
            "success": True,
            "message": "Repository cleaned up successfully"
        }
        
    except Exception as e:
        logger.error(f"Error cleaning up repository: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to cleanup repository: {str(e)}")

@app.get("/api/v1/github/status")
async def get_agent_status():
    """Get GitHub Integration Agent status"""
    agent = get_github_agent()
    return {
        "agent": "GitHub Integration Agent",
        "status": "active",
        "capabilities": [
            "repository_cloning",
            "file_management",
            "pull_request_creation",
            "approval_workflows"
        ],
        "github_token_configured": bool(agent.github_token),
        "timestamp": datetime.now().isoformat()
    }

# Error handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    from fastapi.responses import JSONResponse
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "timestamp": datetime.now().isoformat()
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}")
    from fastapi.responses import JSONResponse
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "status_code": 500,
            "timestamp": datetime.now().isoformat()
        }
    )

if __name__ == "__main__":
    import uvicorn
    
    # Get configuration from environment
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8002))
    
    logger.info(f"Starting GitHub Integration Agent API on {host}:{port}")
    
    uvicorn.run(
        "api:app",
        host=host,
        port=port,
        reload=False,
        log_level="info"
    )