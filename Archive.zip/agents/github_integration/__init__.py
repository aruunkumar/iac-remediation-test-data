"""
GitHub Integration Agent Package

This package provides GitHub repository operations and PR management
capabilities for the Terraform Security Platform.

Built with Strands SDK for deployment on AWS Bedrock AgentCore.
"""

from .main import GitHubIntegrationAgent
from .api import app

__version__ = "1.0.0"
__author__ = "Terraform Security Platform"

__all__ = ["GitHubIntegrationAgent", "app"]