# GitHub Integration Agent

A specialized agent for GitHub repository operations and pull request management in the Terraform Security Platform. Built with Strands SDK for AWS Bedrock AgentCore deployment, providing seamless integration between security scanning workflows and GitHub repositories.

## Overview

The GitHub Integration Agent serves as the Git operations layer for the Terraform Security Platform, handling all interactions with GitHub repositories. It provides two primary services to the Orchestrator: cloning repositories for security scanning and creating pull requests with remediated security fixes.

## Key Design Principles

### 1. **Singleton Pattern with Environment Variable**
- **Single Agent Instance**: One agent initialized at server startup
- **Environment-Based Configuration**: GitHub token from GITHUB_TOKEN env var
- **Startup Validation**: Server fails to start if token is missing or invalid
- **Independent Operation**: No per-request token handling, fully self-contained

### 2. **Single Responsibility for Git Operations**
- **Centralized Git Logic**: All git and GitHub operations in one agent
- **No Duplication**: Orchestrator and other agents don't need git dependencies
- **Clean Separation**: Clear boundary between workflow orchestration and git operations

### 3. **Feature Branch Workflow**
- **Developer-Centric**: PRs target feature branches, not main
- **Smart Reviewer Assignment**: Original developer for features, security team for main
- **Conditional Approval**: Security workflows only for main branch merges
- **Branch Naming**: Descriptive names like `iac-remediation/main-abc123`

### 4. **No LLM Dependency**
- **Direct Operations**: Uses subprocess for git commands and requests for HTTP
- **Efficient**: No LLM overhead for simple operations
- **Cost-Effective**: No AI model costs
- **Reliable**: Deterministic behavior without LLM interpretation

## High-Level Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Orchestrator   │    │  GitHub Agent    │    │  GitHub API     │
│  (Workflow)     │───▶│  (Git Ops)       │───▶│  (PRs/Labels)   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Clone Request  │    │  Strands Agent   │    │  Git Commands   │
│  • source_branch│    │  • bash_command  │    │  • clone        │
│  • commit_sha   │    │  • http_request  │    │  • checkout     │
│  • author       │    │  • file_ops      │    │  • commit/push  │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Core Components

### 1. **GitHubIntegrationAgent** (`main.py`)
- **Purpose**: Core agent providing git operations and GitHub API integration
- **Architecture**:
  - Direct subprocess calls for git operations
  - Requests library for GitHub API calls
  - No LLM dependency - pure Python implementation
- **Key Public Methods** (called by Orchestrator):
  - `clone_repository_for_scanning()`: Clone repo at specific branch for scanning
  - `create_security_pr()`: Create PR with security fixes
  - `get_repository_path()`: Get local path to cloned repository
  - `cleanup_repository()`: Clean up local clone
- **Key Private Methods**:
  - `_create_remediation_branch()`: Create new branch from source branch
  - `_apply_changes_to_branch()`: Copy fixed files and commit
  - `_create_pull_request()`: Create PR via GitHub API
  - `_generate_pr_description()`: Generate comprehensive PR description
  - `_trigger_approval_workflow()`: Trigger GitHub Actions workflow
- **Workflow**:
  1. Clone repository at specified branch (shallow clone for speed)
  2. Create remediation branch from source branch
  3. Copy pre-fixed files from remediation results
  4. Commit and push changes
  5. Create PR targeting source branch
  6. Add labels and request reviewers
  7. Trigger approval workflow (main branch only)
- **Key Features**:
  - **Shallow Cloning**: `--depth 1` for faster operations
  - **Branch Naming**: `{source_branch}-iac-remediation-{commit_sha}`
  - **Smart PR Targeting**: Feature branches → feature branch, main → main
  - **Conditional Workflows**: Approval gates only for main branch
- **Dependencies**: requests library, subprocess (built-in), GitHub token for authentication

### 2. **FastAPI Wrapper** (`api.py`)
- **Purpose**: HTTP API interface for AgentCore deployment
- **Features**:
  - **RESTful Endpoints**: Clean API for Orchestrator integration
  - **Singleton Agent**: Uses single agent instance initialized at startup
  - **Startup Validation**: Validates GITHUB_TOKEN and fails fast if missing
  - **No Per-Request Auth**: Token configured once at startup, not per-request
  - **Request Validation**: Pydantic models for type safety
  - **Error Handling**: Comprehensive exception handling and logging
- **Key Endpoints**:
  - `POST /api/v1/github/setup`: Clone repository and create remediation branch
  - `POST /api/v1/github/commit-and-create-pr`: Commit changes and create PR
  - `POST /api/v1/github/file-content`: Get file content
  - `POST /api/v1/github/update-file`: Update file content
  - `DELETE /api/v1/github/cleanup`: Clean up repository
  - `GET /api/v1/github/status`: Agent status and capabilities
  - `GET /health`: Health check
- **Data Models**:
  - `RepositoryData`: Repository information (owner, repo, source_branch, author)
  - `SecurityFix`: Auto-fix with complete fixed file content
  - `ManualIntervention`: Manual item with file content including TODOs
  - `RemediationResults`: Complete remediation output
  - `CreatePRResponse`: PR creation results
- **Startup Behavior**:
  - Validates GITHUB_TOKEN environment variable
  - Initializes singleton GitHubIntegrationAgent
  - Exits with error if token is missing or invalid (< 20 chars)

### 3. **PR Description Generator**
- **Purpose**: Creates comprehensive, developer-friendly PR descriptions
- **Features**:
  - **Scan Metadata**: Scan ID, date, total findings
  - **Severity Grouping**: CRITICAL → HIGH → MEDIUM → LOW with emojis
  - **Auto-Fixes Section**: Detailed list of applied fixes
  - **Manual Interventions**: Guidance for items requiring manual work
  - **Review Guidelines**: Clear instructions for reviewers
  - **Knowledge Base Links**: References to security documentation
- **Output Format**: Rich markdown with:
  - Summary statistics
  - Grouped findings by severity
  - File paths and resource names
  - Review checklists
  - Approval process documentation

### 4. **Approval Workflow Creator**
- **Purpose**: Creates GitHub Actions workflow for security approval gates
- **Features**:
  - **Manual Approval**: Uses `trstringer/manual-approval@v1`
  - **Security Team Gate**: Requires approval from security-team or devops-team
  - **Issue Tracking**: Creates GitHub issue for approval tracking
  - **PR Status Updates**: Comments on PR after approval
- **Workflow File**: `.github/workflows/security-approval.yml`
- **Trigger**: Workflow dispatch with PR number and scan ID
- **Conditional**: Only created and triggered for main branch PRs

## API Endpoints

| Endpoint | Method | Purpose | Called By |
|----------|--------|---------|-----------|
| `/health` | GET | Health check | Monitoring |
| `/api/v1/github/clone` | POST | Clone for scanning | Orchestrator |
| `/api/v1/github/create-pr` | POST | Create PR | Orchestrator |
| `/api/v1/github/file-content` | POST | Get file content | Orchestrator (optional) |
| `/api/v1/github/update-file` | POST | Update file | Orchestrator (optional) |
| `/api/v1/github/cleanup` | DELETE | Clean up clone | Orchestrator |
| `/api/v1/github/status` | GET | Agent status | Monitoring |

## Orchestrator Integration

### Complete Workflow Example

```python
class OrchestratorAgent:
    def __init__(self):
        self.github_agent_url = "http://github-integration-service"
        self.checkov_agent = CheckovScannerAgent()
        self.remediation_agent = TerraformRemediationAgent()
    
    def process_security_scan(self, repository_data: dict) -> dict:
        """Main orchestration workflow"""
        try:
            # 1. Clone repository for scanning
            logger.info(f"Cloning {repository_data['owner']}/{repository_data['repo']}")
            repo_path = self._clone_repository(repository_data)
            
            # 2. Scan with Checkov
            logger.info("Running Checkov security scan")
            scan_results = self.checkov_agent.scan_directory(repo_path)
            
            if not scan_results.get('findings'):
                logger.info("No security issues found")
                return {'status': 'success', 'message': 'No issues found'}
            
            # 3. Remediate issues
            logger.info("Remediating security issues")
            remediation_results = self.remediation_agent.remediate(
                repo_path, scan_results
            )
            
            # 4. Create pull request
            logger.info("Creating security remediation PR")
            pr_result = self._create_pr(repository_data, remediation_results)
            
            return {
                'status': 'completed',
                'scan_results': scan_results,
                'remediation_results': remediation_results,
                'pr_result': pr_result
            }
        
        except Exception as e:
            logger.error(f"Workflow failed: {e}")
            return {'status': 'failed', 'error': str(e)}
        
        finally:
            # Always cleanup
            self._cleanup_repository(repository_data)
    
    def _clone_repository(self, repository_data: dict) -> str:
        """Clone repository via GitHub Integration Agent"""
        response = requests.post(
            f"{self.github_agent_url}/api/v1/github/clone",
            headers={
                "Authorization": f"Bearer {os.getenv('GITHUB_TOKEN')}",
                "Content-Type": "application/json"
            },
            json={"repository_data": repository_data}
        )
        
        result = response.json()
        if not result['success']:
            raise Exception(f"Failed to clone: {result['message']}")
        
        return result['repo_path']
    
    def _create_pr(self, repository_data: dict, remediation_results: dict) -> dict:
        """Create PR via GitHub Integration Agent"""
        response = requests.post(
            f"{self.github_agent_url}/api/v1/github/create-pr",
            headers={
                "Authorization": f"Bearer {os.getenv('GITHUB_TOKEN')}",
                "Content-Type": "application/json"
            },
            json={
                "repository_data": repository_data,
                "remediation_results": remediation_results
            }
        )
        
        return response.json()
    
    def _cleanup_repository(self, repository_data: dict):
        """Cleanup via GitHub Integration Agent"""
        try:
            requests.delete(
                f"{self.github_agent_url}/api/v1/github/cleanup",
                headers={
                    "Authorization": f"Bearer {os.getenv('GITHUB_TOKEN')}",
                    "Content-Type": "application/json"
                },
                json=repository_data
            )
        except Exception as e:
            logger.warning(f"Cleanup failed (non-critical): {e}")
```

## Data Models

### Repository Data
```python
{
    "owner": str,              # Repository owner (org or user)
    "repo": str,               # Repository name
    "url": str,                # Clone URL
    "commit_sha": str,         # Commit SHA that triggered scan
    "source_branch": str,      # Branch that was pushed (e.g., "feature/user-auth")
    "author": str,             # GitHub username of commit author
    "default_branch": str,     # Default branch (usually "main")
    "scan_id": str            # Unique scan identifier
}
```

### Remediation Results
```python
{
    "scan_metadata": {
        "scan_id": str,
        "scan_date": str,
        "total_findings": int,
        "scan_duration": float
    },
    "fixes": [
        {
            "check_id": str,           # e.g., "CKV_AWS_18"
            "file": str,               # e.g., "main.tf"
            "resource": str,           # e.g., "aws_s3_bucket.example"
            "severity": str,           # "CRITICAL", "HIGH", "MEDIUM", "LOW"
            "description": str,
            "fixed_content": str,      # Complete fixed file content
            "knowledge_base_reference": str  # Optional
        }
    ],
    "manual_interventions": [
        {
            "check_id": str,
            "file": str,
            "resource": str,
            "severity": str,
            "description": str,
            "file_content_with_todos": str,  # Complete file with TODO comments
            "todo_comment": str,
            "knowledge_base_reference": str  # Optional
        }
    ]
}
```

### PR Creation Response
```python
{
    "pr_number": int,                    # GitHub PR number
    "pr_url": str,                       # Full PR URL
    "branch_name": str,                  # Remediation branch name
    "source_branch": str,                # Target branch for PR
    "workflow_triggered": bool,          # Whether approval workflow was triggered
    "labels_added": List[str],           # Labels added to PR
    "reviewers_requested": bool,         # Whether reviewers were requested
    "requires_security_approval": bool,  # Whether security approval is needed
    "status": str                        # "created"
}
```

## Key Behaviors

### Branch Naming Strategy
- **Feature branches**: `{source_branch}-iac-remediation-{commit_sha}`
  - Example: `feature/user-auth-iac-remediation-abc123`
- **Main branch**: `main-iac-remediation-{commit_sha}`

### PR Targeting Logic
- **Feature branches**: PR targets the source feature branch
  - Example: `feature/user-auth-iac-remediation-abc123` → `feature/user-auth`
- **Main branch**: PR targets main
  - Example: `main-iac-remediation-abc123` → `main`

### Reviewer Assignment
- **Feature branches**: Original commit author (from `repository_data.author`)
- **Main branch**: Security team (`team:security-team`, `team:devops-team`)

### Approval Workflows
- **Feature branches**: No approval workflow (developer approval only)
- **Main branch**: GitHub Actions approval workflow with security team gate

### Labels Applied
- Always: `security`, `terraform`, `automated-fix`
- Conditional: `manual-intervention-required` (if manual items exist)

## Dependencies

### Core Dependencies
```
fastapi>=0.104.1            # Web framework
uvicorn[standard]>=0.24.0   # ASGI server
pydantic>=2.5.0             # Data validation
requests>=2.31.0            # HTTP library for GitHub API
httpx>=0.25.2               # HTTP client
python-jose[cryptography]   # JWT handling
structlog>=23.2.0           # Structured logging
```

### No External Dependencies
- **No LLM Required**: Pure Python implementation
- **No AWS Bedrock**: No AI model costs
- **Standard Libraries**: subprocess, requests, os, json

### GitHub Requirements
- **Authentication**: GitHub Personal Access Token or GitHub App
- **Permissions**: 
  - Repository read/write access
  - Pull request creation
  - Workflow dispatch
  - Label management
  - Reviewer assignment

## Installation & Setup

### 1. Environment Setup
```bash
# Clone repository
git clone <repository-url>
cd agents/github_integration

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. GitHub Token Configuration (REQUIRED)
```bash
# REQUIRED: Set GitHub token before starting the server
export GITHUB_TOKEN=ghp_your_token_here

# The server will fail to start if GITHUB_TOKEN is not set
# Token must be at least 20 characters (validated at startup)
```

**Important**: The GitHub token is validated at server startup. If the token is missing or invalid, the server will exit with an error message.

### 3. Start the Server
```bash
# Start the API server (requires GITHUB_TOKEN to be set)
python api.py

# Server will validate token and initialize singleton agent
# If token is missing: Server exits with error
# If token is valid: Server starts on http://0.0.0.0:8002
```

## Usage Examples

### Python API (Direct Agent Usage)
```python
from agents.github_integration import GitHubIntegrationAgent

# Initialize agent
github_agent = GitHubIntegrationAgent(github_token="ghp_your_token")

# Clone repository for scanning
repository_data = {
    "owner": "my-org",
    "repo": "my-repo",
    "url": "https://github.com/my-org/my-repo.git",
    "commit_sha": "abc123",
    "source_branch": "feature/user-auth",
    "author": "developer-username",
    "default_branch": "main",
    "scan_id": "scan-123"
}

repo_path = github_agent.clone_repository_for_scanning(repository_data)
print(f"Repository cloned to: {repo_path}")

# Create security PR (after remediation)
remediation_results = {
    "scan_metadata": {...},
    "fixes": [...],
    "manual_interventions": [...]
}

pr_result = github_agent.create_security_pr(repository_data, remediation_results)
print(f"PR created: {pr_result['pr_url']}")

# Cleanup
github_agent.cleanup_repository(repository_data)
```

### HTTP API (Orchestrator Usage)
```bash
# Start the server (requires GITHUB_TOKEN environment variable)
export GITHUB_TOKEN=ghp_your_token_here
python api.py

# Setup repository (clone and create branch)
curl -X POST "http://localhost:8002/api/v1/github/setup" \
  -H "Content-Type: application/json" \
  -d '{
    "repository_data": {
      "owner": "my-org",
      "repo": "my-repo",
      "url": "https://github.com/my-org/my-repo.git",
      "commit_sha": "abc123",
      "source_branch": "feature/user-auth",
      "author": "developer-username",
      "default_branch": "main",
      "workflow_id": "workflow-123"
    }
  }'

# Commit and create PR
curl -X POST "http://localhost:8002/api/v1/github/commit-and-create-pr" \
  -H "Content-Type: application/json" \
  -d '{
    "repo_path": "/tmp/github_repos/my-repo",
    "repository_data": {...},
    "remediation_results": {...}
  }'

# Cleanup
curl -X DELETE "http://localhost:8002/api/v1/github/cleanup" \
  -H "Content-Type: application/json" \
  -d '{
    "owner": "my-org",
    "repo": "my-repo"
  }'
```

**Note**: No Authorization header needed - token is configured at server startup.

## Response Format

### Clone Response
```json
{
  "success": true,
  "repo_path": "/tmp/github_repos/my-repo",
  "terraform_files": [
    "/tmp/github_repos/my-repo/main.tf",
    "/tmp/github_repos/my-repo/variables.tf"
  ],
  "message": "Successfully cloned repository to /tmp/github_repos/my-repo and found 2 Terraform files"
}
```

### PR Creation Response
```json
{
  "pr_number": 42,
  "pr_url": "https://github.com/my-org/my-repo/pull/42",
  "branch_name": "feature/user-auth-iac-remediation-abc123",
  "source_branch": "feature/user-auth",
  "workflow_triggered": false,
  "labels_added": ["security", "terraform", "automated-fix", "manual-intervention-required"],
  "reviewers_requested": true,
  "requires_security_approval": false,
  "status": "created"
}
```

## GitHub Actions Integration

### Trigger Workflow (in target repositories)
```yaml
# .github/workflows/terraform-security-scan.yml
name: Terraform Security Scan

on:
  push:
    branches:
      - '**'  # Trigger on ALL branches
    paths:
      - '**.tf'  # Only when Terraform files change

jobs:
  security-scan:
    runs-on: ubuntu-latest
    steps:
      - name: Trigger Terraform Security Platform
        run: |
          curl -X POST https://terraform-security-platform.com/api/v1/orchestrator/scan \
            -H "Authorization: Bearer ${{ secrets.TSP_TOKEN }}" \
            -H "Content-Type: application/json" \
            -d '{
              "repository_data": {
                "owner": "${{ github.repository_owner }}",
                "repo": "${{ github.event.repository.name }}",
                "url": "${{ github.event.repository.clone_url }}",
                "commit_sha": "${{ github.sha }}",
                "source_branch": "${{ github.ref_name }}",
                "author": "${{ github.actor }}",
                "default_branch": "${{ github.event.repository.default_branch }}",
                "scan_id": "scan-${{ github.run_id }}"
              }
            }'
```

### Approval Workflow (created by agent)
The agent automatically creates `.github/workflows/security-approval.yml` in the repository for main branch PRs. This workflow:
- Requires manual approval from security team
- Creates a GitHub issue for tracking
- Updates PR status after approval
- Prevents merge until approved

## Testing

### Quick Test
```bash
# Start the API server (token required)
export GITHUB_TOKEN=ghp_your_token_here
python api.py

# Test health endpoint
curl http://localhost:8002/health

# Test setup endpoint (clone and create branch)
curl -X POST "http://localhost:8002/api/v1/github/setup" \
  -H "Content-Type: application/json" \
  -d '{
    "repository_data": {
      "owner": "test-org",
      "repo": "test-repo",
      "url": "https://github.com/test-org/test-repo.git",
      "source_branch": "main",
      "commit_sha": "abc123",
      "workflow_id": "test-123"
    }
  }'

# Test without token (should fail)
unset GITHUB_TOKEN
python api.py
# Expected: Server exits with error about missing GITHUB_TOKEN
```

### Integration Test
```python
# Test complete workflow
from agents.github_integration import GitHubIntegrationAgent

agent = GitHubIntegrationAgent()

# Test data
repository_data = {
    "owner": "test-org",
    "repo": "test-repo",
    "url": "https://github.com/test-org/test-repo.git",
    "commit_sha": "abc123",
    "source_branch": "feature/test",
    "author": "test-user",
    "default_branch": "main",
    "scan_id": "test-scan-123"
}

remediation_results = {
    "scan_metadata": {
        "scan_id": "test-scan-123",
        "scan_date": "2024-01-15T10:00:00Z",
        "total_findings": 5
    },
    "fixes": [
        {
            "check_id": "CKV_AWS_18",
            "file": "main.tf",
            "resource": "aws_s3_bucket.test",
            "severity": "HIGH",
            "description": "Test fix",
            "fixed_content": "# Fixed content here"
        }
    ],
    "manual_interventions": []
}

# Test clone
repo_path = agent.clone_repository_for_scanning(repository_data)
print(f"✅ Cloned to: {repo_path}")

# Test PR creation
pr_result = agent.create_security_pr(repository_data, remediation_results)
print(f"✅ PR created: {pr_result['pr_url']}")

# Test cleanup
agent.cleanup_repository(repository_data)
print("✅ Cleanup complete")
```

## Error Handling

Common error scenarios and responses:

### Clone Failures
```json
{
  "error": "Failed to clone repository: Authentication failed",
  "timestamp": "2025-01-15T12:00:00Z"
}
```

### GitHub API Errors
```json
{
  "error": "Failed to create PR: Insufficient permissions",
  "timestamp": "2025-01-15T12:00:00Z"
}
```

### Missing Required Fields
```json
{
  "error": "Missing required field: source_branch",
  "timestamp": "2025-01-15T12:00:00Z"
}
```

## Deployment

### Docker Deployment
```bash
# Build container
docker build -t github-integration-agent .

# Run container
docker run -p 8000:8000 \
  -e GITHUB_TOKEN=ghp_your_token \
  github-integration-agent
```

### Kubernetes Deployment
```bash
# Apply deployment configuration
kubectl apply -f agentcore-deployment.yaml

# Verify deployment
kubectl get pods -n terraform-security-platform
kubectl logs -f deployment/github-integration-agent
```

### AWS Bedrock AgentCore
The agent is designed for deployment on AWS Bedrock AgentCore with:
- Horizontal Pod Autoscaling (2-10 replicas)
- Health checks and readiness probes
- Secret management via AWS Secrets Manager
- Service mesh integration

## Production Considerations

### Security
- **Token Management**: Use AWS Secrets Manager for GitHub tokens
- **Webhook Validation**: Implement signature validation for webhooks (handled by Orchestrator)
- **Rate Limiting**: Implement rate limiting for API endpoints
- **Audit Logging**: Log all git operations and PR creations

### Performance
- **Shallow Clones**: Use `--depth 1` for faster cloning
- **Parallel Operations**: Clone for scanning and PR creation happen separately
- **Cleanup**: Always cleanup to avoid disk space issues
- **Caching**: Consider caching repository metadata

### Monitoring
- **Health Checks**: `/health` endpoint for liveness probes
- **Metrics**: Track clone times, PR creation success rates
- **Logging**: Structured logging with correlation IDs
- **Alerts**: Set up alerts for failures and performance degradation

### Scaling
- **Horizontal Scaling**: Use HPA based on CPU/memory
- **Load Balancing**: Distribute requests across replicas
- **Resource Limits**: Set appropriate CPU/memory limits
- **Storage**: Use ephemeral storage for temporary clones

## Singleton Pattern & Token Management

### How It Works

1. **Server Startup**:
   - Reads `GITHUB_TOKEN` from environment variable
   - Validates token exists and has minimum length (20 chars)
   - Creates singleton `GitHubIntegrationAgent` instance
   - If validation fails: Server exits with error message

2. **Request Handling**:
   - All endpoints use the same singleton agent instance
   - No per-request token extraction or validation
   - Token is used for all git operations and GitHub API calls

3. **Benefits**:
   - **Simpler**: No need to pass token in every request
   - **Secure**: Token never exposed in request/response
   - **Efficient**: Single agent instance, no repeated initialization
   - **Fail-Fast**: Invalid configuration detected at startup, not during requests

### Token Validation

The server performs these checks at startup:

```python
# Check 1: Token exists
if not github_token:
    raise ValueError("GITHUB_TOKEN environment variable is required")

# Check 2: Token has minimum length
if len(github_token) < 20:
    raise ValueError("GITHUB_TOKEN appears to be invalid (too short)")

# Check 3: Initialize agent
github_agent = GitHubIntegrationAgent(github_token=github_token)
```

If any check fails, the server exits immediately with a clear error message.

## Troubleshooting

### Common Issues

1. **Server Won't Start - Missing Token**
   ```
   ERROR: GITHUB_TOKEN environment variable is required
   ```
   **Solution**: Set the environment variable before starting:
   ```bash
   export GITHUB_TOKEN=ghp_your_token_here
   python api.py
   ```

2. **Server Won't Start - Invalid Token**
   ```
   ERROR: GITHUB_TOKEN appears to be invalid (length: 10)
   ```
   **Solution**: Verify your token is a valid GitHub personal access token (should be 40+ characters)

3. **Clone Failures**: Check GitHub token permissions and network connectivity

4. **PR Creation Errors**: Verify token has PR creation permissions

5. **Branch Conflicts**: Ensure source branch exists and is up to date

6. **Workflow Trigger Failures**: Check GitHub Actions permissions

7. **Disk Space**: Monitor `/tmp` usage and cleanup old clones

### Debug Mode
Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
export GITHUB_TOKEN=ghp_your_token_here
python api.py
```

### Verify Token Permissions
Test GitHub API access with your token:
```bash
# Test authentication
curl -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user

# Test repository access
curl -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/owner/repo
```

### Check Agent Initialization
```bash
# Start server and check logs
export GITHUB_TOKEN=ghp_your_token_here
python api.py

# Expected output:
# INFO:api:Initializing GitHub Integration Agent with token from environment (length: 93)
# INFO:main:GitHub agent initialized with token: gith...e9rs (length: 93)
# INFO:api:GitHub Integration Agent initialized successfully
```

## Changes from Original Implementation

### Major Changes
1. **Removed Webhook Processing**: Orchestrator now handles GitHub webhooks
2. **Added Clone Method**: New public method for Orchestrator to clone repositories
3. **Feature Branch Support**: PRs now target source branch, not always main
4. **Smart Reviewer Assignment**: Developer for features, security team for main
5. **Conditional Approval Workflows**: Only for main branch PRs
6. **Updated Branch Naming**: Includes source branch name for clarity

### Removed Components
- `validate_webhook_signature()` - Moved to Orchestrator
- `process_webhook_event()` - Moved to Orchestrator
- `_handle_push_event()` - Moved to Orchestrator
- `_handle_pull_request_event()` - Moved to Orchestrator
- `github_app_secret` parameter - No longer needed

### New Components
- `clone_repository_for_scanning()` - Public method for Orchestrator
- `get_repository_path()` - Helper for Orchestrator
- Enhanced `create_security_pr()` - Supports feature branch workflow
- Updated data models - Added `source_branch` and `author` fields

## Contributing

1. Follow the existing code structure and patterns
2. Add tests for new functionality
3. Update documentation for API changes
4. Ensure compatibility with Strands SDK and AgentCore deployment

## License

[Add appropriate license information]


## API Input/Output Reference

### POST /api/v1/github/setup (Step 1: Clone & Branch)

**Input:**
```json
{
  "repository_data": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "url": "https://github.com/aruunkumar/iac-remediation-test-data.git",
    "source_branch": "main",
    "commit_sha": "HEAD",
    "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06",
    "github_token": "ghp_xxxxx"
  }
}
```

**Output:**
```json
{
  "success": true,
  "repo_path": "/tmp/github_repos/iac-remediation-test-data",
  "branch_name": "iac-remediation/main-13db5f4a",
  "message": "Successfully setup repository at /tmp/github_repos/iac-remediation-test-data with remediation branch iac-remediation/main-13db5f4a"
}
```

### POST /api/v1/github/commit-and-create-pr (Step 2: Commit & PR)

**Input:**
```json
{
  "repo_path": "/tmp/github_repos/iac-remediation-test-data",
  "repository_data": {
    "owner": "aruunkumar",
    "repo": "iac-remediation-test-data",
    "source_branch": "main",
    "default_branch": "main",
    "workflow_id": "13db5f4a-0c5a-4bc8-839c-ce43f0f9ed06",
    "github_token": "ghp_xxxxx"
  },
  "remediation_results": {
    "scan_metadata": {
      "scan_id": "43fcb38b-47a1-4161-8f77-a16bb8379f4c",
      "scan_date": "2025-11-21T08:48:17Z",
      "total_findings": 19
    },
    "fixes": [
      {
        "check_id": "CKV_AWS_23",
        "file": "/main.tf",
        "resource": "aws_security_group.fleet_sg",
        "severity": "LOW",
        "description": "Added description to egress rule"
      }
    ],
    "manual_interventions": [
      {
        "check_id": "CKV_AWS_382",
        "file": "/main.tf",
        "resource": "aws_security_group.fleet_sg",
        "severity": "HIGH",
        "description": "Restrict egress traffic",
        "todo_comment": "Requires manual review"
      }
    ]
  }
}
```

**Output:**
```json
{
  "pr_number": 42,
  "pr_url": "https://github.com/aruunkumar/iac-remediation-test-data/pull/42",
  "branch_name": "iac-remediation/main-13db5f4a",
  "labels_added": ["security", "terraform", "automated-fix"],
  "reviewers_requested": true,
  "requires_security_approval": true
}
```

**Key Points:**
- **Step 1** (setup): Called BEFORE scanning - clones repo and creates branch
- **Step 2** (commit-and-create-pr): Called AFTER remediation - commits changes and creates PR
- Branch naming: `iac-remediation/{source_branch}-{workflow_id_or_commit_sha}`
- All work done on same cloned directory - no copying between steps
- PR includes detailed description with all fixes and manual items
