#!/bin/bash

# Generate all architecture diagrams for Terraform Security Platform

echo "=========================================="
echo "Generating Architecture Diagrams"
echo "=========================================="
echo ""

# Check if diagrams library is installed
if ! python -c "import diagrams" 2>/dev/null; then
    echo "Error: diagrams library not installed"
    echo "Please run: pip install -r requirements_diagram.txt"
    exit 1
fi

# Check if graphviz is installed
if ! command -v dot &> /dev/null; then
    echo "Error: Graphviz not installed"
    echo "Please install Graphviz:"
    echo "  macOS: brew install graphviz"
    echo "  Ubuntu: sudo apt-get install graphviz"
    exit 1
fi

echo "✓ Dependencies verified"
echo ""

# Generate main architecture diagram
echo "1. Generating main architecture diagram..."
python generate_architecture_diagram.py
if [ $? -eq 0 ]; then
    echo "   ✓ terraform_security_platform_architecture.png created"
else
    echo "   ✗ Failed to generate architecture diagram"
fi
echo ""

# Generate workflow sequence diagram
echo "2. Generating workflow sequence diagram..."
python generate_workflow_diagram.py
if [ $? -eq 0 ]; then
    echo "   ✓ terraform_security_workflow_sequence.png created"
else
    echo "   ✗ Failed to generate workflow diagram"
fi
echo ""

# Generate data flow diagram
echo "3. Generating data flow diagram..."
python generate_data_flow_diagram.py
if [ $? -eq 0 ]; then
    echo "   ✓ terraform_security_data_flow.png created"
else
    echo "   ✗ Failed to generate data flow diagram"
fi
echo ""

echo "=========================================="
echo "Diagram Generation Complete!"
echo "=========================================="
echo ""
echo "Generated files:"
echo "  • terraform_security_platform_architecture.png"
echo "  • terraform_security_workflow_sequence.png"
echo "  • terraform_security_data_flow.png"
echo ""
echo "View the diagrams to understand:"
echo "  1. Overall AWS architecture and components"
echo "  2. Step-by-step workflow execution"
echo "  3. Data flow and S3 storage structure"
