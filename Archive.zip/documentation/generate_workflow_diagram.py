"""
Generate Detailed Workflow Sequence Diagram
Shows the step-by-step execution flow with iterations
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.ml import Bedrock
from diagrams.onprem.vcs import Github
from diagrams.programming.language import Python

# Graph attributes for workflow sequence
graph_attr = {
    "fontsize": "14",
    "bgcolor": "white",
    "pad": "0.5",
    "rankdir": "TB",
    "splines": "ortho",
    "nodesep": "0.6",
    "ranksep": "1.2"
}

with Diagram(
    "Terraform Security Platform - Workflow Sequence",
    filename="terraform_security_workflow_sequence",
    show=False,
    direction="TB",
    graph_attr=graph_attr
):
    
    # Start
    github_webhook = Github("GitHub Push Event")
    
    with Cluster("Step 1: Repository Setup"):
        orchestrator_1 = Bedrock("Orchestrator\n(Generate workflow_id)")
        github_agent_1 = Bedrock("GitHub Agent")
        s3_upload_1 = S3("S3: Upload\nOriginal Repo")
        
        github_webhook >> orchestrator_1
        orchestrator_1 >> Edge(label="invoke setup") >> github_agent_1
        github_agent_1 >> Edge(label="1. Clone repo\n2. Create branch\n3. Upload tarball") >> s3_upload_1
    
    with Cluster("Iterative Loop (Max 5 iterations)"):
        with Cluster("Step 2: Security Scan"):
            orchestrator_2 = Bedrock("Orchestrator")
            checkov_agent = Bedrock("Checkov Scanner")
            s3_scan = S3("S3: Scan Results")
            
            s3_upload_1 >> Edge(label="iteration N") >> orchestrator_2
            orchestrator_2 >> Edge(label="invoke scan") >> checkov_agent
            checkov_agent >> Edge(label="1. Download repo\n2. Run Checkov\n3. Upload findings") >> s3_scan
        
        with Cluster("Step 3: Remediation"):
            orchestrator_3 = Bedrock("Orchestrator")
            remediation_agent = Bedrock("Terraform\nRemediation")
            
            # Knowledge sources
            mcp = Python("MCP Server\n(AWS Docs)")
            kb = Bedrock("Knowledge Base\n(Best Practices)")
            claude = Bedrock("Claude 4.5")
            
            s3_fixed = S3("S3: Fixed Code")
            
            s3_scan >> Edge(label="findings") >> orchestrator_3
            orchestrator_3 >> Edge(label="invoke remediate") >> remediation_agent
            
            remediation_agent >> Edge(label="query", color="brown") >> mcp
            remediation_agent >> Edge(label="query", color="brown") >> kb
            remediation_agent >> Edge(label="inference", color="brown") >> claude
            
            remediation_agent >> Edge(label="1. Download repo\n2. Apply fixes\n3. Add TODOs\n4. Upload") >> s3_fixed
        
        # Convergence check
        convergence = Bedrock("Convergence\nCheck")
        s3_fixed >> Edge(label="rescan") >> convergence
        
        # Loop back or continue
        convergence >> Edge(label="more fixes\npossible", color="orange", style="dashed") >> orchestrator_2
        convergence >> Edge(label="converged OR\nmax iterations", color="green") >> orchestrator_3
    
    with Cluster("Step 4: Pull Request Creation"):
        orchestrator_4 = Bedrock("Orchestrator")
        github_agent_2 = Bedrock("GitHub Agent")
        github_pr = Github("GitHub API\n(Create PR)")
        
        s3_fixed >> Edge(label="final code") >> orchestrator_4
        orchestrator_4 >> Edge(label="invoke create_pr") >> github_agent_2
        github_agent_2 >> Edge(label="1. Download fixed code\n2. Commit changes\n3. Push branch\n4. Create PR\n5. Add labels\n6. Request review") >> github_pr
    
    # Final output
    pr_created = Github("Pull Request\nCreated")
    github_pr >> Edge(label="PR #123", color="purple") >> pr_created

print("Workflow sequence diagram generated successfully!")
print("Output file: terraform_security_workflow_sequence.png")
