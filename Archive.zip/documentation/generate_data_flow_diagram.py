"""
Generate Data Flow Diagram
Focus on S3 storage structure and agent data exchange
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.storage import S3, SimpleStorageServiceS3Bucket
from diagrams.aws.ml import Bedrock
from diagrams.aws.management import Cloudwatch

graph_attr = {
    "fontsize": "14",
    "bgcolor": "white",
    "pad": "0.5",
    "splines": "ortho",
    "nodesep": "0.8",
    "ranksep": "1.0"
}

with Diagram(
    "Terraform Security Platform - Data Flow & Storage",
    filename="terraform_security_data_flow",
    show=False,
    direction="LR",
    graph_attr=graph_attr
):
    
    # Agents
    with Cluster("AWS Bedrock AgentCore Agents"):
        orchestrator = Bedrock("Orchestrator")
        github_agent = Bedrock("GitHub\nAgent")
        checkov_agent = Bedrock("Checkov\nAgent")
        remediation_agent = Bedrock("Terraform\nRemediation")
    
    # S3 Storage Structure
    with Cluster("S3 Bucket: terraform-security-platform-storage"):
        with Cluster("workflows/{workflow_id}/"):
            
            with Cluster("github-agent/"):
                s3_github_data = S3("data.tar.gz\n(Original Repo)")
                s3_github_meta = S3("metadata.json\n(Branch, Owner)")
            
            with Cluster("checkov-agent/"):
                s3_scan_results = S3("scan_results.json\n(Security Findings)")
            
            with Cluster("terraform-remediation-agent/"):
                s3_fixed_data = S3("data.tar.gz\n(Fixed Repo)")
                s3_remediation = S3("remediation_results.json\n(Fixes & TODOs)")
                s3_report = S3("REMEDIATION_REPORT\n_iteration_N.md")
        
        # Lifecycle policy
        lifecycle = SimpleStorageServiceS3Bucket("Lifecycle Policy\n(7-day retention)")
    
    # Data flow: GitHub Agent
    github_agent >> Edge(label="upload\noriginal repo", color="blue") >> s3_github_data
    github_agent >> Edge(label="upload\nmetadata", color="blue") >> s3_github_meta
    
    # Data flow: Checkov Agent
    s3_github_data >> Edge(label="download\nfor scanning", color="green") >> checkov_agent
    checkov_agent >> Edge(label="upload\nfindings", color="green") >> s3_scan_results
    
    # Data flow: Remediation Agent (Iteration 1)
    s3_github_data >> Edge(label="download\n(iteration 1)", color="orange") >> remediation_agent
    
    # Data flow: Remediation Agent (Iteration 2+)
    s3_fixed_data >> Edge(label="download\n(iteration 2+)", color="orange", style="dashed") >> remediation_agent
    
    remediation_agent >> Edge(label="upload\nfixed code", color="orange") >> s3_fixed_data
    remediation_agent >> Edge(label="upload\nresults", color="orange") >> s3_remediation
    remediation_agent >> Edge(label="upload\nreport", color="orange") >> s3_report
    
    # Data flow: GitHub Agent (PR Creation)
    s3_fixed_data >> Edge(label="download\nfor commit", color="purple") >> github_agent
    s3_remediation >> Edge(label="download\nfor PR body", color="purple") >> github_agent
    
    # Orchestrator monitors all
    orchestrator >> Edge(label="coordinates", style="dotted", color="gray") >> github_agent
    orchestrator >> Edge(label="coordinates", style="dotted", color="gray") >> checkov_agent
    orchestrator >> Edge(label="coordinates", style="dotted", color="gray") >> remediation_agent
    
    # Lifecycle cleanup
    s3_github_data - Edge(style="dotted") - lifecycle
    s3_scan_results - Edge(style="dotted") - lifecycle
    s3_fixed_data - Edge(style="dotted") - lifecycle
    
    # Monitoring
    cloudwatch = Cloudwatch("CloudWatch\n(Audit Trail)")
    s3_github_data >> Edge(label="access logs", style="dotted", color="gray") >> cloudwatch

print("Data flow diagram generated successfully!")
print("Output file: terraform_security_data_flow.png")
