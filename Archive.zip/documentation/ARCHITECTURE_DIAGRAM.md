# Terraform Security Platform - Architecture Diagram

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         TERRAFORM SECURITY PLATFORM                          │
│                    Multi-Agent AI Security Remediation System                │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              TRIGGER LAYER                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐             │
│  │   GitHub     │      │   GitLab     │      │   Manual     │             │
│  │   Webhook    │      │   Webhook    │      │   API Call   │             │
│  └──────┬───────┘      └──────┬───────┘      └──────┬───────┘             │
│         │                     │                     │                       │
│         └─────────────────────┴─────────────────────┘                       │
│                               │                                             │
│                               ▼                                             │
│                    ┌──────────────────────┐                                │
│                    │  API Gateway / ALB   │                                │
│                    │  (Authentication)    │                                │
│                    └──────────┬───────────┘                                │
└───────────────────────────────┼─────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ORCHESTRATION LAYER                                  │
│                      (AWS Bedrock AgentCore)                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│                    ┌────────────────────────────┐                           │
│                    │   ORCHESTRATOR AGENT       │                           │
│                    │   (Workflow Coordinator)   │                           │
│                    │                            │                           │
│                    │  • Workflow Management     │                           │
│                    │  • Iteration Control       │                           │
│                    │  • Convergence Detection   │                           │
│                    │  • A2A Communication       │                           │
│                    │  • Retry & Circuit Breaker │                           │
│                    └────────────┬───────────────┘                           │
│                                 │                                            │
│                    ┌────────────┴───────────────┐                           │
│                    │    Generates workflow_id   │                           │
│                    │    Coordinates 4 agents    │                           │
│                    │    Max 5 iterations        │                           │
│                    └────────────┬───────────────┘                           │
└─────────────────────────────────┼───────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AGENT EXECUTION LAYER                              │
│                      (AWS Bedrock AgentCore Runtimes)                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│  │  STEP 1: SETUP  │  │  STEP 2: SCAN   │  │ STEP 3: REMEDIATE│           │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤            │
│  │                 │  │                 │  │                 │            │
│  │  GitHub Agent   │  │ Checkov Scanner │  │  Terraform      │            │
│  │                 │  │     Agent       │  │  Remediation    │            │
│  │  • Clone repo   │  │                 │  │     Agent       │            │
│  │  • Create branch│  │  • Download S3  │  │                 │            │
│  │  • Upload to S3 │  │  • Run Checkov  │  │  • Download S3  │            │
│  │                 │  │  • Scan .tf     │  │  • Strands SDK  │            │
│  │  Tools:         │  │  • Upload S3    │  │  • MCP Server   │            │
│  │  - Git CLI      │  │                 │  │  • Bedrock KB   │            │
│  │  - S3 Storage   │  │  Tools:         │  │  • Auto-fix     │            │
│  │  - GitHub API   │  │  - Checkov      │  │  • TODO comments│            │
│  │                 │  │  - S3 Storage   │  │  - Upload S3    │            │
│  │                 │  │  - MCP Tools    │  │                 │            │
│  │                 │  │                 │  │  Tools:         │            │
│  │                 │  │                 │  │  - file_read    │            │
│  │                 │  │                 │  │  - file_write   │            │
│  │                 │  │                 │  │  - MCP Terraform│            │
│  │                 │  │                 │  │  - Bedrock KB   │            │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘            │
│           │                    │                    │                       │
│           │                    │                    │                       │
│  ┌────────▼────────────────────▼────────────────────▼────────┐             │
│  │                                                            │             │
│  │              ITERATIVE LOOP (Max 5 iterations)            │             │
│  │                                                            │             │
│  │  Iteration 1: Scan → Remediate → Rescan                  │             │
│  │  Iteration 2: Scan → Remediate → Rescan                  │             │
│  │  ...                                                       │             │
│  │  Until: No more auto-fixes OR max iterations reached      │             │
│  │                                                            │             │
│  └────────────────────────────┬───────────────────────────────┘             │
│                               │                                             │
│                               ▼                                             │
│  ┌─────────────────────────────────────────────────────────┐               │
│  │              STEP 4: CREATE PR                          │               │
│  ├─────────────────────────────────────────────────────────┤               │
│  │                                                         │               │
│  │              GitHub Integration Agent                   │               │
│  │                                                         │               │
│  │  • Download fixed code from S3                         │               │
│  │  • Download remediation results                        │               │
│  │  • Commit changes                                      │               │
│  │  • Push branch                                         │               │
│  │  • Create PR with detailed report                     │               │
│  │  • Add labels & request reviews                       │               │
│  │  • Trigger approval workflow (main branch only)       │               │
│  │                                                         │               │
│  │  Tools:                                                │               │
│  │  - Git CLI                                             │               │
│  │  - S3 Storage                                          │               │
│  │  - GitHub API                                          │               │
│  │                                                         │               │
│  └─────────────────────────────────────────────────────────┘               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                          STORAGE & DATA LAYER                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                         Amazon S3 Bucket                              │  │
│  │              terraform-security-platform-storage                      │  │
│  │                                                                        │  │
│  │  workflows/{workflow_id}/                                            │  │
│  │  ├── github-agent/                                                   │  │
│  │  │   ├── data.tar.gz          (Original repository)                 │  │
│  │  │   └── metadata.json        (Repo metadata)                       │  │
│  │  │                                                                    │  │
│  │  ├── checkov-agent/                                                  │  │
│  │  │   └── scan_results.json    (Security findings)                   │  │
│  │  │                                                                    │  │
│  │  └── terraform-remediation-agent/                                    │  │
│  │      ├── data.tar.gz          (Fixed repository)                    │  │
│  │      ├── remediation_results.json                                   │  │
│  │      └── REMEDIATION_REPORT_iteration_N.md                          │  │
│  │                                                                        │  │
│  │  Features:                                                            │  │
│  │  • Versioning enabled                                                │  │
│  │  • Server-side encryption (AES256)                                   │  │
│  │  • 7-day lifecycle policy (auto-cleanup)                            │  │
│  │  • Public access blocked                                             │  │
│  │                                                                        │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      KNOWLEDGE & INTELLIGENCE LAYER                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────┐    ┌────────────────────────────┐          │
│  │  MCP Terraform Server      │    │  Bedrock Knowledge Base    │          │
│  │  (Model Context Protocol)  │    │                            │          │
│  │                            │    │  • Terraform Best Practices│          │
│  │  • AWS Provider Docs       │    │  • Security Patterns       │          │
│  │  • Resource Syntax         │    │  • Compliance Guidelines   │          │
│  │  • Module Patterns         │    │  • OpenSearch Serverless   │          │
│  │  • Real-time Updates       │    │  • Vector Embeddings       │          │
│  │                            │    │  • Semantic Search         │          │
│  │  Tools:                    │    │                            │          │
│  │  - SearchAwsProviderDocs   │    │  KB ID: LZ2DEM1204        │          │
│  │  - GetResourceSchema       │    │                            │          │
│  │  - ListProviderResources   │    │                            │          │
│  │                            │    │                            │          │
│  └────────────┬───────────────┘    └────────────┬───────────────┘          │
│               │                                 │                           │
│               └─────────────┬───────────────────┘                           │
│                             │                                               │
│                             ▼                                               │
│                  ┌──────────────────────┐                                  │
│                  │  Claude Sonnet 4.5   │                                  │
│                  │  (Bedrock Model)     │                                  │
│                  │                      │                                  │
│                  │  • Intelligent       │                                  │
│                  │    Reasoning         │                                  │
│                  │  • Risk Assessment   │                                  │
│                  │  • Code Generation   │                                  │
│                  │                      │                                  │
│                  └──────────────────────┘                                  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
