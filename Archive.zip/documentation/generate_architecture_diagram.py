"""
Generate AWS Architecture Diagram for Terraform Security Platform
Uses the diagrams library to create professional architecture diagrams with AWS icons
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.compute import Lambda, ECS
from diagrams.aws.storage import S3
from diagrams.aws.network import APIGateway, ELB
from diagrams.aws.ml import Bedrock, SagemakerModel
from diagrams.aws.integration import Eventbridge, StepFunctions
from diagrams.aws.management import Cloudwatch
from diagrams.aws.security import SecretsManager, IAM
from diagrams.aws.analytics import AmazonOpensearchService
from diagrams.custom import Custom
from diagrams.programming.language import Python
from diagrams.onprem.vcs import Github, Gitlab
from diagrams.onprem.client import User

# Graph attributes for better layout
graph_attr = {
    "fontsize": "16",
    "bgcolor": "white",
    "pad": "0.5",
    "splines": "ortho",
    "nodesep": "0.8",
    "ranksep": "1.0"
}

node_attr = {
    "fontsize": "12",
    "height": "1.2",
    "width": "1.2"
}

edge_attr = {
    "fontsize": "10"
}

with Diagram(
    "Terraform Security Platform - AWS Architecture",
    filename="terraform_security_platform_architecture",
    show=False,
    direction="TB",
    graph_attr=graph_attr,
    node_attr=node_attr,
    edge_attr=edge_attr
):
    
    # External triggers
    with Cluster("External Triggers"):
        github = Github("GitHub\nWebhook")
        gitlab = Gitlab("GitLab\nWebhook")
        user = User("Manual\nAPI Call")
    
    # API Gateway
    api_gateway = APIGateway("API Gateway\n(Authentication)")
    
    # Connect triggers to API Gateway
    github >> Edge(label="push event") >> api_gateway
    gitlab >> Edge(label="push event") >> api_gateway
    user >> Edge(label="POST /orchestrate") >> api_gateway
    
    # Orchestrator
    with Cluster("AWS Bedrock AgentCore"):
        orchestrator = Bedrock("Orchestrator Agent\n(Workflow Coordinator)")
        
        api_gateway >> Edge(label="invoke") >> orchestrator
        
        # Agent execution layer
        with Cluster("Specialized Agents"):
            github_agent = Bedrock("GitHub Integration\nAgent")
            checkov_agent = Bedrock("Checkov Scanner\nAgent")
            remediation_agent = Bedrock("Terraform Remediation\nAgent")
            
            # Orchestrator coordinates all agents
            orchestrator >> Edge(label="1. setup", color="blue") >> github_agent
            orchestrator >> Edge(label="2. scan", color="green") >> checkov_agent
            orchestrator >> Edge(label="3. remediate", color="orange") >> remediation_agent
            orchestrator >> Edge(label="4. create PR", color="purple") >> github_agent
    
    # S3 Storage (central data hub)
    with Cluster("Shared Storage Layer"):
        s3_bucket = S3("S3 Bucket\nworkflows/{workflow_id}/\n• github-agent/\n• checkov-agent/\n• terraform-remediation-agent/")
        
        # All agents interact with S3
        github_agent >> Edge(label="upload/download\nrepo data", style="dashed") >> s3_bucket
        checkov_agent >> Edge(label="download repo\nupload scan results", style="dashed") >> s3_bucket
        remediation_agent >> Edge(label="download repo\nupload fixes", style="dashed") >> s3_bucket
    
    # Knowledge & Intelligence Layer
    with Cluster("Knowledge & Intelligence"):
        with Cluster("Model Context Protocol"):
            mcp_server = Python("MCP Terraform\nServer\n(AWS Provider Docs)")
        
        with Cluster("Bedrock Knowledge Base"):
            kb = Bedrock("Knowledge Base\n(Best Practices)")
            opensearch = AmazonOpensearchService("OpenSearch\nServerless\n(Vector Store)")
            kb - opensearch
        
        claude = SagemakerModel("Claude Sonnet 4.5\n(Foundation Model)")
        
        # Remediation agent uses knowledge sources
        remediation_agent >> Edge(label="query docs", color="brown") >> mcp_server
        remediation_agent >> Edge(label="query KB", color="brown") >> kb
        remediation_agent >> Edge(label="inference", color="brown") >> claude
    
    # GitHub API
    github_api = Github("GitHub API\n(PR Creation)")
    github_agent >> Edge(label="create PR\nadd labels\nrequest review", color="purple") >> github_api
    
    # Security & Secrets
    with Cluster("Security & Configuration"):
        secrets = SecretsManager("Secrets Manager\n(GitHub Token)")
        iam = IAM("IAM Roles\n(Agent Permissions)")
        
        github_agent >> Edge(label="fetch token", style="dotted") >> secrets
        orchestrator - Edge(style="dotted") - iam
    
    # Monitoring
    with Cluster("Observability"):
        cloudwatch = Cloudwatch("CloudWatch\n(Logs & Metrics)")
        
        orchestrator >> Edge(label="logs", style="dotted", color="gray") >> cloudwatch
        github_agent >> Edge(label="logs", style="dotted", color="gray") >> cloudwatch
        checkov_agent >> Edge(label="logs", style="dotted", color="gray") >> cloudwatch
        remediation_agent >> Edge(label="logs", style="dotted", color="gray") >> cloudwatch

print("Architecture diagram generated successfully!")
print("Output file: terraform_security_platform_architecture.png")
